<?php
namespace ElementHelper;

defined( 'ABSPATH' ) || die();

class Element_El_Icons {

    public static function init() {
        add_filter( 'elementor/icons_manager/additional_tabs', [__CLASS__, 'add_elh_el_icons_tab'] );
        add_filter( 'elementor/icons_manager/additional_tabs', [__CLASS__, 'add_elh_flaticon_tab'] );
        add_filter( 'elementor/icons_manager/additional_tabs', [__CLASS__, 'add_elh_flaticon_tab_2'] );
        add_filter( 'elementor/icons_manager/additional_tabs', [__CLASS__, 'add_elh_flaticon_tab_3'] );
    }

    public static function add_elh_el_icons_tab( $tabs ) {
        $tabs['element-helper-icons'] = [
            'name'          => 'element-helper-icons',
            'label'         => __( 'Fontawesome Icons (Pro)', 'element-helper' ),
            'url'           => TA_ASSETS . 'css/font-awesome.min.css',
            'enqueue'       => [TA_ASSETS . 'css/font-awesome.min.css'],
            'prefix'        => '',
            'displayPrefix' => '',
            'labelIcon'     => 'fab fa-font-awesome',
            'ver'           => ELH_VERSION,
            'fetchJson'     => TA_ASSETS . 'js/elh-fontAwesome-icons.js?v=' . ELH_VERSION,
            'native'        => false,
        ];
        return $tabs;
    }

    public static function add_elh_flaticon_tab( $tabs ) {
        $tabs['element-helper-flaticon'] = [
            'name'          => 'element-helper-flaticon',
            'label'         => __( 'Flaticon Icons 1', 'element-helper' ),
            'url'           => get_template_directory_uri() . '/assets/css/flaticon.css',
            'enqueue'       => [ get_template_directory_uri() . '/assets/css/flaticon.css'],
            'prefix'        => 'flaticon-',
            'displayPrefix' => 'flaticon',
            'labelIcon'     => 'fab fa-fonticons',
            'ver'           => ELH_VERSION,
            'fetchJson'     => TA_ASSETS . 'js/elh-flaticon.js?v=' . ELH_VERSION,
            'native'        => false,
        ];
        return $tabs;
    }

    public static function add_elh_flaticon_tab_2( $tabs ) {
        $tabs['element-helper-flaticon-2'] = [
            'name'          => 'element-helper-flaticon-2',
            'label'         => __( 'Flaticon Icons 2', 'element-helper' ),
            'url'           => get_template_directory_uri() . '/assets/css/flaticon-2.css',
            'enqueue'       => [ get_template_directory_uri() . '/assets/css/flaticon-2.css'],
            'prefix'        => 'flaticon_2-',
            'displayPrefix' => 'flaticon',
            'labelIcon'     => 'fab fa-fonticons',
            'ver'           => ELH_VERSION,
            'fetchJson'     => TA_ASSETS . 'js/elh-flaticon-2.js?v=' . ELH_VERSION,
            'native'        => false,
        ];
        return $tabs;
    }

    public static function add_elh_flaticon_tab_3( $tabs ) {
        $tabs['element-helper-flaticon-3'] = [
            'name'          => 'element-helper-flaticon-3',
            'label'         => __( 'Flaticon Icons 3', 'element-helper' ),
            'url'           => get_template_directory_uri() . '/assets/css/flaticon-3.css',
            'enqueue'       => [ get_template_directory_uri() . '/assets/css/flaticon-3.css'],
            'prefix'        => 'flaticon_3-',
            'displayPrefix' => 'flaticon',
            'labelIcon'     => 'fab fa-fonticons',
            'ver'           => ELH_VERSION,
            'fetchJson'     => TA_ASSETS . 'js/elh-flaticon-3.js?v=' . ELH_VERSION,
            'native'        => false,
        ];
        return $tabs;
    }

}