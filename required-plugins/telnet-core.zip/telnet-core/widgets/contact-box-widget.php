<?php

// Control core classes for avoid errors
if ( class_exists( 'CSF' ) ) {

    CSF::createWidget( 'contact_info_widget', [
        'title'       => 'TelNet Contact Info Widget',
        'classname'   => 'tx-contact-info-widget',
        'description' => 'Widget description.',
        'fields'      => [
            [
                'id'    => 'title',
                'type'  => 'text',
                'title' => 'Title',
            ],

            // email
            [
                'id'    => 'email',
                'type'  => 'text',
                'title' => 'Email',
            ],

            // description
            [
                'id'    => 'address',
                'type'  => 'textarea',
                'title' => 'Address',
            ],

            // social links
            [
                'id'     => 'social_links',
                'type'   => 'repeater',
                'title'  => 'Repeater Field',
                'fields' => [
                    [
                        'id'    => 'social_text_enable',
                        'type'  => 'switcher',
                        'title' => 'Enable Text?',
                        'default' => true,
                    ],
                    [
                        'id'         => 'social_text',
                        'type'       => 'text',
                        'title'      => 'Link',
                        'dependency' => [ 'social_text_enable', '==', 'true' ],
                    ],
                    [
                        'id'         => 'social_icon',
                        'type'       => 'icon',
                        'title'      => 'Icon',
                        'dependency' => [ 'social_text_enable', '==', 'false' ],
                    ],
                    [
                        'id'    => 'social_link',
                        'type'  => 'text',
                        'title' => 'Link',
                    ],
                ],
            ],
        ],
    ] );

    //
    // Front-end display of widget example 1
    // Attention: This function named considering above widget base id.
    //
    if ( !function_exists( 'contact_info_widget' ) ) {
        function contact_info_widget( $args, $instance ) {

            echo $args['before_widget'];

            if ( !empty( $instance['title'] ) ) {
                echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
            }

            $html = '';

            $html .= '<div class="tx-contactInfo-widget">';
            $html .= '<a class="tx-mailText tx-underline" href="mailto:' . esc_attr( $instance['email'] ) . '">' . esc_html( $instance['email'] ) . '</a>';
            $html .= '<p class="mt-20">' . esc_html( $instance['address'] ) . '</p>';

            if ( $instance['social_links'] ) {
                $html .= '<div class="tx-social-links tx-social-links__styleCercle d-flex align-items-center mt-35">';
                foreach ( $instance['social_links'] as $social_link ) {
                    $html .= '<a href="' . esc_url( $social_link['social_link'] ) . '">';

                    if ( isset( $social_link['social_text_enable'] ) && $social_link['social_text_enable'] == true ) {
                        $html .= esc_html( $social_link['social_text'] );
                    } else {
                        $html .= '<i class="' . esc_attr( $social_link['social_icon'] ) . '"></i>';
                    }

                    $html .= '</a>';
                }
                $html .= '</div>';
            }
            $html .= '</div>';

            echo $html;

            echo $args['after_widget'];

        }
    }

}
