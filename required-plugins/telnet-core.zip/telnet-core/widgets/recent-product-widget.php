<?php
/**
* xriver-companion
* @since 1.0.0
*/

Class Recent_Product_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct( 'tc-recent-products', ''.tf_theme_name().' Recent Products ('.tf_theme_name().')', [
            'description' => 'Recent Products by '.tf_theme_name().'',
        ] );
    }

    public function widget( $args, $instance ) {
        extract( $args );
        extract( $instance );

        echo $before_widget;
		?>
		<?php
			if ( $instance['title'] ):
				echo $before_title;?>
						<?php echo apply_filters( 'widget_title', $instance['title'] ); ?>
					<?php echo $after_title; ?>
				<?php endif;?>

		<div class="tx-recent-posts">
            <?php
				$q = new WP_Query( [
				'post_type'      => 'product',
				'posts_per_page' => ( $instance['count'] ) ? $instance['count'] : '3',
				'order'          => ( $instance['posts_order'] ) ? $instance['posts_order'] : 'DESC',
				'orderby'        => 'date',
			] );

			if ( $q->have_posts() ):
				while ( $q->have_posts() ): $q->the_post();

				$title_length = ( $instance['title_length'] ) ? $instance['title_length'] : '10';
			?>

			<div class="tx-item mt-10" id="<?php echo esc_attr('post-'.$id); ?>">
				<?php if ( has_post_thumbnail() ): ?>
				<div class="tx-thumb mr-15">
					<?php the_post_thumbnail( 'thumbnail' );?>
				</div>
				<?php endif; ?>
				<div class="tx-content">
					<h6 class="tx-title tx-border-effect">
						<a href="<?php the_permalink();?>">
						<?php print wp_trim_words( get_the_title(), $title_length, '' );?></a>
					</h6>
                    <div class="tx-productPrice">
                        <?php woocommerce_template_loop_price(); ?>
                    </div>
				</div>
			</div>
			<?php endwhile;
			endif;?>

            <?php wp_reset_postdata();?>

		</div>



		<?php echo $after_widget; ?>

		<?php
}

    public function form( $instance ) {
        $title = !empty( $instance['title'] ) ? $instance['title'] : '';
        $count = !empty( $instance['count'] ) ? $instance['count'] : esc_html__( '3', TELNET_CORE_TEXT_DOMAIN );
		$title_length = !empty( $instance['title_length'] ) ? $instance['title_length'] : esc_html__( '10', TELNET_CORE_TEXT_DOMAIN );
        $posts_order = !empty( $instance['posts_order'] ) ? $instance['posts_order'] : esc_html__( 'DESC', TELNET_CORE_TEXT_DOMAIN );
        ?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php echo esc_html__('Title', 'tf-companion'); ?></label>
			<input type="text" name="<?php echo $this->get_field_name( 'title' ); ?>" id="<?php echo $this->get_field_id( 'title' ); ?>" value="<?php echo esc_attr( $title ); ?>" class="widefat">
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'count' ); ?>"><?php echo esc_html__('How many posts you want to show ?', 'tf-companion'); ?></label>
			<input type="number" name="<?php echo $this->get_field_name( 'count' ); ?>" id="<?php echo $this->get_field_id( 'count' ); ?>" value="<?php echo esc_attr( $count ); ?>" class="widefat">
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'title_length' ); ?>"><?php echo esc_html__('Title Length', 'tf-companion'); ?></label>
			<input type="number" name="<?php echo $this->get_field_name( 'title_length' ); ?>" id="<?php echo $this->get_field_id( 'title_length' ); ?>" value="<?php echo esc_attr( $title_length ); ?>" class="widefat">
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'posts_order' ); ?>"><?php echo esc_html__('Posts Order', 'tf-companion'); ?></label>
			<select name="<?php echo $this->get_field_name( 'posts_order' ); ?>" id="<?php echo $this->get_field_id( 'posts_order' ); ?>" class="widefat">
				<option value="" disabled="disabled"><?php echo esc_html__('Select Post Order', 'tf-companion'); ?></option>
				<option value="ASC" <?php if ( $posts_order === 'ASC' ) {echo 'selected="selected"';}?>><?php echo esc_html__('ASC', 'tf-companion'); ?></option>
				<option value="DESC" <?php if ( $posts_order === 'DESC' ) {echo 'selected="selected"';}?>><?php echo esc_html__('DESC', 'tf-companion'); ?></option>
			</select>
		</p>

	<?php }

}

add_action( 'widgets_init', function () {
    register_widget( 'Recent_Product_Widget' );
} );