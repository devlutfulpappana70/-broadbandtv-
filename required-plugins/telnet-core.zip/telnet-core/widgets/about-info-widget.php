<?php


if ( class_exists( 'CSF' ) ) {

    CSF::createWidget( 'about_info_widget', [
        'title'       => 'TelNet About Info Widget',
        'classname'   => 'tx-about-info-widget',
        'description' => 'This is a about info widget.',
        'fields'      => [
            [
                'id'    => 'title',
                'type'  => 'text',
                'title' => 'Title',
            ],

            // author image
            [
                'id'    => 'logo_image',
                'type'  => 'media',
                'title' => 'Logo Image',
            ],

            // description
            [
                'id'    => 'description',
                'type'  => 'textarea',
                'title' => 'Description',
            ],

            // button text
            [
                'id'    => 'button_text',
                'type'  => 'text',
                'title' => 'Button Text',
            ],

            // button link
            [
                'id'    => 'button_link',
                'type'  => 'text',
                'title' => 'Button Link',
            ],
        ],
    ] );

    // Register widget
    if ( !function_exists( 'about_info_widget' ) ) {
        function about_info_widget( $args, $instance ) {

            echo $args['before_widget'];

            if ( !empty( $instance['title'] ) ) {
                echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
            }

            $html = '';

            $html .= '<div class="tx-aboutInfo-widget">';
            $html .= '<a class="tx-logo" href="'.home_url( '/' ).'">';
            $html .= '<img src="'.esc_url($instance['logo_image']['url']).'" alt="">';
            $html .= '</a>';
            $html .= '<p class="mt-20">'.$instance['description'].'</p>';
            $html .= '<a class="tx-inline-btn tx-inline-btn__styleTheme tx-underline mt-15 pb-0" href="'.esc_url($instance['button_link']).'">'.esc_html($instance['button_text']).'</a>';
            $html .= '</div>';

            echo $html;

            echo $args['after_widget'];

        }
    }

}
