<?php

// Control core classes for avoid errors
if ( class_exists( 'CSF' ) ) {

    CSF::createWidget( 'author_box_widget', [
        'title'       => 'TelNet Author Box Widget',
        'classname'   => 'tx-author-box-widget p-0 border-none text-center',
        'description' => 'Widget description.',
        'fields'      => [
            [
                'id'    => 'title',
                'type'  => 'text',
                'title' => 'Title',
            ],
            // bg image
            [
                'id'    => 'bg_image',
                'type'  => 'media',
                'title' => 'Background',
            ],

            // author image
            [
                'id'    => 'author_image',
                'type'  => 'media',
                'title' => 'Author Image',
            ],

            // author name
            [
                'id'    => 'author_name',
                'type'  => 'text',
                'title' => 'Author Name',
            ],

            // description
            [
                'id'    => 'description',
                'type'  => 'textarea',
                'title' => 'Description',
            ],

            // social links
            [
                'id'     => 'social_links',
                'type'   => 'repeater',
                'title'  => 'Repeater Field',
                'fields' => [
                    [
                        'id'    => 'social_icon',
                        'type'  => 'icon',
                        'title' => 'Icon',
                    ],
                    [
                        'id'    => 'social_link',
                        'type'  => 'text',
                        'title' => 'Link',
                    ],
                ],
            ],
        ],
    ] );

    //
    // Front-end display of widget example 1
    // Attention: This function named considering above widget base id.
    //
    if ( !function_exists( 'author_box_widget' ) ) {
        function author_box_widget( $args, $instance ) {

            echo $args['before_widget'];

            if ( !empty( $instance['title'] ) ) {
                echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
            }

            $html = '';

            $html .= '<div class="tx-topWrapper position-relative" data-background="'.esc_attr($instance['bg_image']['url']).'">';
            $html .= '</div>';
            $html .= '<div class="tx-wrapper pb-35 pl-40 pr-40">';
            $html .= '<div class="tx-authorThumb tx-radious-50 mt-none-50 m-auto">';
            $html .= '<img src="'.esc_url($instance['author_image']['url']).'" alt="">';
            $html .= '</div>';
            $html .= '<h5 class="tx-name mt-15">'.$instance['author_name'].'</h5>';
            $html .= '<p class="mt-15">'.esc_html($instance['description']).'</p>';

            if($instance['social_links']) {
                $html .= '<div class="tx-social-links tx-social-links__styleCercle d-flex justify-content-center align-items-center mt-15">';
                foreach ( $instance['social_links'] as $social_link ) {
                    $html .= '<a href="' . esc_url($social_link['social_link']) . '">';
                    $html .= '<i class="' . esc_attr($social_link['social_icon']) . '"></i>';
                    $html .= '</a>';
                }
                $html .= '</div>';
            }
            $html .= '</div>';

            echo $html;

            echo $args['after_widget'];

        }
    }

}
