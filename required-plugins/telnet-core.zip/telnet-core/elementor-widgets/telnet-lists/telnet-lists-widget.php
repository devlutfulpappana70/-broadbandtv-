<?php

namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
use \Elementor\Core\Schemes\Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;

defined( 'ABSPATH' ) || die();

class Telnet_Lists extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name() {
        return 'telnet_lists';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title() {
        return __( 'TelNet Lists', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/gradient-heading/';
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-t-letter';
    }

    public function get_keywords() {
        return ['btn', 'lists', 'telnet', 'telnet lists'];
    }

    protected function register_content_controls() {

        //Settings
        $this->start_controls_section(
            '_section_settings',
            [
                'label' => __( 'Settings', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'design_style',
            [
                'label'              => __( 'Design Style', 'telnet-core' ),
                'type'               => Controls_Manager::SELECT,
                'options'            => [
                    'style_1' => __( 'Style 1', 'telnet-core' ),
                    'style_2' => __( 'Style 2', 'telnet-core' ),
                    'style_3' => __( 'Style 3', 'telnet-core' ),
                    'style_4' => __( 'Style 4', 'telnet-core' ),
                    'style_5' => __( 'Style 5', 'telnet-core' ),
                    'style_6' => __( 'Style 6', 'telnet-core' ),
                ],
                'default'            => 'style_1',
                'frontend_available' => true,
                'style_transfer'     => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_title',
            [
                'label' => __( 'Lists', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        // choose style
        $repeater->add_control(
            'option_style',
            [
                'label' => __('CHOOSE STYLE', 'telnet-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __('Style 1', 'telnet-core'),
                    'style_2' => __('Style 2', 'telnet-core'),
                    'style_3' => __('Style 3', 'telnet-core'),
                    'style_4' => __('Style 4', 'telnet-core'),
                    'style_5' => __('Style 5', 'telnet-core'),
                    'style_6' => __('Style 6', 'telnet-core'),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        // icon type
        $repeater->add_control(
            'type',
            [
                'label'          => __( 'Service Icon', 'telnet-core' ),
                'type'           => Controls_Manager::CHOOSE,
                'label_block'    => false,
                'options'        => [
                    'icon'  => [
                        'title' => __( 'Icon', 'telnet-core' ),
                        'icon'  => 'far fa-smile',
                    ],
                    'image' => [
                        'title' => __( 'Image', 'telnet-core' ),
                        'icon'  => 'fa fa-image',
                    ],
                ],
                'default'        => 'icon',
                'toggle'         => false,
                'style_transfer' => true,
                'condition'   => [
                    'option_style' => [
                        'style_1',
                        'style_2',
                        'style_3',
                        'style_5',
                    ],
                ]
            ]
        );

        // list icon
        $repeater->add_control(
            'list_icon',
            [
                'label'       => __( 'Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'default'     => [
                    'value'   => 'fas fa-check',
                    'library' => 'solid',
                ],
                'label_block' => true,
                'condition'   => [
                    'type' => 'icon',
                    'option_style' => [
                        'style_1',
                        'style_2',
                        'style_3',
                        'style_5',
                    ],
                ],
            ]
        );

        // list image
        $repeater->add_control(
            'list_image',
            [
                'label'       => __( 'Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition'   => [
                    'type' => 'image',
                    'option_style' => [
                        'style_1',
                        'style_2',
                        'style_3',
                        'style_5',
                    ],
                ],
            ]
        );

        // list title
        $repeater->add_control(
            'list_title',
            [
                'label'       => __( 'List Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'List Title', 'telnet-core' ),
                'label_block' => true,
                'condition'   => [
                    'option_style' => 'style_2',
                ],
            ]
        );

        // list count
        $repeater->add_control(
            'list_count',
            [
                'label'       => __( 'List Count', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'List Count', 'telnet-core' ),
                'label_block' => true,
                'condition'   => [
                    'option_style' => 'style_4',
                ],
            ]
        );

        // list text
        $repeater->add_control(
            'list_text',
            [
                'label'       => __( 'List Text', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'List Text', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        // link
        $repeater->add_control(
            'link',
            [
                'label'       => __( 'Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'label_block' => true,
                'condition'   => [
                    'option_style' => [
                        'style_6',
                    ],
                ],
            ]
        );

        // enable_link
        $repeater->add_control(
            'enable_link',
            [
                'label'        => __( 'Enable Link', 'telnet-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'telnet-core' ),
                'label_off'    => __( 'No', 'telnet-core' ),
                'return_value' => 'yes',
                'default'      => 'no',
                'condition'    => [
                    'option_style' => [
                        'style_2',
                    ],
                ],
            ]
        );

        $repeater->add_control(
            'link_type',
            [
                'label'          => __( 'Choose Link Type', 'telnet-core' ),
                'type'           => Controls_Manager::CHOOSE,
                'label_block'    => false,
                'options'        => [
                    'url'   => [
                        'title' => __( 'URL', 'telnet-core' ),
                        'icon'  => 'far fa-globe',
                    ],
                    'email' => [
                        'title' => __( 'Email', 'telnet-core' ),
                        'icon'  => 'fa fa-envelope',
                    ],
                    'phone' => [
                        'title' => __( 'Phone', 'telnet-core' ),
                        'icon'  => 'fa fa-phone',
                    ],
                ],
                'default'        => 'icon',
                'toggle'         => false,
                'style_transfer' => true,
                'condition'   => [
                    'option_style' => [
                        'style_2',
                    ],
                    'enable_link' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'list_items',
            [
                'label'       => __( 'List Items', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [
                    [
                        'list_text' => __( 'List Text', 'telnet-core' ),
                    ],
                    [
                        'list_text' => __( 'List Text', 'telnet-core' ),
                    ],
                ],
                'title_field' => '{{{ list_text }}}',
            ]
        );

        $this->end_controls_section();

    }

    protected function register_style_controls() {

        // Icon style
        $this->start_controls_section(
            '_section_icon_style',
            [
                'label' => __( 'Icon', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // icon size
        $this->add_responsive_control(
            'icon_size',
            [
                'label'      => __( 'Size', 'telnet-core' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range'      => [
                    'px' => [
                        'min'  => 10,
                        'max'  => 200,
                        'step' => 1,
                    ],
                    'em' => [
                        'min'  => 0.1,
                        'max'  => 20,
                        'step' => 0.1,
                    ],
                    '%'  => [
                        'min'  => 10,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .tx-listItems .tx-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // icon width & height
        $this->add_responsive_control(
            'icon_width_height',
            [
                'label'      => __( 'Width & Height', 'telnet-core' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range'      => [
                    'px' => [
                        'min'  => 10,
                        'max'  => 200,
                        'step' => 1,
                    ],
                    'em' => [
                        'min'  => 0.1,
                        'max'  => 20,
                        'step' => 0.1,
                    ],
                    '%'  => [
                        'min'  => 10,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .tx-listItems .tx-icon' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .tx-listItems .tx-content' => 'width: calc(100% - {{SIZE}}{{UNIT}} - 15px);',
                ],
            ]
        );

        // icon bg color
        $this->add_control(
            'icon_bg_color',
            [
                'label'     => __( 'Background Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-listItems .tx-icon' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        // icon color
        $this->add_control(
            'icon_color',
            [
                'label'     => __( 'Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-listItems .tx-icon' => 'color: {{VALUE}};',
                ],
            ]
        );

        // icon border
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'icon_border',
                'label'    => __( 'Border', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-listItems .tx-icon',
            ]
        );

        // border radius
        $this->add_responsive_control(
            'icon_border_radius',
            [
                'label'      => __( 'Border Radius', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-listItems .tx-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // icon gap
        $this->add_responsive_control(
            'icon_gap',
            [
                'label'      => __( 'Gap', 'telnet-core' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                    'em' => [
                        'min'  => 0,
                        'max'  => 10,
                        'step' => 0.1,
                    ],
                    '%'  => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .tx-listItems .tx-icon' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // end icon style
        $this->end_controls_section();

        // CONTENT STYLE
        $this->start_controls_section(
            '_section_content_style',
            [
                'label' => __( 'Content', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // CONTENT WIDTH
        $this->add_responsive_control(
            'content_width',
            [
                'label'      => __( 'Width', 'telnet-core' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range'      => [
                    'px' => [
                        'min'  => 10,
                        'max'  => 1000,
                        'step' => 1,
                    ],
                    'em' => [
                        'min'  => 0.1,
                        'max'  => 100,
                        'step' => 0.1,
                    ],
                    '%'  => [
                        'min'  => 10,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .tx-listItems .tx-content' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // END CONTENT STYLE
        $this->end_controls_section();

        // title style
        $this->start_controls_section(
            '_section_title_style',
            [
                'label' => __( 'Title', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // title color
        $this->add_control(
            'title_color',
            [
                'label'     => __( 'Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-listItems .tx-title' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .tx-listItems p' => 'color: {{VALUE}};',
                ],
            ]
        );

        // title typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typography',
                'label'    => __( 'Typography', 'telnet-core' ),
                'selector' => '
                    {{WRAPPER}} .tx-listItems .tx-title,
                    {{WRAPPER}} .tx-listItems p
                ',
            ]
        );


        // title margin
        $this->add_responsive_control(
            'title_margin',
            [
                'label'      => __( 'Margin', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-listItems p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .tx-listItems .tx-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // title padding
        $this->add_responsive_control(
            'title_padding',
            [
                'label'      => __( 'Padding', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-listItems p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .tx-listItems .tx-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // end title style
        $this->end_controls_section();

        // text style
        $this->start_controls_section(
            '_section_text_style',
            [
                'label' => __( 'Text', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // text color
        $this->add_control(
            'text_color',
            [
                'label'     => __( 'Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-listItems .tx-content p' => 'color: {{VALUE}};',
                ],
            ]
        );

        // text typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'text_typography',
                'label'    => __( 'Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-listItems .tx-content p',
            ]
        );

        // text margin
        $this->add_responsive_control(
            'text_margin',
            [
                'label'      => __( 'Margin', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-listItems .tx-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // text padding
        $this->add_responsive_control(
            'text_padding',
            [
                'label'      => __( 'Padding', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-listItems .tx-content p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // text end
        $this->end_controls_section();

        // count style
        $this->start_controls_section(
            '_section_count_style',
            [
                'label' => __( 'Count Text', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition'   => [
                    'option_style' => 'style_4',
                ],
            ]
        );

        // count color
        $this->add_control(
            'count_color',
            [
                'label'     => __( 'Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-listItems .tx-count' => 'color: {{VALUE}};',
                ],
            ]
        );

        // typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'count_typography',
                'label'    => __( 'Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-listItems .tx-count',
            ]
        );

        // count end
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $dir = dirname( __FILE__ );
        $style = !empty($settings['design_style']) ? $settings['design_style'] : 'style_1';

        switch ($style) {
            case 'style_6':
                include $dir . '/views/view-6.php';
                break;
            case 'style_5':
                include $dir . '/views/view-5.php';
                break;
            case 'style_4':
                include $dir . '/views/view-4.php';
                break;
            case 'style_3':
                include $dir . '/views/view-3.php';
                break;
            case 'style_2':
                include $dir . '/views/view-2.php';
                break;
            default:
                include $dir . '/views/view-1.php';
        }
    }
}
