<?php

use \Elementor\Group_Control_Image_Size;

if ( !empty( $settings['list_items'] ) ): ?>
<ul class="list-unstyled tx-listItems tx-listItems__styleTwo">
    <?php foreach ( $settings['list_items'] as $key => $list ): ?>
    <li>
        <?php
            if( $list['enable_link'] === 'yes' ) :

            if($list['link_type'] === 'email') {
                $link_url = 'mailto:' . $list['list_text'];
            } elseif( $list['link_type'] === 'phone' ) {
                $link_url = 'tel:' . $list['list_text'];
            } else {
                $link_url = $list['list_text'];
            }
        ?>
        <a href="<?php echo esc_url( $link_url ); ?>">
            <span class="tx-icon">
                <?php
                    if ($list['type'] === 'image' && ($list['list_image']['url'] || $list['list_image']['id'])) {
                        $this->get_render_attribute_string('list_image');
                        $list['hover_animation'] = 'disable-animation';
                        echo Group_Control_Image_Size::get_attachment_image_html($list, 'thumbnail', 'list_image');
                    } elseif (!empty($list['list_icon'])) {
                        elh_element_render_icon($list, '', 'list_icon');
                    }
                ?>
            </span>
        </a>
        <?php else : ?>
        <span class="tx-icon">
            <?php
                if ($list['type'] === 'image' && ($list['list_image']['url'] || $list['list_image']['id'])) {
                    $this->get_render_attribute_string('list_image');
                    $list['hover_animation'] = 'disable-animation';
                    echo Group_Control_Image_Size::get_attachment_image_html($list, 'thumbnail', 'list_image');
                } elseif (!empty($list['list_icon'])) {
                    elh_element_render_icon($list, '', 'list_icon');
                }
            ?>
        </span>
        <?php endif; ?>
        <div class="tx-content">
            <?php if(!empty( $list['list_title'] )) : ?>
            <h5 class="tx-title"><?php echo elh_element_kses_intermediate( $list['list_title'] ); ?></h5>
            <?php endif; ?>

            <?php
                if( $list['enable_link'] === 'yes' ) :

                if($list['link_type'] === 'email') {
                    $link_url = 'mailto:' . $list['list_text'];
                } elseif( $list['link_type'] === 'phone' ) {
                    $link_url = 'tel:' . $list['list_text'];
                } else {
                    $link_url = $list['list_text'];
                }
            ?>
            <a href="<?php echo esc_url( $link_url ); ?>">
                <?php echo esc_html( $list['list_text'] ); ?>
            </a>
            <?php else : ?>
            <p><?php echo elh_element_kses_intermediate( $list['list_text'] ); ?></p>
            <?php endif; ?>
        </div>
    </li>
    <?php endforeach;?>
</ul>
<?php endif;