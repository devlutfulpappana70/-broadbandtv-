<?php if ( !empty( $settings['list_items'] ) ) : ?>
<ul class="about-one_list list-unstyled">
    <?php foreach ( $settings['list_items'] as $key => $list ): ?>
    <li>
        <?php if($list['type'] == 'icon') : ?>
            <?php \Elementor\Icons_Manager::render_icon( $list['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
        <?php else : ?>
            <img src="<?php echo esc_url($list['list_image']['url']); ?>" alt="" />
        <?php endif; ?>
        <?php echo elh_element_kses_intermediate( $list['list_text'] ); ?>
    </li>
    <?php endforeach;?>
</ul>
<?php endif; ?>