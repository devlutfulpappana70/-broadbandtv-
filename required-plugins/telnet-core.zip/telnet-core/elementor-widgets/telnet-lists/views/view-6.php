<?php if ( !empty( $settings['list_items'] ) ) : ?>
<ul class="quick-links-two">
    <?php foreach ( $settings['list_items'] as $key => $list ): ?>
    <li>
        <?php if($list['type'] == 'icon') : ?>
            <?php \Elementor\Icons_Manager::render_icon( $list['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
        <?php else : ?>
            <img src="<?php echo esc_url($list['list_image']['url']); ?>" alt="" />
        <?php endif; ?>
        <a href="<?php echo esc_url($list['link']['url']); ?>"><?php echo elh_element_kses_intermediate( $list['list_text'] ); ?></a>
    </li>
    <?php endforeach;?>
</ul>
<?php endif; ?>