<?php

if ( !empty( $settings['list_items'] ) ) : ?>
<ul class="list-unstyled tx-listItems tx-listItems__styleFour">
    <?php foreach ( $settings['list_items'] as $key => $list ): ?>
    <li>
        <?php if(!empty( $list['list_count'] )) : ?>
        <span class="tx-count">
            <?php echo elh_element_kses_intermediate( $list['list_count'] ); ?>
        </span>
        <?php endif; ?>

        <div class="tx-content">
            <?php if(!empty( $list['list_text'] )) : ?>
            <p><?php echo elh_element_kses_intermediate( $list['list_text'] ); ?></p>
            <?php endif; ?>
        </div>
    </li>
    <?php endforeach;?>
</ul>
<?php endif;