<?php

if ( !empty( $settings['list_items'] ) ): ?>
<ul class="list-unstyled tx-listItems tx-listItems__styleOne">
    <?php foreach ( $settings['list_items'] as $key => $list ): ?>
    <li>
        <span class="tx-icon">
            <?php
                if ($list['type'] === 'image' && ($list['list_image']['url'] || $list['list_image']['id'])) {
                    $this->get_render_attribute_string('list_image');
                    $list['hover_animation'] = 'disable-animation';
                    echo Group_Control_Image_Size::get_attachment_image_html($list, 'thumbnail', 'list_image');
                } elseif (!empty($list['list_icon'])) {
                    elh_element_render_icon($list, '', 'list_icon');
                }
            ?>
        </span>
        <p><?php echo elh_element_kses_intermediate( $list['list_text'] ); ?></p>
    </li>
    <?php endforeach;?>
</ul>
<?php endif;