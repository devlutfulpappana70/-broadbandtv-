<div class="tx-infoText">
    <p>
        <?php echo $settings['info_text'] ? elh_element_kses_basic( $settings['info_text'] ) : ''; ?>
        <?php if(!empty( $settings['button_text'] )) : ?>
        <a href="<?php echo $settings['button_link']['url'] ? esc_url( $settings['button_link']['url'] ) : '';  ?>"
        target="<?php echo esc_attr( $settings['button_link']['is_external'] ? '_blank' : '_self' ); ?>"
        rel=" <?php echo esc_attr( $settings['button_link']['nofollow'] ? 'nofollow' : '' ); ?>">
            <?php echo elh_element_kses_intermediate( $settings['button_text'] ); ?>
        </a>
        <?php endif; ?>
    </p>
</div>