<?php

namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
use \Elementor\Core\Schemes\Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;

defined( 'ABSPATH' ) || die();

class Telnet_Counter extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name() {
        return 'telnet_counter';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title() {
        return __( 'TelNet Counter', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/gradient-heading/';
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-t-letter';
    }

    public function get_keywords() {
        return ['count', 'telnet', 'telnet counter'];
    }

    public function elh_element_animations() {
        return [
            'none' => __( 'None', 'telnet-core' ),
            'fadeIn' => __( 'Fade In', 'telnet-core' ),
            'fadeInUp' => __( 'Fade In Up', 'telnet-core' ),
            'fadeInDown' => __( 'Fade In Down', 'telnet-core' ),
            'fadeInLeft' => __( 'Fade In Left', 'telnet-core' ),
            'fadeInRight' => __( 'Fade In Right', 'telnet-core' ),
            'fadeInUpBig' => __( 'Fade In Up Big', 'telnet-core' ),
            'fadeInDownBig' => __( 'Fade In Down Big', 'telnet-core' ),
            'fadeInLeftBig' => __( 'Fade In Left Big', 'telnet-core' ),
            'fadeInRightBig' => __( 'Fade In Right Big', 'telnet-core' ),
            'bounceIn' => __( 'Bounce In', 'telnet-core' ),
            'bounceInUp' => __( 'Bounce In Up', 'telnet-core' ),
            'bounceInDown' => __( 'Bounce In Down', 'telnet-core' ),
            'bounceInLeft' => __( 'Bounce In Left', 'telnet-core' ),
            'bounceInRight' => __( 'Bounce In Right', 'telnet-core' ),
            'rotateIn' => __( 'Rotate In', 'telnet-core' ),
            'rotateInUpLeft' => __( 'Rotate In Up Left', 'telnet-core' ),
            'rotateInDownLeft' => __( 'Rotate In Down Left', 'telnet-core' ),
            'rotateInUpRight' => __( 'Rotate In Up Right', 'telnet-core' ),
            'rotateInDownRight' => __( 'Rotate In Down Right', 'telnet-core' ),
            'lightSpeedIn' => __( 'Light Speed In', 'telnet-core' ),
            'rollIn' => __( 'Roll In', 'telnet-core' ),
            'zoomIn' => __( 'Zoom In', 'telnet-core' ),
            'zoomInUp' => __( 'Zoom In Up', 'telnet-core' ),
            'zoomInDown' => __( 'Zoom In Down', 'telnet-core' ),
            'zoomInLeft' => __( 'Zoom In Left', 'telnet-core' ),
            'zoomInRight' => __( 'Zoom In Right', 'telnet-core' ),
            'slideInUp' => __( 'Slide In Up', 'telnet-core' ),
            'slideInDown' => __( 'Slide In Down', 'telnet-core' ),
            'slideInLeft' => __( 'Slide In Left', 'telnet-core' ),
            'slideInRight' => __( 'Slide In Right', 'telnet-core' ),
        ];
    }

    protected function register_content_controls() {

        //Settings
        $this->start_controls_section(
            '_section_settings',
            [
                'label' => __( 'Settings', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'design_style',
            [
                'label'              => __( 'Design Style', 'telnet-core' ),
                'type'               => Controls_Manager::SELECT,
                'options'            => [
                    'style_1' => __( 'Style 1', 'telnet-core' ),
                    'style_2' => __( 'Style 2', 'telnet-core' ),
                    'style_3' => __( 'Style 3', 'telnet-core' ),
                    'style_4' => __( 'Style 4', 'telnet-core' ),
                    'style_5' => __( 'Style 5', 'telnet-core' ),
                    'style_6' => __( 'Style 6', 'telnet-core' ),
                    'style_7' => __( 'Style 7', 'telnet-core' ),
                ],
                'default'            => 'style_1',
                'frontend_available' => true,
                'style_transfer'     => true,
            ]
        );

        // anim name list for animation
        $this->add_control(
            'anim_name',
            [
                'label'       => __( 'Animation Name', 'telnet-core' ),
                'type'        => Controls_Manager::SELECT,
                'options'     => $this->elh_element_animations(),
                'default'     => 'fadeInUp',
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );

        // anim delay
        $this->add_control(
            'anim_delay',
            [
                'label'       => __( 'Animation Delay', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );

        // anim duration
        $this->add_control(
            'anim_duration',
            [
                'label'       => __( 'Animation Duration', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_title',
            [
                'label' => __( 'Counter', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'design_style' => [
                        'style_1',
                        'style_2',
                        'style_3',
                        'style_4',
                        'style_5',
                        'style_6'
                    ]
                ]
            ]
        );

        // shape bg img
        $this->add_control(
            'shape_bg_img',
            [
                'label'       => __( 'Shape Background Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        // counter icon
        $this->add_control(
            'counter_icon',
            [
                'label'       => __( 'Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'label_block' => true,
                'default'     => [
                    'value'   => 'fas fa-check',
                    'library' => 'solid',
                ],
            ]
        );

        // count number
        $this->add_control(
            'count_number',
            [
                'label'       => __( 'Count Number', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __( '100', 'telnet-core' ),
            ]
        );

        // sing
        $this->add_control(
            'count_sing',
            [
                'label'       => __( 'Sing', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __( 'k+', 'telnet-core' ),
            ]
        );

        // count title
        $this->add_control(
            'count_title',
            [
                'label'       => __( 'Count Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __( 'Happy Clients', 'telnet-core' ),
            ]
        );

        $this->end_controls_section();

        // Counter Lists
        $this->start_controls_section(
            '_section_counter_lists',
            [
                'label' => __( 'Counter Lists', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'design_style' => ['style_7']
                ]
            ]
        );

        $repeater = new Repeater();

        // counter icon
        $repeater->add_control(
            'counter_icon',
            [
                'label'       => __( 'Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'label_block' => true,
                'default'     => [
                    'value'   => 'fas fa-check',
                    'library' => 'solid',
                ],
            ]
        );

        // count number
        $repeater->add_control(
            'count_number',
            [
                'label'       => __( 'Count Number', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __( '100', 'telnet-core' ),
            ]
        );

        // sing
        $repeater->add_control(
            'count_sing',
            [
                'label'       => __( 'Sing', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __( 'k+', 'telnet-core' ),
            ]
        );

        // count title
        $repeater->add_control(
            'count_title',
            [
                'label'       => __( 'Count Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __( 'Happy Clients', 'telnet-core' ),
            ]
        );

        // counter lists
        $this->add_control(
            'counters',
            [
                'label'       => __( 'Counter Lists', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ count_title }}}',
            ]
        );

        // end
        $this->end_controls_section();

    }

    protected function register_style_controls() {
        // Icon style
        $this->start_controls_section(
            '_section_icon_style',
            [
                'label' => __( 'Icon', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // icon size
        $this->add_responsive_control(
            'icon_size',
            [
                'label'      => __( 'Size', 'telnet-core' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range'      => [
                    'px' => [
                        'min'  => 10,
                        'max'  => 200,
                        'step' => 1,
                    ],
                    'em' => [
                        'min'  => 0.1,
                        'max'  => 20,
                        'step' => 0.1,
                    ],
                    '%'  => [
                        'min'  => 10,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .tx-counterItem .tx-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // icon width & height
        $this->add_responsive_control(
            'icon_width_height',
            [
                'label'      => __( 'Width & Height', 'telnet-core' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range'      => [
                    'px' => [
                        'min'  => 10,
                        'max'  => 200,
                        'step' => 1,
                    ],
                    'em' => [
                        'min'  => 0.1,
                        'max'  => 20,
                        'step' => 0.1,
                    ],
                    '%'  => [
                        'min'  => 10,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .tx-counterItem .tx-icon' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // icon bg color
        $this->add_control(
            'icon_bg_color',
            [
                'label'     => __( 'Background Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-counterItem .tx-icon' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        // icon color
        $this->add_control(
            'icon_color',
            [
                'label'     => __( 'Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-counterItem .tx-icon' => 'color: {{VALUE}};',
                ],
            ]
        );

        // icon border
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'icon_border',
                'label'    => __( 'Border', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-counterItem .tx-icon',
            ]
        );

        // icon gap
        $this->add_responsive_control(
            'icon_gap',
            [
                'label'      => __( 'Gap', 'telnet-core' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                    'em' => [
                        'min'  => 0,
                        'max'  => 10,
                        'step' => 0.1,
                    ],
                    '%'  => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .tx-counterItem .tx-icon' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // end icon style
        $this->end_controls_section();

        // number style
        $this->start_controls_section(
            '_section_number_style',
            [
                'label' => __( 'Number', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // number color
        $this->add_control(
            'number_color',
            [
                'label'     => __( 'Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-counterItem .tx-count span' => 'color: {{VALUE}};',
                ],
            ]
        );

        // number typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'number_typography',
                'label'    => __( 'Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-counterItem .tx-count span',
            ]
        );

        // number margin
        $this->add_responsive_control(
            'number_margin',
            [
                'label'      => __( 'Margin', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-counterItem .tx-count span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // number padding
        $this->add_responsive_control(
            'number_padding',
            [
                'label'      => __( 'Padding', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-counterItem .tx-count span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // number end
        $this->end_controls_section();

        // title style
        $this->start_controls_section(
            '_section_title_style',
            [
                'label' => __( 'Title', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // title color
        $this->add_control(
            'title_color',
            [
                'label'     => __( 'Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-counterItem p' => 'color: {{VALUE}};',
                ],
            ]
        );

        // title typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typography',
                'label'    => __( 'Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-counterItem p',
            ]
        );


        // title margin
        $this->add_responsive_control(
            'title_margin',
            [
                'label'      => __( 'Margin', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-counterItem p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // title padding
        $this->add_responsive_control(
            'title_padding',
            [
                'label'      => __( 'Padding', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-counterItem p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // end title style
        $this->end_controls_section();

    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $dir = dirname( __FILE__ );
        $style = !empty($settings['design_style']) ? $settings['design_style'] : 'style_1';

        switch ($style) {
            case 'style_7':
                include $dir . '/views/view-7.php';
                break;
            case 'style_6':
                include $dir . '/views/view-6.php';
                break;
            case 'style_5':
                include $dir . '/views/view-5.php';
                break;
            case 'style_4':
                include $dir . '/views/view-4.php';
                break;
            case 'style_3':
                include $dir . '/views/view-3.php';
                break;
            case 'style_2':
                include $dir . '/views/view-2.php';
                break;
            default:
                include $dir . '/views/view-1.php';
        }
    }
}
