<div class="tna-project-count-1-item">
    <?php if(!empty( $settings['counter_icon'] )) : ?>
    <div class="icon">
        <?php if(!empty( $settings['shape_bg_img']['url'] )) : ?>
        <img src="<?php echo esc_url($settings['shape_bg_img']['url']) ?>" alt="">
        <?php endif; ?>
        <?php echo elh_element_render_icon($settings, '', 'counter_icon'); ?>
    </div>
    <?php endif; ?>
    <div class="content-wrap">
        <?php if(!empty( $settings['count_number'] )) : ?>
        <h3 class="tna-heading-1 number">
            <span class="odometer" data-count="<?php echo esc_html( $settings['count_number'] ); ?>"></span><?php echo esc_html( $settings['count_sing'] ); ?>
        </h3>
        <?php endif; ?>

        <?php if(!empty( $settings['count_title'] )) : ?>
        <p class="tna-para-1 disc"><?php echo elh_element_kses_intermediate( $settings['count_title'] ); ?></p>
        <?php endif; ?>
    </div>
</div>