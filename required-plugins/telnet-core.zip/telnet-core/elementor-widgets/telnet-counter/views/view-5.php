<div class="about-one_counter">
    <div class="about-one_counter-inner">
        <div class="about-one_counter-number">
            <?php if(!empty( $settings['count_number'] )) : ?>
            <span class="odometer" data-count="<?php echo esc_html( $settings['count_number'] ); ?>"></span><?php echo esc_html( $settings['count_sing'] ); ?>
        </div>
        <?php endif; ?>

        <?php if(!empty( $settings['count_title'] )) : ?>
        <div class="about-one_counter-text"><?php echo elh_element_kses_intermediate( $settings['count_title'] ); ?></div>
        <?php endif; ?>
    </div>
</div>