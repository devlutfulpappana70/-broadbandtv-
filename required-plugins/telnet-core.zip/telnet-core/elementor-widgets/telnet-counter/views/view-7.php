<div class="tna-project-count-2-area flat_3 tna-fix">
    <span class="bg-shape-1 wow slideInLeft"></span>
    <span class="bg-shape-2 wow slideInRight"></span>
    <div class="tna-project-count-1-wrap">
        <?php foreach($settings['counters'] as $list) : ?>
        <div class="tna-project-count-1-item">
            <?php if(!empty( $list['counter_icon'] )) : ?>
            <div class="icon">
                <?php echo elh_element_render_icon($list, '', 'counter_icon'); ?>
            </div>
            <?php endif; ?>
            <div class="content-wrap">
                <?php if(!empty( $list['count_number'] )) : ?>
                <h3 class="tna-heading-1 number"><span class="odometer" data-count="<?php echo esc_html( $list['count_number'] ); ?>"></span><?php echo esc_html( $list['count_sing'] ); ?></h3>
                <?php endif; ?>

                <?php if(!empty( $list['count_title'] )) : ?>
                <p class="tna-para-1 disc"><?php echo elh_element_kses_intermediate( $list['count_title'] ); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>