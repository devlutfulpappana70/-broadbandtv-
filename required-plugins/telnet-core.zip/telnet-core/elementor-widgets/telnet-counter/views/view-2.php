<div class="wow <?php echo $settings['anim_name'] ? esc_attr($settings['anim_name']) : ''; ?>"
data-wow-delay="<?php echo $settings['anim_delay'] ? esc_attr($settings['anim_delay']) : ''; ?>"
data-wow-duration="<?php echo $settings['anim_duration'] ? esc_attr($settings['anim_duration']) : ''; ?>">
<div class="tx-counterItem tx-counterItem__styleTwo d-flex align-items-center">
    <?php if(!empty( $settings['counter_icon'] )) : ?>
    <div class="tx-icon d-flex align-items-center justify-content-center">
        <?php echo elh_element_render_icon($settings, '', 'counter_icon'); ?>
    </div>
    <?php endif; ?>
    <div class="tx-content headline text-uppercase pera-content">
        <?php if(!empty( $settings['count_number'] )) : ?>
        <h3 class="tx-count"><span class="counter" data-txCounter><?php echo esc_html( $settings['count_number'] ); ?></span></h3>
        <?php endif; ?>

        <?php if(!empty( $settings['count_title'] )) : ?>
        <p><?php echo elh_element_kses_intermediate( $settings['count_title'] ); ?></p>
        <?php endif; ?>
    </div>
</div>
</div>