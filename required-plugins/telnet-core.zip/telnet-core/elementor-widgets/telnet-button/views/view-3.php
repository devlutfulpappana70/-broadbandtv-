<div class="tel-btn-3 text-uppercase">
    <a href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>"><?php echo elh_element_kses_intermediate($settings['button_text']); ?><i class="fas fa-arrow-right"></i></a>
</div>