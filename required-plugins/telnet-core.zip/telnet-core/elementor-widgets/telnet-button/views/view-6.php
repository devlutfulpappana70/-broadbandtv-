<a href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>" class="tna-pr-btn-2">
    <?php if(!empty( $settings['button_text'] )) {
            echo elh_element_kses_intermediate($settings['button_text']);
        }
    ?>
    <?php \Elementor\Icons_Manager::render_icon( $settings['btn_icon'], [ 'aria-hidden' => 'true' ] ); ?>
</a>