<div class="tel-btn-1 text-uppercase">
    <a
    href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>"
    target="<?php echo esc_attr($settings['button_link']['is_external'] ? '_blank' : '_self'); ?>"
    rel="<?php echo esc_attr($settings['button_link']['nofollow'] ? 'nofollow' : ''); ?>"
    >
    <?php echo elh_element_kses_intermediate($settings['button_text']); ?>
    <?php if(!empty($settings['button_icon']['url'])):?>
        <img src="<?php echo esc_url($settings['button_icon']['url']);?>" alt="">
        <?php endif;?></a>
</div>