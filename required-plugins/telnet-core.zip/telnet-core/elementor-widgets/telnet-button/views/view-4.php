<div class="tel-btn-2 text-uppercase <?php echo esc_attr($button_class . $button_center); ?> text-uppercase">
    <a href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>"><?php echo elh_element_kses_intermediate($settings['button_text']); ?> <img src="<?php echo esc_url($settings['button_icon']['url']);?>" alt=""></a>
</div>