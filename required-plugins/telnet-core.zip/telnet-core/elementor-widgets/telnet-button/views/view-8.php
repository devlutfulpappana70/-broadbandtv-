<div class="btn-wrapper <?php echo esc_attr($button_center); ?>">
    <a class="tna-pr-btn-4" href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>">
        <?php if(!empty( $settings['button_text'] )) : ?>
        <span class="text">
            <?php echo elh_element_kses_intermediate($settings['button_text']); ?>
        </span>
        <?php endif; ?>
        <?php \Elementor\Icons_Manager::render_icon( $settings['btn_icon'], [ 'aria-hidden' => 'true' ] ); ?>
    </a>
</div>
