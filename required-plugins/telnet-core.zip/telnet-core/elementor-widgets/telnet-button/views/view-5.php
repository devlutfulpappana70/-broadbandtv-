<div class="service-one_button <?php echo esc_attr($button_class . $button_center); ?>">
    <a href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>" class="theme-btn btn-style-eighteen">
        <?php if(!empty( $settings['button_text'] )) : ?>
        <span class="txt"><?php echo elh_element_kses_intermediate($settings['button_text']); ?></span>
        <?php endif; ?>

        <?php \Elementor\Icons_Manager::render_icon( $settings['btn_icon'], [ 'aria-hidden' => 'true' ] ); ?>
    </a>
</div>