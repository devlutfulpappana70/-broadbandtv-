<?php if(!empty( $settings['button_text'] )) : ?>
<a href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>" class="tx-button tx-button__styleTheme <?php echo esc_attr($button_class . $button_center); ?>">
    <?php echo elh_element_kses_intermediate($settings['button_text']); ?>
</a>
<?php endif; ?>