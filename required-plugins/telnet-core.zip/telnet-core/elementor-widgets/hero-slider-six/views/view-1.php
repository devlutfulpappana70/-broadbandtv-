<div class="tna-hero-3-area flat_3 bg-default" tna-data-background="<?php echo $settings['bg_image']['url'] ? esc_attr($settings['bg_image']['url']) : ''; ?>" >
    <div class="tna-hero-3-wrap">
        <div class="container tna-container-1">
            <div class="tna-hero-3-slider swiper">
                <div class="swiper-container tna_hero_3_active">
                    <div class="swiper-wrapper">

                        <?php foreach($settings['slides'] as $slide) :
                            if ($slide['currency'] === 'custom') {
                                $currency = $slide['currency_custom'];
                            } else {
                                $currency = self::get_currency_symbol($slide['currency']);
                            }
                        ?>
                        <div class="swiper-slide">
                            <div class="tna-hero-3-item">

                                <?php if(!empty( $slide['image_1']['url'] )) : ?>
                                <img src="<?php echo esc_url($slide['image_1']['url']); ?>" alt="" class="il-raoter">
                                <?php endif; ?>

                                <?php if(!empty( $slide['title'] )) : ?>
                                <h1 class="tna-heading-2 title"><?php echo elh_element_kses_intermediate($slide['title']); ?></h1>
                                <?php endif; ?>

                                <?php if(!empty( $slide['title_bottom'] )) : ?>
                                <h1 class="tna-heading-2 title-2"><?php echo elh_element_kses_intermediate($slide['title_bottom']); ?></h1>
                                <?php endif; ?>

                                <?php if(!empty( $slide['description'] )) : ?>
                                <p class="tna-para-2 disc"><?php echo elh_element_kses_intermediate($slide['description']); ?></p>
                                <?php endif; ?>

                                <?php if(!empty( $slide['button_text'] )) : ?>
                                <a class="tna-pr-btn-4 mb-20" >
                                    <span class="text"><?php echo elh_element_kses_intermediate($slide['button_text']); ?></span>
                                    <?php \Elementor\Icons_Manager::render_icon( $slide['btn_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                </a>
                                <?php endif; ?>

                                <div class="ultra-fast-wrap mb-40">
                                    <?php if(!empty( $settings['shape_image']['url'] )) : ?>
                                    <img src="<?php echo esc_url($settings['shape_image']['url']); ?>" alt="" class="il-shape">
                                    <?php endif; ?>
                                    <div class="ultra-fast">
                                        <?php if(!empty( $slide['speed_title'] )) : ?>
                                        <span class="tna-para-2"><?php echo elh_element_kses_intermediate($slide['speed_title']); ?></span>
                                        <?php endif; ?>

                                        <?php if(!empty( $slide['speed_value'] )) : ?>
                                        <h5 class="tna-heading-2"><?php echo elh_element_kses_intermediate($slide['speed_value']); ?></h5>
                                        <?php endif; ?>

                                        <?php if(!empty( $slide['speed_unit'] )) : ?>
                                        <span class="tna-para-2"><?php echo elh_element_kses_intermediate($slide['speed_unit']); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>


                                <div class="tna-services-1-price ">
                                    <h3 class="tna-heading-1 price"><span class="dollar-sing"><?php echo esc_html($currency); ?></span><?php echo elh_element_kses_intermediate($slide['price']); ?>

                                    <?php if(!empty( $slide['period'] )) : ?>
                                    <span class="month"><?php echo elh_element_kses_intermediate($slide['period']); ?></span></h3>
                                    <?php endif; ?>

                                    <?php if(!empty( $slide['package_feature'] )) : ?>
                                    <p class="tna-para-1 para"><?php echo elh_element_kses_intermediate($slide['package_feature']); ?></p>
                                    <?php endif; ?>
                                </div>
                                <div class="tna-hero-3-img-position">
                                    <div class="tna-hero-3-img">
                                        <?php if(!empty( $slide['image_2']['url'] )) : ?>
                                        <img class="li-shape-1" src="<?php echo esc_url($slide['image_2']['url']); ?>" alt="">
                                        <?php endif; ?>

                                        <?php if(!empty( $slide['image_3']['url'] )) : ?>
                                        <img src="<?php echo esc_url($slide['image_3']['url']); ?>" alt="" class="main-img">
                                        <?php endif; ?>
                                    </div>
                                </div>


                                <?php if( $settings['enable_counter'] === 'yes' ) : ?>
                                <div class="tna-hero-3-counter-wrap">
                                    <?php foreach($slide['counter_lists'] as $list) : ?>
                                    <div class="tna-hero-3-counter-item">
                                        <?php if(!empty( $list['counter_value'] )) : ?>
                                        <h4 class="number"><?php echo elh_element_kses_intermediate($list['counter_value']); ?></h4>
                                        <?php endif; ?>

                                        <?php if(!empty( $list['counter_title'] )) : ?>
                                        <p class="tna-para-2 disc"><?php echo elh_element_kses_intermediate($list['counter_title']); ?></p>
                                        <?php endif; ?>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <?php if( $settings['enable_slider_nav'] === 'yes' ) : ?>
        <div class="tna_hero_3_next-position">
            <div class="tna_hero_3_next">
                <i class="fas fa-chevron-right"></i>
            </div>
        </div>

        <div class="tna_hero_3_prev-position">
            <div class="tna_hero_3_prev">
                <i class="fas fa-chevron-left"></i>
            </div>
        </div>
        <?php endif; ?>

    </div>
</div>