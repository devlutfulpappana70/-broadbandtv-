<?php
namespace ElementHelper\Widget;

use \Elementor\Group_Control_Background;
use \Elementor\Repeater;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Typography;
use \ElementHelper\Element_El_Select2;
use \Elementor\Core\Schemes\Typography;
use \Elementor\Utils;
use \Elementor\Control_Media;

defined( 'ABSPATH' ) || die();

class Hero_Slider_Six extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'hero_slider_six';
    }


    /**
     * Get widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Hero Slider Six', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/slider/';
    }

    /**
     * Get widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-slider-full-screen';
    }

    public function get_keywords() {
        return [ 'slider', 'image', 'gallery', 'carousel' ];
    }

    protected function register_content_controls() {

        $this->start_controls_section(
            '_section_design_title',
            [
                'label' => __( 'Design Style', 'telnet-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'design_style',
            [
                'label' => __( 'Design Style', 'telnet-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'telnet-core' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        $this->end_controls_section();


        // section images
        $this->start_controls_section(
            '_section_images',
            [
                'label' => __( 'Images', 'telnet-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        // bg image
        $this->add_control(
            'bg_image',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Bg Image', 'telnet-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        // shape image
        $this->add_control(
            'shape_image',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Shape Image', 'telnet-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_slides',
            [
                'label' => __( 'SLIDE ITEMS', 'telnet-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        // SHAPE IMAGE
        $repeater->add_control(
            'image_1',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Image', 'telnet-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        // image 2
        $repeater->add_control(
            'image_2',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Image 2', 'telnet-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        // image 3
        $repeater->add_control(
            'image_3',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Image 3', 'telnet-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        // CONTENT HEADING
        $repeater->add_control(
            'heading_content',
            [
                'label' => __( 'CONTENT', 'telnet-core' ),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $repeater->add_control(
            'title',
            [
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'label' => __( 'Title', 'telnet-core' ),
                'default' => __( 'Title Here', 'telnet-core' ),
                'placeholder' => __( 'Type title here', 'telnet-core' ),
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        // title bottom
        $repeater->add_control(
            'title_bottom',
            [
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'label' => __( 'Title Bottom', 'telnet-core' ),
                'default' => __( 'Title Bottom Here', 'telnet-core' ),
                'placeholder' => __( 'Type title bottom here', 'telnet-core' ),
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'description',
            [
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'label' => __( 'Description', 'telnet-core' ),
                'default' => __( 'Description Here', 'telnet-core' ),
                'placeholder' => __( 'Type title here', 'telnet-core' ),
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        // heading field
        $repeater->add_control(
            'heading_button',
            [
                'label' => __( 'BUTTON', 'telnet-core' ),
                'type' => Controls_Manager::HEADING,
            ]
        );

        // BUTTON TEXT
        $repeater->add_control(
            'button_text',
            [
                'label'       => __( 'Text', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Button Text', 'telnet-core' ),
                'placeholder' => __( 'Type button text here', 'telnet-core' ),
                'label_block' => true,
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );
        // button icns
        $repeater->add_control(
            'btn_icon',
            [
                'label'       => __( 'Button Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'default'     => [
                    'value'   => 'fas fa-arrow-right',
                    'library' => 'solid',
                ],
                'label_block' => true,
            ]
        );

        // BUTTON LINK
        $repeater->add_control(
            'button_link',
            [
                'label'       => __( 'Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'placeholder' => __( 'http://elementor.themexriver.com', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
                'default' => [
					'url' => 'http://elementor.themexriver.com',
					'is_external' => true,
					'nofollow' => true,
				],
            ]
        );

        // SPEED HEADING
        $repeater->add_control(
            'heading_speed',
            [
                'label' => __( 'SPEED', 'telnet-core' ),
                'type' => Controls_Manager::HEADING,
            ]
        );

        // SPEED TITLE
        $repeater->add_control(
            'speed_title',
            [
                'label' => __( 'Title', 'telnet-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'Speed Title', 'telnet-core' ),
                'dynamic' => [
                    'active' => true
                ]
            ]
        );

        // SPEED VALUE
        $repeater->add_control(
            'speed_value',
            [
                'label' => __( 'Value', 'telnet-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( '100', 'telnet-core' ),
                'dynamic' => [
                    'active' => true
                ]
            ]
        );

        // SPEED UNIT
        $repeater->add_control(
            'speed_unit',
            [
                'label' => __( 'Unit', 'telnet-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'Mbps', 'telnet-core' ),
                'dynamic' => [
                    'active' => true
                ]
            ]
        );

        // PACKAGE PRICE HEADING
        $repeater->add_control(
            'heading_package_price',
            [
                'label' => __( 'PACKAGE PRICE', 'telnet-core' ),
                'type' => Controls_Manager::HEADING,
            ]
        );

        // CURRENCY SYMBOL
        $repeater->add_control(
            'currency',
            [
                'label' => __('Currency', 'telnet-core'),
                'type' => Controls_Manager::SELECT,
                'label_block' => false,
                'options' => [
                    '' => __('None', 'telnet-core'),
                    'baht' => '&#3647; ' . _x('Baht', 'Currency Symbol', 'telnet-core'),
                    'bdt' => '&#2547; ' . _x('BD Taka', 'Currency Symbol', 'telnet-core'),
                    'dollar' => '&#36; ' . _x('Dollar', 'Currency Symbol', 'telnet-core'),
                    'euro' => '&#128; ' . _x('Euro', 'Currency Symbol', 'telnet-core'),
                    'franc' => '&#8355; ' . _x('Franc', 'Currency Symbol', 'telnet-core'),
                    'guilder' => '&fnof; ' . _x('Guilder', 'Currency Symbol', 'telnet-core'),
                    'krona' => 'kr ' . _x('Krona', 'Currency Symbol', 'telnet-core'),
                    'lira' => '&#8356; ' . _x('Lira', 'Currency Symbol', 'telnet-core'),
                    'peseta' => '&#8359 ' . _x('Peseta', 'Currency Symbol', 'telnet-core'),
                    'peso' => '&#8369; ' . _x('Peso', 'Currency Symbol', 'telnet-core'),
                    'pound' => '&#163; ' . _x('Pound Sterling', 'Currency Symbol', 'telnet-core'),
                    'real' => 'R$ ' . _x('Real', 'Currency Symbol', 'telnet-core'),
                    'ruble' => '&#8381; ' . _x('Ruble', 'Currency Symbol', 'telnet-core'),
                    'rupee' => '&#8360; ' . _x('Rupee', 'Currency Symbol', 'telnet-core'),
                    'indian_rupee' => '&#8377; ' . _x('Rupee (Indian)', 'Currency Symbol', 'telnet-core'),
                    'shekel' => '&#8362; ' . _x('Shekel', 'Currency Symbol', 'telnet-core'),
                    'won' => '&#8361; ' . _x('Won', 'Currency Symbol', 'telnet-core'),
                    'yen' => '&#165; ' . _x('Yen/Yuan', 'Currency Symbol', 'telnet-core'),
                    'custom' => __('Custom', 'telnet-core'),
                ],
                'default' => 'dollar',
            ]
        );

        // PRICE
        $repeater->add_control(
            'price',
            [
                'label' => __('Price', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '9.99',
                'dynamic' => [
                    'active' => true
                ]
            ]
        );

        // PERIOD
        $repeater->add_control(
            'period',
            [
                'label' => __('Period', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Per Month', 'telnet-core'),
                'dynamic' => [
                    'active' => true
                ],
            ]
        );

        $repeater->add_control(
            'package_feature',
            [
                'label' => __('Package Feature Text', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Ultra Fast inernet', 'telnet-core'),
                'label_block' => true,
                'dynamic' => [
                    'active' => true
                ],
            ]
        );

        // COUNTER HEADING
        $repeater->add_control(
            'heading_counter',
            [
                'label' => __( 'COUNTER', 'telnet-core' ),
                'type' => Controls_Manager::HEADING,
            ]
        );

        // counter lists
        $repeater->add_control(
            'counter_lists',
            [
                'label' => __( 'Counter Lists', 'telnet-core' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'counter_title',
                        'label' => __( 'Title', 'telnet-core' ),
                        'type' => Controls_Manager::TEXT,
                        'default' => __( 'Counter Title', 'telnet-core' ),
                        'label_block' => true,
                        'dynamic' => [
                            'active' => true,
                        ],
                    ],
                    [
                        'name' => 'counter_value',
                        'label' => __( 'Value', 'telnet-core' ),
                        'type' => Controls_Manager::TEXT,
                        'default' => __( '100', 'telnet-core' ),
                        'label_block' => true,
                        'dynamic' => [
                            'active' => true,
                        ],
                    ],
                ],
                'title_field' => '{{{ counter_title }}}',
            ]
        );


        // ALL SLIDES
        $this->add_control(
            'slides',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '<# print(title || "Carousel Item"); #>',
                'default' => [
                    [
                        'image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                ]
            ]
        );

        $this->end_controls_section();

        // settings
        $this->start_controls_section(
            '_section_settings',
            [
                'label' => __( 'Settings', 'telnet-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        // enable slider nav
        $this->add_control(
            'enable_slider_nav',
            [
                'label' => __( 'Enable Slider Nav', 'telnet-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'telnet-core' ),
                'label_off' => __( 'Hide', 'telnet-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        // enable counter section
        $this->add_control(
            'enable_counter',
            [
                'label' => __( 'Enable Counter', 'telnet-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'telnet-core' ),
                'label_off' => __( 'Hide', 'telnet-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );


        // end settings
        $this->end_controls_section();


    }

    protected function register_style_controls() {
        $dir = dirname( __FILE__ );

        include $dir . '/styles/slide-style.php';
        include $dir . '/styles/title-style.php';
        include $dir . '/styles/description-style.php';
        include $dir . '/styles/price-style.php';
        include $dir . '/styles/button-style.php';

    }

    private static function get_currency_symbol($symbol_name)
    {
        $symbols = [
            'baht' => '&#3647;',
            'bdt' => '&#2547;',
            'dollar' => '&#36;',
            'euro' => '&#128;',
            'franc' => '&#8355;',
            'guilder' => '&fnof;',
            'indian_rupee' => '&#8377;',
            'pound' => '&#163;',
            'peso' => '&#8369;',
            'peseta' => '&#8359',
            'lira' => '&#8356;',
            'ruble' => '&#8381;',
            'shekel' => '&#8362;',
            'rupee' => '&#8360;',
            'real' => 'R$',
            'krona' => 'kr',
            'won' => '&#8361;',
            'yen' => '&#165;',
        ];

        return isset($symbols[$symbol_name]) ? $symbols[$symbol_name] : '';
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $dir = dirname( __FILE__ );
        $style = !empty($settings['design_style']) ? $settings['design_style'] : 'style_1';

        switch ($style) {
            case 'style_2':
                include $dir . '/views/view-2.php';
                break;
            default:
                include $dir . '/views/view-1.php';
        }
    }
}