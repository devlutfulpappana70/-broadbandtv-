<div class="swiper tna-testimonial-3-slider flat_3">
    <div class="swiper-container tna_t3_active">
        <div class="swiper-wrapper">

            <?php foreach( $settings['testimonial_lists'] as $list ) : ?>
            <div class="swiper-slide">
                <div class="tna-testimonial-3-item">
                    <?php if(!empty( $list['big_image']['url'] )) : ?>
                    <div class="main-img tna-img-cover">
                        <img src="<?php echo esc_url($list['big_image']['url']); ?>" alt="">
                    </div>
                    <?php endif; ?>
                    <div class="content-wrap">
                        <div class="reating">
                            <?php
                                for ( $i = 1; $i < $list['rating_star']; $i++ ) {
                                    echo '<span class="fa fa-star"></span>';
                                }
                            ?>
                        </div>
                        <?php if(!empty( $list['comment'] )) : ?>
                        <p class="tna-heading-2 comment"><?php echo elh_element_kses_intermediate($list['comment']); ?></p>
                        <?php endif; ?>
                        <div class="person-wrap">
                            <?php if(!empty( $list['image']['url'] )) : ?>
                            <div class="person-img">
                                <img src="<?php echo esc_url($list['image']['url']); ?>" alt="">
                            </div>
                            <?php endif; ?>

                            <div class="person-name-wrap">
                            <?php if(!empty( $list['name'] )) : ?>
                                <h5 class="tna-heading-2 person-name"><?php echo elh_element_kses_intermediate($list['name']); ?></h5>
                            <?php endif; ?>
                            <?php if(!empty( $list['designation'] )) : ?>
                                <span class="tna-para-2 bio"><?php echo elh_element_kses_intermediate($list['designation']); ?></span>
                            <?php endif; ?>
                            </div>

                            <?php if(!empty( $list['quote_icon'] )) : ?>
                            <div class="icon">
                                <?php \Elementor\Icons_Manager::render_icon( $list['quote_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>

        </div>
    </div>

    <div class="btn-wrap">
        <div class="tna_t3_prev"><i class="far fa-angle-left"></i></div>
        <div class="tna_t3_next"><i class="far fa-angle-right"></i></div>
    </div>
</div>