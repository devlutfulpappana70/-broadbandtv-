<?php

namespace ElementHelper\Widget;


use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
use \Elementor\Core\Schemes\Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;

defined( 'ABSPATH' ) || die();

class Testimonial_Five extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name() {
        return 'testimonial_five';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title() {
        return __( 'Testimonial Five', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/gradient-heading/';
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-t-letter';
    }

    public function get_keywords() {
        return ['count', 'telnet', 'telnet testimonial', 'testimonial', 'telnet testimonial widget'];
    }

    protected function register_content_controls() {

         //Settings
         $this->start_controls_section(
            '_section_settings',
            [
                'label' => __( 'Settings', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'design_style',
            [
                'label'              => __( 'Design Style', 'telnet-core' ),
                'type'               => Controls_Manager::SELECT,
                'options'            => [
                    'style_1' => __( 'Style 1', 'telnet-core' ),
                ],
                'default'            => 'style_1',
                'frontend_available' => true,
                'style_transfer'     => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_testimonial',
            [
                'label' => __( 'Testimonial', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // repeater
        $repeater = new Repeater();

        // big image
        $repeater->add_control(
            'big_image',
            [
                'label'   => __( 'Big Image', 'telnet-core' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        // image
        $repeater->add_control(
            'image',
            [
                'label'   => __( 'Author Image', 'telnet-core' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        // content
        $repeater->add_control(
            'comment',
            [
                'label'       => __( 'Comment', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => __( 'Enter your content', 'telnet-core' ),
                'default'     => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'telnet-core' ),
            ]
        );


        // name
        $repeater->add_control(
            'name',
            [
                'label'       => __( 'Name', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter your name', 'telnet-core' ),
                'default'     => __( 'John Doe', 'telnet-core' ),
            ]
        );

        // designation
        $repeater->add_control(
            'designation',
            [
                'label'       => __( 'Designation', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter your designation', 'telnet-core' ),
                'default'     => __( 'CEO', 'telnet-core' ),
            ]
        );

        // choose type
        $repeater->add_control(
            'rating_star',
            [
                'label'   => __( 'Rating Star', 'telnet-core' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    '1' => __( '1 Star', 'telnet-core' ),
                    '2' => __( '2 Star', 'telnet-core' ),
                    '3' => __( '3 Star', 'telnet-core' ),
                    '4' => __( '4 Star', 'telnet-core' ),
                    '5' => __( '5 Star', 'telnet-core' ),
                ],
                'default' => '5',
            ]
        );

        // quote icons
        $repeater->add_control(
            'quote_icon',
            [
                'label'       => __( 'Button Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'default'     => [
                    'value'   => 'fas fa-arrow-right',
                    'library' => 'solid',
                ],
                'label_block' => true,
            ]
        );


        $this->add_control(
            'testimonial_lists',
            [
                'label'       => __( 'Testimonial Lists', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ name }}}',
            ]
        );

        $this->end_controls_section();

    }

    protected function register_style_controls() {


    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $dir = dirname( __FILE__ );
        $style = !empty($settings['design_style']) ? $settings['design_style'] : 'style_1';

        switch ($style) {
            case 'style_2':
                include $dir . '/views/view-2.php';
                break;
            default:
                include $dir . '/views/view-1.php';
        }
    }
}
