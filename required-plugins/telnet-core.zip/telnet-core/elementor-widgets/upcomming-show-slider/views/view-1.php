<div class="tx-movieSliderWrapper">
     <!-- slider navigation -->
     <div class="outer-wrapper d-flex aling-items-center justify-content-end">
        <div class="tx-slideNav tx-slideNav__styleTop">
            <div class="swiper-button-prev">
                <i class="fa-regular fa-arrow-left"></i>
            </div>
            <div class="swiper-button-next">
                <i class="fa-regular fa-arrow-right"></i>
            </div>
        </div>
     </div>
    <div class="swiper-container mt-55" data-txMovieSlider>
        <div class="swiper-wrapper">
            <?php if ( !empty( $settings['slide_lists'] ) ) : foreach ( $settings['slide_lists'] as $key => $list ): ?>
            <div class="swiper-slide">
                <div class="tx-movieBlock tx-movieBlock__styleOne position-relative">
                    <?php if(!empty( $list['show_image']['url'] )) : ?>
                    <div class="tx-thumb">
                        <img class="w-100" src="<?php echo esc_url($list['show_image']['url']); ?>" alt="">
                    </div>
                    <?php endif; ?>
                    <a href="<?php echo esc_url($list['show_link']['url']); ?>" class="tx-videoBtn position-absolute start-50 top-50 translate-middle" data-rel="lightcase">
                        <?php echo elh_element_render_icon($list, '', 'show_icon'); ?>
                    </a>
                </div>
            </div>
            <?php endforeach; endif; ?>
        </div>
    </div>
</div>
