<ul class="footer-2-social list-unstyled">
    <?php foreach($settings['social_list_lists'] as $list ) : ?>
    <li>
        <a href="<?php echo esc_url($list['social_list_link']['url']); ?>">
            <?php if($list['social_list_btn_type'] == 'icon') : ?>
                <?php \Elementor\Icons_Manager::render_icon( $list['social_list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
            <?php else : ?>
                <img src="<?php echo esc_url($list['social_list_image']['url']); ?>" alt="" />
            <?php endif; ?>
        </a>
    </li>
    <?php endforeach; ?>
</ul>