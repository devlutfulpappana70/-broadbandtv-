<?php

namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Core\Schemes\Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Background;
use \Elementor\Utils;

defined( 'ABSPATH' ) || die();

class Pricing_Table_Two extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name() {
        return 'pricing_table_two';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title() {
        return __( 'Pricing Table Two', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/gradient-heading/';
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-t-letter';
    }

    public function get_keywords() {
        return ['pricing', 'telnet', 'telnet pricing', 'price'];
    }

    protected function register_content_controls() {


        $this->start_controls_section(
            '_section_price',
            [
                'label' => __( 'Price', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
			'active',
			[
				'label' => esc_html__( 'Active', 'telnet-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'YES', 'telnet-core' ),
				'label_off' => esc_html__( 'NO', 'telnet-core' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
        // title
        $this->add_control(
            'p_bg',
            [
                'label' => __('Pricing  BG', 'telnet-core'),
                'type' => Controls_Manager::MEDIA,
                'condition' => [
                    'active' => 'yes',
                ],
                'dynamic' => [
                    'active' => true
                ],
            ]
        );
        $this->add_control(
            'title',
            [
                'label' => __('Title', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('UITRA FAST INTERNET', 'telnet-core'),
                'dynamic' => [
                    'active' => true
                ],
            ]
        );
        $this->add_control(
            'desc',
            [
                'label' => __('Description', 'telnet-core'),
                'type' => Controls_Manager::TEXTAREA,
                'dynamic' => [
                    'active' => true
                ],
            ]
        );
        $this->add_control(
            'package_feature_lists',
            [
                'label' => __('Package List', 'telnet-core'),
                'type' => Controls_Manager::TEXTAREA,
                'dynamic' => [
                    'active' => true
                ],
            ]
        );
        $this->add_control(
            'currency',
            [
                'label' => __('Currency', 'telnet-core'),
                'type' => Controls_Manager::SELECT,
                'label_block' => false,
                'options' => [
                    '' => __('None', 'telnet-core'),
                    'baht' => '&#3647; ' . _x('Baht', 'Currency Symbol', 'telnet-core'),
                    'bdt' => '&#2547; ' . _x('BD Taka', 'Currency Symbol', 'telnet-core'),
                    'dollar' => '&#36; ' . _x('Dollar', 'Currency Symbol', 'telnet-core'),
                    'euro' => '&#128; ' . _x('Euro', 'Currency Symbol', 'telnet-core'),
                    'franc' => '&#8355; ' . _x('Franc', 'Currency Symbol', 'telnet-core'),
                    'guilder' => '&fnof; ' . _x('Guilder', 'Currency Symbol', 'telnet-core'),
                    'krona' => 'kr ' . _x('Krona', 'Currency Symbol', 'telnet-core'),
                    'lira' => '&#8356; ' . _x('Lira', 'Currency Symbol', 'telnet-core'),
                    'peseta' => '&#8359 ' . _x('Peseta', 'Currency Symbol', 'telnet-core'),
                    'peso' => '&#8369; ' . _x('Peso', 'Currency Symbol', 'telnet-core'),
                    'pound' => '&#163; ' . _x('Pound Sterling', 'Currency Symbol', 'telnet-core'),
                    'real' => 'R$ ' . _x('Real', 'Currency Symbol', 'telnet-core'),
                    'ruble' => '&#8381; ' . _x('Ruble', 'Currency Symbol', 'telnet-core'),
                    'rupee' => '&#8360; ' . _x('Rupee', 'Currency Symbol', 'telnet-core'),
                    'indian_rupee' => '&#8377; ' . _x('Rupee (Indian)', 'Currency Symbol', 'telnet-core'),
                    'shekel' => '&#8362; ' . _x('Shekel', 'Currency Symbol', 'telnet-core'),
                    'won' => '&#8361; ' . _x('Won', 'Currency Symbol', 'telnet-core'),
                    'yen' => '&#165; ' . _x('Yen/Yuan', 'Currency Symbol', 'telnet-core'),
                    'custom' => __('Custom', 'telnet-core'),
                ],
                'default' => 'dollar',
            ]
        );

        $this->add_control(
            'currency_custom',
            [
                'label' => __('Custom Symbol', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'condition' => [
                    'currency' => 'custom',
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        // PRICE
        $this->add_control(
            'price',
            [
                'label' => __('Price', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '9.99',
                'dynamic' => [
                    'active' => true
                ]
            ]
        );

        // PERIOD
        $this->add_control(
            'period',
            [
                'label' => __('Period', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Per Month', 'telnet-core'),
                'dynamic' => [
                    'active' => true
                ],
            ]
        );
        $this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'check-thumb-shape',
				'types' => [ 'classic' ],
				'exclude' => [ 'color' ],
				'selector' => '{{WRAPPER}} .tel-pricing-item-3 .tel-price-list ul li:before',
                'fields_options' => [
                    'background' => [
                        'label' => esc_html__( 'Check Icon Image', 'invite-plugin' ),
                        'separator' => 'before',
                    ]
                ]
			]
		);
        $this->add_control(
            'button_text',
            [
                'label'       => __( 'Button Text', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __( 'Tab Button Text', 'telnet-core' ),
                'placeholder' => __( 'Type Tab Button Text', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );

        // tab button link
        $this->add_control(
            'button_link',
            [
                'label'       => __( 'Button Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'label_block' => true,
                'default'     => [
                    'url' => '#',
                ],
                'placeholder' => __( 'https://your-link.com', 'telnet-core' ),
            ]
        );
        
        $repeater = new \Elementor\Repeater();

        // list image
        $repeater->add_control(
            'icon',
            [
                'label'       => __( 'Badge Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'label_block' => true,
            ]
        );


        // slide items
        $this->add_control(
            'badges',
            [
                'label'       => __( 'Items', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
            ]
        );
        
        $this->end_controls_section();


    }

    protected function register_style_controls() {

    }

    private static function get_currency_symbol($symbol_name)
    {
        $symbols = [
            'baht' => '&#3647;',
            'bdt' => '&#2547;',
            'dollar' => '&#36;',
            'euro' => '&#128;',
            'franc' => '&#8355;',
            'guilder' => '&fnof;',
            'indian_rupee' => '&#8377;',
            'pound' => '&#163;',
            'peso' => '&#8369;',
            'peseta' => '&#8359',
            'lira' => '&#8356;',
            'ruble' => '&#8381;',
            'shekel' => '&#8362;',
            'rupee' => '&#8360;',
            'real' => 'R$',
            'krona' => 'kr',
            'won' => '&#8361;',
            'yen' => '&#165;',
        ];

        return isset($symbols[$symbol_name]) ? $symbols[$symbol_name] : '';
    }

    protected function render() {

        $settings = $this->get_settings_for_display();
        
        if ($settings['currency'] === 'custom') {
            $currency = $settings['currency_custom'];
        } else {
            $currency = self::get_currency_symbol($settings['currency']);
        }
        ?>
    <div class="tel-price-item-4 text-center <?php if($settings['active'] == 'yes'){echo esc_attr('active');}?>">
        <span class="plan-title text-uppercase"><?php echo wp_kses($settings['title'], true);?></span>
        <div class="plan-price">
            <h3><?php if(!empty( $currency )) : ?>
                        <sub><?php echo esc_html($currency); ?></sub>
                    <?php endif; ?>
                    <?php if(!empty( $settings['price'] )) : ?>
                        <?php echo esc_html($settings['price']); ?>
                    <?php endif;?></h3>

                <?php if(!empty( $settings['period'] )) : ?>
                    <span class="plan-duration text-uppercase"><?php echo esc_html($settings['period']); ?></span>
                <?php endif;?>
        </div>
        <?php if(!empty($settings['badges'])):?>
        <div class="price-plan-icon ul-li">
            <ul>
                <?php foreach($settings['badges'] as $item):?>
                    <li><?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?></li>
                <?php endforeach;?>
            </ul>
        </div>
        <?php endif;?>
        <div class="price-plan-list ul-li-block">
            <ul>
                <?php 
                    $list_item = $settings['package_feature_lists'];
                    $list_item = explode("\n", ($list_item));
                    foreach($list_item as $list):
                ?>
                <li><?php echo wp_kses($list, true)?></li>
                <?php endforeach;?>
            </ul>
        </div>
        <?php if(!empty($settings['button_text'])):?>
            <div class="tel-btn-2 text-uppercase">
                <a href="<?php echo esc_url($settings['button_link']['url']);?>"><?php echo esc_html($settings['button_text']);?></a>
            </div>
        <?php endif;?>
    </div>
    <?php }
}
