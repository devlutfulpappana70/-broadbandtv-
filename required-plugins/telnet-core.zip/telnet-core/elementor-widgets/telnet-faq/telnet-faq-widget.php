<?php

namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
use \Elementor\Core\Schemes\Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;

defined( 'ABSPATH' ) || die();

class Telnet_Faq extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name() {
        return 'telnet_faq';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title() {
        return __( 'TelNet Faq', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/gradient-heading/';
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-t-letter';
    }

    public function get_keywords() {
        return ['btn', 'faq', 'telnet', 'telnet faq'];
    }

    protected function register_content_controls() {

        //Settings
        $this->start_controls_section(
            '_section_settings',
            [
                'label' => __( 'Settings', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'design_style',
            [
                'label'              => __( 'Design Style', 'telnet-core' ),
                'type'               => Controls_Manager::SELECT,
                'options'            => [
                    'style_1' => __( 'Style 1', 'telnet-core' ),
                    'style_2' => __( 'Style 2', 'telnet-core' ),
                ],
                'default'            => 'style_1',
                'frontend_available' => true,
                'style_transfer'     => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_title',
            [
                'label' => __( 'Lists', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        // faq title
        $repeater->add_control(
            'title',
            [
                'label'       => __( 'Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Faq Title', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        // faq content
        $repeater->add_control(
            'content',
            [
                'label'       => __( 'Content', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'default'     => __( 'Faq Content', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        // faq lists
        $this->add_control(
            'faq_lists',
            [
                'label'       => __( 'Lists', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [
                    [
                        'title'   => __( 'Faq Title #1', 'telnet-core' ),
                        'content' => __( 'Faq Content #1', 'telnet-core' ),
                    ],
                    [
                        'title'   => __( 'Faq Title #2', 'telnet-core' ),
                        'content' => __( 'Faq Content #2', 'telnet-core' ),
                    ],
                    [
                        'title'   => __( 'Faq Title #3', 'telnet-core' ),
                        'content' => __( 'Faq Content #3', 'telnet-core' ),
                    ],
                ],
                'title_field' => '{{{ title }}}',
            ]
        );


        $this->end_controls_section();

    }

    protected function register_style_controls() {

        // count style
        $this->start_controls_section(
            '_section_count_style',
            [
                'label' => __( 'Count Text', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // count color
        $this->add_control(
            'box_bg_color',
            [
                'label'     => __( 'Faq Title Box BG Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-faqItem, .tx-faqWrapper .tx-title' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'title_color',
            [
                'label'     => __( 'Title Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-faqWrapper .tx-title' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'plus_bg_color',
            [
                'label'     => __( 'Icon BG Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-faqWrapper .tx-title::after' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'plus_color',
            [
                'label'     => __( 'Icon Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-faqWrapper .tx-title::after' => 'color: {{VALUE}};',
                ],
            ]
        );

        // typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'boc_typography',
                'label'    => __( 'Feedbacy Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-faqWrapper .tx-title',
            ]
        );
        $this->add_control(
            'desc_color',
            [
                'label'     => __( 'Desc Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-faqWrapper .tx-content p' => 'color: {{VALUE}};',
                ],
            ]
        );


        // typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'desc_typography',
                'label'    => __( 'Feedbacy Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-faqWrapper .tx-content p',
            ]
        );
        // count end
        $this->end_controls_section();

    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $dir = dirname( __FILE__ );
        $style = !empty($settings['design_style']) ? $settings['design_style'] : 'style_1';

        switch ($style) {
            case 'style_2':
                include $dir . '/views/view-2.php';
                break;
            default:
                include $dir . '/views/view-1.php';
        }
    }
}
