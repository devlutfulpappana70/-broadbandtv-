<div class="tx-faqWrapper tx-faqWrapper__styleOne">
    <?php $rnad_id = rand( 1245, 6698 ); ?>
    <div class="tx-faqLists" id="accordionFaq-<?php print esc_attr( $rnad_id );?>">
        <?php foreach ($settings['faq_lists'] as $id => $list) :
            $collapsed_tab = ($id == 0) ? '' : 'collapsed';
            $area_expanded = ($id == 0) ? 'true' : 'false';
            $active_show_tab = ($id == 0) ? 'show' : '';
        ?>
        <div class="tx-faqItem">
            <h6
                class="accordion-header"
                id="heading-<?php print esc_attr( $rnad_id );?>-<?php echo esc_attr( $id ); ?>">
                <button
                    class="accordion-button tx-title <?php echo esc_attr($collapsed_tab); ?>"
                    type="button" data-bs-toggle="collapse"
                    data-bs-target="#collapse-<?php print esc_attr( $rnad_id );?>-<?php echo esc_attr( $id ); ?>"
                    aria-expanded="<?php echo esc_attr($area_expanded); ?>"
                    aria-controls="collapse-<?php print esc_attr( $rnad_id );?>-<?php echo esc_attr( $id ); ?>">
                    <?php echo elh_element_kses_intermediate($list['title']); ?>
                </button>
            </h6>
            <div
                id="collapse-<?php print esc_attr( $rnad_id );?>-<?php echo esc_attr( $id ); ?>"
                class="accordion-collapse collapse <?php echo esc_attr($active_show_tab); ?>"
                aria-labelledby="heading-<?php print esc_attr( $rnad_id );?>-<?php echo esc_attr( $id ); ?>"
                data-bs-parent="#accordionFaq-<?php print esc_attr( $rnad_id );?>">
                <div class="accordion-body tx-content">
                    <p><?php echo elh_element_kses_intermediate($list['content']); ?></p>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>