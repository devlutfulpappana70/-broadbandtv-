<?php $rnad_id = rand( 1245, 6698 ); ?>
<div class="tna-faq-2-wrap">
    <div class="accordion tna-faq-2-item" id="accordionExample_31">
        <?php foreach ($settings['faq_lists'] as $id => $list) :
            $collapsed_tab = ($id == 0) ? '' : 'collapsed';
            $area_expanded = ($id == 0) ? 'true' : 'false';
            $active_show_tab = ($id == 0) ? 'show' : '';
        ?>
        <div class="accordion-item tna_faq2_bg" >
            <h2 class="accordion-header" id="heading17">
                <button class="accordion-button <?php echo esc_attr($collapsed_tab); ?>"
                type="button" data-bs-toggle="collapse"
                data-bs-target="#collapse-<?php print esc_attr( $rnad_id );?>-<?php echo esc_attr( $id ); ?>"
                aria-expanded="<?php echo esc_attr($area_expanded); ?>"
                aria-controls="collapse-<?php print esc_attr( $rnad_id );?>-<?php echo esc_attr( $id ); ?>">
                    <?php if(!empty( $list['title'] )) : ?>
                    <span class="text" ><?php echo elh_element_kses_intermediate($list['title']); ?></span>
                    <span class="icon"><i class="far fa-plus"></i></span>
                    <?php endif; ?>
                </button>
            </h2>
            <div
            id="collapse-<?php print esc_attr( $rnad_id );?>-<?php echo esc_attr( $id ); ?>"
                class="accordion-collapse collapse <?php echo esc_attr($active_show_tab); ?>"
                aria-labelledby="heading-<?php print esc_attr( $rnad_id );?>-<?php echo esc_attr( $id ); ?>"
                data-bs-parent="#accordionFaq-<?php print esc_attr( $rnad_id );?>">
                <div class="accordion-body ">
                    <div class="faq-text">
                        <?php echo elh_element_kses_intermediate($list['content']); ?>
                    </div>
                </div>
            </div>
            <span class="line"></span>
        </div>
        <?php endforeach; ?>
    </div>
</div>