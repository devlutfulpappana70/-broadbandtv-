<?php

$this->add_inline_editing_attributes( 'title', 'basic' );
$this->add_render_attribute( 'title', 'class', 'tna-title-1 txa-split-text txa-split-in-up' );
$title = elh_element_kses_basic( $settings['title'] );

if ($settings['currency'] === 'custom') {
	$currency = $settings['currency_custom'];
} else {
	$currency = self::get_currency_symbol($settings['currency']);
}

?>
<div class="tna-services-1-area pt-20 pb-125 tna-fix">
    <div class="tna-services-1-wrap">
        <div class="tna-services-1-img tna-img-cover txa-slide-left">
            <?php if(!empty( $settings['side_image']['url'] )) : ?>
            <img src="<?php echo esc_url($settings['side_image']['url']); ?>" alt="">
            <?php endif; ?>
        </div>
        <div class="tna-services-1-content">
            <div class="tna-section-title mb-30">
                <?php if(!empty( $settings['sub_title'] )) : ?>
                <h4 class="tna-subtitle-1 wow fadeInRight">
                    <?php echo elh_element_kses_intermediate($settings['sub_title']); ?>
                </h4>
                <?php endif; ?>
                <?php
                    printf('<%1$s %2$s>%3$s</%1$s>',
                        tag_escape($settings['title_tag']),
                        $this->get_render_attribute_string('title'),
                        $title
                    );
                ?>
                <?php if(!empty( $settings['description'] )) : ?>
                <p class="tna-para-1 wow fadeInRight" data-wow-delay=".5s">
                    <?php echo wp_kses($settings['description'], true)?>
                </p>
                <?php endif; ?>
            </div>

            <div class="content-wrap">

                <div class="tna-services-1-price wow fadeInRight">
                    <h3 class="tna-heading-1 price"><?php if(!empty( $currency )) : ?><span class="dollar-sing"><?php echo esc_html($currency); ?></span><?php endif; ?><?php echo esc_html($settings['price']); ?> <?php if(!empty( $settings['period'] )) : ?><span class="month"><?php echo esc_html($settings['period']); ?></span><?php endif; ?></h3>
                    <p class="tna-para-1 para"><?php echo esc_html($settings['package_feature']); ?></p>
                </div>

                <?php if(!empty( $settings['button_text'] )) : ?>
                <a class="tna-pr-btn-2 "href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>">
                    <?php echo elh_element_kses_intermediate($settings['button_text']); ?>
                    <?php \Elementor\Icons_Manager::render_icon( $settings['btn_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                </a>
                <?php endif; ?>
            </div>

        </div>
    </div>

    <div class="tna-services-1-card-wrap races racesWrapper">
        <?php foreach( $settings['services'] as $list ) : ?>
        <div class="tna-services-1-card">
            <?php if(!empty( $list['bg_shape']['url'] )) : ?>
            <img src="<?php echo esc_url($list['bg_shape']['url']); ?>" alt="" class="bg-shape-1">
            <?php endif; ?>

            <?php if(!empty( $list['service_image_2']['url'] )) : ?>
            <div class="bg-img">
                <img src="<?php echo esc_url($list['service_image_2']['url']); ?>" alt="">
            </div>
            <?php endif; ?>

            <?php if( $list['enable_icon'] === 'yes' ) : ?>
            <div class="icon">
                <?php if($list['icon_type'] == 'icon') : ?>
                    <?php \Elementor\Icons_Manager::render_icon( $list['service_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                <?php else : ?>
                    <img src="<?php echo esc_url($list['service_image']['url']); ?>" alt="" />
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <?php if(!empty( $list['title'] )) : ?>
            <h5 class="tna-heading-1 title" ><?php echo elh_element_kses_intermediate($list['title']); ?></h5>
            <?php endif; ?>

            <?php if(!empty( $list['description'] )) : ?>
            <p class="tna-para-1 disc"><?php echo elh_element_kses_intermediate($list['description']); ?></p>
            <?php endif; ?>

            <div class="hover-content">
                <?php if(!empty( $list['title'] )) : ?>
                <h5 class="tna-heading-1 title" ><?php echo elh_element_kses_intermediate($list['title']); ?></h5>
                <?php endif; ?>

                <?php if(!empty( $list['btn_label'] )) : ?>
                <a class="tna-pr-btn-1 "href="<?php echo esc_url($list['list_link']['url']); ?>">
                    <?php echo elh_element_kses_intermediate($list['btn_label']); ?>
                    <?php \Elementor\Icons_Manager::render_icon( $list['btn_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                </a>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>