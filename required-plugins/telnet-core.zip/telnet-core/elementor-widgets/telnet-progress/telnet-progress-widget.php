<?php
namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Telnet_Progress extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'telnet_progress';
    }

    /**
     * Get widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Telnet Progress', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/icon-box/';
    }

    /**
     * Get widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-preview-medium';
    }

    public function get_keywords() {
        return ['telnet', 'skill', 'speed', 'progress', 'bar'];
    }

    protected function register_content_controls() {

        $this->start_controls_section(
            '_section_design_title',
            [
                'label' => __( 'Design Style', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'design_style',
            [
                'label'              => __( 'Design Style', 'telnet-core' ),
                'type'               => Controls_Manager::SELECT,
                'options'            => [
                    'style_1' => __( 'Style 1', 'telnet-core' ),
                    'style_2' => __( 'Style 2', 'telnet-core' ),
                    'style_3' => __( 'Style 3', 'telnet-core' ),
                ],
                'default'            => 'style_1',
                'frontend_available' => true,
                'style_transfer'     => true,
            ]
        );

        $this->end_controls_section();

        // BUTTON & TEXT
        $this->start_controls_section(
            '_section_progress',
            [
                'label' => __( 'Progress', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // progress value
        $this->add_control(
            'progress_value',
            [
                'label'       => __( 'Progress Value', 'telnet-core' ),
                'type'        => Controls_Manager::SLIDER,
                'size_units'  => ['%'],
                'range'       => [
                    '%' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'default'     => [
                    'unit' => '%',
                    'size' => 50,
                ],
                'label_block' => true,
            ]
        );

        $this->add_control(
            'progress_value_2',
            [
                'label'       => __( 'Progress Value', 'vistro-core' ),
                'type'        => Controls_Manager::SLIDER,
                'size_units'  => ['%'],
                'range'       => [
                    '%' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'default'     => [
                    'unit' => '%',
                    'size' => 50,
                ],
                'label_block' => true,
                'selectors'   => [
                    '{{WRAPPER}} .tna-progress-item-1:is(.active) .progress-line' => 'width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'design_style' => ['style_3'],
                ],
            ]
        );

        // title
        $this->add_control(
            'progress_title',
            [
                'label'       => __( 'Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Title', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        // sub title
        $this->add_control(
            'progress_sub_title',
            [
                'label'       => __( 'Sub Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Sub Title', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        // description
        $this->add_control(
            'progress_description',
            [
                'label'       => __( 'Description', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'default'     => __( 'Description', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        $this->end_controls_section();

    }

    protected function register_style_controls() {

        //  PROGRESS BAR STYLE
        $this->start_controls_section(
            '_section_progress_bar_style',
            [
                'label' => __( 'Progress Bar', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // progress size
        $this->add_control(
            'progress_size',
            [
                'label'       => __( 'Progress Size', 'telnet-core' ),
                'type'        => Controls_Manager::SLIDER,
                'size_units'  => ['px'],
                'range'       => [
                    'px' => [
                        'min'  => 1,
                        'max'  => 500,
                        'step' => 1,
                    ],
                ],
                'default'     => [
                    'unit' => 'px',
                    'size' => 180,
                ],
                'label_block' => true,
                'selectors'   => [
                    '{{WRAPPER}} .tx-progressBox__styleOne' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // progress color
        $this->add_control(
            'progress_color',
            [
                'label'     => __( 'Progress Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#d40418',
            ]
        );

        // progress background color
        $this->add_control(
            'progress_bg_color',
            [
                'label'     => __( 'Progress Background Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#fff',
            ]
        );

        // progress thickness
        $this->add_control(
            'progress_thickness',
            [
                'label'       => __( 'Progress Thickness', 'telnet-core' ),
                'type'        => Controls_Manager::SLIDER,
                'size_units'  => ['px'],
                'range'       => [
                    'px' => [
                        'min'  => 0.01,
                        'max'  => 1,
                        'step' => 0.01,
                    ],
                ],
                'default'     => [
                    'unit' => 'px',
                    'size' => 0.5,
                ],
                'label_block' => true,
            ]
        );

        // END SECTION
        $this->end_controls_section();


    }

    /**
     * Render widget output on the frontend.
     *
     * Used to generate the final HTML displayed on the frontend.
     *
     * Note that if skin is selected, it will be rendered by the skin itself,
     * not the widget.
     *
     * @since 1.0.0
     * @access public
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $dir = dirname( __FILE__ );
        $style = !empty($settings['design_style']) ? $settings['design_style'] : 'style_1';

        switch ($style) {
            case 'style_3':
                include $dir . '/views/view-3.php';
                break;
            case 'style_2':
                include $dir . '/views/view-2.php';
                break;
            default:
                include $dir . '/views/view-1.php';
        }
    }

}