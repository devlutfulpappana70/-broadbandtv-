<div class="tx-progressBox tx-progressBox__styleOne text-center">
    <div class="tx-wrapper position-relative">
        <div class="round">
            <input
                type="text"
                class="knob"
                value="0"
                data-rel="<?php echo isset($settings['progress_value']['size']) ? esc_attr($settings['progress_value']['size']) : ''; ?>"
                data-width="<?php echo isset($settings['progress_size']['size']) ? esc_attr($settings['progress_size']['size']) : ''; ?>"
                data-height="<?php echo isset($settings['progress_size']['size']) ? esc_attr($settings['progress_size']['size']) : ''; ?>"
                data-bgcolor="<?php echo isset($settings['progress_bg_color']) ? esc_attr($settings['progress_bg_color']) : ''; ?>"
                data-fgcolor="<?php echo isset($settings['progress_color']) ? esc_attr($settings['progress_color']) : ''; ?>"
                data-thickness="<?php echo isset($settings['progress_thickness']['size']) ? esc_attr($settings['progress_thickness']['size']) : ''; ?>"
                data-readonly="true"
                data-skin="tron"
                data-angleOffset="10"
                data-linecap="round"
                disabled>
        </div>
        <div class="tx-content position-absolute start-50 top-50 translate-middle">
            <?php if (!empty($settings['progress_title'])) : ?>
                <h6 class="tx-title"><?php echo elh_element_kses_intermediate($settings['progress_title']); ?></h6>
            <?php endif; ?>

            <?php if (!empty($settings['progress_sub_title'])) : ?>
                <span class="tx-subTitle d-block mt-10"><?php echo elh_element_kses_intermediate($settings['progress_sub_title']); ?></span>
            <?php endif; ?>
        </div>
    </div>
    <?php if (!empty($settings['progress_description'])) : ?>
        <p class="tx-desc"><?php echo elh_element_kses_intermediate($settings['progress_description']); ?></p>
    <?php endif; ?>
</div>
