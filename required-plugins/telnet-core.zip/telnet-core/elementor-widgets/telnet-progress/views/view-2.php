
<div class="about-one">
    <div class="about-one_progress">
        <?php if(!empty( $settings['progress_title'] )) : ?>
        <div class="about-one_progress-title"><?php echo elh_element_kses_intermediate($settings['progress_title']); ?></div>
        <?php endif; ?>

        <div class="count-box">
            <span class="count-text" data-speed="2500" data-stop="<?php echo $settings['progress_value']['size'] ? esc_attr($settings['progress_value']['size']) : ''; ?>">0</span>%
        </div>
        <div class="bar progress-line" data-width="<?php echo $settings['progress_value']['size'] ? esc_attr($settings['progress_value']['size']) : ''; ?>"></div>
    </div>
</div>