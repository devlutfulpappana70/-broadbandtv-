<div class="tna-progress-item-1-wrap">
    <?php if(!empty( $settings['progress_title'] )) : ?>
    <h5 class="tna-heading-1 title"><?php echo elh_element_kses_intermediate($settings['progress_title']); ?></h5>
    <?php endif; ?>

    <div class="tna-progress-item-1 txa-class-add">
        <span class="tna-heading-1 percent"><?php echo $settings['progress_value_2']['size'] ? esc_attr($settings['progress_value_2']['size']) : ''; ?>%</span>
        <span class="progress-line"></span>
    </div>
</div>