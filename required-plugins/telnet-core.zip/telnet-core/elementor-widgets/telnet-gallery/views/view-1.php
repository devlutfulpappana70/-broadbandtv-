<div class="gallery-slider swiper-container" data-txGallerySlider>
    <div class="swiper-wrapper">
        <?php foreach($settings['gallery_slides'] as $slide ) : ?>
        <div class="swiper-slide">
            <div class="gallery-block">
                <div class="inner-box">
                    <div class="image">
                        <?php if(!empty( $slide['image']['url'] )) : ?>
                        <img src="<?php echo esc_url($slide['image']['url']); ?>" alt="" />
                        <?php endif; ?>
                        <div class="overlay-box">
                            <a href="<?php echo esc_url($slide['image']['url']); ?>" class="plus" data-rel="ligthcase">
                                <?php elh_element_render_icon( $slide, '', 'button_icon' ); ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>