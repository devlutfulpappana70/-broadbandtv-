<div class="swiper tna-follower-slider wow slideInRight">
    <div class="swiper-container tna_follower_active">
        <div class="swiper-wrapper">
            <?php foreach($settings['gallery_slides'] as $slide ) : ?>
            <div class="swiper-slide">
                <div class="tna-follower-item tna-img-cover">
                    <img src="<?php echo esc_url($slide['image']['url']); ?>" alt="">
                    <a class="lightbox-btn popup_img" href="<?php echo esc_url($slide['image']['url']); ?>">
                        <?php elh_element_render_icon( $slide, '', 'button_icon' ); ?>
                    </a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>