<div class="row tx-column-gap-15 mt-none-15">
    <?php foreach($settings['gallery_slides'] as $slide ) : ?>
    <div class="col-xl-4 col-lg-6 col-sm-6 mt-15">
        <div class="gallery-block_two">
            <div class="inner-box">
                <div class="image">
                    <?php if(!empty( $slide['image']['url'] )) : ?>
                    <img src="<?php echo esc_url($slide['image']['url']); ?>" alt="" />
                    <div class="overlay-box">
                        <a href="<?php echo esc_url($slide['image']['url']); ?>" class="lightbox-image plus">
                            <?php elh_element_render_icon( $slide, '', 'button_icon' ); ?>
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
