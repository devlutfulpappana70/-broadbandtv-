<?php
namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
use \Elementor\Core\Schemes\Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Utils;

defined( 'ABSPATH' ) || die();

class Telnet_Icon_Box extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'telnet_icon_box';
    }

    /**
     * Get widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Telnet Icon Box', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/icon-box/';
    }

    /**
     * Get widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-preview-medium';
    }

    public function get_keywords() {
        return ['service', 'gird', 'icon'];
    }

    public function elh_element_animations() {
        return [
            'none' => __( 'None', 'telnet-core' ),
            'fadeIn' => __( 'Fade In', 'telnet-core' ),
            'fadeInUp' => __( 'Fade In Up', 'telnet-core' ),
            'fadeInDown' => __( 'Fade In Down', 'telnet-core' ),
            'fadeInLeft' => __( 'Fade In Left', 'telnet-core' ),
            'fadeInRight' => __( 'Fade In Right', 'telnet-core' ),
            'fadeInUpBig' => __( 'Fade In Up Big', 'telnet-core' ),
            'fadeInDownBig' => __( 'Fade In Down Big', 'telnet-core' ),
            'fadeInLeftBig' => __( 'Fade In Left Big', 'telnet-core' ),
            'fadeInRightBig' => __( 'Fade In Right Big', 'telnet-core' ),
            'bounceIn' => __( 'Bounce In', 'telnet-core' ),
            'bounceInUp' => __( 'Bounce In Up', 'telnet-core' ),
            'bounceInDown' => __( 'Bounce In Down', 'telnet-core' ),
            'bounceInLeft' => __( 'Bounce In Left', 'telnet-core' ),
            'bounceInRight' => __( 'Bounce In Right', 'telnet-core' ),
            'rotateIn' => __( 'Rotate In', 'telnet-core' ),
            'rotateInUpLeft' => __( 'Rotate In Up Left', 'telnet-core' ),
            'rotateInDownLeft' => __( 'Rotate In Down Left', 'telnet-core' ),
            'rotateInUpRight' => __( 'Rotate In Up Right', 'telnet-core' ),
            'rotateInDownRight' => __( 'Rotate In Down Right', 'telnet-core' ),
            'lightSpeedIn' => __( 'Light Speed In', 'telnet-core' ),
            'rollIn' => __( 'Roll In', 'telnet-core' ),
            'zoomIn' => __( 'Zoom In', 'telnet-core' ),
            'zoomInUp' => __( 'Zoom In Up', 'telnet-core' ),
            'zoomInDown' => __( 'Zoom In Down', 'telnet-core' ),
            'zoomInLeft' => __( 'Zoom In Left', 'telnet-core' ),
            'zoomInRight' => __( 'Zoom In Right', 'telnet-core' ),
            'slideInUp' => __( 'Slide In Up', 'telnet-core' ),
            'slideInDown' => __( 'Slide In Down', 'telnet-core' ),
            'slideInLeft' => __( 'Slide In Left', 'telnet-core' ),
            'slideInRight' => __( 'Slide In Right', 'telnet-core' ),
        ];
    }

    protected function register_content_controls() {

        // SERVICES
        $this->start_controls_section(
            '_section_service_box',
            [
                'label' => __( 'Services Boxs', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
       

        $repeater = new Repeater();
        $repeater->add_control(
            'type',
            [
                'label'          => __( 'Service Icon', 'telnet-core' ),
                'type'           => Controls_Manager::CHOOSE,
                'label_block'    => false,
                'options'        => [
                    'icon'  => [
                        'title' => __( 'Icon', 'telnet-core' ),
                        'icon'  => 'far fa-smile',
                    ],
                    'image' => [
                        'title' => __( 'Image', 'telnet-core' ),
                        'icon'  => 'fa fa-image',
                    ],
                ],
                'default'        => 'icon',
                'toggle'         => false,
                'style_transfer' => true,
            ]
        );


        $repeater->add_control(
            'image',
            [
                'label'     => __( 'Service Icon', 'telnet-core' ),
                'type'      => Controls_Manager::MEDIA,
                'default'   => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'type' => 'image',
                ],
                'dynamic'   => [
                    'active' => true,
                ],
            ]
        );

        if ( elh_element_is_elementor_version( '<', '2.6.0' ) ) {
            $repeater->add_control(
                'icon',
                [
                    'label'       => __( 'Icon', 'telnet-core' ),
                    'label_block' => true,
                    'type'        => Controls_Manager::ICON,
                    'options'     => elh_element_get_elh_element_icons(),
                    'default'     => 'fa fa-smile-o',
                    'condition'   => [
                        'type' => 'icon',
                    ],
                ]
            );
        } else {
            $repeater->add_control(
                'selected_icon',
                [
                    'type'             => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block'      => true,
                    'default'          => [
                        'value'   => 'fal fa-long-arrow-right',
                        'library' => 'fa-solid',
                    ],
                    'condition'        => [
                        'type' => 'icon',
                    ],
                ]
            );
        }


        $repeater->add_control(
            'title',
            [
                'label'       => __( 'Service Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __( 'Service title', 'telnet-core' ),
                'placeholder' => __( 'Type Icon Box Title', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );
        $repeater->add_control(
            'desc',
            [
                'label'       => __( 'Description', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );
        $this->add_control(
            'infoboxs',
            [
                'label'       => __( 'Add Info Box', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ title }}}',
            ]
        );
        $this->add_control(
            'shapeimage',
            [
                'label'     => __( 'BG Image', 'telnet-core' ),
                'type'      => Controls_Manager::MEDIA,
            ]
        );
        $this->end_controls_section();

    }

    protected function register_style_controls() {
        // Style
    }

    /**
     * Render widget output on the frontend.
     *
     * Used to generate the final HTML displayed on the frontend.
     *
     * Note that if skin is selected, it will be rendered by the skin itself,
     * not the widget.
     *
     * @since 1.0.0
     * @access public
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $dir = dirname( __FILE__ );?>
        <div class="tel-about-img-feature-4 d-flex">
            <div class="tel-about-feature-list-area-4">
                <?php foreach($settings['infoboxs'] as $item):?>
                <div class="tel-about-feature-list-4">
                    <div class="feature-icon position-relative">
                    <?php if ( $item['type'] === 'image' && ( $item['image']['url'] || $item['image']['id'] ) ):
                        $this->get_render_attribute_string( 'image' );
                        $item['hover_animation'] = 'disable-animation';?>
                        <?php echo Group_Control_Image_Size::get_attachment_image_html( $item, 'thumbnail', 'image' ); ?>
                    <?php elseif ( !empty( $item['icon']['value'] ) ): ?>
                    <?php elh_element_render_icon( $item, '', 'icon' );?>
                <?php endif;?>
                    </div>
                    <div class="feature-text">
                        <h3><?php echo wp_kses($item['title'], true);?></h3>
                        <p><?php echo wp_kses($item['desc'], true);?></p>
                    </div>
                </div>
                <?php endforeach;?>
            </div>
            <?php if(!empty($settings['shapeimage']['url'])):?>
            <div class="tel-about-feature-img-area-4 position-relative">
                <div class="tel-about-feature-img-4">
                    <img src="<?php echo esc_url($settings['shapeimage']['url']);?>" alt="">
                </div>
            </div>
            <?php endif;?>
        </div>
    <?php 
    }

}