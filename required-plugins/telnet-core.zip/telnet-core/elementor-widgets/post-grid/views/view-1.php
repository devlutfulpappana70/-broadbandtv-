<div class="tx-PostSliderWrapper position-relative">
    <div class="swiper-container" data-txPosttSlider>
        <div class="swiper-wrapper">
            <?php
                if (!empty($posts)):
                foreach ( $posts as $inx => $post ):
                $title = $post->post_title;
                if ( 'selected' === $settings['show_post_by'] && array_key_exists( $post->ID, $customize_title ) ) {
                    $title = $customize_title[$post->ID];
                }

                $thumb = get_the_post_thumbnail_url( $post->ID, 'large' );
                if ( 'selected' === $settings['show_post_by'] && array_key_exists( $post->ID, $customize_img ) && !empty( $customize_img[$post->ID]['url'] ) ) {
                    $thumb = $customize_img[$post->ID]['url'];
                }

                $readmore_text = $settings['readmore_text'];
                $enable_default_date = $settings['enable_default_date'];
            ?>
            <div class="swiper-slide">
                <div class="tx-postGridBox tx-postGridBox__styleOne">
                    <?php if(!empty( $thumb && $settings['feature_image'] === 'yes' )) : ?>
                    <div class="tx-thumb mb-none-30 fix">
                        <img src="<?php echo esc_url($thumb); ?>" alt="<?php if(function_exists('tf_img_alt_text')) { echo tf_img_alt_text($thumb); } ?>">
                    </div>
                    <?php endif; ?>
                    <div class="tx-content pl-30 pr-30 pt-30 pb-30 tx-z1 position-relative m-auto">
                        <?php if ( 'yes' === $settings['meta'] && 'yes' === $settings['date_meta'] ): ?>
                        <a href="<?php echo get_day_link(get_the_time('Y'), get_the_time('M'), get_the_time('j'));?>" class="tx-metaDate">
                            <?php
                                if( 'yes' === $enable_default_date ) {
                                    $date_format = get_option( 'date_format' );
                                    echo esc_html( get_the_date( $date_format, $post->ID ) );
                                } else {
                                    $date_month = get_the_date( "M", $post->ID );
                                    $date_day = get_the_date( "d", $post->ID );
                                    print esc_html( $date_month . ' ' . $date_day );
                                }
                            ?>
                        </a>
                        <?php endif; ?>
                        <h5 class="tx-title tx-border-effect mt-15">
                            <a href="<?php echo esc_url(get_the_permalink( $post->ID )); ?>"> <?php echo esc_html($title); ?></a>
                        </h5>
                        <a href="<?php echo esc_url(get_the_permalink( $post->ID )); ?>" class="tx-inline-btn tx-border-effect mt-20">
                            <?php echo esc_html($readmore_text); ?>
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach;
                else:
                    printf('%1$s %2$s %3$s',
                        __('No ', 'telnet-core'),
                        esc_html($settings['post_type']),
                        __('Found', 'telnet-core')
                    );
                endif;
            ?>
        </div>
    </div>

    <!-- slider navigation -->
    <div class="tx-slideNav tx-slideNav__styleOuter tx-slideNav__styleMiddle tx-slideNav__styleLight">
        <div class="swiper-button-prev">
            <i class="fa-regular fa-arrow-left-long"></i>
        </div>
        <div class="swiper-button-next">
            <i class="fa-regular fa-arrow-right-long"></i>
        </div>
    </div>
</div>