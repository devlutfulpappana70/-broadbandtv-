<?php
    if (!empty($posts)):
    foreach ( $posts as $inx => $post ):
    $title = $post->post_title;
    if ( 'selected' === $settings['show_post_by'] && array_key_exists( $post->ID, $customize_title ) ) {
        $title = $customize_title[$post->ID];
    }

    $thumb = get_the_post_thumbnail_url( $post->ID, 'large' );
    if ( 'selected' === $settings['show_post_by'] && array_key_exists( $post->ID, $customize_img ) && !empty( $customize_img[$post->ID]['url'] ) ) {
        $thumb = $customize_img[$post->ID]['url'];
    }

    $readmore_text = $settings['readmore_text'];
                $enable_default_date = $settings['enable_default_date'];
    $post_by = $settings['post_by'];
    $author_name = get_the_author_meta( 'display_name', $post->post_author );

?>
<div class="tna-blog-3-item">
    <?php if ( !empty( $thumb && $settings['feature_image'] === 'yes' ) ): ?>
    <div class="main-img tna-img-cover">
        <img src="<?php echo esc_url( $thumb ); ?>" alt="">
    </div>
    <?php endif;?>
    <div class="content-wrap">
        <?php if ( 'yes' === $settings['meta'] ): ?>
        <div class="tna-blog-3-item-meta">
            <?php if ( 'yes' === $settings['meta'] && 'yes' === $settings['author_meta'] ): ?>
            <h4 class="tna-heading-2 name"><?php echo esc_html($post_by) ?>
                <span class="tna-inherit"><?php echo esc_html($author_name) ?></span>
            </h4>
            <?php endif; ?>


            <?php if ( 'yes' === $settings['meta'] && 'yes' === $settings['date_meta'] ): ?>
            <p class="tna-para-2 date">
            <?php
                if( 'yes' === $enable_default_date ) {
                    $date_format = get_option( 'date_format' );
                    echo esc_html( get_the_date( $date_format, $post->ID ) );
                } else {
                    $date_month = get_the_date( "M", $post->ID );
                    $date_day = get_the_date( "d", $post->ID );
                    $date_year = get_the_date( "Y", $post->ID );
                    print esc_html( $date_month . ' ' . $date_day . ', ' . $date_year);
                }
            ?>
            </p>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <h5 class="tna-heading-2 title">
            <a class="tna-inherit" href="<?php echo esc_url(get_the_permalink( $post->ID )); ?>"><?php echo esc_html($title); ?></a>
        </h5>
        <p class="tna-para-2 disc"><?php echo wp_trim_words(get_the_excerpt(), 15, '')  ;?></p>
    </div>
</div>
<?php endforeach;
    else:
        printf('%1$s %2$s %3$s',
            __('No ', 'telnet-core'),
            esc_html($settings['post_type']),
            __('Found', 'telnet-core')
        );
    endif;
?>