<div class="news-one">
	<div class="auto-container">
        <?php
            if (!empty($posts)):
            foreach ( $posts as $inx => $post ):
            $title = $post->post_title;
            if ( 'selected' === $settings['show_post_by'] && array_key_exists( $post->ID, $customize_title ) ) {
                $title = $customize_title[$post->ID];
            }

            $thumb = get_the_post_thumbnail_url( $post->ID, 'large' );
            if ( 'selected' === $settings['show_post_by'] && array_key_exists( $post->ID, $customize_img ) && !empty( $customize_img[$post->ID]['url'] ) ) {
                $thumb = $customize_img[$post->ID]['url'];
            }

            $readmore_text = $settings['readmore_text'];
                $enable_default_date = $settings['enable_default_date'];
            $post_by = $settings['post_by'];
            $author_name = get_the_author_meta( 'display_name', $post->post_author );
        ?>
        <div class="news-block_one">
            <div class="news-block_one-inner wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                <?php if ( !empty( $thumb && $settings['feature_image'] === 'yes' ) ): ?>
                <div class="news-block_one-image">
                    <a href="<?php echo esc_url(get_the_permalink( $post->ID )); ?>">
                        <img src="<?php echo esc_url( $thumb ); ?>" alt="" />
                    </a>
                </div>
                <?php endif;?>
                <div class="news-block_one-content">
                <?php if ( 'yes' === $settings['meta'] && 'yes' === $settings['date_meta'] ): ?>
                    <div class="news-block_one-date">
                    <?php
                        if( 'yes' === $enable_default_date ) {
                            $date_format = get_option( 'date_format' );
                            echo esc_html( get_the_date( $date_format, $post->ID ) );
                        } else {
                            $date_month = get_the_date( "M", $post->ID );
                            $date_day = get_the_date( "d", $post->ID );
                            $date_year = get_the_date( "Y", $post->ID );
                            print esc_html( $date_month . ' ' . $date_day . ', ' . $date_year);
                        }
                    ?>
                    </div>
                <?php endif; ?>
                    <h3 class="news-block_one-heading">
                        <a href="<?php echo esc_url(get_the_permalink( $post->ID )); ?>">
                            <?php echo esc_html($title); ?>
                        </a>
                    </h3>
                    <div class="news-block_one-text"><?php echo wp_trim_words(get_the_excerpt(), 15, '')  ;?></div>
                    <div class="news-block_one-button">
                        <a href="<?php echo esc_url(get_the_permalink( $post->ID )); ?>" class="theme-btn btn-style-eighteen"><span class="txt"><?php echo esc_html( $readmore_text ); ?></span><i class="lnr lnr-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach;
            else:
                printf('%1$s %2$s %3$s',
                    __('No ', 'telnet-core'),
                    esc_html($settings['post_type']),
                    __('Found', 'telnet-core')
                );
            endif;
        ?>
    </div>
</div>