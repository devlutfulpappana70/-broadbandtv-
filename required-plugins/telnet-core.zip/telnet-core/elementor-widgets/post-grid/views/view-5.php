<?php
// choose columns
$col = 'col-lg-4 col-md-6';
if ( $settings['columns'] == 'column_1' ) {
    $col = 'col-xl-12 mt-30';
} elseif ( $settings['columns'] == 'column_2' ) {
    $col = 'col-xl-6 col-lg-6 col-md-6 col-sm-6 mt-30';
} elseif ( $settings['columns'] == 'column_3' ) {
    $col = 'col-xl-4 col-lg-6 col-md-6 col-sm-6 mt-30';
} elseif ( $settings['columns'] == 'column_4' ) {
    $col = 'col-xl-3 col-lg-6 col-md-6 col-sm-6 mt-30';
} else {
    $col = 'col-xl-4 col-lg-6 col-md-6 col-sm-6 mt-30';
}
?>


<div class="row justify-content-center">
    <?php
    if ( !empty( $posts ) ):
    foreach ( $posts as $inx => $post ):
        $title = $post->post_title;
        if ( 'selected' === $settings['show_post_by'] && array_key_exists( $post->ID, $customize_title ) ) {
            $title = $customize_title[$post->ID];
        }

        $thumb = get_the_post_thumbnail_url( $post->ID, 'large' );
        if ( 'selected' === $settings['show_post_by'] && array_key_exists( $post->ID, $customize_img ) && !empty( $customize_img[$post->ID]['url'] ) ) {
            $thumb = $customize_img[$post->ID]['url'];
        }

        $readmore_text = $settings['readmore_text'];
                $enable_default_date = $settings['enable_default_date'];
        ?>
        <div class="<?php echo esc_attr( $col ); ?> wow fadeInUp"  data-wow-delay="300ms" data-wow-duration="1000ms">
            <div class="tel-blog-item-3">
                <div class="blog-img-meta position-relative">
                    <?php if ( !empty( $thumb && $settings['feature_image'] === 'yes' ) ): ?>
                        <div class="blog-img">
                            <img src="<?php echo esc_url( $thumb ); ?>" alt="<?php if ( function_exists( 'tf_img_alt_text' ) ) {echo tf_img_alt_text( $thumb );}?>">
                        </div>
                    <?php endif;?>

                    <?php if ( 'yes' === $settings['meta'] && 'yes' === $settings['date_meta'] ): ?>
                    <div class="blog-meta position-absolute">
                        <i class="fal fa-calendar-alt"></i>

                        <?php
                            if( 'yes' === $enable_default_date ) {
                                $date_format = get_option( 'date_format' );
                                echo esc_html( get_the_date( $date_format, $post->ID ) );
                            } else {
                                $date_month = get_the_date( "M", $post->ID );
                                $date_day = get_the_date( "d", $post->ID );
                                print esc_html( $date_month . ' ' . $date_day );
                            }
                        ?>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="blog-text">
                    <h1><a href="<?php echo esc_url( get_the_permalink( $post->ID ) ); ?>"> <?php echo esc_html( $title ); ?></a></h1>
                    <p><?php echo wp_trim_words(get_the_excerpt(), 10, '')  ;?></p>
                    <div class="blog-author-more-btn d-flex align-items-center justify-content-between">
                        <?php if ( 'yes' === $settings['meta'] && 'yes' === $settings['author_meta'] ): ?>
                        <div class="blog-author d-flex align-items-center">
                            <div class="inner-img">
                                <?php elh_post_author_avatars(40);?>
                            </div>
                            <div class="inner-text">
                                <a href="<?php echo esc_url( get_the_permalink( $post->ID ) ); ?>"><?php the_author();?></a>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="more-btn text-uppercase">
                            <a href="<?php echo esc_url( get_the_permalink( $post->ID ) ); ?>"><?php echo esc_html( $readmore_text ); ?>
                                <?php if(!empty($settings['arrow_icon']['url'])):?>
                                    <img src="<?php echo esc_url($settings['arrow_icon']['url']);?>" alt="">
                                <?php endif;?>
                            </a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach;
else:
    printf( '%1$s %2$s %3$s',
        __( 'No ', 'telnet-core' ),
        esc_html( $settings['post_type'] ),
        __( 'Found', 'telnet-core' )
    );
endif;
?>
</div>
