<?php
// choose columns

?>
<div class="row tx-column-gap-30 mt-none-30">
    <?php
    $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
    $args = array(
        'post_type' => $settings['post_type'], // Replace with the actual post type
        'posts_per_page' => $settings['posts_per_page'],
        'paged' => $paged,
    );

    $query = new WP_Query( $args );

    if ( $query->have_posts() ) :
        while ( $query->have_posts() ) : $query->the_post();
            $title = get_the_title();
            $thumb = get_the_post_thumbnail_url( get_the_ID(), 'large' );
            $readmore_text = $settings['readmore_text'];
                $enable_default_date = $settings['enable_default_date'];
            $col = 'col-xl-4 col-lg-6 col-md-6 col-sm-6 mt-30';
            if ( $settings['columns'] == 'column_1' ) {
                $col = 'col-xl-12 mt-30';
            } elseif ( $settings['columns'] == 'column_2' ) {
                $col = 'col-xl-6 col-lg-6 col-md-6 col-sm-6 mt-30';
            } elseif ( $settings['columns'] == 'column_3' ) {
                $col = 'col-xl-4 col-lg-6 col-md-6 col-sm-6 mt-30';
            } elseif ( $settings['columns'] == 'column_4' ) {
                $col = 'col-xl-3 col-lg-6 col-md-6 col-sm-6 mt-30';
            } else {
                $col = 'col-xl-4 col-lg-6 col-md-6 col-sm-6 mt-30';
            }

            ?>
            <div class="<?php echo esc_attr( $col ); ?>">
                <div class="tx-postGridBox tx-postGridBox__styleOne">
                    <?php if ( !empty( $thumb && $settings['feature_image'] === 'yes' ) ): ?>
                    <div class="tx-thumb mb-none-30 fix">
                        <img src="<?php echo esc_url( $thumb ); ?>" alt="<?php if ( function_exists( 'tf_img_alt_text' ) ) {echo tf_img_alt_text( $thumb );}?>">
                    </div>
                    <?php endif;?>
                    <div class="tx-content pl-30 pr-30 pt-30 pb-30 tx-z1 position-relative m-auto">
                        <?php if ( 'yes' === $settings['meta'] && 'yes' === $settings['date_meta'] ): ?>
                        <a href="<?php echo get_day_link( get_the_time( 'Y' ), get_the_time( 'M' ), get_the_time( 'j' ) ); ?>" class="tx-metaDate">
                            <?php
                                if( 'yes' === $enable_default_date ) {
                                    $date_format = get_option( 'date_format' );
                                    echo esc_html( get_the_date( $date_format, $post->ID ) );
                                } else {
                                    $date_month = get_the_date( "M", $post->ID );
                                    $date_day = get_the_date( "d", $post->ID );
                                    print esc_html( $date_month . ' ' . $date_day );
                                }
                            ?>
                        </a>
                        <?php endif;?>
                        <h5 class="tx-title tx-border-effect mt-15">
                            <a href="<?php echo esc_url( get_the_permalink() ); ?>"><?php echo esc_html( $title ); ?></a>
                        </h5>
                        <a href="<?php echo esc_url( get_the_permalink() ); ?>" class="tx-inline-btn tx-border-effect mt-20">
                            <?php echo esc_html( $readmore_text ); ?>
                        </a>
                    </div>
                </div>
            </div>
            <?php
        endwhile;

        // Pagination links
        if ( $query->max_num_pages > 1 ) {
            echo '<div class="tx-pagination tx-pagination__stylePost">';
            echo '<ul class="mt-50 list-unstyled d-flex align-items-center justify-content-center">';
            echo paginate_links( array(
                'base' => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
                'format' => '?paged=%#%',
                'current' => max( 1, get_query_var( 'paged' ) ),
                'total' => $query->max_num_pages,
                'prev_text' => '<i class="fas fa-chevrons-left"></i>',
                'next_text' => '<i class="fas fa-chevrons-right"></i>',
            ) );
            echo '</ul>';
            echo '</div>';
        }

        wp_reset_postdata();
    else:
        printf( '%1$s %2$s %3$s',
            __( 'No ', 'telnet-core' ),
            esc_html( $settings['post_type'] ),
            __( 'Found', 'telnet-core' )
        );
    endif;
    ?>
</div>
