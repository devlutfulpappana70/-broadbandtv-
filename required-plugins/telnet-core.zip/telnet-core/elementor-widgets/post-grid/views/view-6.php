<div class="tel-blog-content-4">
    <?php
        if (!empty($posts)):
        foreach ( $posts as $inx => $post ):
        $title = $post->post_title;
        if ( 'selected' === $settings['show_post_by'] && array_key_exists( $post->ID, $customize_title ) ) {
            $title = $customize_title[$post->ID];
        }

        $thumb = get_the_post_thumbnail_url( $post->ID, 'large' );
        if ( 'selected' === $settings['show_post_by'] && array_key_exists( $post->ID, $customize_img ) && !empty( $customize_img[$post->ID]['url'] ) ) {
            $thumb = $customize_img[$post->ID]['url'];
        }

        $readmore_text = $settings['readmore_text'];
        $enable_default_date = $settings['enable_default_date'];
        $post_by = $settings['post_by'];
        $author_name = get_the_author_meta( 'display_name', $post->post_author );
    ?>
    <div class="tel-blog-item-4">
        <div class="row">
            <div class="col-md-6">
                <div class="blog-text">
                    <div class="blog-meta position-relative">
                        <a href="<?php echo esc_url(get_the_permalink( $post->ID )); ?>"><i class="fal fa-user"></i> <?php esc_html_e( 'By', 'telnet-plugin' )?> <?php the_author(); ?></a>
                        <?php if ( 'yes' === $settings['meta'] && 'yes' === $settings['date_meta'] ): ?>
                        <a href="<?php echo esc_url(get_the_permalink( $post->ID )); ?>"><i class="fal fa-calendar-alt"></i>
                            <?php
                                // date format
                                $date_format = get_option( 'date_format' );
                                echo esc_html( get_the_date( $date_format, $post->ID ) );
                            ?>
                        </a>
                        <?php endif; ?>

                    </div>
                    <h1><a href="<?php echo esc_url(get_the_permalink( $post->ID )); ?>"><?php echo esc_html($title); ?></a></h1>
                    <p><?php echo wp_trim_words(get_the_excerpt(), 50, '')  ;?></p>
                    <div class="tel-btn-2 text-uppercase">
                        <a href="<?php echo esc_url( get_the_permalink( $post->ID ) ); ?>"><?php echo esc_html( $readmore_text ); ?> <?php if(!empty($settings['arrow_icon']['url'])):?>
                            <img src="<?php echo esc_url($settings['arrow_icon']['url']);?>" alt="">
                        <?php endif;?></a>
                    </div>
                </div>
            </div>
            <?php if ( !empty( $thumb && $settings['feature_image'] === 'yes' ) ): ?>
            <div class="col-md-6">
                <div class="blog-img">
                    <img src="<?php echo esc_url( $thumb ); ?>" alt="<?php if ( function_exists( 'tf_img_alt_text' ) ) {echo tf_img_alt_text( $thumb );}?>">
                </div>
            </div>
            <?php endif;?>
        </div>
    </div>
    <?php endforeach;
        else:
            printf('%1$s %2$s %3$s',
                __('No ', 'telnet-core'),
                esc_html($settings['post_type']),
                __('Found', 'telnet-core')
            );
        endif;
    ?>
</div>