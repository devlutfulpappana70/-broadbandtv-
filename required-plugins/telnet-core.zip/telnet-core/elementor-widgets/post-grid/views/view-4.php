<div class="tel-blog-slider swiper-container">
    <div class="swiper-wrapper">
        <?php
            if (!empty($posts)):
            foreach ( $posts as $inx => $post ):
            $title = $post->post_title;
            if ( 'selected' === $settings['show_post_by'] && array_key_exists( $post->ID, $customize_title ) ) {
                $title = $customize_title[$post->ID];
            }

            $thumb = get_the_post_thumbnail_url( $post->ID, 'large' );
            if ( 'selected' === $settings['show_post_by'] && array_key_exists( $post->ID, $customize_img ) && !empty( $customize_img[$post->ID]['url'] ) ) {
                $thumb = $customize_img[$post->ID]['url'];
            }

            $readmore_text = $settings['readmore_text'];
                $enable_default_date = $settings['enable_default_date'];
            $post_by = $settings['post_by'];
            $author_name = get_the_author_meta( 'display_name', $post->post_author );
        ?>
        <div class="swiper-slide">
            <div class="tel-blog-item text-center position-relative">
            <?php if(!empty( $thumb && $settings['feature_image'] === 'yes' )) : ?>
                <div class="blog-img">
                    <img src="<?php echo esc_url($thumb); ?>" alt="<?php if(function_exists('tf_img_alt_text')) { echo tf_img_alt_text($thumb); } ?>">
                </div>
                <?php endif; ?>
                <div class="blog-meta position-relative">
                    <?php if ( 'yes' === $settings['author_meta'] ): ?>
                    <a href="<?php echo esc_url(get_the_permalink( $post->ID )); ?>"><i class="fal fa-user"></i>
                        <?php echo esc_html($post_by); ?>
                        <?php echo esc_html($author_name); ?>
                    </a>
                    <?php endif; ?>
                    <?php if ( 'yes' === $settings['meta'] && 'yes' === $settings['date_meta'] ): ?>
                    <a href="<?php echo get_day_link(get_the_time('Y'), get_the_time('M'), get_the_time('j'));?>">
                    <i class="fal fa-calendar-alt"></i>
                        <?php
                            if( 'yes' === $enable_default_date ) {
                                $date_format = get_option( 'date_format' );
                                echo esc_html( get_the_date( $date_format, $post->ID ) );
                            } else {
                                $date_month = get_the_date( "M", $post->ID );
                                $date_day = get_the_date( "d", $post->ID );
                                $date_year = get_the_date( "Y", $post->ID );
                                print esc_html( $date_month . ' ' . $date_day . ', ' . $date_year);
                            }
                        ?>
                    </a>
                    <?php endif; ?>
                </div>
                <h3><a href="<?php echo esc_url(get_the_permalink( $post->ID )); ?>"><?php echo esc_html($title); ?></a></h3>
                <a class="blog_more text-uppercase" href="<?php echo esc_url(get_the_permalink( $post->ID )); ?>">
                    <?php echo esc_html($readmore_text); ?> <i class="fal fa-long-arrow-right"></i>
                </a>
            </div>
        </div>
        <?php endforeach;
            else:
                printf('%1$s %2$s %3$s',
                    __('No ', 'telnet-core'),
                    esc_html($settings['post_type']),
                    __('Found', 'telnet-core')
                );
            endif;
        ?>
    </div>
    <div class="tel-dot-carousel swiper-blog-paginations text-center"></div>
</div>