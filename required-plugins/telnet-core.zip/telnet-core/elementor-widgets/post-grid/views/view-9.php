<?php
    $this->add_render_attribute( 'title', 'class', 'tna-title-1 txa-split-text txa-split-in-up' );
    $section_heading = elh_element_kses_basic( $settings['title'] );
?>
<div class="tna-blog-1-area flat_3">
    <div class="container tna-container-1">
        <div class="row">

            <!-- left-contnet -->
            <div class="col-xl-5">
                <div class="tna-blog-1-content">

                    <!-- section-title -->
                    <div class="tna-section-title mb-55">
                        <?php if(!empty( $settings['sub_title'] )) : ?>
						<h4 class="tna-subtitle-1">
							<?php echo elh_element_kses_intermediate($settings['sub_title']); ?>
						</h4>
						<?php endif; ?>

						<?php printf('<%1$s %2$s>%3$s</%1$s>',
							tag_escape($settings['title_tag']),
							$this->get_render_attribute_string('title'),
							$section_heading
						); ?>

						<?php if(!empty( $settings['description'] )) : ?>
						<p class="tna-para-1"><?php echo elh_element_kses_intermediate($settings['description']); ?></p>
						<?php endif; ?>
                    </div>

                    <a href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>" class="tna-pr-btn-2 ">
						<?php
							echo elh_element_kses_intermediate($settings['button_text']);
							if(($settings['enable_icon']) === 'yes' ) {
								\Elementor\Icons_Manager::render_icon( $settings['btn_icon'], [ 'aria-hidden' => 'true' ] );
							}
						?>
					</a>
                </div>
            </div>

            <!-- right-content -->
            <div class="col-xl-7">
                <div class="tna-blog-1-item-wrap">

                <?php
                    if (!empty($posts)):
                    foreach ( $posts as $inx => $post ):
                    $title = $post->post_title;
                    if ( 'selected' === $settings['show_post_by'] && array_key_exists( $post->ID, $customize_title ) ) {
                        $title = $customize_title[$post->ID];
                    }

                    $thumb = get_the_post_thumbnail_url( $post->ID, 'large' );
                    if ( 'selected' === $settings['show_post_by'] && array_key_exists( $post->ID, $customize_img ) && !empty( $customize_img[$post->ID]['url'] ) ) {
                        $thumb = $customize_img[$post->ID]['url'];
                    }

                    $readmore_text = $settings['readmore_text'];
                    $enable_default_date = $settings['enable_default_date'];
                    $post_by = $settings['post_by'];
                    $author_name = get_the_author_meta( 'display_name', $post->post_author );
                ?>
                    <div class="tna-blog-1-item">
                        <?php if ( !empty( $thumb && $settings['feature_image'] === 'yes' ) ): ?>
                        <div class="main-img tna-img-cover">
                            <img src="<?php echo esc_url( $thumb ); ?>" alt="">
                        </div>
                        <?php endif;?>
                        <div class="content-wrap">
                            <h4 class="tna-heading-1 title"><?php echo esc_html($title); ?></h4>
                            <p class="tna-para-1 disc">
                                <?php echo wp_trim_words(get_the_excerpt(), 15, '')  ;?>
                            </p>

                            <p class="tna-para-1 date">
                            <?php if ( 'yes' === $settings['meta'] && 'yes' === $settings['date_meta'] ): ?>
                            <?php
                                if( 'yes' === $enable_default_date ) {
                                    $date_format = get_option( 'date_format' );
                                    echo esc_html( get_the_date( $date_format, $post->ID ) );
                                } else {
                                    $date_month = get_the_date( "M", $post->ID );
                                    $date_day = get_the_date( "d", $post->ID );
                                    $date_year = get_the_date( "Y", $post->ID );
                                    print esc_html( $date_month . ' ' . $date_day . ', ' . $date_year);
                                }
                            ?>
                            <?php endif; ?>

                            <?php echo esc_html($post_by) ?> <span><?php echo esc_html($author_name) ?></span></p>
                        </div>
                        <a href="<?php echo esc_url(get_the_permalink( $post->ID )); ?>" class="b1-btn" >
                            <i class="flaticon-right-arrow"></i>
                        </a>
                    </div>
                    <?php endforeach;
                        else:
                            printf('%1$s %2$s %3$s',
                                __('No ', 'telnet-core'),
                                esc_html($settings['post_type']),
                                __('Found', 'telnet-core')
                            );
                        endif;
                    ?>
                </div>
            </div>

        </div>
    </div>
</div>