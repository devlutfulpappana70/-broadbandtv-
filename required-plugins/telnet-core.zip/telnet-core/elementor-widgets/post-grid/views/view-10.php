<div class="tna-blog-2-gird flat_3">
    <?php
        if (!empty($posts)):
        foreach ( $posts as $inx => $post ):
        $title = $post->post_title;
        if ( 'selected' === $settings['show_post_by'] && array_key_exists( $post->ID, $customize_title ) ) {
            $title = $customize_title[$post->ID];
        }

        $thumb = get_the_post_thumbnail_url( $post->ID, 'large' );
        if ( 'selected' === $settings['show_post_by'] && array_key_exists( $post->ID, $customize_img ) && !empty( $customize_img[$post->ID]['url'] ) ) {
            $thumb = $customize_img[$post->ID]['url'];
        }

        $readmore_text = $settings['readmore_text'];
                $enable_default_date = $settings['enable_default_date'];
        $post_by = $settings['post_by'];
        $author_name = get_the_author_meta( 'display_name', $post->post_author );

        $is_big = $inx === 0 ? 'big fadeInUp active' : 'fadeInRight';
    ?>
    <div class="tna-blog-2-item wow <?php echo esc_attr($is_big); ?>">
        <?php if ( !empty( $thumb && $settings['feature_image'] === 'yes' ) ): ?>
        <div class="main-img tna-img-cover">
            <img src="<?php echo esc_url( $thumb ); ?>" alt="">
        </div>
        <?php endif;?>
        <div class="content-wrap">
            <?php if ( 'yes' === $settings['meta'] ): ?>
            <div class="tna-blog-2-item-meta">
                <?php if ( 'yes' === $settings['meta'] && 'yes' === $settings['author_meta'] ): ?>
                <span class="tna-heading-2 author"><i class="fa-light fa-user"></i> <?php echo esc_html($post_by . ' ' . $author_name) ?></span>
                <?php endif; ?>

                <?php if ( 'yes' === $settings['meta'] && 'yes' === $settings['date_meta'] ): ?>
                <span class="tna-heading-2 date"><i class="fa-light fa-calendar-days"></i>
                <?php
                    if( 'yes' === $enable_default_date ) {
                        $date_format = get_option( 'date_format' );
                        echo esc_html( get_the_date( $date_format, $post->ID ) );
                    } else {
                        $date_month = get_the_date( "M", $post->ID );
                        $date_day = get_the_date( "d", $post->ID );
                        $date_year = get_the_date( "Y", $post->ID );
                        print esc_html( $date_month . ' ' . $date_day . ', ' . $date_year);
                    }
                ?>
                </span>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <h4 class="tna-heading-2 title">
                <a href="<?php echo esc_url(get_the_permalink( $post->ID )); ?>"><?php echo esc_html($title); ?></a>
            </h4>

            <p class="tna-para-2 disc"><?php echo wp_trim_words(get_the_excerpt(), 15, '')  ;?></p>

        </div>

        <?php if(!empty( $readmore_text )) : ?>
        <a href="<?php echo esc_url(get_the_permalink( $post->ID )); ?>" class="b2-btn"><?php echo esc_html($readmore_text); ?></a>
        <?php endif; ?>
    </div>
    <?php endforeach;
        else:
            printf('%1$s %2$s %3$s',
                __('No ', 'telnet-core'),
                esc_html($settings['post_type']),
                __('Found', 'telnet-core')
            );
        endif;
    ?>

    <!-- single-item -->
    <div class="tna-blog-2-content">
        <?php if(!empty( $settings['description'] )) : ?>
        <p class="tna-para-2 section-disc wow fadeInUp"><?php echo elh_element_kses_intermediate($settings['description']); ?></p>
        <?php endif; ?>

        <a class="tna-pr-btn-3 wow fadeInUp" data-wow-delay=".3s" href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>">
            <span class="text">
                <?php echo elh_element_kses_intermediate($settings['button_text']); ?>
            </span>
            <?php

            if(($settings['enable_icon']) === 'yes' ) {
                \Elementor\Icons_Manager::render_icon( $settings['btn_icon'], [ 'aria-hidden' => 'true' ] );
            }
        ?>
        </a>
    </div>

</div>