<section id="tel-team-2" class="tel-team-section-2 position-relative">
    <div class="container ">
        <div class="tel-team-content-2 d-flex">
            <div class="tel-team-text-area-2">
                <div class="tel-section-title-2">
                    <?php if(!empty( $settings['sub_title'] )) : ?>
                    <div class="sub-title text-uppercase wow fadeInRight"  data-wow-delay="200ms" data-wow-duration="1000ms">
                        <?php echo wp_kses($settings['sub_title'], true);?>
                    </div>
                    <?php endif; ?>
                    
                    <h3 class="headline-title"><?php echo wp_kses($settings['title'], true)?></h3>
                    <?php if(!empty($settings['description'])):?>
                    <p><?php echo wp_kses($settings['description'], true)?></p>
                    <?php endif;?>
                </div>
                <?php if(!empty($settings['btn_label'])):?>
                <div class="tel-btn-2 text-uppercase wow fadeInRight"  data-wow-delay="400ms" data-wow-duration="1000ms">
                    <a href="<?php echo esc_url($settings['btn_link']['url']);?>"><?php echo esc_html($settings['btn_label']);?>
                    <?php if(!empty($settings['btn_arrow']['url'])):?>
                        <img src="<?php echo esc_url($settings['btn_arrow']['url']);?>" alt="">
                    <?php endif;?>
                </a>
                </div>
                <?php endif;?>
            </div>
            <div class="tel-team-area-2 d-flex wow slideInRight"  data-wow-delay="100ms" data-wow-duration="1500ms">
            <?php $i = 0; foreach( $settings['team_members'] as $team ) : $i++ ?>
                <div class="tel-team-item-2 position-relative <?php if($i == 1):?>active<?php endif;?>">
                    <?php if(!empty( $team['image']['url'] )) : ?>
                        <div class="team-img">
                            <img src="<?php echo esc_url($team['image']['url']); ?>" alt="">
                        </div>
                    <?php endif; ?>
                    <?php if(!empty( $team['social_links'] )) : ?>
                    <div class="team-social position-absolute">
                        <?php foreach($team['social_links'] as $social_link) : ?>
                        <a href="<?php echo esc_url($social_link['social_link']['url']); ?>"> <?php echo elh_element_render_icon($social_link, '', 'social_icon'); ?></a>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                    <div class="team-text position-absolute text-uppercase">
                        <?php if(!empty( $team['name'] )) : ?>
                            <h3><?php echo esc_html($team['name']); ?></h3>
                        <?php endif; ?>
                        <?php if(!empty($team['icon_img']['url'])):?>
                            <span class="team-name-shape position-absolute"><img src="<?php echo esc_url($team['icon_img']['url']);?>" alt=""></span>
                        <?php endif;?>
                    </div>
                    <div class="team-hover-content d-flex align-items-center position-absolute">
                        <div class="name-degi">
                            <?php if(!empty( $team['name'] )) : ?>
                            <h3><a href="<?php echo esc_url($team['details_link']['url']); ?>">
                                <?php echo esc_html($team['name']); ?></a>
                            </h3>
                            <?php endif; ?>
                            <?php if(!empty( $team['designation'] )) : ?>
                            <span><?php echo esc_html($team['designation']); ?></span>
                            <?php endif; ?>
                        </div>
                        <?php if(!empty($team['icon_img2']['url'])):?>
                        <span class="team-shape position-absolute">
                            <img src="<?php echo esc_url($team['icon_img2']['url']);?>" alt="">
                        </span>
                        <?php endif;?>
                    </div>
                </div>
            <?php endforeach;?>
            </div>
        </div>
    </div>
</section>	