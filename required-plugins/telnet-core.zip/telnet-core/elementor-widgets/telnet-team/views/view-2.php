<div class="tel-team-slider-area d-flex justify-content-end">
    <div class="tel-team-slider swiper-container">
        <div class="swiper-wrapper">
            <?php foreach( $settings['team_members'] as $team ) : ?>
            <div class="swiper-slide">
                <div class="tel-team-item position-relative ">
                    <div class="team-img-social">
                        <?php if(!empty( $team['image']['url'] )) : ?>
                        <img src="<?php echo esc_url($team['image']['url']); ?>" alt="">
                        <?php endif; ?>

                        <?php if(!empty( $team['social_links'] )) : ?>
                        <div class="team-social position-absolute">
                            <?php foreach($team['social_links'] as $social_link) : ?>
                            <a href="<?php echo esc_url($social_link['social_link']['url']); ?>">
                                <?php echo elh_element_render_icon($social_link, '', 'social_icon'); ?>
                            </a>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>

                    </div>
                    <div class="team-text position-absolute d-flex align-items-center justify-content-between">
                        <div class="name-degi">
                            <?php if(!empty( $team['name'] )) : ?>
                            <h3><a href="<?php echo esc_url($team['details_link']['url']); ?>">
                                <?php echo esc_html($team['name']); ?></a>
                            </h3>
                            <?php endif; ?>

                            <?php if(!empty( $team['designation'] )) : ?>
                            <span><?php echo esc_html($team['designation']); ?></span>
                            <?php endif; ?>
                        </div>
                        <a class="text_more d-flex align-items-center justify-content-center" href="<?php echo esc_url($team['details_link']['url']); ?>">
                            <?php
                                if ($team['type'] === 'image' && ($team['details_image']['url'] || $team['details_image']['id'])) {
                                    $this->get_render_attribute_string('details_image');
                                    $team['hover_animation'] = 'disable-animation';?>
                                    <img src="<?php echo esc_url($team['details_image']['url']);?>" alt="">
                                    
                              <?php   } elseif (!empty($team['details_icon'])) {
                                    elh_element_render_icon($team, '', 'details_icon');
                                }
                            ?>
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>