<?php

$image = $settings['image']['url'];

?>

<div class="tel-team-item-4 text-center position-relative">
    <?php if(!empty( $settings['social_links'] )) : ?>
    <div class="team-social position-absolute">
        <?php foreach($settings['social_links'] as $social_link) : ?>
            <a href="<?php echo esc_url($social_link['social_link']['url']) ?>">
                <?php echo elh_element_render_icon($social_link, '', 'social_icon'); ?>
            </a>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
    <div class="team-img position-relative">
        <?php if(!empty( $image )) : ?>
        <img class="w-100" src="<?php echo esc_url($image); ?>" alt="">
        <?php endif; ?>
    </div>
    <div class="team-text position-absolute">
        <h3><a href="<?php echo esc_url($settings['link_to_single']['url']);?>"><?php echo esc_html($settings['name']); ?></a></h3>
        <?php if(!empty( $settings['designation'] )) : ?>
        <span><?php echo esc_html($settings['designation']); ?></span>
        <?php endif; ?>
    </div>
</div>