<?php

$image = $settings['image']['url'];

?>
<div class="wow fadeInUp" <?php if(!empty($settings['anim_delay'])):?> data-wow-delay="<?php echo esc_attr($settings['anim_delay'])?>" data-wow-duration="1200ms" <?php endif;?> >
<div class="tx-teamBox tx-teamBox__styleOne">
    <div class="tx-thumb tx-radious-60 position-relative">
        <?php if(!empty( $image )) : ?>
        <img class="w-100" src="<?php echo esc_url($image); ?>" alt="">
        <?php endif; ?>

        <?php if(!empty( $settings['social_links'] )) : ?>
        <div class="tx-social-links position-absolute start-50 d-flex align-items-center justify-content-center translate-middle-x">
            <?php foreach($settings['social_links'] as $social_link) : ?>
            <a href="<?php echo esc_url($social_link['social_link']['url']) ?>">
                <?php echo elh_element_render_icon($social_link, '', 'social_icon'); ?>
            </a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
    <div class="tx-content mt-25 text-center">
        <?php if(!empty( $settings['name'] )) : ?>
        <h4 class="tx-name">
            <a href=""><?php echo esc_html($settings['name']); ?></a>
        </h4>
        <?php endif; ?>

        <?php if(!empty( $settings['designation'] )) : ?>
        <span class="tx-designation"><?php echo esc_html($settings['designation']); ?></span>
        <?php endif; ?>
    </div>
</div>
</div>