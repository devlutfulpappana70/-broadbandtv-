<div class="tna-team-1-member <?php echo $settings['anim_name'] ? esc_attr($settings['anim_name']) : ''; ?>"
data-wow-delay="<?php echo $settings['anim_delay'] ? esc_attr($settings['anim_delay']) : ''; ?>"
data-wow-duration="<?php echo $settings['anim_duration'] ? esc_attr($settings['anim_duration']) : ''; ?>">
    <ul class="tna-team-1-member-social">
        <?php foreach($settings['social_links'] as $social_link) : ?>
        <li>
            <a href="<?php echo esc_url($social_link['social_link']['url']) ?>">
                <?php echo elh_element_render_icon($social_link, '', 'social_icon'); ?>
            </a>
        </li>
        <?php endforeach; ?>
    </ul>

    <?php if(!empty( $settings['bg_image']['url'] )) : ?>
    <img src="<?php echo esc_url($settings['bg_image']['url']); ?>" alt="" class="shape">
    <?php endif; ?>

    <?php if(!empty( $settings['image']['url'] )) : ?>
    <div class="main-img">
        <img src="<?php echo esc_url($settings['image']['url']); ?>" alt="">
    </div>
    <?php endif; ?>
    <div class="content-wrap">
        <div class="name-wrap">
            <?php if(!empty( $settings['name'] )) : ?>
            <a href="#" class="tna-heading-1 name"><?php echo esc_html($settings['name']); ?></a>
            <?php endif; ?>

            <?php if(!empty( $settings['designation'] )) : ?>
            <p class="tna-para-1 bio"><?php echo esc_html($settings['designation']); ?></p>
            <?php endif; ?>
        </div>

        <a href="<?php echo esc_url($settings['link_to_single']['url']);?>" class="btn-link flat_3">
            <i class="flaticon-resize"></i>
        </a>
    </div>
</div>