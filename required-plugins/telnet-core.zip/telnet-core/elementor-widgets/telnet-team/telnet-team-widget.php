<?php

namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
use \Elementor\Core\Schemes\Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;

defined( 'ABSPATH' ) || die();

class Telnet_Team extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name() {
        return 'telnet_team';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title() {
        return __( 'TelNet Team', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/gradient-heading/';
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-t-letter';
    }

    public function get_keywords() {
        return ['count', 'telnet', 'telnet team'];
    }

    public function elh_element_animations() {
        return [
            'none' => __( 'None', 'telnet-core' ),
            'fadeIn' => __( 'Fade In', 'telnet-core' ),
            'fadeInUp' => __( 'Fade In Up', 'telnet-core' ),
            'fadeInDown' => __( 'Fade In Down', 'telnet-core' ),
            'fadeInLeft' => __( 'Fade In Left', 'telnet-core' ),
            'fadeInRight' => __( 'Fade In Right', 'telnet-core' ),
            'fadeInUpBig' => __( 'Fade In Up Big', 'telnet-core' ),
            'fadeInDownBig' => __( 'Fade In Down Big', 'telnet-core' ),
            'fadeInLeftBig' => __( 'Fade In Left Big', 'telnet-core' ),
            'fadeInRightBig' => __( 'Fade In Right Big', 'telnet-core' ),
            'bounceIn' => __( 'Bounce In', 'telnet-core' ),
            'bounceInUp' => __( 'Bounce In Up', 'telnet-core' ),
            'bounceInDown' => __( 'Bounce In Down', 'telnet-core' ),
            'bounceInLeft' => __( 'Bounce In Left', 'telnet-core' ),
            'bounceInRight' => __( 'Bounce In Right', 'telnet-core' ),
            'rotateIn' => __( 'Rotate In', 'telnet-core' ),
            'rotateInUpLeft' => __( 'Rotate In Up Left', 'telnet-core' ),
            'rotateInDownLeft' => __( 'Rotate In Down Left', 'telnet-core' ),
            'rotateInUpRight' => __( 'Rotate In Up Right', 'telnet-core' ),
            'rotateInDownRight' => __( 'Rotate In Down Right', 'telnet-core' ),
            'lightSpeedIn' => __( 'Light Speed In', 'telnet-core' ),
            'rollIn' => __( 'Roll In', 'telnet-core' ),
            'zoomIn' => __( 'Zoom In', 'telnet-core' ),
            'zoomInUp' => __( 'Zoom In Up', 'telnet-core' ),
            'zoomInDown' => __( 'Zoom In Down', 'telnet-core' ),
            'zoomInLeft' => __( 'Zoom In Left', 'telnet-core' ),
            'zoomInRight' => __( 'Zoom In Right', 'telnet-core' ),
            'slideInUp' => __( 'Slide In Up', 'telnet-core' ),
            'slideInDown' => __( 'Slide In Down', 'telnet-core' ),
            'slideInLeft' => __( 'Slide In Left', 'telnet-core' ),
            'slideInRight' => __( 'Slide In Right', 'telnet-core' ),
        ];
    }

    protected function register_content_controls() {

        //Settings
        $this->start_controls_section(
            '_section_settings',
            [
                'label' => __( 'Settings', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'design_style',
            [
                'label'              => __( 'Design Style', 'telnet-core' ),
                'type'               => Controls_Manager::SELECT,
                'options'            => [
                    'style_1' => __( 'Style 1', 'telnet-core' ),
                    'style_2' => __( 'Style 2: SLIDER', 'telnet-core' ),
                    'style_3' => __( 'Style 3: Grid', 'telnet-core' ),
                    'style_4' => __( 'Style 4: Grid', 'telnet-core' ),
                    'style_5' => __( 'Style 5: Grid', 'telnet-core' ),
                ],
                'default'            => 'style_1',
                'frontend_available' => true,
                'style_transfer'     => true,
            ]
        );

        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'team_bg_image',
				'types' => [ 'classic' ],
				'exclude' => [ 'color' ],
				'selector' => '{{WRAPPER}} .tel-team-section-2:before',
                'fields_options' => [
                    'background' => [
                        'label' => esc_html__( 'Team BG ', 'telnet-core' ),
                        'separator' => 'before',
                    ]
                ],
                'condition' => [
                    'design_style' => 'style_3',
                ],
			]
		);


        // anim name list for animation
        $this->add_control(
            'anim_name',
            [
                'label'       => __( 'Animation Name', 'telnet-core' ),
                'type'        => Controls_Manager::SELECT,
                'options'     => $this->elh_element_animations(),
                'default'     => 'fadeInUp',
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );

        // anim delay
        $this->add_control(
            'anim_delay',
            [
                'label'       => __( 'Animation Delay', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );

        // anim duration
        $this->add_control(
            'anim_duration',
            [
                'label'       => __( 'Animation Duration', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_title',
            [
                'label' => __( 'Team Member', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'design_style' => ['style_1', 'style_4', 'style_5'],
                ],
            ]
        );

        // image
        $this->add_control(
            'image',
            [
                'label'   => __( 'Image', 'telnet-core' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        // bg_image
        $this->add_control(
            'bg_image',
            [
                'label'   => __( 'Background Image', 'telnet-core' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'design_style' => ['style_5'],
                ],
            ]
        );

        // name
        $this->add_control(
            'name',
            [
                'label'       => __( 'Name', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter your name', 'telnet-core' ),
                'default'     => __( 'John Doe', 'telnet-core' ),
            ]
        );
        $this->add_control(
            'icon_img',
            [
                'label'       => __( 'Icon Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'condition' => [
                    'design_style' => 'style_3',
                ],
            ]
        );
        $this->add_control(
            'icon_img2',
            [
                'label'       => __( 'Icon Image 2', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'condition' => [
                    'design_style' => 'style_3',
                ],
            ]
        );

        // designation
        $this->add_control(
            'designation',
            [
                'label'       => __( 'Designation', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter your designation', 'telnet-core' ),
                'default'     => __( 'CEO', 'telnet-core' ),
            ]
        );
        $this->add_control(
            'link_to_single',
            [
                'label'       => __( 'Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
            ]
        );

        // social links
        $repeater = new Repeater();

        $repeater->add_control(
            'social_icon',
            [
                'label'       => __( 'Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'label_block' => true,
                'default'     => [
                    'value'   => 'fas fa-check',
                    'library' => 'solid',
                ],
            ]
        );

        $repeater->add_control(
            'social_link',
            [
                'label'       => __( 'Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'telnet-core' ),
                'default'     => [
                    'url' => '#',
                ],
            ]
        );

        $this->add_control(
            'social_links',
            [
                'label'       => __( 'Social Links', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ social_icon.value }}}',
            ]
        );

        $this->end_controls_section();

        // team member slider
        $this->start_controls_section(
            '_section_slider',
            [
                'label' => __( 'Team Members', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'design_style' => ['style_2', 'style_3'],
                ],
            ]
        );
         // sub title
         $this->add_control(
            'sub_title',
            [
                'label'       => __( 'Sub Title', 'telnet-core' ),
                'label_block' => true,
                'type'        => Controls_Manager::TEXTAREA,
                'rows'        => 4,
                'default'     => 'Sub Title',
                'placeholder' => __( 'Sub Title Text', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
                'condition'   => [
                    'design_style' => ['style_3'],
                ],
            ]
        );

        $this->add_control(
            'title',
            [
                'label'       => __( 'Title', 'telnet-core' ),
                'label_block' => true,
                'type'        => Controls_Manager::TEXTAREA,
                'rows'        => 4,
                'default'     => 'Heading Title',
                'placeholder' => __( 'Heading Text', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
                'condition'   => [
                    'design_style' => ['style_3'],
                ],
            ]
        );

        $this->add_control(
            'description',
            [
                'label'       => __( 'Description', 'telnet-core' ),
                'label_block' => true,
                'type'        => Controls_Manager::TEXTAREA,
                'rows'        => 4,
                'default'     => 'The opportunity to work abroad is a popular prospect, one',
                'placeholder' => __( 'Description Text', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
                'condition'   => [
                    'design_style' => ['style_3'],
                ],
            ]
        );
        $this->add_control(
            'btn_label',
            [
                'label'       => __( 'Button Label', 'telnet-core' ),
                'label_block' => true,
                'type'        => Controls_Manager::TEXT,
                'dynamic'     => [
                    'active' => true,
                ],
                'condition'   => [
                    'design_style' => ['style_3'],
                ],
            ]
        );
        $this->add_control(
            'btn_arrow',
            [
                'label'       => __( 'Button Arrow', 'telnet-core' ),
                'label_block' => true,
                'type'        => Controls_Manager::MEDIA,
                'dynamic'     => [
                    'active' => true,
                ],
                'condition'   => [
                    'design_style' => ['style_3'],
                ],
            ]
        );
        $this->add_control(
            'btn_link',
            [
                'label'       => __( 'Button Link', 'telnet-core' ),
                'label_block' => true,
                'type'        => Controls_Manager::URL,
                'dynamic'     => [
                    'active' => true,
                ],
                'condition'   => [
                    'design_style' => ['style_3'],
                ],
            ]
        );

        // team members
        $repeater = new Repeater();

        // image
        $repeater->add_control(
            'image',
            [
                'label'   => __( 'Image', 'telnet-core' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        // name
        $repeater->add_control(
            'name',
            [
                'label'       => __( 'Name', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter your name', 'telnet-core' ),
                'default'     => __( 'John Doe', 'telnet-core' ),
            ]
        );

        // designation
        $repeater->add_control(
            'designation',
            [
                'label'       => __( 'Designation', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter your designation', 'telnet-core' ),
                'default'     => __( 'CEO', 'telnet-core' ),
            ]
        );

        // team details link
        $repeater->add_control(
            'details_link',
            [
                'label'       => __( 'Details Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'telnet-core' ),
                'default'     => [
                    'url' => '#',
                ],
            ]
        );

        // details icon
        $repeater->add_control(
            'type',
            [
                'label'          => __( 'Details Icon', 'telnet-core' ),
                'type'           => Controls_Manager::CHOOSE,
                'label_block'    => false,
                'options'        => [
                    'icon'  => [
                        'title' => __( 'Icon', 'telnet-core' ),
                        'icon'  => 'far fa-smile',
                    ],
                    'image' => [
                        'title' => __( 'Image', 'telnet-core' ),
                        'icon'  => 'fa fa-image',
                    ],
                ],
                'default'        => 'icon',
                'toggle'         => false,
                'style_transfer' => true,
            ]
        );

        // list icon
        $repeater->add_control(
            'details_icon',
            [
                'label'       => __( 'Details Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'default'     => [
                    'value'   => 'fas fa-arrow-right',
                    'library' => 'solid',
                ],
                'label_block' => true,
                'condition'   => [
                    'type' => 'icon',
                ],
            ]
        );

        // list image
        $repeater->add_control(
            'details_image',
            [
                'label'       => __( 'Details Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition'   => [
                    'type' => 'image',
                ],
            ]
        );

        $repeater->add_control(
            'social_links',
            [
                'label' => __('Social Links', 'telnet-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => [
                    // social icon
                    [
                        'name' => 'social_icon',
                        'label' => __('Social Icon', 'telnet-core'),
                        'type' => Controls_Manager::ICONS,
                        'default' => [
                            'value' => 'fab fa-facebook-f',
                            'library' => 'fa-solid',
                        ],
                    ],
                    // social link
                    [
                        'name' => 'social_link',
                        'label' => __('Social Link', 'telnet-core'),
                        'type' => Controls_Manager::URL,
                        'placeholder' => __('https://your-link.com', 'telnet-core'),
                        'default' => [
                            'url' => '#',
                        ],
                    ],
                ],
            ],
        );

        // team members
        $this->add_control(
            'team_members',
            [
                'label'       => __( 'Team Members', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ name }}}',
            ]
        );

        $this->end_controls_section();

    }

    protected function register_style_controls() {


    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $dir = dirname( __FILE__ );
        $style = !empty($settings['design_style']) ? $settings['design_style'] : 'style_1';

        switch ($style) {
            case 'style_5':
                include $dir . '/views/view-5.php';
                break;
            case 'style_4':
                include $dir . '/views/view-4.php';
                break;
            case 'style_3':
                include $dir . '/views/view-3.php';
                break;
            case 'style_2':
                include $dir . '/views/view-2.php';
                break;
            default:
                include $dir . '/views/view-1.php';
        }
    }
}
