<?php
	$rand = rand(1, 9999999);
?>

<div class="tna-movie-3-area flat_3">
	<div class="tna-movie-3-wrap">
		<div class="row g-0">
			<div class="col-xl-6">
				<div class="tab-content tna-movie-3-tabs-content" id="myTabContent-<?php echo esc_attr($id); ?>">
					<?php
						foreach ($settings['movie_poster_lists'] as $id => $list) :
							$active = ($id == 1) ? 'show active' : '';
							$id = $id . '_' . $rand;
							$aria_selected = ($id == 1) ? 'true' : 'false';
					?>
					<div class="tab-pane fade <?php echo esc_attr($active); ?>"
					id="home-<?php echo esc_attr($id); ?>"
					role="tabpanel"
					aria-labelledby="home-<?php echo esc_attr($id); ?>">
						<div class="tna-movie-3-tabs-content-item bg-default" tna-data-background="<?php echo $list['big_banner_image']['url'] ? esc_url($list['big_banner_image']['url']) : ''; ?>" >
						<?php if(!empty( $list['movie_name'] )) : ?>
							<h5 class="tna-heading-2 movie-name"><?php echo elh_element_kses_intermediate( $list['movie_name'] ); ?></h5>
						<?php endif; ?>
							<p class="tna-para-2 movie-date">
								<?php echo elh_element_kses_intermediate( $list['date'] ); ?>

								<?php if(!empty( $list['quality'] )) : ?>
								<span class="qoulity"><?php echo elh_element_kses_intermediate( $list['quality'] ); ?></span>
								<?php endif; ?>

								<?php if(!empty( $list['rating'] )) : ?>
								<span class="reating"><?php echo elh_element_kses_intermediate( $list['rating'] ); ?></span>
								<?php endif; ?>
							</p>

							<?php if(!empty( $list['short_description'] )) : ?>
							<p class="tna-para-2 movie-disc">
								<?php echo elh_element_kses_intermediate( $list['short_description'] ); ?></p>
							<?php endif; ?>

							<?php if(!empty( $list['btn_text'] )) : ?>
							<a class="tna-pr-btn-4">
								<span class="text"><?php echo elh_element_kses_intermediate( $list['btn_text'] ); ?></span>
								<?php \Elementor\Icons_Manager::render_icon( $list['btn_icon'], [ 'aria-hidden' => 'true' ] ); ?>
							</a>
							<?php endif; ?>

							<?php if(!empty( $list['video_link']['url'] )) : ?>
							<div class="btn-position">
								<a href="<?php echo esc_url($list['video_link']['url']); ?>" class="tna-playbtn-1 popup-video">
									<?php \Elementor\Icons_Manager::render_icon( $list['video_icon'], [ 'aria-hidden' => 'true' ] ); ?>
								</a>
							</div>
							<?php endif; ?>
						</div>
					</div>
					<?php endforeach; ?>
				</div>
			</div>
			<div class="col-xl-6">
				<div class="tna-movie-3-content">

					<!-- section-title -->
					<div class="tna-section-title mb-25 bg-default" tna-data-background="<?php echo $settings['bg_image']['url'] ? esc_url($settings['bg_image']['url']) : ''; ?>">
						<?php if(!empty( $settings['sub_title'] )) : ?>
						<h4 class="tna-subtitle-2 has-4 wow fadeInRight">
							<?php echo elh_element_kses_intermediate($settings['sub_title']); ?>
						</h4>
						<?php endif; ?>

						<?php printf('<%1$s %2$s>%3$s</%1$s>',
							tag_escape($settings['title_tag']),
							$this->get_render_attribute_string('title'),
							$title
						); ?>

						<?php if(!empty( $settings['description'] )) : ?>
						<p class="tna-para-2 wow fadeInRight"><?php echo elh_element_kses_intermediate($settings['description']); ?></p>
						<?php endif; ?>
					</div>

					<div class="js-marquee-wrapper">
						<ul class="tna-movie-3-tabs-btn js-marquee" id="myTab-<?php echo esc_attr($id); ?>" role="tablist">

							<?php
								foreach ($settings['movie_poster_lists'] as $id => $list) :
									$active = ($id == 1) ? 'active' : '';
									$id = $id . '_' . $rand;
									$aria_selected = ($id == 1) ? 'true' : 'false';
							?>
							<li class="nav-item" role="presentation">
								<button class="nav-link <?php echo esc_attr($active); ?>"
								id="home-<?php echo esc_attr($id); ?>"
								data-bs-toggle="tab"
								data-bs-target="#home<?php echo esc_attr($id); ?>"
								type="button"
								role="tab"
								aria-controls="home-<?php echo esc_attr($id); ?>"
								aria-selected="<?php echo esc_attr($aria_selected); ?>">
								<?php if(!empty( $list['rating'] )) : ?>
									<span class="reating" ><i class="fas fa-star"></i>
										<?php echo elh_element_kses_intermediate( $list['rating'] ); ?>
									</span>
								<?php endif; ?>

								<?php if(!empty( $list['comment_count'] )) : ?>
									<span class="comment" ><i class="fas fa-comments-alt"></i>
										<?php echo elh_element_kses_intermediate( $list['comment_count'] ); ?>
									</span>
								<?php endif; ?>

								<?php if(!empty( $list['movie_poster_small']['url'] )) : ?>
									<img src="<?php echo  esc_url($list['movie_poster_small']['url']); ?>" alt="">
								<?php endif; ?>

									<?php if(!empty( $list['video_link']['url'] )) : ?>
									<span class="btn-position">
										<a href="<?php echo esc_url($list['video_link']['url']); ?>" class="tna-playbtn-1 popup-video">
											<?php \Elementor\Icons_Manager::render_icon( $list['video_icon'], [ 'aria-hidden' => 'true' ] ); ?>
										</a>
									</span>
									<?php endif; ?>
								</button>
							</li>
							<?php endforeach; ?>
						</ul>
					</div>

				</div>
			</div>
		</div>
	</div>
</div>