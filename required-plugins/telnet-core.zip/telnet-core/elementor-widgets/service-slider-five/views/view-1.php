<div class="tna-services-3-area flat_3">
    <div class="container tna-container-1">
        <div class="swiper tna-services-3-slider">
            <div class="swiper-container tna_services_3_active">
                <div class="swiper-wrapper">

                    <?php foreach( $settings['services'] as $list ) : ?>
                    <div class="swiper-slide">
                        <div class="tna-services-3-item bg-default" tna-data-background="<?php echo $list['bg_shape']['url'] ? esc_url($list['bg_shape']['url']) : ''; ?>">
                            <?php if( $list['enable_icon'] === 'yes' ) : ?>
                            <div class="icon-2">
                                <?php if($list['icon_type'] == 'icon') : ?>
                                    <?php \Elementor\Icons_Manager::render_icon( $list['service_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                <?php else : ?>
                                    <img src="<?php echo esc_url($list['service_image']['url']); ?>" alt="" />
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                            <div class="content-wrap">

                                <?php if( $list['enable_icon'] === 'yes' ) : ?>
                                <div class="icon">
                                    <?php if($list['icon_type'] == 'icon') : ?>
                                        <?php \Elementor\Icons_Manager::render_icon( $list['service_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                    <?php else : ?>
                                        <img src="<?php echo esc_url($list['service_image']['url']); ?>" alt="" />
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>

                                <?php if(!empty( $list['title'] )) : ?>
                                <h3 class="title tna-heading-2">
                                    <a class="tna-inherit" href="<?php echo esc_url($list['list_link']['url']); ?>"><?php echo elh_element_kses_intermediate($list['title']); ?></a>
                                </h3>
                                <?php endif; ?>

                                <?php if(!empty( $list['description'] )) : ?>
                                <p class="tna-para-2 disc"><?php echo elh_element_kses_intermediate($list['description']); ?></p>
                                <?php endif; ?>

                                <?php if(!empty( $list['list_link']['url'] )) : ?>
                                <a class="s3-btn" href="<?php echo esc_url($list['list_link']['url']); ?>">
                                    <?php \Elementor\Icons_Manager::render_icon( $list['btn_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- slider-btn -->
            <div class="tna_services_3_prev-position">
                <div class="tna_services_3_prev">
                    <i class="flaticon-arrow-3"></i>
                </div>
            </div>
            <div class="tna_services_3_next-position">
                <div class="tna_services_3_next">
                    <i class="flaticon-arrow-4"></i>
                </div>
            </div>

        </div>
    </div>
</div>
