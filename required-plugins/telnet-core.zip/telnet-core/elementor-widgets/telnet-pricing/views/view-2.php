<?php

use \Elementor\Group_Control_Image_Size;

?>
<div class="wow fadeInUp" <?php if(!empty($settings['anim_delay'])):?> data-wow-delay="<?php echo esc_attr($settings['anim_delay'])?>" data-wow-duration="1200ms" <?php endif;?> >
<div class="tx-pricingBox tx-pricingBox__styleTwo">

    <?php if(!empty( $settings['pricing_subtitle'] || $settings['pricing_title'] )) : ?>
    <div class="tx-pricingBox-header d-block text-center pt-50">
        <?php if(!empty( $settings['pricing_subtitle'] )) : ?>
        <span class="tx-subTitle"><?php echo elh_element_kses_intermediate($settings['pricing_subtitle']); ?></span>
        <?php endif; ?>

        <?php if(!empty( $settings['pricing_title'] )) : ?>
        <h5 class="tx-title"><?php echo elh_element_kses_intermediate($settings['pricing_title']); ?></h5>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php if(!empty( $currency || $settings['price'] || $settings['period'] || $settings['package_feature'] )) : ?>
    <div class="tx-pricingBox-price text-center mt-20">

        <?php if(!empty( $currency )) : ?>
        <sub class="tx-price__currency"><?php echo esc_html($currency); ?></sub>
        <?php endif; ?>

        <?php if(!empty( $settings['price'] )) : ?>
        <span class="tx-price__price">
            <?php echo esc_html($settings['price']); ?>
        </span>
        <?php endif; ?>

        <?php if(!empty( $settings['period'] )) : ?>
        <sub class="tx-price__period"><?php echo esc_html($settings['period']); ?></sub>
        <?php endif; ?>

    </div>
    <?php endif; ?>

    <div class="tx-wrapper">

        <div class="tx-featureImg-wrapper m-auto pt-20">
            <div class="tx-thumb tx-outherHoverEffect">
                <?php if(!empty( $settings['package_image']['url'] )) : ?>
                <img class="w-100" src="<?php echo esc_url($settings['package_image']['url']); ?>" alt="">
                <?php endif; ?>
            </div>

            <?php if(!empty( $settings['feature_image_lists'] )) : ?>
            <div class="tx-featureIcons mt-15">
                <?php foreach( $settings['feature_image_lists'] as $feature_image_list ) : ?>
                <div class="tx-icon d-flex align-items-center justify-content-center">
                    <?php
                        if ($feature_image_list['feature_image_type'] === 'image' && ($feature_image_list['feature_image']['url'] || $feature_image_list['feature_image']['id'])) {
                            $this->get_render_attribute_string('feature_image');
                            $feature_image_list['hover_animation'] = 'disable-animation';
                            echo Group_Control_Image_Size::get_attachment_image_html($feature_image_list, 'thumbnail', 'feature_image');
                        } elseif (!empty($feature_image_list['feature_image_icon'])) {
                            elh_element_render_icon($feature_image_list, '', 'feature_image_icon');
                        }
                    ?>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

        <?php if(!empty( $settings['package_feature_lists'] )) : ?>
        <ul class="list-unstyled tx-listItems tx-listItems__styleOne">
            <?php foreach($settings['package_feature_lists'] as $list) : ?>
            <li>
                <?php if(!empty($list['package_feature_icon'])) : ?>
                <span class="tx-icon">
                    <?php elh_element_render_icon($list, '', 'package_feature_icon'); ?>
                </span>
                <?php endif; ?>

                <?php if(!empty( $list['package_feature_title'] )) : ?>
                <p><?php echo elh_element_kses_intermediate($list['package_feature_title']); ?></p>
                <?php endif; ?>
            </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>

        <?php if(!empty( $settings['vat_charge'] || $settings['installation_charge'] )) : ?>
        <div class="tx-pricingBox-fees">
            <?php if(!empty( $settings['vat_charge'] )) : ?>
            <p><?php echo elh_element_kses_intermediate($settings['vat_charge']); ?></p>
            <?php endif; ?>

            <?php if(!empty( $settings['installation_charge'] )) : ?>
            <p><?php echo elh_element_kses_intermediate($settings['installation_charge']); ?></p>
            <?php endif; ?>
        </div>
        <?php endif; ?>

    </div>

    <?php if(!empty( $settings['button_link']['url'] || $settings['button_text'] )) : ?>
    <a href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>" class="tx-button tx-button__styleDark">
        <?php echo esc_html($settings['button_text']); ?>
    </a>
    <?php endif; ?>
</div>
</div>