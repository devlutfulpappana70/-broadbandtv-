<?php

use \Elementor\Group_Control_Image_Size;

?>

<div class="wow <?php echo $settings['anim_name'] ? esc_attr($settings['anim_name']) : ''; ?>"
data-wow-delay="<?php echo $settings['anim_delay'] ? esc_attr($settings['anim_delay']) : ''; ?>"
data-wow-duration="<?php echo $settings['anim_duration'] ? esc_attr($settings['anim_duration']) : ''; ?>">
<div class="tx-pricingBox tx-pricingBox__styleOne">
    <?php if(!empty( $settings['pricing_title'] )) : ?>
    <span class="tx-pricingBox-header d-block text-center">
    <?php echo elh_element_kses_intermediate($settings['pricing_title']); ?>
    </span>
    <?php endif; ?>

    <div class="tx-wrapper">
        <?php if(!empty( $settings['package_speed'] || $settings['package_speed_unit'] || $settings['package_title'] )) : ?>
        <div class="tx-pricingBox-package text-center">
            <h2 class="speed">
                <?php echo $settings['package_speed'] ? elh_element_kses_basic($settings['package_speed']) : ''; ?>
                <?php if(!empty( $settings['package_speed_unit'] )) : ?>
                <span class="speed-unit"><?php echo elh_element_kses_intermediate($settings['package_speed_unit']); ?></span>
                <?php endif; ?>
            </h2>

            <?php if(!empty( $settings['package_title'] )) : ?>
            <h6 class="package_title">
                <?php echo elh_element_kses_intermediate($settings['package_title']); ?>
            </h6>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php if(!empty( $settings['package_feature_lists'] )) : ?>
        <ul class="list-unstyled tx-listItems tx-listItems__styleOne">
            <?php foreach($settings['package_feature_lists'] as $list) : ?>
            <li>
                <?php if(!empty($list['package_feature_icon'])) : ?>
                <span class="tx-icon">
                    <?php elh_element_render_icon($list, '', 'package_feature_icon'); ?>
                </span>
                <?php endif; ?>

                <?php if(!empty( $list['package_feature_title'] )) : ?>
                <p><?php echo elh_element_kses_intermediate($list['package_feature_title']); ?></p>
                <?php endif; ?>
            </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>

        <?php if(!empty( $settings['vat_charge'] || $settings['installation_charge'] )) : ?>
        <div class="tx-pricingBox-fees text-center">
            <?php if(!empty( $settings['vat_charge'] )) : ?>
            <p><?php echo elh_element_kses_intermediate($settings['vat_charge']); ?></p>
            <?php endif; ?>

            <?php if(!empty( $settings['installation_charge'] )) : ?>
            <p><?php echo elh_element_kses_intermediate($settings['installation_charge']); ?></p>
            <?php endif; ?>
        </div>
        <?php endif; ?>


        <?php if(!empty( $currency || $settings['price'] || $settings['period'] || $settings['package_feature'] )) : ?>
        <div class="tx-pricingBox-price text-center">

            <?php if(!empty( $currency )) : ?>
            <sub class="tx-price__currency tx-price__currency--white"><?php echo esc_html($currency); ?></sub>
            <?php endif; ?>

            <?php if(!empty( $settings['price'] )) : ?>
            <span class="tx-price__price tx-price__price--white">
                <?php echo esc_html($settings['price']); ?>
            </span>
            <?php endif; ?>

            <?php if(!empty( $settings['period'] )) : ?>
            <sub class="tx-price__period tx-price__period--white"><?php echo esc_html($settings['period']); ?></sub>
            <?php endif; ?>

        </div>
        <?php endif; ?>
    </div>

    <?php if(!empty( $settings['button_link']['url'] || $settings['button_text'] )) : ?>
    <a href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>" class="tx-button tx-button__styleTheme">
            <?php echo esc_html($settings['button_text']); ?>
    </a>
    <?php endif; ?>
</div>
</div>