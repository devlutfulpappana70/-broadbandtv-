<div class="tna-price-1-item flat_3 <?php echo $settings['anim_name'] ? esc_attr($settings['anim_name']) : ''; ?>"
data-wow-delay="<?php echo $settings['anim_delay'] ? esc_attr($settings['anim_delay']) : ''; ?>"
data-wow-duration="<?php echo $settings['anim_duration'] ? esc_attr($settings['anim_duration']) : ''; ?>">
    <?php if(!empty( $settings['shape_image_1']['url'] )) : ?>
    <img src="<?php echo esc_url($settings['shape_image_1']['url']); ?>" alt="" class="bg-shape-1">
    <?php endif; ?>

    <?php if(!empty( $settings['shape_image_2']['url'] )) : ?>
    <img src="<?php echo esc_url($settings['shape_image_2']['url']); ?>" alt="" class="bg-shape-2">
    <?php endif; ?>

    <div class="header">
        <?php if(!empty( $currency || $settings['price'] || $settings['period'] )) : ?>
        <div class="price-wrap">
            <h6 class="tna-heading-1 price">
                <span><?php echo esc_html($currency); ?></span><?php echo esc_html($settings['price']); ?></h6>
            <?php if(!empty( $settings['period'] )) : ?>
            <p class="tna-para-1 month"><?php echo esc_html($settings['period']); ?></p>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <div class="right">
            <?php if(!empty( $settings['pricing_title'] )) : ?>
            <span class="tna-heading-1 categorie"><?php echo elh_element_kses_intermediate($settings['pricing_title']); ?></span>
            <?php endif; ?>
            <?php if(!empty( $settings['feature_image_lists'] )) : ?>
            <ul class="feature-icon" >
                <?php foreach( $settings['feature_image_lists'] as $feature_image_list ) : ?>
                <li>
                <?php if($feature_image_list['feature_image_type'] == 'icon') : ?>
                    <?php \Elementor\Icons_Manager::render_icon( $feature_image_list['feature_image_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                <?php else : ?>
                    <img src="<?php echo esc_url($feature_image_list['feature_image']['url']); ?>" alt="" />
                <?php endif; ?>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
        </div>
    </div>
    <div class="body">

        <?php if(!empty( $settings['package_feature_lists'] )) : ?>
        <ul class="tna-list-item-1 mb-50">
            <?php foreach($settings['package_feature_lists'] as $list) : ?>
            <li>
                <?php elh_element_render_icon($list, '', 'package_feature_icon'); ?>
                <?php echo elh_element_kses_intermediate($list['package_feature_title']); ?>
            </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>

        <a href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>" class="tna-p1-btn" >
            <?php echo esc_html($settings['button_text']); ?> <i class="flaticon-right"></i>
        </a>
    </div>
</div>