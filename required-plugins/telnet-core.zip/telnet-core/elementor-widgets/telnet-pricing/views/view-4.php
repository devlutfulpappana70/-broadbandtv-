<?php

use \Elementor\Group_Control_Image_Size;

?>
<div class="tna-price-2-area">
<div class="price-block_two">
    <div class="price-block_two-inner wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
        <?php if(!empty( $settings['pricing_subtitle'] )) : ?>
        <div class="price-block_two-title"><?php echo elh_element_kses_intermediate($settings['pricing_subtitle']); ?></div>
        <?php endif; ?>

        <?php if(!empty( $settings['pricing_title'] )) : ?>
        <div class="price-block_two-category"><?php echo elh_element_kses_intermediate($settings['pricing_title']); ?></div>
        <?php endif; ?>

        <div class="price-block_two-price"><sub><?php echo esc_html($currency); ?></sub><?php echo esc_html($settings['price']); ?> <span><?php echo esc_html($settings['period']); ?></span></div>

        <?php if(!empty( $settings['package_image']['url'] )) : ?>
        <div class="price-block_two-image">
            <img src="<?php echo esc_url($settings['package_image']['url']); ?>" alt="">
        </div>
        <?php endif; ?>

        <?php if(!empty( $settings['feature_image_lists'] )) : ?>
        <ul class="price-block_two-options">
            <?php foreach( $settings['feature_image_lists'] as $feature_image_list ) : ?>
            <li>
                <?php
                    if ($feature_image_list['feature_image_type'] === 'image' && ($feature_image_list['feature_image']['url'] || $feature_image_list['feature_image']['id'])) {
                        $this->get_render_attribute_string('feature_image');
                        $feature_image_list['hover_animation'] = 'disable-animation';
                        echo Group_Control_Image_Size::get_attachment_image_html($feature_image_list, 'thumbnail', 'feature_image');
                    } elseif (!empty($feature_image_list['feature_image_icon'])) {
                        elh_element_render_icon($feature_image_list, '', 'feature_image_icon');
                    }
                ?>
            </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>

        <?php if(!empty( $settings['package_feature_lists'] )) : ?>
        <ul class="price-block_two-list">
            <?php foreach($settings['package_feature_lists'] as $list) : ?>
            <li><?php echo elh_element_kses_intermediate($list['package_feature_title']); ?></li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>
        <div class="price-block_two-vat">
            <?php echo elh_element_kses_intermediate($settings['vat_charge']); ?>
             <?php echo elh_element_kses_intermediate($settings['installation_charge']); ?>
        </div>

        <?php if(!empty( $settings['button_text'] )) : ?>
        <div class="price-block_two-button">
            <a class="theme-btn price-two_start-btn" href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>"><?php echo esc_html($settings['button_text']); ?></a>
        </div>
        <?php endif; ?>
    </div>
</div>
</div>