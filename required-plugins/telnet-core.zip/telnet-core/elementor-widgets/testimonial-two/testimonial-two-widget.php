<?php

namespace ElementHelper\Widget;


use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
use \Elementor\Core\Schemes\Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;

defined( 'ABSPATH' ) || die();

class Testimonial_Two extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name() {
        return 'testimonial_two';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title() {
        return __( 'Testimonial Two', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/gradient-heading/';
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-t-letter';
    }

    public function get_keywords() {
        return ['count', 'telnet', 'telnet testimonial', 'testimonial', 'telnet testimonial widget'];
    }

    protected function register_content_controls() {

        //Settings
        $this->start_controls_section(
            '_section_settings',
            [
                'label' => __( 'Settings', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );


        // list image
        $this->add_control(
            'image',
            [
                'label'       => __( 'BG Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );
        
        // sub title
        $this->add_control(
            'sub_title',
            [
                'label'       => __( 'Sub Title', 'telnet-core' ),
                'label_block' => true,
                'type'        => Controls_Manager::TEXTAREA,
                'rows'        => 4,
                'default'     => 'Sub Title',
                'placeholder' => __( 'Sub Title Text', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ]
            ]
        );
        
        

        $this->add_control(
            'title',
            [
                'label'       => __( 'Title', 'telnet-core' ),
                'label_block' => true,
                'type'        => Controls_Manager::TEXTAREA,
                'rows'        => 4,
                'default'     => 'Heading Title',
                'placeholder' => __( 'Heading Text', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );
        $this->add_control(
            'button_label',
            [
                'label'       => __( 'Button Label', 'telnet-core' ),
                'label_block' => true,
                'type'        => Controls_Manager::TEXT,
                'rows'        => 4,
                'default'     => 'Button Title',
                'placeholder' => __( 'Button Text', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );
        $this->add_control(
            'button_icon',
            [
                'label'       => __( 'Button Icon', 'telnet-core' ),
                'label_block' => true,
                'type'        => Controls_Manager::MEDIA,
            ]
        );
        $this->add_control(
            'button_link',
            [
                'label'       => __( 'Button Link', 'telnet-core' ),
                'label_block' => true,
                'type'        => Controls_Manager::URL,
            ]
        );
       

        $this->end_controls_section();
        
        $this->start_controls_section(
            '_section_testimonial',
            [
                'label' => __( 'Testimonial', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // repeater
        $repeater = new Repeater();


        // icon type
        $repeater->add_control(
            'type',
            [
                'label'          => __( 'Service Icon', 'telnet-core' ),
                'type'           => Controls_Manager::CHOOSE,
                'label_block'    => false,
                'options'        => [
                    'icon'  => [
                        'title' => __( 'Icon', 'telnet-core' ),
                        'icon'  => 'far fa-smile',
                    ],
                    'image' => [
                        'title' => __( 'Image', 'telnet-core' ),
                        'icon'  => 'fa fa-image',
                    ],
                ],
                'default'        => 'icon',
                'toggle'         => false,
                'style_transfer' => true,
            ]
        );

        // list icon
        $repeater->add_control(
            'quote_icon',
            [
                'label'       => __( 'Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'default'     => [
                    'value'   => 'fas fa-check',
                    'library' => 'solid',
                ],
                'label_block' => true,
                'condition'   => [
                    'type' => 'icon',
                ],
            ]
        );

        // list image
        $repeater->add_control(
            'quote_image',
            [
                'label'       => __( 'Quote Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition'   => [
                    'type' => 'image',
                ],
            ]
        );

        // image
        $repeater->add_control(
            'image',
            [
                'label'   => __( 'Image', 'telnet-core' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        // content
        $repeater->add_control(
            'comment',
            [
                'label'       => __( 'Comment', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'placeholder' => __( 'Enter your content', 'telnet-core' ),
                'default'     => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'telnet-core' ),
            ]
        );


        // name
        $repeater->add_control(
            'name',
            [
                'label'       => __( 'Name', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter your name', 'telnet-core' ),
                'default'     => __( 'John Doe', 'telnet-core' ),
            ]
        );

        // designation
        $repeater->add_control(
            'designation',
            [
                'label'       => __( 'Designation', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter your designation', 'telnet-core' ),
                'default'     => __( 'CEO', 'telnet-core' ),
            ]
        );

        $this->add_control(
            'testimonial_lists',
            [
                'label'       => __( 'Testimonial Lists', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ name }}}',
            ]
        );

        $this->end_controls_section();
        // count style
        $this->start_controls_section(
            '_section_count_style',
            [
                'label' => __( 'Count Text', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // count color
        $this->add_control(
            'count_color',
            [
                'label'     => __( 'Feedback Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-testimonial__styleOne .tx-comment p' => 'color: {{VALUE}};',
                ],
            ]
        );

        // typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'count_typography',
                'label'    => __( 'Feedbacy Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-testimonial__styleOne .tx-comment p',
            ]
        );
        // count color
        $this->add_control(
            'title_color',
            [
                'label'     => __( 'Title Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-testimonial__styleOne .tx-name' => 'color: {{VALUE}};',
                ],
            ]
        );

        // typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typography',
                'label'    => __( 'Title Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-testimonial__styleOne .tx-name',
            ]
        );
        // count color
        $this->add_control(
            'desig_color',
            [
                'label'     => __( 'Designation Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-testimonial__styleOne .tx-designation, .txNavPagi-wrapper .tx-testimonialPagination span, .txNavPagi-wrapper .swiper-pagination-current' => 'color: {{VALUE}};',
                ],
            ]
        );

        // typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'des_typography',
                'label'    => __( 'Designation Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-testimonial__styleOne .tx-designation',
            ]
        );

        // count end
        $this->end_controls_section();

    }

    protected function register_style_controls() {


    }

    protected function render() {

        $settings = $this->get_settings_for_display();
        $dir = dirname( __FILE__ );?>
        <section id="tel-testimonial-4" class="tel-testimonial-section-4 position-relative">
            <?php if(!empty($settings['image']['url'])):?>
            <span class="tel-testimonial-side-img position-absolute"><img src="<?php echo esc_url($settings['image']['url']);?>" alt=""></span>
            <?php endif;?>
            <div class="container">
                <div class="tel-testimonial-top-content-4 d-flex justify-content-between align-items-end">
                <div class="tel-section-title-2">
                        <?php if(!empty( $settings['sub_title'] )) : ?>
                        <div class="sub-title text-uppercase wow fadeInRight"  data-wow-delay="200ms" data-wow-duration="1000ms">
                            <?php echo elh_element_kses_intermediate($settings['sub_title']); ?>
                        </div>
                        <?php endif; ?>
                       <h3 class="headline-title"><?php echo wp_kses($settings['title'], true);?></h3>
                    </div>
                    <?php if(!empty($settings['button_label'])):?>
                        <div class="tel-btn-2 text-uppercase">
                            <a href="<?php echo esc_url($settings['button_link']['url']);?>"><?php echo esc_html($settings['button_label']);?> 
                            <?php if(!empty($settings['button_icon']['url'])):?>
                            <img src="<?php echo esc_url($settings['button_icon']['url']);?>" alt="">
                            <?php endif;?>
                        </a>
                        </div>
                    <?php endif;?>
                </div>
            </div>
            <div class="tel-testimonial-slider-area-4 d-flex justify-content-end">
                <div class="tel-testimonial-slider-4  swiper-container">
                    <div class="swiper-wrapper">
                        <?php foreach($settings['testimonial_lists'] as $item):?>
                        <div class="swiper-slide">
                            <div class="tel-testimonial-item-4">
                                <div class="testimonial-author-quote d-flex align-items-center justify-content-between">
                                    <div class="testimonial-author d-flex align-items-center">
                                        <div class="author-img">
                                            <img src="<?php echo esc_url($item['image']['url']);?>" alt="">
                                        </div>
                                        <div class="author-text">
                                            <h3><?php echo esc_html($item['name']); ?></h3>
                                            <span><?php echo esc_html($item['designation']); ?></span>
                                        </div>
                                    </div>
                                    <div class="testimonial-quote">
                                        <?php
                                            if ($item['type'] === 'image' && ($item['quote_image']['url'] || $item['quote_image']['id'])) {
                                                $this->get_render_attribute_string('quote_image');
                                                $item['hover_animation'] = 'disable-animation';
                                                echo Group_Control_Image_Size::get_attachment_image_html($item, 'thumbnail', 'quote_image');
                                            } elseif (!empty($item['quote_icon'])) {
                                                elh_element_render_icon($item, '', 'quote_icon');
                                            }
                                        ?>
                                    </div>
                                </div>
                                <div class="testimonial-text">
                                    <?php echo wp_kses($item['comment'], true);?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach;?>
                    </div>
                </div>
            </div>
            <div class="tel-testi-paginations text-center"></div>
        </section>	
    <?php 
    }
}
