<div class="tx-productSliderWrapper position-relative">
    <div class="swiper-container" data-txProductSlider>
        <div class="swiper-wrapper">
            <?php foreach ($posts as $post): ?>
            <div class="swiper-slide">
                <div class="tx-product-box tx-pd-20 tx-radious-25 tx-border-all tx-border-op-10">
                    <div class="tx-thumb position-relative">
                        <?php echo \ElementHelper\Element_El_Woocommerce::wishlist_button($post->ID); ?>
                        <?php
                            $product_thumbnail = \ElementHelper\Element_El_Woocommerce::product_thumb($post->ID);
                            if (!empty($product_thumbnail)) {
                                $product_title_or_name = get_the_title($post->ID);
                                $alt_text = 'Product: ' . esc_attr($product_title_or_name);
                                echo '<img src="' . esc_attr($product_thumbnail) . '" alt="' . $alt_text . '">';
                            }
                        ?>
                    </div>
                    <div class="tx-content position-relative tx-z1 pt-20">
                        <h2 class="tx-product-title">
                            <?php
                                $title = $post->post_title;
                                printf('<a href="%2$s">%1$s</a>',
                                    esc_html($title),
                                    esc_url(get_the_permalink($post->ID))
                                );
                            ?>
                        </h2>
                        <div class="tx-productPrice pt-10">
                            <?php print \ElementHelper\Element_El_Woocommerce::tx_get_price($post->ID, true); ?>
                        </div>
                        <div class="tx-buttonWrapper mt-20">
                            <?php echo \ElementHelper\Element_El_Woocommerce::add_to_cart_button_text($post->ID); ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <!-- slider navigation -->
    <div class="tx-slideNav tx-slideNav__styleOuter tx-slideNav__styleMiddle tx-slideNav__styleLight">
        <div class="swiper-button-prev">
            <i class="fa-regular fa-arrow-left-long"></i>
        </div>
        <div class="swiper-button-next">
            <i class="fa-regular fa-arrow-right-long"></i>
        </div>
    </div>
</div>