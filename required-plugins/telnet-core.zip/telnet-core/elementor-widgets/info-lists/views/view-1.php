<?php

if ( !empty( $settings['info_items'] ) ): ?>
<ul class="list-unstyled tx-listItems tx-listItems__styleOne tx-listItems__styleInfoList">
    <?php foreach ( $settings['info_items'] as $key => $list ): ?>
    <li>
        <?php if(!empty( $list['info_label'] )) : ?>
        <span class="tx-label"><?php echo elh_element_kses_intermediate( $list['info_label'] ); ?></span>
        <?php endif; ?>

        <?php if(!empty( $list['info_text'] )) : ?>
        <p class="tx-text"><?php echo elh_element_kses_intermediate( $list['info_text'] ); ?></p>
        <?php endif; ?>
    </li>
    <?php endforeach;?>
</ul>
<?php endif;