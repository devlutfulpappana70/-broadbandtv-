<div class="tna-partner-1-area">
    <div class="tna-partner-1-wrap">
        <h5 class="tna-heading-1 title txa-split-text txa-split-in-up ">
            <?php echo elh_element_kses_intermediate($settings['title']); ?>
            <svg width="300" height="3" viewBox="0 0 300 3" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="0.75" y="0.75" width="298.5" height="1.5" stroke="#E10419" stroke-width="1.5" stroke-dasharray="8 8"/>
            </svg>
        </h5>
        <div class="tna-partner-1-logo-wrap">
            <div class="tna-partner-1-logo">
                <?php foreach ( $settings['brands_image'] as $key => $brand ) :
                    if (!empty($brand['url'])) {
                        $brand_image = $brand['url'];
                    }
                ?>
                <img src="<?php echo $brand_image ? esc_url($brand_image) : ''; ?>" alt="">
                <?php endforeach;?>
            </div>
        </div>
    </div>
</div>