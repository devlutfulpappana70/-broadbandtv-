<div class="tx-brands-section">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="tx-brandsWrapper">
                    <div class="swiper-container" data-txBrandSlider>
                        <div class="swiper-wrapper">
                            <?php foreach ( $settings['brands_image'] as $key => $brand ) :
                                if (!empty($brand['url'])) {
                                    $brand_image = $brand['url'];
                                }
                            ?>
                            <div class="swiper-slide tx-brandItem">
                                <div class="tx-brandItem__inner">
                                    <img src="<?php echo $brand_image ? esc_url($brand_image) : ''; ?>" alt="">
                                </div>
                            </div>
                            <?php endforeach;?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>