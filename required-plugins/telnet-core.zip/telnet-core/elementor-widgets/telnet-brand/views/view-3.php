<div class="swiper tna-channel-2-slider">
    <div class="swipe-container tna-fix tna_channel_2_active">
        <div class="swiper-wrapper">
            <?php foreach ( $settings['brands_image'] as $key => $brand ) :
                if (!empty($brand['url'])) {
                    $brand_image = $brand['url'];
                }
            ?>
            <div class="swiper-slide">
                <div class="tna-channel-2-item">
                    <img src="<?php echo $brand_image ? esc_url($brand_image) : ''; ?>" alt="">
                </div>
            </div>
            <?php endforeach;?>
        </div>
    </div>
</div>