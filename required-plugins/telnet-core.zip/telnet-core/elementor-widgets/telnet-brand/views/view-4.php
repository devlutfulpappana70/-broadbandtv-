<div class="tna-partner-1-logo-wrap">
    <div class="tna-partner-1-logo">
        <?php foreach ( $settings['brands_image'] as $key => $brand ) :
            if (!empty($brand['url'])) {
                $brand_image = $brand['url'];
            }
        ?>
        <img src="<?php echo $brand_image ? esc_url($brand_image) : ''; ?>" alt="">
        <?php endforeach;?>
    </div>
</div>