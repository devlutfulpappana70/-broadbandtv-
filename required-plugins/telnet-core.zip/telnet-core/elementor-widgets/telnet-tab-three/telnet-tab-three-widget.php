<?php

namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Icons_Manager;


defined( 'ABSPATH' ) || die();

class Telnet_Tab_Three extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name() {
        return 'telnet_tab_three';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title() {
        return __( 'Telnet Tab Three', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/gradient-heading/';
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-t-letter';
    }

    public function get_keywords() {
        return ['brand', 'image', 'icon', 'telnet'];
    }

    protected function register_content_controls() {

        //Settings
        $this->start_controls_section(
            '_section_settings',
            [
                'label' => __( 'Settings', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'design_style',
            [
                'label'              => __( 'Design Style', 'telnet-core' ),
                'type'               => Controls_Manager::SELECT,
                'options'            => [
                    'style_1' => __( 'Style 1', 'telnet-core' ),
                ],
                'default'            => 'style_1',
                'frontend_available' => true,
                'style_transfer'     => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_tabs',
            [
                'label' => __( 'Tabs', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // Tab Repeater
        $repeater = new Repeater();

        // tab title
        $repeater->add_control(
            'tab_title',
            [
                'label'       => __( 'Tab Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Tab Title', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        // tab content
        $repeater->add_control(
            'tab_content',
            [
                'label'       => __( 'Tab Content', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'default'     => __( 'Tab Content', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        // speed lists
        $repeater->add_control(
            'speed_lists',
            [
                'label'       => __( 'Speed Lists', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => [
                    // speed icons
                    [
                        'name'        => 'speed_icon',
                        'label'       => __( 'Speed Icon', 'telnet-core' ),
                        'type'        => Controls_Manager::ICONS,
                        'default'     => [
                            'value'   => 'fas fa-arrow-right',
                            'library' => 'solid',
                        ],
                        'label_block' => true,
                    ],
                    [
                        'name'        => 'speed_title',
                        'label'       => __( 'Speed Title', 'telnet-core' ),
                        'type'        => Controls_Manager::TEXT,
                        'default'     => __( 'Speed Title', 'telnet-core' ),
                        'label_block' => true,
                    ],

                ],
                'default'     => [
                    [
                        'speed_title' => __( 'Speed Title', 'telnet-core' ),
                    ],
                ],
                'title_field' => '{{{ speed_title }}}',
            ]
        );

        // button text
        $repeater->add_control(
            'btn_text',
            [
                'label'       => __( 'Button Text', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Button Text', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        // button link
        $repeater->add_control(
            'btn_link',
            [
                'label'       => __( 'Button Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'default'     => [
                    'url' => '#',
                ],
                'label_block' => true,
            ]
        );

        // button icons
        $repeater->add_control(
            'btn_icon',
            [
                'name'        => 'btn_icon',
                'label'       => __( 'Button Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'default'     => [
                    'value'   => 'fas fa-arrow-right',
                    'library' => 'solid',
                ],
                'label_block' => true,
            ]
        );

         // CURRENCY SYMBOL
         $repeater->add_control(
            'currency',
            [
                'label'       => __( 'Currency', 'telnet-core' ),
                'type'        => Controls_Manager::SELECT,
                'label_block' => false,
                'options'     => [
                    ''             => __( 'None', 'telnet-core' ),
                    'baht'         => '&#3647; ' . _x( 'Baht', 'Currency Symbol', 'telnet-core' ),
                    'bdt'          => '&#2547; ' . _x( 'BD Taka', 'Currency Symbol', 'telnet-core' ),
                    'dollar'       => '&#36; ' . _x( 'Dollar', 'Currency Symbol', 'telnet-core' ),
                    'euro'         => '&#128; ' . _x( 'Euro', 'Currency Symbol', 'telnet-core' ),
                    'franc'        => '&#8355; ' . _x( 'Franc', 'Currency Symbol', 'telnet-core' ),
                    'guilder'      => '&fnof; ' . _x( 'Guilder', 'Currency Symbol', 'telnet-core' ),
                    'krona'        => 'kr ' . _x( 'Krona', 'Currency Symbol', 'telnet-core' ),
                    'lira'         => '&#8356; ' . _x( 'Lira', 'Currency Symbol', 'telnet-core' ),
                    'peseta'       => '&#8359 ' . _x( 'Peseta', 'Currency Symbol', 'telnet-core' ),
                    'peso'         => '&#8369; ' . _x( 'Peso', 'Currency Symbol', 'telnet-core' ),
                    'pound'        => '&#163; ' . _x( 'Pound Sterling', 'Currency Symbol', 'telnet-core' ),
                    'real'         => 'R$ ' . _x( 'Real', 'Currency Symbol', 'telnet-core' ),
                    'ruble'        => '&#8381; ' . _x( 'Ruble', 'Currency Symbol', 'telnet-core' ),
                    'rupee'        => '&#8360; ' . _x( 'Rupee', 'Currency Symbol', 'telnet-core' ),
                    'indian_rupee' => '&#8377; ' . _x( 'Rupee (Indian)', 'Currency Symbol', 'telnet-core' ),
                    'shekel'       => '&#8362; ' . _x( 'Shekel', 'Currency Symbol', 'telnet-core' ),
                    'won'          => '&#8361; ' . _x( 'Won', 'Currency Symbol', 'telnet-core' ),
                    'yen'          => '&#165; ' . _x( 'Yen/Yuan', 'Currency Symbol', 'telnet-core' ),
                    'rand'         => 'R ' . _x( 'Rand', 'Currency Symbol', 'telnet-core' ),
                    'dinar'        => '&#8373; ' . _x( 'Dinar', 'Currency Symbol', 'telnet-core' ),
                    'dirham'       => '&#x62f;&#x2e;&#x625; ' . _x( 'Dirham', 'Currency Symbol', 'telnet-core' ),
                    'riyal'        => '&#65020; ' . _x( 'Riyal', 'Currency Symbol', 'telnet-core' ),
                    'ringgit'      => '&#82;&#77; ' . _x( 'Ringgit', 'Currency Symbol', 'telnet-core' ),
                    'baht'         => '&#3647; ' . _x( 'Baht', 'Currency Symbol', 'telnet-core' ),
                    'custom'       => __( 'Custom', 'telnet-core' ),
                ],
                'default'     => 'dollar',
            ]
        );

        $repeater->add_control(
            'currency_custom',
            [
                'label'     => __( 'Custom Symbol', 'telnet-core' ),
                'type'      => Controls_Manager::TEXT,
                'condition' => [
                    'currency' => 'custom',
                ],
                'dynamic'   => [
                    'active' => true,
                ],
            ]
        );

        // PRICE
        $repeater->add_control(
            'price',
            [
                'label'   => __( 'Price', 'telnet-core' ),
                'type'    => Controls_Manager::TEXT,
                'default' => '9.99',
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        // PERIOD
        $repeater->add_control(
            'period',
            [
                'label'   => __( 'Period', 'telnet-core' ),
                'type'    => Controls_Manager::TEXT,
                'default' => __( 'Per Month', 'telnet-core' ),
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        // packge feature title
        $repeater->add_control(
            'package_feature_title',
            [
                'label'       => __( 'Package Feature Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Package Feature Title', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'tab_lists',
            [
                'label'       => __( 'Tab List', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [
                    [
                        'tab_title'         => __( 'Tab Title', 'telnet-core' ),
                    ],
                ],
                'title_field' => '{{{ tab_title }}}',
            ]
        );


        $this->end_controls_section();

    }

    protected function register_style_controls() {

    }


    private static function get_currency_symbol( $symbol_name ) {
        $symbols = [
            'baht'         => '&#3647;',
            'bdt'          => '&#2547;',
            'dollar'       => '&#36;',
            'euro'         => '&#128;',
            'franc'        => '&#8355;',
            'guilder'      => '&fnof;',
            'indian_rupee' => '&#8377;',
            'pound'        => '&#163;',
            'peso'         => '&#8369;',
            'peseta'       => '&#8359',
            'lira'         => '&#8356;',
            'ruble'        => '&#8381;',
            'shekel'       => '&#8362;',
            'rupee'        => '&#8360;',
            'real'         => 'R$',
            'krona'        => 'kr',
            'won'          => '&#8361;',
            'yen'          => '&#165;',
            'rand'         => 'R',
            'dinar'        => '&#8373;',
            'dirham'       => '&#x62f;&#x2e;&#x625;',
            'riyal'        => '&#65020;',
            'ringgit'      => '&#82;&#77;',
        ];

        return isset( $symbols[$symbol_name] ) ? $symbols[$symbol_name] : '';
    }

    protected function render() {

        $settings = $this->get_settings_for_display();
        $dir = dirname( __FILE__ );

        if ( !empty( $settings['design_style'] ) && $settings['design_style'] == 'style_3' ):
            include $dir . '/views/view-3.php';

        elseif ( !empty( $settings['design_style'] ) && $settings['design_style'] == 'style_2' ):
            include $dir . '/views/view-2.php';
        else:
            include $dir . '/views/view-1.php';
        endif;
    }
}
