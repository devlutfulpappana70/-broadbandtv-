<?php
    $rand = rand(0, 9999);
?>

<div class="tna-speed-1-tabs-btn mb-45" id="nav-tab" role="tablist">
    <?php
        foreach( $settings['tab_lists'] as $id => $list ) :
        $active = ($id == 0) ? 'active' : '';
        $aria_selected = ($id == 0) ? 'true' : 'false';

    ?>
    <button class="nav-link <?php echo esc_attr($active) ?> tna-heading-1" id="nav-<?php echo esc_attr($id . $rand); ?>-tab" data-bs-toggle="tab" data-bs-target="#nav-<?php echo esc_attr($id . $rand); ?>" type="button" role="tab" aria-controls="nav-<?php echo esc_attr($id . $rand); ?>" aria-selected="<?php echo esc_attr($aria_selected) ?>"><?php echo elh_element_kses_intermediate($list['tab_title']); ?></button>
    <?php endforeach; ?>
</div>


<!-- tabs-content -->
<div class="tna-speed-1-tabs-content tab-content" id="nav-tabContent">
    <?php
        foreach( $settings['tab_lists'] as $id => $list ) :
        $active = ($id == 0) ? 'active show' : '';

        if ($list['currency'] === 'custom') {
            $currency = $list['currency_custom'];
        } else {
            $currency = self::get_currency_symbol($list['currency']);
        }
    ?>
    <div class="tab-pane fade <?php echo esc_attr($active) ?>" id="nav-<?php echo esc_attr($id . $rand); ?>" role="tabpanel" aria-labelledby="nav-<?php echo esc_attr($id . $rand); ?>-tab">

        <?php if(!empty( $list['tab_content'] )) : ?>
        <p class="tna-para-1">
            <?php echo elh_element_kses_intermediate($list['tab_content']); ?>
        </p>
        <?php endif; ?>

        <?php if(!empty( $list['speed_lists'] )) : ?>
        <ul class="tna-list-item-1 mt-20">
            <?php
                foreach( $list['speed_lists'] as $id => $speed_list ) :
            ?>
            <li>
                <?php \Elementor\Icons_Manager::render_icon( $speed_list['speed_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                <?php echo elh_element_kses_intermediate($speed_list['speed_title']); ?>
            </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>

        <div class="btn-wrap mt-65">
            <a class="tna-pr-btn-2">
                <?php echo elh_element_kses_intermediate($list['btn_text']); ?>
                <?php \Elementor\Icons_Manager::render_icon( $list['btn_icon'], [ 'aria-hidden' => 'true' ] ); ?>
            </a>
            <div class="tna-package-1-price-wrap">
                <h6 class="tna-heading-1 price"><span class="dollar-sing"><?php echo esc_html($currency); ?></span><span class="dollar"><?php echo esc_html($list['price']); ?></span> <?php echo esc_html($list['period']); ?></h6>

                <?php if(!empty( $list['package_feature_title'] )) : ?>
                <p class="tna-para-1 month"><?php echo esc_html($list['package_feature_title']); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endforeach; ?>

</div>