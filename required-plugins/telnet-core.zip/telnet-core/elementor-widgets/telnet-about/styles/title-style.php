<?php

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

$this->start_controls_section(
    '_section_style_title',
    [
        'label' => __( 'HEADING STYLE', 'builta-core' ),
        'tab'   => Controls_Manager::TAB_STYLE,
    ]
);

// enable full width
$this->add_control(
    'enable_full_width',
    [
        'label'        => __( 'Enable Full Width', 'builta-core' ),
        'type'         => Controls_Manager::SWITCHER,
        'label_on'     => __( 'Yes', 'builta-core' ),
        'label_off'    => __( 'No', 'builta-core' ),
        'return_value' => 'yes',
        'default'      => 'no',
    ]
);

// enable title animation
$this->add_control(
    'enable_title_animation',
    [
        'label'        => __( 'Enable Title Animation', 'builta-core' ),
        'type'         => Controls_Manager::SWITCHER,
        'label_on'     => __( 'Yes', 'builta-core' ),
        'label_off'    => __( 'No', 'builta-core' ),
        'return_value' => 'yes',
        'default'      => 'yes',
    ]
);

// title color
$this->add_control(
    'title_color',
    [
        'label'     => __( 'Title Color', 'builta-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tna-title-2' => 'color: {{VALUE}};',
        ],
    ]
);

// title span color
$this->add_control(
    'title_span_color',
    [
        'label'     => __( 'Title Span Color', 'builta-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tna-title-2 span' => 'color: {{VALUE}};',
        ],
    ]
);

// title padding
$this->add_responsive_control(
    'title_padding',
    [
        'label'      => __( 'Padding', 'builta-core' ),
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => ['px', 'em', '%'],
        'selectors'  => [
            '{{WRAPPER}} .tna-title-2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
    ]
);

// title margin
$this->add_responsive_control(
    'title_margin',
    [
        'label'      => __( 'Margin', 'builta-core' ),
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => ['px', 'em', '%'],
        'selectors'  => [
            '{{WRAPPER}} .tna-title-2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
    ]
);

// title typography
$this->add_group_control(
    Group_Control_Typography::get_type(),
    [
        'name'     => 'title_typography',
        'label'    => __( 'Typography', 'builta-core' ),
        'selector' => '
        {{WRAPPER}} .tna-title-2
        ',
    ]
);

$this->end_controls_section();