<?php

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

// LIST ITEMS STYLE
$this->start_controls_section(
    '_section_style_list_items',
    [
        'label' => __( 'LIST ITEMS STYLE', 'builta-core' ),
        'tab'   => Controls_Manager::TAB_STYLE,
    ]
);

// list icon color
$this->add_control(
    'list_icon_color',
    [
        'label'     => __( 'List Icon Color', 'builta-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tx-listsItems .icon i' => 'color: {{VALUE}};-webkit-text-fill-color: {{VALUE}};'
        ],
    ]
);

// icon bg color
$this->add_control(
    'icon_bg_color',
    [
        'label'     => __( 'Icon Background Color', 'builta-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tx-listsItems .icon' => 'background-color: {{VALUE}};',
        ],
    ]
);

// hover icon bg color
$this->add_control(
    'hover_icon_bg_color',
    [
        'label'     => __( 'Hover Icon Background Color', 'builta-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tx-listsItems:hover .icon' => 'background: {{VALUE}};',
        ],
    ]
);

// title color
$this->add_control(
    'list_title_color',
    [
        'label'     => __( 'Title Color', 'builta-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tx-listsItems .title' => 'color: {{VALUE}};',
        ],
    ]
);

// typography
$this->add_group_control(
    Group_Control_Typography::get_type(),
    [
        'name'     => 'list_typography',
        'label'    => __( 'Typography', 'builta-core' ),
        'selector' => '
        {{WRAPPER}} .tx-listsItems .title
        ',
    ]
);

// description color
$this->add_control(
    'description_color',
    [
        'label'     => __( 'Description Color', 'builta-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tx-listsItems .disc' => 'color: {{VALUE}};',
        ],
    ]
);

// typography
$this->add_group_control(
    Group_Control_Typography::get_type(),
    [
        'name'     => 'description_typography',
        'label'    => __( 'Typography', 'builta-core' ),
        'selector' => '
        {{WRAPPER}} .tx-listsItems .disc
        ',
    ]
);

// box hover bg
$this->add_control(
    'box_hover_bg',
    [
        'label'     => __( 'Box Hover Background Color', 'builta-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tna-chooe-2-feature-item .bg-img::after' => 'background: {{VALUE}};',
        ],
    ]
);

// end
$this->end_controls_section();