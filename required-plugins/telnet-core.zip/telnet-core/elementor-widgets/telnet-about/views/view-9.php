<?php

$this->add_inline_editing_attributes( 'title', 'basic' );
$this->add_render_attribute( 'title', 'class', 'tna-title-2 font-56  txa-split-text txa-split-in-up' );
$title = elh_element_kses_basic( $settings['title'] );
if ($settings['currency'] === 'custom') {
	$currency = $settings['currency_custom'];
} else {
	$currency = self::get_currency_symbol($settings['currency']);
}

?>
<div class="tna-speed-3-area flat_3 tna-fix">
	<div class="container tna-container-1">
		<div class="row align-items-center">

			<!-- left-content -->
			<div class="col-xl-5 col-lg-6">
				<div class="tna-speed-3-content">
					<!-- section-title -->
					<div class="tna-section-title mb-30">
						<?php if(!empty( $settings['sub_title'] )) : ?>
						<h4 class="tna-subtitle-2 has-4 wow fadeInLeft"><?php echo elh_element_kses_intermediate($settings['sub_title']); ?></h4>
						<?php endif; ?>
						<?php
							printf('<%1$s %2$s>%3$s</%1$s>',
								tag_escape($settings['title_tag']),
								$this->get_render_attribute_string('title'),
								$title
							);
						?>
						<?php if(!empty( $settings['description'] )) : ?>
						<p class="tna-para-2 wow fadeInLeft"><?php echo wp_kses($settings['description'], true)?></p>
						<?php endif; ?>
					</div>

					<div class="content-div mb-30">
						<?php if(!empty( $settings['feature_lists_2'] )) : ?>
						<ul class="tna-list-item-1">
							<?php foreach($settings['feature_lists_2'] as $list ) : ?>
							<li class="wow fadeInUp" data-wow-delay="0s">
								<?php \Elementor\Icons_Manager::render_icon( $list['feature_icon'], [ 'aria-hidden' => 'true' ] ); ?>
								<?php echo elh_element_kses_intermediate($list['title']); ?>
							</li>
							<?php endforeach; ?>
						</ul>
						<?php endif; ?>

						<div class="tna-package-1-price-wrap fadeInUp wow">
							<h6 class="tna-heading-1 price">
							<?php if(!empty( $currency )) : ?><span class="dollar-sing"><?php echo esc_html($currency); ?></span><?php endif; ?><span class="dollar"><?php echo esc_html($settings['price']); ?></span> <?php echo esc_html($settings['period']); ?></h6>
							<?php if(!empty( $settings['package_feature'] )) : ?>
							<p class="tna-para-1 month"><?php echo esc_html($settings['package_feature']); ?></p>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>

			<!-- right-img -->
			<div class="col-xl-7 col-lg-6">
				<div class="tna-speed-3-img">
					<div class="main-img">
						<?php if(!empty( $settings['image_1']['url'] )) : ?>
						<div class="txa-zoomout tna-img-cover">
							<img src="<?php echo $settings['image_1']['url'] ? esc_url($settings['image_1']['url']) : ''; ?>" alt="">
						</div>
						<?php endif; ?>
					</div>

					<?php if(!empty( $settings['image_2']['url'] )) : ?>
					<div class="popup-img-1 wow slideInRight">
						<img src="<?php echo $settings['image_2']['url'] ? esc_url($settings['image_2']['url']) : ''; ?>" alt="">
					</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</div>