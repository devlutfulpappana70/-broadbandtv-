<?php

$this->add_inline_editing_attributes( 'title', 'basic' );
$this->add_render_attribute( 'title', 'class', 'tna-title-2 txa-split-text txa-split-in-up' );
$title = elh_element_kses_basic( $settings['title'] );
?>
<div class="tna-about-2-area tna-fix pt-125 pb-125">
	<span class="bg-shape-1 wow slideInDown" data-wow-duration="5s"></span>
	<div class="bg-il-1-position">
		<div class="bg-il-1-wrap wow fadeInRight" data-wow-delay="1s">
			<?php if(!empty( $settings['image_4']['url'] )) : ?>
			<img src="<?php echo esc_url($settings['image_4']['url']); ?>" alt="" class="bg-il-1" >
			<?php endif; ?>

			<?php if(!empty( $settings['image_5']['url'] )) : ?>
			<img class="wifi-signal" src="<?php echo esc_url($settings['image_5']['url']); ?>" alt="">
			<?php endif; ?>
		</div>
	</div>

	<div class="container tna-container-1">
		<div class="row align-items-center">

			<!-- left-img -->
			<div class="col-xl-6">
				<div class="tna-about-2-img txa-class-add">
					<?php if(!empty( $settings['image_1']['url'] )) : ?>
					<div class="img-item ">
						<img src="<?php echo esc_url($settings['image_1']['url']); ?>" alt="">
					</div>
					<?php endif; ?>

					<?php if(!empty( $settings['image_2']['url'] )) : ?>
					<div class="img-item">
						<img src="<?php echo esc_url($settings['image_2']['url']); ?>" alt="">
					</div>
					<?php endif; ?>

					<?php if(!empty( $settings['image_3']['url'] )) : ?>
					<div class="img-item ">
						<img src="<?php echo esc_url($settings['image_3']['url']); ?>" alt="">
					</div>
					<?php endif; ?>
				</div>
			</div>

			<!-- right-content -->
			<div class="col-xl-6">
				<div class="tna-about-2-content">

					<!-- section-title -->
					<div class="tna-section-title mb-50">
						<?php if(!empty( $settings['sub_title'] )) : ?>
						<h4 class="tna-subtitle-2 wow fadeInLeft"><?php echo elh_element_kses_intermediate($settings['sub_title']); ?></h4>
						<?php endif; ?>

						<?php
							printf('<%1$s %2$s>%3$s</%1$s>',
								tag_escape($settings['title_tag']),
								$this->get_render_attribute_string('title'),
								$title
							);
						?>
						<?php if(!empty( $settings['description'] )) : ?>
						<p class="tna-para-2 wow fadeInUp"><?php echo elh_element_kses_intermediate($settings['description']); ?></p>
						<?php endif; ?>
					</div>

					<div class="tna-about-2-feature-wrap mb-25">
						<?php foreach ($settings['feature_lists'] as $id => $list) : ?>
						<div class="tna-about-2-feature-item wow fadeIn">
							<?php if ($list['enable_icon'] == true) : ?>
								<div class="icon">
									<?php if ($list['type'] == 'icon') : ?>
										<?php \Elementor\Icons_Manager::render_icon($list['feature_icon'], ['aria-hidden' => 'true']); ?>
									<?php else : ?>
										<img src="<?php echo esc_url($list['feature_image']['url']); ?>" alt="" />
									<?php endif; ?>
								</div>
							<?php endif; ?>

							<?php if(!empty( $list['title'] )) : ?>
							<h5 class="tna-heading-2 title">
								<?php echo elh_element_kses_intermediate($list['title']); ?>
							</h5>
							<?php endif; ?>
						</div>
						<?php endforeach; ?>
					</div>

					<?php if(!empty( $settings['description_2'] )) : ?>
					<p class="tna-para-2 feature-para wow fadeInUp"><?php echo elh_element_kses_intermediate($settings['description_2']); ?></p>
					<?php endif; ?>

					<div class="btn-wrap">

						<a class="tna-pr-btn-3 wow fadeInRight" href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>">
							<span class="text"><?php echo elh_element_kses_intermediate($settings['button_text']); ?></span>
							<?php
								if(($settings['enable_icon']) === 'yes' ) {
									\Elementor\Icons_Manager::render_icon( $settings['btn_icon'], [ 'aria-hidden' => 'true' ] );
								}
							?>
						</a>

						<div class="tna-call-btn-1 has-2 wow fadeInRight" data-wow-delay=".5s">
							<?php if(!empty( $settings['contact_icon'] )) : ?>
							<div class="icon">
								<?php \Elementor\Icons_Manager::render_icon( $settings['contact_icon'], [ 'aria-hidden' => 'true' ] ); ?>
							</div>
							<?php endif; ?>
							<div class="content">
								<?php if(!empty( $settings['contact_text'] )) : ?>
								<span class="text"><?php echo elh_element_kses_intermediate($settings['contact_text']); ?></span>
								<?php endif; ?>

								<?php if(!empty( $settings['contact_number'] )) : ?>
								<a class="number" href="tel:<?php echo esc_attr($settings['contact_number']); ?>">'
									<?php echo elh_element_kses_intermediate($settings['contact_number']); ?>
								</a>
								<?php endif; ?>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>
</div>