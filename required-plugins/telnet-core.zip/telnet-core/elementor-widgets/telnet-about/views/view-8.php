<?php

$this->add_inline_editing_attributes( 'title', 'basic' );
$this->add_render_attribute( 'title', 'class', 'tna-title-2 font-56  txa-split-text txa-split-in-up' );
$title = elh_element_kses_basic( $settings['title'] );

?>
<div class="tna-internet-3-area flat_3 tna-fix txa-class-add pt-120 pb-120">
	<div class="bg-img">
		<?php if(!empty( $settings['image_1']['url'] )) : ?>
		<div class="txa-zoomout tna-img-cover">
			<img src="<?php echo $settings['image_1']['url'] ? esc_url($settings['image_1']['url']) : ''; ?>" alt="">
		</div>
		<?php endif; ?>
	</div>

	<div class="container tna-container-1 z-index-3">
		<div class="row">

			<div class="col-xl-6 col-lg-7 col-md-10">
				<div class="tna-internet-3-content">

					<!-- section-title -->
					<div class="tna-section-title mb-30">
						<?php if(!empty( $settings['sub_title'] )) : ?>
						<h4 class="tna-subtitle-2 has-4 wow fadeInLeft"><?php echo elh_element_kses_intermediate($settings['sub_title']); ?></h4>
						<?php endif; ?>

						<?php
							printf('<%1$s %2$s>%3$s</%1$s>',
								tag_escape($settings['title_tag']),
								$this->get_render_attribute_string('title'),
								$title
							);
						?>

						<?php if(!empty( $settings['description'] )) : ?>
						<p class="tna-para-2 wow fadeInLeft"><?php echo wp_kses($settings['description'], true)?></p>
						<?php endif; ?>
					</div>

					<div class="tna-channel-1-feature-wrap mb-50">
						<?php foreach ($settings['feature_lists'] as $id => $list) : ?>
						<div class="tna-channel-1-feature wow fadeIn" >
							<?php if ($list['enable_icon'] == true) : ?>
								<div class="icon">
									<?php if ($list['type'] == 'icon') : ?>
										<?php \Elementor\Icons_Manager::render_icon($list['feature_icon'], ['aria-hidden' => 'true']); ?>
									<?php else : ?>
										<img src="<?php echo esc_url($list['feature_image']['url']); ?>" alt="" />
									<?php endif; ?>
								</div>
							<?php endif; ?>
							<div class="content-wrap">
								<?php if(!empty( $list['title'] )) : ?>
								<h5 class="tna-heading-2 title"><?php echo elh_element_kses_intermediate($list['title']); ?></h5>
								<?php endif; ?>

								<?php if(!empty( $list['text'] )) : ?>
								<p class="tna-para-2 disc"><?php echo elh_element_kses_intermediate($list['text']); ?></p>
								<?php endif; ?>
							</div>
						</div>
						<?php endforeach; ?>

					</div>

					<div class="btn-wrap">

						<?php if(!empty( $settings['button_text'] )) : ?>
						<a class="tna-pr-btn-4 wow fadeInLeft" data-wow-delay=".3s" href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>">
							<span class="text"><?php echo elh_element_kses_intermediate($settings['button_text']); ?></span>
							<?php
								if(($settings['enable_icon']) === 'yes' ) {
									\Elementor\Icons_Manager::render_icon( $settings['btn_icon'], [ 'aria-hidden' => 'true' ] );
								}
							?>
						</a>
						<?php endif; ?>

						<div class="tna-call-btn-1 wow fadeInLeft">
							<?php if(!empty( $settings['contact_icon'] )) : ?>
							<div class="icon">
								<?php \Elementor\Icons_Manager::render_icon( $settings['contact_icon'], [ 'aria-hidden' => 'true' ] ); ?>
							</div>
							<?php endif; ?>
							<div class="content">
								<?php if(!empty( $settings['contact_text'] )) : ?>
								<span class="text"><?php echo elh_element_kses_intermediate($settings['contact_text']); ?></span>
								<?php endif; ?>

								<?php if(!empty( $settings['contact_number'] )) : ?>
								<a class="number" href="tel:<?php echo esc_attr($settings['contact_number']); ?>">'
									<?php echo elh_element_kses_intermediate($settings['contact_number']); ?>
								</a>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>