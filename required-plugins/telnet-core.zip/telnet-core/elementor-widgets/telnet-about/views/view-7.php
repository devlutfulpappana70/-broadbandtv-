<?php

$this->add_inline_editing_attributes( 'title', 'basic' );
$this->add_render_attribute( 'title', 'class', 'tna-title-2 font-56 txa-split-text txa-split-in-up' );
$title = elh_element_kses_basic( $settings['title'] );
?>
<div class="tna-about-3-area flat_3 pt-120 pb-180">
	<?php if(!empty( $settings['image_1']['url'] )) : ?>
	<img src="<?php echo esc_url($settings['image_1']['url']); ?>" class="bg-il-1" alt="">
	<?php endif; ?>

	<div class="container tna-container-1">
		<div class="row">

			<!-- left-side -->
			<div class="col-xxl-6">
				<div class="tna-about-3-left">

					<?php if(!empty( $settings['image_2']['url'] )) : ?>
					<div class="tna-about-3-img">
						<div class="txa-zoomout tna-img-cover">
							<img src="<?php echo esc_url($settings['image_2']['url']); ?>" alt="">
						</div>
					</div>
					<?php endif; ?>
					<?php if(!empty( $settings['image_3']['url'] )) : ?>
					<div class="popup-img-1 tna-fix">
						<div class="txa-zoomout tna-img-cover">
							<img src="<?php echo esc_url($settings['image_3']['url']); ?>" alt="" class="">
						</div>
					</div>
					<?php endif; ?>

					<div class="tna-about-3-feature-wrap">
						<?php foreach ($settings['feature_lists'] as $id => $list) : ?>
						<div class="tna-about-3-feature-item wow fadeInUp">
							<?php if ($list['enable_icon'] == true) : ?>
								<div class="icon">
									<?php if ($list['type'] == 'icon') : ?>
										<?php \Elementor\Icons_Manager::render_icon($list['feature_icon'], ['aria-hidden' => 'true']); ?>
									<?php else : ?>
										<img src="<?php echo esc_url($list['feature_image']['url']); ?>" alt="" />
									<?php endif; ?>
								</div>
							<?php endif; ?>

							<?php if(!empty( $list['title'] )) : ?>
							<h4 class="tna-heading-2 title"><?php echo elh_element_kses_intermediate($list['title']); ?></h4>
							<?php endif; ?>

							<?php if(!empty( $list['text'] )) : ?>
							<p class="tna-para-2 disc"><?php echo elh_element_kses_intermediate($list['text']); ?></p>
							<?php endif; ?>
						</div>
						<?php endforeach; ?>
					</div>
				</div>
			</div>

			<!-- right-side -->
			<div class="col-xxl-6">
				<div class="tna-about-3-right">

					<!-- section-title -->
					<div class="tna-section-title mb-30">
						<?php if(!empty( $settings['sub_title'] )) : ?>
						<h4 class="tna-subtitle-2 has-4 wow fadeInRight"><?php echo elh_element_kses_intermediate($settings['sub_title']); ?></h4>
						<?php endif; ?>

						<?php
							printf('<%1$s %2$s>%3$s</%1$s>',
								tag_escape($settings['title_tag']),
								$this->get_render_attribute_string('title'),
								$title
							);
						?>

						<?php if(!empty( $settings['description'] )) : ?>
						<p class="tna-para-2 wow fadeInRight"><?php echo elh_element_kses_intermediate($settings['description']); ?></p>
						<?php endif; ?>
					</div>

					<div class="content-div mb-30">
						<?php if(!empty( $settings['feature_lists_2'] )) : ?>
						<ul class="tna-about-3-list">
							<?php foreach ($settings['feature_lists_2'] as $id => $list) : ?>
							<li class="wow fadeInUp" data-wow-delay="0s">
								<?php \Elementor\Icons_Manager::render_icon($list['feature_icon'], ['aria-hidden' => 'true']); ?>
								<?php echo elh_element_kses_intermediate($list['title']); ?>
							</li>
							<?php endforeach; ?>
						</ul>
						<?php endif; ?>

						<div class="tna-about-3-video wow fadeInRight">
							<?php if(!empty( $settings['video_image']['url'] )) : ?>
							<img src="<?php echo esc_url($settings['video_image']['url']); ?>" alt="">
							<?php endif; ?>

							<?php if(!empty( $settings['video_button_link']['url'] )) : ?>
							<a href="<?php echo esc_url($settings['video_button_link']['url']); ?>" class="tna-playbtn-1 popup-video">
								<?php \Elementor\Icons_Manager::render_icon( $settings['video_button_icon'], [ 'aria-hidden' => 'true' ] ); ?>
							</a>
							<?php endif; ?>
						</div>

					</div>

					<div class="btn-wrap">
						<?php if(!empty( $settings['button_link']['url'] )) : ?>
						<a class="tna-pr-btn-4 has-white wow fadeInRight" href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>">
							<span class="text"><?php echo elh_element_kses_intermediate($settings['button_text']); ?></span>
							<?php
								if(($settings['enable_icon']) === 'yes' ) {
									\Elementor\Icons_Manager::render_icon( $settings['btn_icon'], [ 'aria-hidden' => 'true' ] );
								}
							?>
						</a>
						<?php endif; ?>

						<div class="tna-call-btn-1 wow fadeInRight" data-wow-delay=".3s">
							<?php if(!empty( $settings['contact_icon'] )) : ?>
							<div class="icon">
								<?php \Elementor\Icons_Manager::render_icon( $settings['contact_icon'], [ 'aria-hidden' => 'true' ] ); ?>
							</div>
							<?php endif; ?>
							<div class="content">

								<?php if(!empty( $settings['contact_text'] )) : ?>
								<span class="text"><?php echo elh_element_kses_intermediate($settings['contact_text']); ?></span>
								<?php endif; ?>

								<?php if(!empty( $settings['contact_number'] )) : ?>
								<a class="number" href="tel:<?php echo esc_attr($settings['contact_number']); ?>">
									<?php echo elh_element_kses_intermediate($settings['contact_number']); ?>
								</a>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>