<?php

$this->add_inline_editing_attributes( 'title', 'basic' );
$this->add_render_attribute( 'title', 'class', 'tna-title-1 txa-split-text txa-split-in-up' );
$title = elh_element_kses_basic( $settings['title'] );
?>

<div class="tna-channel-1-area txa-class-add pt-95 pb-95 tna-fix">

	<?php if(!empty( $settings['bg_shape_image']['url'] )) : ?>
	<img src="<?php echo esc_url($settings['bg_shape_image']['url']) ?>" alt="" class="bg-shape-1">
	<?php endif; ?>

	<div class="container tna-container-1 z-index-3">
		<div class="row align-items-center">
			<!-- left-content -->
			<div class="col-xl-5 col-lg-6">
				<div class="tna-channel-1-content">

					<!-- section-title -->
					<div class="tna-section-title mb-30">
						<?php if(!empty( $settings['sub_title'] )) : ?>
						<h4 class="tna-subtitle-1 wow fadeInLeft">
							<?php echo elh_element_kses_intermediate($settings['sub_title']); ?>
						</h4>
						<?php endif; ?>
						<?php
							printf('<%1$s %2$s>%3$s</%1$s>',
								tag_escape($settings['title_tag']),
								$this->get_render_attribute_string('title'),
								$title
							);
						?>
						<?php if(!empty( $settings['description'] )) : ?>
						<p class="tna-para-1 wow fadeInLeft"><?php echo wp_kses($settings['description'], true)?></p>
						<?php endif; ?>
					</div>

					<div class="tna-channel-1-feature-wrap mb-50">
						<?php foreach($settings['feature_lists'] as $list ) : ?>
						<div class="tna-channel-1-feature wow fadeIn">
							<?php if( $list['enable_icon'] == true ) : ?>
							<div class="icon">
								<?php if($list['type'] == 'icon') : ?>
									<?php \Elementor\Icons_Manager::render_icon( $list['feature_icon'], [ 'aria-hidden' => 'true' ] ); ?>
								<?php else : ?>
									<img src="<?php echo esc_url($list['feature_image']['url']); ?>" alt="" />
								<?php endif; ?>
							</div>
							<?php endif; ?>
							<div class="content-wrap">
								<?php if(!empty( $list['title'] )) : ?>
								<h5 class="tna-heading-1 title"><?php echo elh_element_kses_intermediate($list['title']); ?></h5>
								<?php endif; ?>

								<?php if(!empty( $list['text'] )) : ?>
								<p class="tna-para-1 disc"><?php echo elh_element_kses_intermediate($list['text']); ?></p>
								<?php endif; ?>
							</div>
						</div>
						<?php endforeach; ?>
					</div>

					<a href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>" class="tna-pr-btn-2 wow fadeInLeft">
						<?php
							echo elh_element_kses_intermediate($settings['button_text']);
							if(($settings['enable_icon']) === 'yes' ) {
								\Elementor\Icons_Manager::render_icon( $settings['btn_icon'], [ 'aria-hidden' => 'true' ] );
							}
						?>
					</a>

				</div>
			</div>

			<!-- right-img -->
			<div class="col-xl-7 col-lg-6">
				<div class="tna-channel-1-img">
					<?php if(!empty( $settings['image_1']['url'] )) : ?>
					<img class="main-img" src="<?php echo esc_url($settings['image_1']['url']) ?>" alt="">
					<?php endif; ?>

					<?php if(!empty( $settings['image_2']['url'] )) : ?>
					<img class="shape"src="<?php echo esc_url($settings['image_2']['url']) ?>" alt="">
					<?php endif; ?>
				</div>
			</div>

		</div>
	</div>
</div>