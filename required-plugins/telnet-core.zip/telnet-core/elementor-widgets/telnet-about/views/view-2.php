<?php

$this->add_inline_editing_attributes( 'title', 'basic' );
$this->add_render_attribute( 'title', 'class', 'tna-title-1 txa-split-text txa-split-in-up' );
$title = elh_element_kses_basic( $settings['title'] );

if ($settings['currency'] === 'custom') {
	$currency = $settings['currency_custom'];
} else {
	$currency = self::get_currency_symbol($settings['currency']);
}

?>

<div class="tna-package-1-area bg-default pt-120 pb-130 tna-fix" tna-data-background="<?php echo $settings['image_1']['url'] ? esc_url($settings['image_1']['url']) : ''; ?>">
	<div class="container tna-container-1">
		<div class="tna-package-1-wrap wow slideInLeft" data-wow-duration="1s" data-wow-delay=".3s">
			<div class="tna-package-1-content">

				<!-- section-title -->
				<div class="tna-section-title mb-30">
					<?php if(!empty( $settings['sub_title'] )) : ?>
					<h4 class="tna-subtitle-1 wow fadeInLeft" data-wow-delay=".5s">
						<?php echo elh_element_kses_intermediate($settings['sub_title']); ?>
					</h4>
					<?php endif; ?>
					<?php
						printf('<%1$s %2$s>%3$s</%1$s>',
							tag_escape($settings['title_tag']),
							$this->get_render_attribute_string('title'),
							$title
						);
					?>
					<?php if(!empty( $settings['description'] )) : ?>
					<p class="tna-para-1 wow fadeInLeft" data-wow-delay=".5s"><?php echo wp_kses($settings['description'], true)?></p>
					<?php endif; ?>
				</div>

				<div class="price-wrap mb-65">

					<div class="tna-package-1-price-wrap">
						<h6 class="tna-heading-1 price"><?php if(!empty( $currency )) : ?><span class="dollar-sing"><?php echo esc_html($currency); ?></span><?php endif; ?><span class="dollar" ><?php echo esc_html($settings['price']); ?></span> <?php echo esc_html($settings['period']); ?></h6>

						<?php if(!empty( $settings['package_feature'] )) : ?>
						<p class="tna-para-1 month"><?php echo esc_html($settings['package_feature']); ?></p>
						<?php endif; ?>
					</div>

					<?php if(!empty( $settings['feature_lists_2'] )) : ?>
					<ul class="tna-package-1-list">
						<?php foreach($settings['feature_lists_2'] as $list ) : ?>
						<li>
							<?php \Elementor\Icons_Manager::render_icon( $list['feature_icon'], [ 'aria-hidden' => 'true' ] ); ?>
							<?php echo elh_element_kses_intermediate($list['title']); ?>
						</li>
						<?php endforeach; ?>
					</ul>
					<?php endif; ?>
				</div>

				<div class="btn-wrap">
					<a class="tna-pr-btn-2 wow fadeInLeft" data-wow-delay=".5s" href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>">
						<?php echo elh_element_kses_intermediate($settings['button_text']); ?>
						<?php
							if(($settings['enable_icon']) === 'yes' ) {
								\Elementor\Icons_Manager::render_icon( $settings['btn_icon'], [ 'aria-hidden' => 'true' ] );
							}
						?>
					</a>
					<div class="tna-call-btn-1">
						<?php if(!empty( $settings['contact_icon'] )) : ?>
						<div class="icon">
							<?php \Elementor\Icons_Manager::render_icon( $settings['contact_icon'], [ 'aria-hidden' => 'true' ] ); ?>
						</div>
						<?php endif; ?>
						<div class="content">
							<?php if(!empty( $settings['contact_text'] )) : ?>
							<span class="text"><?php echo elh_element_kses_intermediate($settings['contact_text']); ?></span>
							<?php endif; ?>

							<?php if(!empty( $settings['contact_number'] )) : ?>
							<a class="number" href="tel:<?php echo esc_attr($settings['contact_number']); ?>">'
								<?php echo elh_element_kses_intermediate($settings['contact_number']); ?>
							</a>
							<?php endif; ?>
						</div>
					</div>
				</div>

				<div class="tna-package-1-playbtn-position">
					<div class="tna-package-1-playbtn">
						<svg width="392" height="276" viewBox="0 0 392 276" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path d="M10.3492 193.268C-1.93893 231.007 0.474806 263.481 3.21768 275H377.895C381.37 265.858 388.318 242.746 388.318 223.437C388.318 199.302 394.353 152.128 388.318 74.2354C383.491 11.9215 333.643 -0.365702 309.323 1.27992C132.133 -6.3996 25.7093 146.094 10.3492 193.268Z" fill="#EE4F35" fill-opacity="0.5" stroke="white" stroke-opacity="0.2" stroke-width="2"/>
						</svg>
						<div class="tna-playbtn-1-postion">
							<a href="<?php echo esc_url($settings['video_button_link']['url']); ?>" class="tna-playbtn-1" >
								<?php \Elementor\Icons_Manager::render_icon( $settings['video_button_icon'], [ 'aria-hidden' => 'true' ] ); ?>
							</a>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>
</div>