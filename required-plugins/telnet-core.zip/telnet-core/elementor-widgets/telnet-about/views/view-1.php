<?php

$this->add_inline_editing_attributes( 'title', 'basic' );
$this->add_render_attribute( 'title', 'class', 'sec-title-five_heading' );
$title = elh_element_kses_basic( $settings['title'] );

if ($settings['currency'] === 'custom') {
	$currency = $settings['currency_custom'];
} else {
	$currency = self::get_currency_symbol($settings['currency']);
}

?>
<section class="about-two">
	<div class="auto-container">
		<div class="row clearfix">

			<!-- Content Column -->
			<div class="about-two_content-column col-lg-6 col-md-12 col-sm-12">
				<div class="about-two_content-outer">
					<!-- Sec Title Five -->
					<div class="sec-title-five">
						<?php if(!empty( $settings['sub_title'] )) : ?>
						<div class="sec-title-five_title"><?php echo elh_element_kses_intermediate($settings['sub_title']); ?></div>
						<?php endif; ?>

						<?php
							printf('<%1$s %2$s>%3$s</%1$s>',
								tag_escape($settings['title_tag']),
								$this->get_render_attribute_string('title'),
								$title
							);
						?>
						<?php if(!empty($settings['description'])) : ?>
						<div class="sec-title-five_text"><?php echo wp_kses($settings['description'], true)?></div>
						<?php endif; ?>
					</div>
					<div class="about-two_info">
						<div class="row clearfix">
							<?php foreach($settings['feature_lists'] as $list ) : ?>
							<div class="column col-lg-6 col-md-6 col-sm-6">
								<div class="about-two_block">
									<div class="about-two_block-inner">
										<?php if( $list['enable_icon'] == true ) : ?>
										<div class="about-two_block-icon">
											<?php if($list['type'] == 'icon') : ?>
												<?php \Elementor\Icons_Manager::render_icon( $list['feature_icon'], [ 'aria-hidden' => 'true' ] ); ?>
											<?php else : ?>
												<img src="<?php echo esc_url($list['feature_image']['url']); ?>" alt="" />
											<?php endif; ?>
										</div>
										<?php endif; ?>

										<?php if(!empty( $list['title'] )) : ?>
										<h5 class="about-two_block-heading">
											<?php echo elh_element_kses_intermediate($list['title']); ?>
										</h5>
										<?php endif; ?>

										<?php if(!empty( $list['text'] )) : ?>
										<p><?php echo elh_element_kses_intermediate($list['text']); ?></p>
										<?php endif; ?>
									</div>
								</div>
							</div>
							<?php endforeach; ?>
						</div>
					</div>

					<!-- Options -->
					<div class="about-two_options d-flex align-item-center flex-wrap">
						<div class="about-two_button">
							<a href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>" class="theme-btn btn-style-eighteen">
								<?php if(!empty( $settings['button_text'] )) : ?>
								<span class="txt"><?php echo elh_element_kses_intermediate($settings['button_text']); ?></span>
								<?php endif; ?>

								<?php
									if(($settings['enable_icon']) === 'yes' ) {
										\Elementor\Icons_Manager::render_icon( $settings['btn_icon'], [ 'aria-hidden' => 'true' ] );
									}
								?>
							</a>
						</div>

						<div class="about-two_price"><?php if(!empty( $currency )) : ?><sup><?php echo esc_html($currency); ?></sup><?php endif; ?><?php echo esc_html($settings['price']); ?> <?php if(!empty( $settings['period'] )) : ?><sub><?php echo esc_html($settings['period']); ?></sub><?php endif; ?> <?php if(!empty( $settings['package_feature'] )) : ?><span><?php echo esc_html($settings['package_feature']); ?></span><?php endif; ?></div>
					</div>

				</div>
			</div>

			<!-- Image Column -->
			<div class="about-two_image-column col-lg-6 col-md-12 col-sm-12">
				<div class="about-two_image-outer">
					<?php if(!empty( $settings['image_1']['url'] )) : ?>
					<div class="about-two_image">
						<img src="<?php echo esc_url($settings['image_1']['url']) ?>" alt="" />
					</div>
					<?php endif; ?>

					<?php if(!empty( $settings['image_2']['url'] )) : ?>
					<div class="about-two_image-two">
						<img src="<?php echo esc_url($settings['image_2']['url']) ?>" alt="" />
					</div>
					<?php endif; ?>
				</div>
			</div>

		</div>
	</div>
</section>