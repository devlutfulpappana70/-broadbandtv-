<?php

$this->add_inline_editing_attributes( 'title', 'basic' );
$this->add_render_attribute( 'title', 'class', 'tna-title-2 txa-split-text txa-split-in-up' );
$title = elh_element_kses_basic( $settings['title'] );
?>
<div class="tna-choose-2-area bg-defualt flat_3 pt-140 pb-120" tna-data-background="<?php echo $settings['image_1'] ? esc_url($settings['image_1']['url']) : ''; ?>">
	<div class="container tna-container-1">
		<div class="tna-choose-2-wrap mb-25 ">
			<!-- section-title -->
			<div class="tna-choose-2-content">
				<div class="tna-section-title">
					<?php if(!empty( $settings['sub_title'] )) : ?>
						<h4 class="tna-subtitle-3 wow fadeInLeft tx-subTitle"><?php echo elh_element_kses_intermediate($settings['sub_title']); ?></h4>
					<?php endif; ?>
					<?php
						printf('<%1$s %2$s>%3$s</%1$s>',
							tag_escape($settings['title_tag']),
							$this->get_render_attribute_string('title'),
							$title
						);
					?>
				</div>

				<?php if(!empty( $settings['button_link']['url'] )) : ?>
				<a class="tna-pr-btn-3 tx-button wow fadeInLeft" href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>">
					<?php if(!empty( $settings['button_text'] )) : ?>
					<span class="text"><?php echo elh_element_kses_intermediate($settings['button_text']); ?></span>
					<?php endif; ?>
					<?php
						if(($settings['enable_icon']) === 'yes' ) {
							\Elementor\Icons_Manager::render_icon( $settings['btn_icon'], [ 'aria-hidden' => 'true' ] );
						}
					?>
				</a>
				<?php endif; ?>
			</div>
			<!-- right-feature -->
			<div class="tna-choose-2-feature-wrap">

			<?php
				$counter = 0;

				foreach ($settings['feature_lists'] as $id => $list) :
					$counter++;

					if ($counter <= 2) :
				?>
						<div class="tna-chooe-2-feature-item wow fadeIn tx-listsItems">
							<div class="bg-img-postion">
								<?php if (!empty($list['shape_bg']['url'])) : ?>
									<div class="bg-img">
										<img src="<?php echo esc_url($list['shape_bg']['url']); ?>" alt="">
									</div>
								<?php endif; ?>
							</div>

							<?php if ($list['enable_icon'] == true) : ?>
								<div class="icon">
									<?php if ($list['type'] == 'icon') : ?>
										<?php \Elementor\Icons_Manager::render_icon($list['feature_icon'], ['aria-hidden' => 'true']); ?>
									<?php else : ?>
										<img src="<?php echo esc_url($list['feature_image']['url']); ?>" alt="" />
									<?php endif; ?>
								</div>
							<?php endif; ?>

							<?php if (!empty($list['title'])) : ?>
								<a href="<?php echo esc_url($list['list_link']['url']); ?>" class="tna-heading-2 title"><?php echo elh_element_kses_intermediate($list['title']); ?></a>
								<a href="<?php echo esc_url($list['list_link']['url']); ?>" class="tna-heading-2 title-hover"><?php echo elh_element_kses_intermediate($list['title']); ?></a>
							<?php endif; ?>

							<?php if (!empty($list['text'])) : ?>
								<p class="tna-para-2 disc"><?php echo elh_element_kses_intermediate($list['text']); ?></p>
							<?php endif; ?>
						</div>
				<?php
					else:
						break;
					endif;
				endforeach;
				?>


			</div>
		</div>

		<div class="tna-choose-2-wrap-2">
			<div class="tna-choose-2-img tilt_scale" data-tilt data-tilt-max="5">
				<span class="shape-1 wow fadeInUp"></span>
				<?php if(!empty( $settings['image_2']['url'] )) : ?>
				<img class="wow fadeInUp" data-wow-delay=".5s" src="<?php echo esc_url($settings['image_2']['url']); ?>" alt="">
				<?php endif; ?>
			</div>
			<div class="tna-choose-2-feature-wrap-2">
				<?php
					$counter = 0;
					foreach ($settings['feature_lists'] as $id => $list) :
					$counter++;
					if ($counter > 2) :
				?>
				<div class="tna-chooe-2-feature-item wow fadeIn tx-listsItems">
					<div class="bg-img-postion">
						<?php if (!empty($list['shape_bg']['url'])) : ?>
							<div class="bg-img">
								<img src="<?php echo esc_url($list['shape_bg']['url']); ?>" alt="">
							</div>
						<?php endif; ?>
					</div>

					<?php if ($list['enable_icon'] == true) : ?>
						<div class="icon">
							<?php if ($list['type'] == 'icon') : ?>
								<?php \Elementor\Icons_Manager::render_icon($list['feature_icon'], ['aria-hidden' => 'true']); ?>
							<?php else : ?>
								<img src="<?php echo esc_url($list['feature_image']['url']); ?>" alt="" />
							<?php endif; ?>
						</div>
					<?php endif; ?>

					<?php if (!empty($list['title'])) : ?>
						<a href="<?php echo esc_url($list['list_link']['url']); ?>" class="tna-heading-2 title"><?php echo elh_element_kses_intermediate($list['title']); ?></a>
						<a href="<?php echo esc_url($list['list_link']['url']); ?>" class="tna-heading-2 title-hover"><?php echo elh_element_kses_intermediate($list['title']); ?></a>
					<?php endif; ?>

					<?php if (!empty($list['text'])) : ?>
						<p class="tna-para-2 disc"><?php echo elh_element_kses_intermediate($list['text']); ?></p>
					<?php endif; ?>
				</div>
				<?php
					endif;
				endforeach;
			?>
			</div>
		</div>
	</div>
</div>