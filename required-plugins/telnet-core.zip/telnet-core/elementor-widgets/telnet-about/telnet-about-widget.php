<?php
namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;

defined( 'ABSPATH' ) || die();

class Telnet_About extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'telnet_about';
    }

    /**
     * Get widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Telnet About', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/icon-box/';
    }

    /**
     * Get widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-preview-medium';
    }

    public function get_keywords() {
        return ['telnet', 'skill', 'speed', 'progress', 'bar'];
    }

    protected function register_content_controls() {

        //Settings
        $this->start_controls_section(
            '_section_settings',
            [
                'label' => __( 'Settings', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'design_style',
            [
                'label'              => __( 'Design Style', 'telnet-core' ),
                'type'               => Controls_Manager::SELECT,
                'options'            => [
                    'style_1' => __( 'Style 1', 'telnet-core' ),
                    'style_2' => __( 'Style 2', 'telnet-core' ),
                    'style_3' => __( 'Style 3', 'telnet-core' ),
                    'style_4' => __( 'Style 4', 'telnet-core' ),
                    'style_5' => __( 'Style 5', 'telnet-core' ),
                    'style_6' => __( 'Style 6', 'telnet-core' ),
                    'style_7' => __( 'Style 7', 'telnet-core' ),
                    'style_8' => __( 'Style 8', 'telnet-core' ),
                    'style_9' => __( 'Style 9', 'telnet-core' ),
                ],
                'default'            => 'style_1',
                'frontend_available' => true,
                'style_transfer'     => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_title',
            [
                'label' => __( 'Title & Description', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // sub title
        $this->add_control(
            'sub_title',
            [
                'label'       => __( 'Sub Title', 'telnet-core' ),
                'label_block' => true,
                'type'        => Controls_Manager::TEXTAREA,
                'rows'        => 4,
                'default'     => 'Sub Title',
                'placeholder' => __( 'Sub Title Text', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );

        $this->add_control(
            'title',
            [
                'label'       => __( 'Title', 'telnet-core' ),
                'label_block' => true,
                'type'        => Controls_Manager::TEXTAREA,
                'rows'        => 4,
                'default'     => 'Heading Title',
                'placeholder' => __( 'Heading Text', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );

        $this->add_control(
            'description',
            [
                'label'       => __( 'Description', 'telnet-core' ),
                'label_block' => true,
                'type'        => Controls_Manager::TEXTAREA,
                'rows'        => 4,
                'default'     => 'The opportunity to work abroad is a popular prospect, one',
                'placeholder' => __( 'Description Text', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
                'condition' => [
                    'design_style' => ['style_2', 'style_3', 'style_4', 'style_6', 'style_7', 'style_8' , 'style_9'],
                ],

            ]
        );

        $this->add_control(
            'description_2',
            [
                'label'       => __( 'Description 2', 'telnet-core' ),
                'label_block' => true,
                'type'        => Controls_Manager::TEXTAREA,
                'rows'        => 4,
                'default'     => 'The opportunity to work abroad is a popular prospect, one',
                'placeholder' => __( 'Description Text', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
                'condition' => [
                    'design_style' => [ 'style_6' ],
                ],

            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label'   => __( 'Title HTML Tag', 'telnet-core' ),
                'type'    => Controls_Manager::CHOOSE,
                'options' => [
                    'h1' => [
                        'title' => __( 'H1', 'telnet-core' ),
                        'icon'  => 'eicon-editor-h1',
                    ],
                    'h2' => [
                        'title' => __( 'H2', 'telnet-core' ),
                        'icon'  => 'eicon-editor-h2',
                    ],
                    'h3' => [
                        'title' => __( 'H3', 'telnet-core' ),
                        'icon'  => 'eicon-editor-h3',
                    ],
                    'h4' => [
                        'title' => __( 'H4', 'telnet-core' ),
                        'icon'  => 'eicon-editor-h4',
                    ],
                    'h5' => [
                        'title' => __( 'H5', 'telnet-core' ),
                        'icon'  => 'eicon-editor-h5',
                    ],
                    'h6' => [
                        'title' => __( 'H6', 'telnet-core' ),
                        'icon'  => 'eicon-editor-h6',
                    ],
                ],
                'default' => 'h2',
                'toggle'  => false,
            ]
        );

        $this->end_controls_section();

        // image
        $this->start_controls_section(
            '_section_image',
            [
                'label' => __( 'Image', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // image_1
        $this->add_control(
            'image_1',
            [
                'label'       => __( 'Image 1', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );

        // image_2
        $this->add_control(
            'image_2',
            [
                'label'       => __( 'Image 2', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition'   => [
                    'design_style' => ['style_1', 'style_3', 'style_4', 'style_5', 'style_6', 'style_7', 'style_9'],
                ],
            ]
        );

        // image 3
        $this->add_control(
            'image_3',
            [
                'label'       => __( 'Image 3', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition'   => [
                    'design_style' => ['style_6', 'style_7'],
                ],
            ]
        );

        // image 4
        $this->add_control(
            'image_4',
            [
                'label'       => __( 'Image 4', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition'   => [
                    'design_style' => ['style_6'],
                ],
            ]
        );

        // image 5
        $this->add_control(
            'image_5',
            [
                'label'       => __( 'Image 5', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition'   => [
                    'design_style' => ['style_6'],
                ],
            ]
        );


        // bg_shape_image
        $this->add_control(
            'bg_shape_image',
            [
                'label'       => __( 'Background Shape Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition'   => [
                    'design_style' => ['style_3'],
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_button',
            [
                'label' => __( 'Button', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // enable icon
        $this->add_control(
            'enable_icon',
            [
                'label'        => __( 'Enable Icon', 'telnet-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Show', 'telnet-core' ),
                'label_off'    => __( 'Hide', 'telnet-core' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        // Button Icons
        $this->add_control(
            'btn_icon',
            [
                'label'       => __( 'Button Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'default'     => [
                    'value'   => 'fas fa-arrow-right',
                    'library' => 'solid',
                ],
                'label_block' => true,
                'condition'   => [
                    'enable_icon' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label'       => __( 'Button Text', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Button Text', 'telnet-core' ),
                'placeholder' => __( 'Type your title here', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        // Button link
        $this->add_control(
            'button_link',
            [
                'label'         => __( 'Button Link', 'telnet-core' ),
                'type'          => Controls_Manager::URL,
                'placeholder'   => __( 'https://your-link.com', 'telnet-core' ),
                'default'       => [
                    'url' => '#',
                ],
                'show_external' => true,
                'label_block'   => false,
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
            '_section_design_title',
            [
                'label' => __( 'Feature Boxs', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'design_style' => ['style_1', 'style_3', 'style_4', 'style_5', 'style_6', 'style_7', 'style_8'],
                ],
            ]
        );

        $repeater = new \Elementor\Repeater();

        // desing style
        $repeater->add_control(
            'design_style',
            [
                'label'              => __( 'Design Style', 'telnet-core' ),
                'type'               => Controls_Manager::SELECT,
                'options'            => [
                    'style_1' => __( 'Style 1', 'telnet-core' ),
                    'style_2' => __( 'Style 2: For Style 5', 'telnet-core' ),
                ],
                'default'            => 'style_1',
                'frontend_available' => true,
                'style_transfer'     => true,
            ]
        );

        // enable icon
        $repeater->add_control(
            'enable_icon',
            [
                'label'        => __( 'Enable Icon', 'telnet-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Show', 'telnet-core' ),
                'label_off'    => __( 'Hide', 'telnet-core' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        // type
        $repeater->add_control(
            'type',
            [
                'label'   => __( 'Type', 'telnet-core' ),
                'type'    => Controls_Manager::CHOOSE,
                'options' => [
                    'icon' => [
                        'title' => __( 'Icon', 'telnet-core' ),
                        'icon'  => 'eicon-star',
                    ],
                    'image' => [
                        'title' => __( 'Image', 'telnet-core' ),
                        'icon'  => 'eicon-image',
                    ],
                ],
                'default' => 'icon',
                'condition' => [
                    'enable_icon' => 'yes',
                ],
            ]
        );

        // icon
        $repeater->add_control(
            'feature_icon',
            [
                'label'       => __( 'Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'default'     => [
                    'value'   => 'fas fa-star',
                    'library' => 'solid',
                ],
                'label_block' => true,
                'condition'   => [
                    'type' => 'icon',
                    'enable_icon' => 'yes',
                ],
            ]
        );

        // image
        $repeater->add_control(
            'feature_image',
            [
                'label'       => __( 'Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition'   => [
                    'type' => 'image',
                    'enable_icon' => 'yes',
                ],
            ]
        );

        // list text
        $repeater->add_control(
            'title',
            [
                'label'       => __( 'Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'List Text', 'telnet-core' ),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'text',
            [
                'label'       => __( 'Text', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'default'     => __( 'List Text', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        // shape bg
        $repeater->add_control(
            'shape_bg',
            [
                'label'       => __( 'Shape Background', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition'   => [
                    'design_style' => ['style_2'],
                ],
            ]
        );

        // list link
        $repeater->add_control(
            'list_link',
            [
                'label'         => __( 'Link', 'telnet-core' ),
                'type'          => Controls_Manager::URL,
                'placeholder'   => __( 'https://your-link.com', 'telnet-core' ),
                'default'       => [
                    'url' => '#',
                ],
                'show_external' => true,
                'label_block'   => false,
                'condition' => [
                    'design_style' => ['style_2'],
                ],
            ]
        );

        $this->add_control(
            'feature_lists',
            [
                'label'       => __( 'Feature Lists', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ title }}}',
            ]
        );

        $this->end_controls_section();

        // feature_lists_2
        $this->start_controls_section(
            '_section_design_title_2',
            [
                'label' => __( 'Feature Boxs', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'design_style' => ['style_2' , 'style_7', 'style_9'],
                ],
            ]
        );

        $repeater = new \Elementor\Repeater();

        // icon
        $repeater->add_control(
            'feature_icon',
            [
                'label'       => __( 'Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'default'     => [
                    'value'   => 'fas fa-star',
                    'library' => 'solid',
                ],
                'label_block' => true,
            ]
        );

        // list text
        $repeater->add_control(
            'title',
            [
                'label'       => __( 'Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'List Text', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'feature_lists_2',
            [
                'label'       => __( 'Feature Lists', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ title }}}',
            ]
        );

        $this->end_controls_section();


        // feature package price
        $this->start_controls_section(
            '_section_feature_package_price',
            [
                'label' => __( 'Feature Package Price', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'design_style' => ['style_1', 'style_2', 'style_4', 'style_9'],
                ],
            ]
        );

        // CURRENCY SYMBOL
        $this->add_control(
            'currency',
            [
                'label' => __('Currency', 'telnet-core'),
                'type' => Controls_Manager::SELECT,
                'label_block' => false,
                'options' => [
                    '' => __('None', 'telnet-core'),
                    'baht' => '&#3647; ' . _x('Baht', 'Currency Symbol', 'telnet-core'),
                    'bdt' => '&#2547; ' . _x('BD Taka', 'Currency Symbol', 'telnet-core'),
                    'dollar' => '&#36; ' . _x('Dollar', 'Currency Symbol', 'telnet-core'),
                    'euro' => '&#128; ' . _x('Euro', 'Currency Symbol', 'telnet-core'),
                    'franc' => '&#8355; ' . _x('Franc', 'Currency Symbol', 'telnet-core'),
                    'guilder' => '&fnof; ' . _x('Guilder', 'Currency Symbol', 'telnet-core'),
                    'krona' => 'kr ' . _x('Krona', 'Currency Symbol', 'telnet-core'),
                    'lira' => '&#8356; ' . _x('Lira', 'Currency Symbol', 'telnet-core'),
                    'peseta' => '&#8359 ' . _x('Peseta', 'Currency Symbol', 'telnet-core'),
                    'peso' => '&#8369; ' . _x('Peso', 'Currency Symbol', 'telnet-core'),
                    'pound' => '&#163; ' . _x('Pound Sterling', 'Currency Symbol', 'telnet-core'),
                    'real' => 'R$ ' . _x('Real', 'Currency Symbol', 'telnet-core'),
                    'ruble' => '&#8381; ' . _x('Ruble', 'Currency Symbol', 'telnet-core'),
                    'rupee' => '&#8360; ' . _x('Rupee', 'Currency Symbol', 'telnet-core'),
                    'indian_rupee' => '&#8377; ' . _x('Rupee (Indian)', 'Currency Symbol', 'telnet-core'),
                    'shekel' => '&#8362; ' . _x('Shekel', 'Currency Symbol', 'telnet-core'),
                    'won' => '&#8361; ' . _x('Won', 'Currency Symbol', 'telnet-core'),
                    'yen' => '&#165; ' . _x('Yen/Yuan', 'Currency Symbol', 'telnet-core'),
                    'custom' => __('Custom', 'telnet-core'),
                ],
                'default' => 'dollar',
            ]
        );

        $this->add_control(
            'currency_custom',
            [
                'label' => __('Custom Symbol', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'condition' => [
                    'currency' => 'custom',
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        // PRICE
        $this->add_control(
            'price',
            [
                'label' => __('Price', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '9.99',
                'dynamic' => [
                    'active' => true
                ]
            ]
        );

        // PERIOD
        $this->add_control(
            'period',
            [
                'label' => __('Period', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Per Month', 'telnet-core'),
                'dynamic' => [
                    'active' => true
                ],
            ]
        );

        // PCACKAGE FEATURE
        $this->add_control(
            'package_feature',
            [
                'label' => __('Package Feature Text', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Ultra Fast inernet', 'telnet-core'),
                'dynamic' => [
                    'active' => true
                ],
            ]
        );

        // end
        $this->end_controls_section();

        // contact info
        $this->start_controls_section(
            '_section_contact_info',
            [
                'label' => __( 'Contact Info', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'design_style' => ['style_2', 'style_6' , 'style_7', 'style_8'],
                ],
            ]
        );

        // contact icon
        $this->add_control(
            'contact_icon',
            [
                'label'       => __( 'Contact Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'default'     => [
                    'value'   => 'fas fa-phone',
                    'library' => 'solid',
                ],
                'label_block' => true,
            ]
        );

        // contact text
        $this->add_control(
            'contact_text',
            [
                'label'       => __( 'Contact Text', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Contact Text', 'telnet-core' ),
                'placeholder' => __( 'Type your title here', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        // contact number
        $this->add_control(
            'contact_number',
            [
                'label'       => __( 'Contact Number', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Contact Number', 'telnet-core' ),
                'placeholder' => __( 'Type your title here', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        // end
        $this->end_controls_section();

        // video button
        $this->start_controls_section(
            '_section_video_button',
            [
                'label' => __( 'Video Button', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'design_style' => ['style_2', 'style_7'],
                ],
            ]
        );

        // video image
        $this->add_control(
            'video_image',
            [
                'label'       => __( 'Video Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition'   => [
                    'design_style' => ['style_7'],
                ],
            ]
        );

        // button icon
        $this->add_control(
            'video_button_icon',
            [
                'label'       => __( 'Button Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'default'     => [
                    'value'   => 'fas fa-play',
                    'library' => 'solid',
                ],
                'label_block' => true,
            ]
        );

        // video button link
        $this->add_control(
            'video_button_link',
            [
                'label'         => __( 'Button Link', 'telnet-core' ),
                'type'          => Controls_Manager::URL,
                'placeholder'   => __( 'https://your-link.com', 'telnet-core' ),
                'default'       => [
                    'url' => '#',
                ],
                'show_external' => true,
                'label_block'   => false,
            ]
        );

        // end
        $this->end_controls_section();

    }

    protected function register_style_controls() {
        $dir = dirname( __FILE__ );

        $style_files = glob( $dir . '/styles/*.php' );

        if ( $style_files ) {
            foreach ( $style_files as $style_file ) {
                include $style_file;
            }
        }
    }

    private static function get_currency_symbol($symbol_name)
    {
        $symbols = [
            'baht' => '&#3647;',
            'bdt' => '&#2547;',
            'dollar' => '&#36;',
            'euro' => '&#128;',
            'franc' => '&#8355;',
            'guilder' => '&fnof;',
            'indian_rupee' => '&#8377;',
            'pound' => '&#163;',
            'peso' => '&#8369;',
            'peseta' => '&#8359',
            'lira' => '&#8356;',
            'ruble' => '&#8381;',
            'shekel' => '&#8362;',
            'rupee' => '&#8360;',
            'real' => 'R$',
            'krona' => 'kr',
            'won' => '&#8361;',
            'yen' => '&#165;',
        ];

        return isset($symbols[$symbol_name]) ? $symbols[$symbol_name] : '';
    }


    /**
     * Render widget output on the frontend.
     *
     * Used to generate the final HTML displayed on the frontend.
     *
     * Note that if skin is selected, it will be rendered by the skin itself,
     * not the widget.
     *
     * @since 1.0.0
     * @access public
     */
    protected function render() {

        $settings = $this->get_settings_for_display();
        $dir = dirname( __FILE__ );

        $title = elh_element_kses_basic( $settings['title'] );

        $style = !empty($settings['design_style']) ? $settings['design_style'] : 'style_1';

        switch ($style) {
            case 'style_9':
                include $dir . '/views/view-9.php';
                break;
            case 'style_8':
                include $dir . '/views/view-8.php';
                break;
            case 'style_7':
                include $dir . '/views/view-7.php';
                break;
            case 'style_6':
                include $dir . '/views/view-6.php';
                break;
            case 'style_5':
                include $dir . '/views/view-5.php';
                break;
            case 'style_4':
                include $dir . '/views/view-4.php';
                break;
            case 'style_3':
                include $dir . '/views/view-3.php';
                break;
            case 'style_2':
                include $dir . '/views/view-2.php';
                break;
            default:
                include $dir . '/views/view-1.php';
        }
    }

}