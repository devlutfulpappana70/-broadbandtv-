<?php
namespace ElementHelper\Widget;

use \Elementor\Group_Control_Background;
use \Elementor\Repeater;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Typography;
use \ElementHelper\Element_El_Select2;
use \Elementor\Core\Schemes\Typography;
use \Elementor\Utils;
use \Elementor\Control_Media;

defined( 'ABSPATH' ) || die();

class Hero_Slider_Five extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'hero_slider_five';
    }


    /**
     * Get widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Hero Slider Five', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/slider/';
    }

    /**
     * Get widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-slider-full-screen';
    }

    public function get_keywords() {
        return [ 'slider', 'image', 'gallery', 'carousel' ];
    }


    public function get_script_depends() {
		return ['ta_Hero_Slider_Six'];
	}

    public function get_style_depends() {
        return [ 'tf-hero-slider-style' ];
    }

    public function get_post_types() {
        $post_types = elh_element_get_post_types([], ['elementor_library', 'attachment']);
        return $post_types;
    }

    protected function register_content_controls() {

        $this->start_controls_section(
            '_section_slides',
            [
                'label' => __( 'SLIDE ITEMS', 'telnet-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        // bg image
        $this->add_control(
            'bg_image',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Bg Image', 'telnet-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );


        $repeater = new Repeater();

        // SHAPE IMAGE
        $repeater->add_control(
            'image',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Image', 'telnet-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        // TITLE
        $repeater->add_control(
            'subtitle',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'label' => __( 'Sub Title', 'telnet-core' ),
                'default' => __( 'Sub Title Here', 'telnet-core' ),
                'placeholder' => __( 'Type title here', 'telnet-core' ),
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );
        $repeater->add_control(
            'title',
            [
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'label' => __( 'Title', 'telnet-core' ),
                'default' => __( 'Title Here', 'telnet-core' ),
                'placeholder' => __( 'Type title here', 'telnet-core' ),
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );
        $repeater->add_control(
            'description',
            [
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'label' => __( 'Description', 'telnet-core' ),
                'default' => __( 'Description Here', 'telnet-core' ),
                'placeholder' => __( 'Type title here', 'telnet-core' ),
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );


        // CURRENCY SYMBOL
        $repeater->add_control(
            'currency',
            [
                'label' => __('Currency', 'telnet-core'),
                'type' => Controls_Manager::SELECT,
                'label_block' => false,
                'options' => [
                    '' => __('None', 'telnet-core'),
                    'baht' => '&#3647; ' . _x('Baht', 'Currency Symbol', 'telnet-core'),
                    'bdt' => '&#2547; ' . _x('BD Taka', 'Currency Symbol', 'telnet-core'),
                    'dollar' => '&#36; ' . _x('Dollar', 'Currency Symbol', 'telnet-core'),
                    'euro' => '&#128; ' . _x('Euro', 'Currency Symbol', 'telnet-core'),
                    'franc' => '&#8355; ' . _x('Franc', 'Currency Symbol', 'telnet-core'),
                    'guilder' => '&fnof; ' . _x('Guilder', 'Currency Symbol', 'telnet-core'),
                    'krona' => 'kr ' . _x('Krona', 'Currency Symbol', 'telnet-core'),
                    'lira' => '&#8356; ' . _x('Lira', 'Currency Symbol', 'telnet-core'),
                    'peseta' => '&#8359 ' . _x('Peseta', 'Currency Symbol', 'telnet-core'),
                    'peso' => '&#8369; ' . _x('Peso', 'Currency Symbol', 'telnet-core'),
                    'pound' => '&#163; ' . _x('Pound Sterling', 'Currency Symbol', 'telnet-core'),
                    'real' => 'R$ ' . _x('Real', 'Currency Symbol', 'telnet-core'),
                    'ruble' => '&#8381; ' . _x('Ruble', 'Currency Symbol', 'telnet-core'),
                    'rupee' => '&#8360; ' . _x('Rupee', 'Currency Symbol', 'telnet-core'),
                    'indian_rupee' => '&#8377; ' . _x('Rupee (Indian)', 'Currency Symbol', 'telnet-core'),
                    'shekel' => '&#8362; ' . _x('Shekel', 'Currency Symbol', 'telnet-core'),
                    'won' => '&#8361; ' . _x('Won', 'Currency Symbol', 'telnet-core'),
                    'yen' => '&#165; ' . _x('Yen/Yuan', 'Currency Symbol', 'telnet-core'),
                    'custom' => __('Custom', 'telnet-core'),
                ],
                'default' => 'dollar',
            ]
        );

        // PRICE
        $repeater->add_control(
            'price',
            [
                'label' => __('Price', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '9.99',
                'dynamic' => [
                    'active' => true
                ]
            ]
        );

        // PERIOD
        $repeater->add_control(
            'period',
            [
                'label' => __('Period', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Per Month', 'telnet-core'),
                'dynamic' => [
                    'active' => true
                ],
            ]
        );

        $repeater->add_control(
            'package_feature',
            [
                'label' => __('Package Feature Text', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Ultra Fast inernet', 'telnet-core'),
                'dynamic' => [
                    'active' => true
                ],
            ]
        );

        // BUTTON TEXT

        $repeater->add_control(
            'button_text',
            [
                'label'       => __( 'Text', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Button Text', 'telnet-core' ),
                'placeholder' => __( 'Type button text here', 'telnet-core' ),
                'label_block' => true,
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );
        // button_arrow
        $repeater->add_control(
            'button_arrow',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Button Arrow', 'telnet-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        // BUTTON LINK
        $repeater->add_control(
            'button_link',
            [
                'label'       => __( 'Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'placeholder' => __( 'http://elementor.themexriver.com', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
                'default' => [
					'url' => 'http://elementor.themexriver.com',
					'is_external' => true,
					'nofollow' => true,
				],
            ]
        );


        // ALL SLIDES
        $this->add_control(
            'slides',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '<# print(title || "Carousel Item"); #>',
                'default' => [
                    [
                        'image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                ]
            ]
        );

        $this->end_controls_section();

        // settings
        $this->start_controls_section(
            '_section_settings',
            [
                'label' => __( 'Settings', 'telnet-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        // enable slider nav
        $this->add_control(
            'enable_slider_nav',
            [
                'label' => __( 'Enable Slider Nav', 'telnet-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'telnet-core' ),
                'label_off' => __( 'Hide', 'telnet-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        // end settings
        $this->end_controls_section();


    }

    protected function register_style_controls() {
        $dir = dirname( __FILE__ );

        include $dir . '/styles/slide-style.php';
        include $dir . '/styles/title-style.php';
        include $dir . '/styles/description-style.php';
        include $dir . '/styles/price-style.php';
        include $dir . '/styles/button-style.php';

    }

    private static function get_currency_symbol($symbol_name)
    {
        $symbols = [
            'baht' => '&#3647;',
            'bdt' => '&#2547;',
            'dollar' => '&#36;',
            'euro' => '&#128;',
            'franc' => '&#8355;',
            'guilder' => '&fnof;',
            'indian_rupee' => '&#8377;',
            'pound' => '&#163;',
            'peso' => '&#8369;',
            'peseta' => '&#8359',
            'lira' => '&#8356;',
            'ruble' => '&#8381;',
            'shekel' => '&#8362;',
            'rupee' => '&#8360;',
            'real' => 'R$',
            'krona' => 'kr',
            'won' => '&#8361;',
            'yen' => '&#165;',
        ];

        return isset($symbols[$symbol_name]) ? $symbols[$symbol_name] : '';
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <section id="tel-slider-4" class="tel-slider-section-4 position-relative">
            <div class="bg_image position-absolute" data-background="<?php echo esc_url($settings['bg_image']['url']);?>"></div>
            <div class="tel-main-slider-area-4">
                <div class="tel-main-slider-4 swiper-container">
                    <div class="swiper-wrapper">
                        <?php foreach($settings['slides'] as $item):
                            if ($item['currency'] === 'custom') {
                                $currency = $item['currency_custom'];
                            } else {
                                $currency = self::get_currency_symbol($item['currency']);
                            }
                        ?>
                        <div class="swiper-slide">
                            <div class="tel-slider-item-4 position-relative">
                                <div class="container">
                                    <div class="tel-slider-text-4">
                                        <div class="slider-slug text-uppercase">
                                            <?php echo wp_kses($item['subtitle'], true);?>
                                        </div>
                                        <h1><?php echo wp_kses($item['title'], true);?></h1>
                                        <p><?php echo wp_kses($item['description'], true);?></p>
                                        <div class="slider-btn-price d-flex align-items-center">
                                            <?php if(!empty($item['button_text'])):?>
                                                <div class="tel-btn-2 text-uppercase">
                                                    <a href="<?php echo esc_url($item['button_link']['url']);?>"
                                                    target="<?php echo esc_attr($item['button_link']['is_external'] ? '_blank' : '_self');?>"
                                                    rel="<?php echo esc_attr($item['button_link']['nofollow'] ? 'nofollow' : '');?>">
                                                    <?php echo esc_html($item['button_text']);?>
                                                        <?php if(!empty($item['button_arrow']['url'])):?>
                                                            <img src="<?php echo esc_url($item['button_arrow']['url']);?>" alt="">
                                                        <?php endif;?>
                                                    </a>
                                                </div>
                                            <?php endif;?>
                                            <div class="slider-pricing headline pera-content">
                                                <h3><?php if(!empty($currency)):?>
                                                <sup><?php echo esc_html($currency)?></sup>
                                            <?php endif;?>
                                                <?php echo esc_html($item['price'])?>
                                            <?php if(!empty( $item['period'] )) : ?>
                                                <sub><?php echo esc_html($item['period']); ?></sub>
                                            <?php endif;?></h3>

                                            <?php if(!empty( $item['package_feature'] )) : ?>
                                                <span><?php echo esc_html($item['package_feature']); ?></span>
                                            <?php endif;?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php if(!empty($item['image']['url'])):?>
                                    <div class="tel-slider-img-4 position-absolute">
                                        <img src="<?php echo esc_url($item['image']['url']);?>" alt="">
                                    </div>
                                <?php endif;?>
                            </div>
                        </div>
                        <?php endforeach;?>
                    </div>
                </div>
                <?php if( $settings['enable_slider_nav'] === 'yes' ) : ?>
                <div class="tel-main-arrow-next-prev position-absolute d-flex align-items-center justify-content-center">
                    <div class="tel-slider-arrow d-flex justify-content-center align-items-center tel-main-button-prev_3"><i class="fal fa-long-arrow-up"></i></div>
                    <div class="swiper-main-paginations-2 text-center"></div>
                    <div class="tel-slider-arrow d-flex justify-content-center align-items-center tel-main-button-next_3"><i class="fal fa-long-arrow-down"></i></div>
                </div>
                <?php endif;?>
            </div>
        </section>
        <?php
    }
}