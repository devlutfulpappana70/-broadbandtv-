<?php

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;


$this->start_controls_section(
    '_section_style_button',
    [
        'label' => __( 'BUTTON STYLE', 'telnet-core' ),
        'tab'   => Controls_Manager::TAB_STYLE,
    ]
);

// typography
$this->add_group_control(
    Group_Control_Typography::get_type(),
    [
        'name'     => 'button_typography',
        'label'    => __( 'Typography', 'telnet-core' ),
        'selector' => '{{WRAPPER}} .tel-btn-2 a',
    ]
);

// Border radious
$this->add_responsive_control(
    'button_border_radius',
    [
        'label'      => __( 'Border Radius', 'telnet-core' ),
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => ['px', '%'],
        'selectors'  => [
            '{{WRAPPER}} .tel-btn-2 a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
    ]
);

// Group_Control_Border
$this->add_group_control(
    Group_Control_Border::get_type(),
    [
        'name'     => 'button_border',
        'label'    => __( 'Border', 'telnet-core' ),
        'selector' => '{{WRAPPER}} .tel-btn-2 a',
    ]
);

// padding
$this->add_responsive_control(
    'button_padding',
    [
        'label'      => __( 'Padding', 'telnet-core' ),
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => ['px', 'em', '%'],
        'selectors'  => [
            '{{WRAPPER}} .tel-btn-2 a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
    ]
);

// margin
$this->add_responsive_control(
    'button_margin',
    [
        'label'      => __( 'Margin', 'telnet-core' ),
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => ['px', 'em', '%'],
        'selectors'  => [
            '{{WRAPPER}} .tel-btn-2 a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
    ]
);

$this->start_controls_tabs('_tabs_button');

$this->start_controls_tab(
    '_tab_button_normal',
    [
        'label' => __( 'Normal', 'telnet-core' ),
    ]
);

// color
$this->add_control(
    'button_color',
    [
        'label'     => __( 'Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tel-btn-2 a' => 'color: {{VALUE}};',
        ],
    ]
);

// background color
$this->add_control(
    'button_bg_color',
    [
        'label'     => __( 'Background Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tel-btn-2 a' => 'background-color: {{VALUE}};',
        ],
    ]
);

$this->end_controls_tab();

$this->start_controls_tab(
    '_tab_button_hover',
    [
        'label' => __( 'Hover', 'telnet-core' ),
    ]
);

// color
$this->add_control(
    'button_color_hover',
    [
        'label'     => __( 'Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tel-btn-2 a:hover' => 'color: {{VALUE}};',
        ],
    ]
);

// background color
$this->add_control(
    'button_bg_color_hover',
    [
        'label'     => __( 'Background Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tel-btn-2 a:hover' => 'background-color: {{VALUE}};',
        ],
    ]
);

$this->end_controls_tab();

$this->end_controls_tabs();

$this->end_controls_section();