<div class="tx-formWrapper tx-formWrapper__styleOne">
    <?php
        if (!empty($settings['form_id'])) {
            echo elh_element_do_shortcode('contact-form-7', [
                'id' => $settings['form_id'],
                'html_class' => 'elh-cf7-form ' . elh_element_sanitize_html_class_param($settings['html_class']),
            ]);
        }
    ?>
</div>