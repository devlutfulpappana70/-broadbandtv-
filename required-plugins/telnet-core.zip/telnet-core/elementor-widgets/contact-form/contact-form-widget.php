<?php

namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Repeater;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Typography;
use \Elementor\Core\Schemes\Typography;
use \Elementor\Utils;

defined('ABSPATH') || die();

class Contact_Form extends Element_El_Widget
{

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'contact_form';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return __('Contact Form', 'telnet-core');
    }

    public function get_custom_help_url()
    {
        return 'http://elementor.themexriver.com/widgets/contact-7-form/';
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'elh-widget-icon eicon-form-horizontal';
    }

    public function get_keywords()
    {
        return ['form', 'contact', 'cf7', 'contact form', 'gravity', 'ninja'];
    }

    protected function register_content_controls() {

        $this->start_controls_section(
            '_section_design_title',
            [
                'label' => __( 'Design Style', 'telnet-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'design_style',
            [
                'label' => __( 'Design Style', 'telnet-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'telnet-core' ),
                    'style_2' => __( 'Style 2', 'telnet-core' ),
                    'style_3' => __( 'Style 3', 'telnet-core' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_cf7',
            [
                'label' => elh_element_is_cf7_activated() ? __('Contact Form 7', 'telnet-core') : __('Missing Notice', 'telnet-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        if (!elh_element_is_cf7_activated()) {
            $this->add_control(
                '_cf7_missing_notice',
                [
                    'type' => Controls_Manager::RAW_HTML,
                    'raw' => sprintf(
                        __('Hello %2$s, looks like %1$s is missing in your site. Please click on the link below and install/activate %1$s. Make sure to refresh this page after installation or activation.', 'telnet-core'),
                        '<a href="' . esc_url(admin_url('plugin-install.php?s=Contact+Form+7&tab=search&type=term'))
                        . '" target="_blank" rel="noopener">Contact Form 7</a>',
                        elh_element_get_current_user_display_name()
                    ),
                    'content_classes' => 'elementor-panel-alert elementor-panel-alert-danger',
                ]
            );

            $this->add_control(
                '_cf7_install',
                [
                    'type' => Controls_Manager::RAW_HTML,
                    'raw' => '<a href="' . esc_url(admin_url('plugin-install.php?s=Contact+Form+7&tab=search&type=term')) . '" target="_blank" rel="noopener">Click to install or activate Contact Form 7</a>',
                ]
            );
            $this->end_controls_section();
            return;
        }

        $this->add_control(
            'form_id',
            [
                'label' => __('Select Your Form', 'telnet-core'),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => ['' => __('', 'telnet-core')] + \elh_element_get_cf7_forms(),
            ]
        );

        $this->add_control(
            'html_class',
            [
                'label' => __('HTML Class', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'description' => __('Add CSS custom class to the form.', 'telnet-core'),
            ]
        );

        $this->end_controls_section();
      
        $this->start_controls_section(
            '_section_count_style',
            [
                'label' => __( 'Count Text', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // count color
        $this->add_control(
            'form_bg',
            [
                'label'     => __( 'Form BG Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-formWrapper__styleOne input, .tx-formWrapper__styleOne textarea, .tx-formWrapper .nice-select' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'form_border',
            [
                'label'     => __( 'Form Border Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-formWrapper__styleOne input, .tx-formWrapper__styleOne textarea, .tx-formWrapper .nice-select, .nice-select' => 'border:1px solid {{VALUE}}; box-shadow:none',
                ],
            ]
        );
        $this->add_control(
            'form_color',
            [
                'label'     => __( 'Form Text Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-formWrapper__styleOne input, .tx-formWrapper__styleOne textarea, .tx-formWrapper .nice-select' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'count_typography',
                'label'    => __( 'Form Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-formWrapper__styleOne input, .tx-formWrapper__styleOne textarea, .tx-formWrapper .current, .tx-formWrapper__styleOne input::placeholder, .tx-formWrapper__styleOne textarea::placeholder',
            ]
        );


        // count end
        $this->end_controls_section();


    }

    protected function register_style_controls() {

    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        if (!elh_element_is_cf7_activated()) {
            return;
        }
        $dir = dirname(__FILE__);

        if (!empty($settings['design_style']) && $settings['design_style'] == 'style_3') :
            include $dir . '/views/view-3.php';

        elseif (!empty($settings['design_style']) && $settings['design_style'] == 'style_2') :
            include $dir . '/views/view-2.php';
        else :
            include $dir . '/views/view-1.php';
        endif;
    }
}
