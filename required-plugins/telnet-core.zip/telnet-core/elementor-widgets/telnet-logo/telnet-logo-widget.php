<?php

namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
use \Elementor\Core\Schemes\Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;

defined( 'ABSPATH' ) || die();

class Telnet_Logo extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name() {
        return 'telnet_logo';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title() {
        return __( 'TelNet Logo', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/gradient-heading/';
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-t-letter';
    }

    public function get_keywords() {
        return ['telnet', 'telnet logo'];
    }

    protected function register_content_controls() {

        //Settings
        $this->start_controls_section(
            '_section_settings',
            [
                'label' => __( 'TelNet Logo', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // image
        $this->add_control(
            'image',
            [
                'label'   => __( 'Logo Image', 'telnet-core' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        // enable custom link
        $this->add_control(
            'enable_custom_link',
            [
                'label'        => __( 'Enable Custom Link', 'telnet-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'telnet-core' ),
                'label_off'    => __( 'No', 'telnet-core' ),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        // custom link
        $this->add_control(
            'custom_link',
            [
                'label'       => __( 'Custom Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'telnet-core' ),
                'condition'   => [
                    'enable_custom_link' => 'yes',
                ],
            ]
        );

        // logo size
        $this->add_responsive_control(
            'logo_size',
            [
                'label'      => __( 'Logo Size', 'telnet-core' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em', 'rem' ],
                'range'      => [
                    'px' => [
                        'min'  => 10,
                        'max'  => 500,
                        'step' => 1,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .tx-logo img' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // alignment
        $this->add_responsive_control(
            'alignment',
            [
                'label'     => __( 'Alignment', 'telnet-core' ),
                'type'      => Controls_Manager::CHOOSE,
                'options'   => [
                    'left'    => [
                        'title' => __( 'Left', 'telnet-core' ),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center'  => [
                        'title' => __( 'Center', 'telnet-core' ),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right'   => [
                        'title' => __( 'Right', 'telnet-core' ),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default'   => 'center',
                'selectors' => [
                    '{{WRAPPER}}' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

    }

    protected function register_style_controls() {


    }

    protected function render() {

        $settings = $this->get_settings_for_display();

        $image_alt = get_post_meta( $settings['image']['id'], '_wp_attachment_image_alt', true );

        if($settings['enable_custom_link'] == 'yes') {

            $this->add_render_attribute( 'link', 'href', $settings['custom_link']['url'] );
            $this->add_render_attribute( 'link', 'target', $settings['custom_link']['is_external'] ? '_blank' : '_self' );
            $this->add_render_attribute( 'link', 'rel', $settings['custom_link']['nofollow'] ? 'nofollow' : '' );

            $this->add_render_attribute( 'link', 'class', 'tx-logo' );

            ?>
            <a <?php echo $this->get_render_attribute_string( 'link' ); ?>>
                <img src="<?php echo $settings['image']['url']; ?>" alt="<?php echo $image_alt ? esc_attr($image_alt) : 'Logo'; ?>">
            </a>
            <?php

            return;

        } else {
            ?>
            <a href="<?php print esc_url( home_url( '/' ) );?>" class="tx-link">
                <img src="<?php echo $settings['image']['url']; ?>" alt="<?php echo $image_alt ? esc_attr($image_alt) : 'Logo'; ?>">
            </a>
            <?php
            return;
        }
    }
}
