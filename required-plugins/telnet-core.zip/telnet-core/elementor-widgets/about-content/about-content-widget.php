<?php
namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;

defined( 'ABSPATH' ) || die();

class About_Content extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'about_content';
    }

    /**
     * Get widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'About Content', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/icon-box/';
    }

    /**
     * Get widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-preview-medium';
    }

    public function get_keywords() {
        return ['telnet', 'skill', 'speed', 'progress', 'bar'];
    }

    protected function register_content_controls() {
        $this->start_controls_section(
            '_section_exp_title',
            [
                'label' => __( 'Expriencr ', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'count',
            [
                'label'       => __( 'Count', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );
        $this->add_control(
            'prefix',
            [
                'label'       => __( 'Prefix', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );
        $this->add_control(
            'exptitle',
            [
                'label'       => __( 'Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );
        $this->add_control(
            'image1',
            [
                'label'       => __( 'Image 1', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );
        $this->add_control(
            'image2',
            [
                'label'       => __( 'Image 2', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            '_section_design_title',
            [
                'label' => __( 'Content', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'check-title-shape',
                'types' => [ 'classic' ],
				'exclude' => [ 'color' ],
				'selector' => '{{WRAPPER}} .tel-section-title-4 .sub-title:before',
                'fields_options' => [
                    'background' => [
                        'label' => esc_html__( 'Box Active BG COlor', 'invite-plugin' ),
                        'separator' => 'before',
                    ]
                ]
			]
		);

        $this->add_control(
            'subtitle',
            [
                'label'       => __( 'Sub Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );
        $this->add_control(
            'title',
            [
                'label'       => __( 'Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'description',
            [
                'label'       => __( 'Description', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'label_block' => true,
            ]
        );

        $repeater = new \Elementor\Repeater();

        // info label
        $repeater->add_control(
            'image',
            [
                'label'       => __( 'image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );

        // list text
        $repeater->add_control(
            'title',
            [
                'label'       => __( 'Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'List Text', 'telnet-core' ),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'text',
            [
                'label'       => __( 'Text', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'default'     => __( 'List Text', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'iconbox',
            [
                'label'       => __( 'Info', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [
                    [
                        'info_text' => __( 'Info Text', 'telnet-core' ),
                    ],
                ],
                'title_field' => '{{{ title }}}',
            ]
        );

        $this->add_control(
            'list_items',
            [
                'label'       => __( 'List Item', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'label_block' => true,
            ]
        );
        $this->add_control(
            'video_img',
            [
                'label'       => __( 'Video Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );
        $this->add_control(
            'video_link',
            [
                'label'       => __( 'Video Link', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );
        $this->add_control(
            'btn_label',
            [
                'label'       => __( 'Button Label', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );
        $this->add_control(
            'btn_link',
            [
                'label'       => __( 'Button Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'label_block' => true,
            ]
        );
        $this->end_controls_section();

    }

    protected function register_style_controls() {

    }


    /**
     * Render widget output on the frontend.
     *
     * Used to generate the final HTML displayed on the frontend.
     *
     * Note that if skin is selected, it will be rendered by the skin itself,
     * not the widget.
     *
     * @since 1.0.0
     * @access public
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $this->add_render_attribute( 'title2', 'class', 'headline-title tx-sectionHeading__title' );
        ?>
        <div class="tel-about-text-area-3">
            <div class="tel-about-content-3 position-relative">
                <div class="tel-about-img-wrapper-3 position-absolute">
                    <?php if(!empty($settings['image1']['url'])):?>
                        <div class="tel-about-img-3_1 tel-img-animation">
                            <img src="<?php echo esc_url($settings['image1']['url']);?>" alt="">
                        </div>
                    <?php endif;?>
                    <?php if(!empty($settings['image2']['url'])):?>
                        <div class="tel-about-img-3_2 position-absolute tel-img-animation">
                            <img src="<?php echo esc_url($settings['image2']['url']);?>" alt="">
                        </div>
                    <?php endif;?>
                    <div class="tel-about-exp-3 text-center d-flex align-items-center justify-content-center position-absolute">
                        <div class="tel-about-exp-text">
                            <h3><span class="counter"><?php echo esc_html($settings['count']);?></span><?php if(!empty($settings['prefix'])){echo esc_html($settings['prefix']);}?></h3>
                            <p><?php echo wp_kses($settings['exptitle'], true)?></p>
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="tel-about-text-area-3 d-flex justify-content-end">
                        <div class="tel-about-text-area">
                            <div class="tel-section-title-4 telnet-text">
                            <?php if(!empty( $settings['subtitle'] )) : ?>
                            <div class="sub-title text-uppercase position-relative  d-inline-block wow fadeInRight"  data-wow-delay="200ms" data-wow-duration="2000ms">
                                <span><?php echo elh_element_kses_intermediate($settings['subtitle']); ?></span>
                            </div>
                            <?php endif; ?>
                            <h2><?php echo wp_kses($settings['title'], true); ?></h2>
                            <?php if(!empty($settings['description'])):?>
                            <p><?php echo wp_kses($settings['description'], true)?></p>
                            <?php endif;?>
                            </div>
                            <div class="tel-about-featured-area d-flex">
                            <div class="tel-about-featured-items">
                                <?php foreach($settings['iconbox'] as $item):?>
                                <div class="tel-about-feature-item position-relative d-flex align-items-center wow fadeInUp"  data-wow-delay="300ms" data-wow-duration="1200ms">
                                    <div class="inner-icon d-flex justify-content-center align-items-center">
                                        <img src="<?php echo esc_url($item['image']['url']);?>" alt="">
                                    </div>
                                    <div class="inner-text">
                                        <h3><?php echo esc_html($item['title']);?></h3>
                                        <p><?php echo esc_html($item['text']);?></p>
                                    </div>
                                </div>
                                <?php endforeach;?>
                            </div>
                                <div class="tel-about-feature-video-list position-relative wow fadeInRight"  data-wow-delay="300ms" data-wow-duration="1200ms">
                                    <?php if(!empty($settings['video_img']['url'])):?>
                                    <div class="tel-slide-video-btn position-relative d-flex align-items-center justify-content-center" data-background="<?php echo esc_url($settings['video_img']['url']);?>">
                                        <a
                                        class="d-flex justify-content-center align-items-center"
                                        href="<?php echo esc_url($settings['video_link']);?>"><i class="fas fa-play"></i></a>
                                    </div>
                                    <?php endif;?>
                                    <?php if(!empty($settings['list_items'])):?>
                                    <div class="tel-about-feature-list ul-li-block">
                                        <ul>
                                            <?php
                                                $list_item = $settings['list_items'];
                                                $list_item = explode("\n", ($list_item));
                                                foreach($list_item as $list):
                                            ?>
                                            <li><?php echo wp_kses($list, true)?></li>
                                            <?php endforeach;?>
                                        </ul>
                                    </div>
                                    <?php endif;?>
                                </div>
                            </div>
                            <?php if(!empty($settings['btn_label'])):?>
                                <div class="tel-btn-3 text-uppercase">
                                    <a
                                    href="<?php echo esc_url($settings['btn_link']['url']);?>"
                                    target="<?php echo esc_attr($settings['btn_link']['is_external'] ? '_blank' : '_self');?>"
                                    rel="<?php echo esc_attr($settings['btn_link']['nofollow'] ? 'nofollow' : ''); ?>"
                                    >
                                    <?php echo esc_html($settings['btn_label']); ?><i class="fas fa-arrow-right"></i>
                                </a>
                                </div>
                            <?php endif;?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php }

}