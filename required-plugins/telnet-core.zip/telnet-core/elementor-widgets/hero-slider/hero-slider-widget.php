<?php
namespace ElementHelper\Widget;

use \Elementor\Group_Control_Background;
use \Elementor\Repeater;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Typography;
use \ElementHelper\Element_El_Select2;
use \Elementor\Core\Schemes\Typography;
use \Elementor\Utils;
use \Elementor\Control_Media;

defined( 'ABSPATH' ) || die();

class Hero_slider extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'hero_slider';
    }


    /**
     * Get widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Hero Slider', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/slider/';
    }

    /**
     * Get widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-slider-full-screen';
    }

    public function get_keywords() {
        return [ 'slider', 'image', 'gallery', 'carousel' ];
    }


    public function get_script_depends() {
		return ['ta_hero_slider'];
	}

    public function get_style_depends() {
        return [ 'tf-hero-slider-style' ];
    }

    public function get_post_types() {
        $post_types = elh_element_get_post_types([], ['elementor_library', 'attachment']);
        return $post_types;
    }

    protected function register_content_controls() {

        $this->start_controls_section(
            '_section_design_title',
            [
                'label' => __('CHOOSE STYLE', 'telnet-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'design_style',
            [
                'label' => __('CHOOSE STYLE', 'telnet-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __('Style 1', 'telnet-core'),
                    'style_2' => __('Style 2', 'telnet-core'),
                    'style_3' => __('Style 3', 'telnet-core'),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_icon_list',
            [
                'label' => __( 'SOCIAL ICON LISTS', 'telnet-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'design_style' => ['style_3']
                ],
            ]
        );

        $repeater = new Repeater();

        // details icon
        $repeater->add_control(
            'social_list_1_btn_type',
            [
                'label'          => __( 'Button Icon', 'telnet-core' ),
                'type'           => Controls_Manager::CHOOSE,
                'label_block'    => false,
                'options'        => [
                    'icon'  => [
                        'title' => __( 'Icon', 'telnet-core' ),
                        'icon'  => 'far fa-smile',
                    ],
                    'image' => [
                        'title' => __( 'Image', 'telnet-core' ),
                        'icon'  => 'fa fa-image',
                    ],
                ],
                'default'        => 'icon',
                'toggle'         => false,
                'style_transfer' => true,
            ]
        );

        // list icon
        $repeater->add_control(
            'social_list_1_icon',
            [
                'label'       => __( 'Button Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'default'     => [
                    'value'   => 'fas fa-arrow-right',
                    'library' => 'solid',
                ],
                'label_block' => true,
                'condition'   => [
                    'social_list_1_btn_type' => 'icon',
                ],
            ]
        );

        // list image
        $repeater->add_control(
            'social_list_1_image',
            [
                'label'       => __( 'Button Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition'   => [
                    'social_list_1_btn_type' => 'image',
                ],
            ]
        );

        // link
        $repeater->add_control(
            'social_list_1_link',
            [
                'label'       => __( 'Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'label_block' => true,
                'default'     => [
                    'url' => '#',
                ],
                'placeholder' => __( 'https://your-link.com', 'telnet-core' ),
            ]
        );

        $this->add_control(
            'social_list_1_lists',
            [
                'label'       => __( 'Social lists', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
            ]
        );

        // social heading
        $this->add_control(
            'social_heading',
            [
                'label'       => __( 'SOCIAL HEADING', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block'    => false,
            ]
        );

        $repeater = new Repeater();

        // details icon
        $repeater->add_control(
            'social_list_2_btn_type',
            [
                'label'          => __( 'Button Icon', 'telnet-core' ),
                'type'           => Controls_Manager::CHOOSE,
                'label_block'    => false,
                'options'        => [
                    'icon'  => [
                        'title' => __( 'Icon', 'telnet-core' ),
                        'icon'  => 'far fa-smile',
                    ],
                    'image' => [
                        'title' => __( 'Image', 'telnet-core' ),
                        'icon'  => 'fa fa-image',
                    ],
                ],
                'default'        => 'icon',
                'toggle'         => false,
                'style_transfer' => true,
            ]
        );

        // list icon
        $repeater->add_control(
            'social_list_2_icon',
            [
                'label'       => __( 'Button Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'default'     => [
                    'value'   => 'fas fa-arrow-right',
                    'library' => 'solid',
                ],
                'label_block' => true,
                'condition'   => [
                    'social_list_2_btn_type' => 'icon',
                ],
            ]
        );

        // list image
        $repeater->add_control(
            'social_list_2_image',
            [
                'label'       => __( 'Button Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition'   => [
                    'social_list_2_btn_type' => 'image',
                ],
            ]
        );

        // link
        $repeater->add_control(
            'social_list_2_link',
            [
                'label'       => __( 'Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'label_block' => true,
                'default'     => [
                    'url' => '#',
                ],
                'placeholder' => __( 'https://your-link.com', 'telnet-core' ),
            ]
        );

        $this->add_control(
            'social_list_2_lists',
            [
                'label'       => __( 'Social lists', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_slides',
            [
                'label' => __( 'SLIDE ITEMS', 'telnet-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        // bg image
        $this->add_control(
            'bg_image',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Bg Image', 'telnet-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'design_style' => ['style_2', 'style_3'],
                ],
            ]
        );


        $repeater = new Repeater();

        $repeater->add_control(
            'option_style',
            [
                'label' => __('CHOOSE STYLE', 'telnet-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __('Style 1', 'telnet-core'),
                    'style_2' => __('Style 2', 'telnet-core'),
                    'style_3' => __('Style 3', 'telnet-core'),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        // BIG IMAGE
        $repeater->add_control(
            'big_image',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Big Image', 'telnet-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        // SHAPE IMAGE
        $repeater->add_control(
            'shape_image',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Pattern Image', 'telnet-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'option_style' => ['style_1', 'style_3'],
                ],
            ]
        );

        // SHAPE IMAGE
        $repeater->add_control(
            'shape_image_2',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Pattern Image', 'telnet-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'option_style' => ['style_3'],
                ],
            ]
        );

        // SUBTITLE
        $repeater->add_control(
            'subtitle',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'show_label' => true,
                'label' => __( 'Sub Title', 'telnet-core' ),
                'default' => __( 'Subtitle', 'telnet-core' ),
                'placeholder' => __( 'Type subtitle here', 'telnet-core' ),
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        // TITLE
        $repeater->add_control(
            'title',
            [
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'label' => __( 'Title', 'telnet-core' ),
                'default' => __( 'Title Here', 'telnet-core' ),
                'placeholder' => __( 'Type title here', 'telnet-core' ),
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        // video bg image
        $repeater->add_control(
            'video_bg',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Video IMage', 'telnet-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'option_style' => ['style_3'],
                ],
            ]
        );

        // video link
        $repeater->add_control(
            'video_link',
            [
                'label'       => __( 'Video Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'placeholder' => __( 'https://www.youtube.com/embed/4xe72U7mXNg?rel=0&controls=0&showinfo=0', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
                'default' => [
					'url' => 'https://www.youtube.com/embed/4xe72U7mXNg?rel=0&controls=0&showinfo=0',
					'is_external' => true,
					'nofollow' => true,
				],
                'description' => __( 'Enter only Embed video link here.', 'telnet-core' ),
            ]
        );

        // CERCLE BOX TEXT
        $repeater->add_control(
            'cercle_box_text',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'label' => __( 'Cercle Box Text', 'telnet-core' ),
                'default' => __( 'Super Sale', 'telnet-core' ),
                'placeholder' => __( 'Type cercle box text here', 'telnet-core' ),
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'option_style' => ['style_1'],
                ],
            ]
        );

        // CURRENCY SYMBOL
        $repeater->add_control(
            'currency',
            [
                'label' => __('Currency', 'telnet-core'),
                'type' => Controls_Manager::SELECT,
                'label_block' => false,
                'options' => [
                    '' => __('None', 'telnet-core'),
                    'baht' => '&#3647; ' . _x('Baht', 'Currency Symbol', 'telnet-core'),
                    'bdt' => '&#2547; ' . _x('BD Taka', 'Currency Symbol', 'telnet-core'),
                    'dollar' => '&#36; ' . _x('Dollar', 'Currency Symbol', 'telnet-core'),
                    'euro' => '&#128; ' . _x('Euro', 'Currency Symbol', 'telnet-core'),
                    'franc' => '&#8355; ' . _x('Franc', 'Currency Symbol', 'telnet-core'),
                    'guilder' => '&fnof; ' . _x('Guilder', 'Currency Symbol', 'telnet-core'),
                    'krona' => 'kr ' . _x('Krona', 'Currency Symbol', 'telnet-core'),
                    'lira' => '&#8356; ' . _x('Lira', 'Currency Symbol', 'telnet-core'),
                    'peseta' => '&#8359 ' . _x('Peseta', 'Currency Symbol', 'telnet-core'),
                    'peso' => '&#8369; ' . _x('Peso', 'Currency Symbol', 'telnet-core'),
                    'pound' => '&#163; ' . _x('Pound Sterling', 'Currency Symbol', 'telnet-core'),
                    'real' => 'R$ ' . _x('Real', 'Currency Symbol', 'telnet-core'),
                    'ruble' => '&#8381; ' . _x('Ruble', 'Currency Symbol', 'telnet-core'),
                    'rupee' => '&#8360; ' . _x('Rupee', 'Currency Symbol', 'telnet-core'),
                    'indian_rupee' => '&#8377; ' . _x('Rupee (Indian)', 'Currency Symbol', 'telnet-core'),
                    'shekel' => '&#8362; ' . _x('Shekel', 'Currency Symbol', 'telnet-core'),
                    'won' => '&#8361; ' . _x('Won', 'Currency Symbol', 'telnet-core'),
                    'yen' => '&#165; ' . _x('Yen/Yuan', 'Currency Symbol', 'telnet-core'),
                    'custom' => __('Custom', 'telnet-core'),
                ],
                'default' => 'dollar',
            ]
        );

        $repeater->add_control(
            'currency_custom',
            [
                'label' => __('Custom Symbol', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'condition' => [
                    'currency' => 'custom',
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        // PRICE
        $repeater->add_control(
            'price',
            [
                'label' => __('Price', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '9.99',
                'dynamic' => [
                    'active' => true
                ]
            ]
        );

        // PERIOD
        $repeater->add_control(
            'period',
            [
                'label' => __('Period', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Per Month', 'telnet-core'),
                'dynamic' => [
                    'active' => true
                ],
            ]
        );

        // PCACKAGE FEATURE
        $repeater->add_control(
            'package_feature',
            [
                'label' => __('Package Feature Text', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Ultra Fast inernet', 'telnet-core'),
                'dynamic' => [
                    'active' => true
                ],
            ]
        );

        // Show package feature
        $repeater->add_control(
            'show_package_feature',
            [
                'label' => __('Show Package Feature', 'telnet-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'telnet-core'),
                'label_off' => __('Hide', 'telnet-core'),
                'return_value' => 'yes',
                'default' => 'no',
                'condition' => [
                    'option_style' => ['style_1'],
                ],
            ]
        );

        // PCACKAGE FEATURES
        $repeater->add_control(
            'package_features',
            [
                'label' => __('Package Features', 'telnet-core'),
                'type' => Controls_Manager::REPEATER,
                'condition' => [
                    'option_style' => ['style_1'],
                    'show_package_feature' => 'yes',
                ],
                'fields' => [

                    // package_icon
                    [
                        'name' => 'package_icon',
                        'label' => __('Package Icon', 'telnet-core'),
                        'type' => Controls_Manager::ICONS,
                        'default' => [
                            'value' => 'fas fa-check',
                            'library' => 'fa-solid',
                        ],
                    ],

                    // package feature
                    [
                        'name' => 'package_feature',
                        'label' => __('Package Feature Text', 'telnet-core'),
                        'type' => Controls_Manager::TEXT,
                        'default' => __('Ultra Fast inernet', 'telnet-core'),
                        'label_block' => true,
                    ],
                ],
                'default' => [
                    [
                        'package_feature' => __('Ultra Fast inernet', 'telnet-core'),
                    ],
                    [
                        'package_feature' => __('Ultra Fast inernet', 'telnet-core'),
                    ],
                ],
                'title_field' => '{{{ package_feature }}}',
            ],

        );


        // BUTTON TEXT
        $repeater->add_control(
            'button_text',
            [
                'label'       => __( 'Text', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Button Text', 'telnet-core' ),
                'placeholder' => __( 'Type button text here', 'telnet-core' ),
                'label_block' => true,
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );

        // BUTTON LINK
        $repeater->add_control(
            'button_link',
            [
                'label'       => __( 'Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'placeholder' => __( 'http://elementor.themexriver.com', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
                'default' => [
					'url' => 'http://elementor.themexriver.com',
					'is_external' => true,
					'nofollow' => true,
				],
            ]
        );

        // details icon
        $repeater->add_control(
            'btn_type',
            [
                'label'          => __( 'Button Icon', 'telnet-core' ),
                'type'           => Controls_Manager::CHOOSE,
                'label_block'    => false,
                'options'        => [
                    'icon'  => [
                        'title' => __( 'Icon', 'telnet-core' ),
                        'icon'  => 'far fa-smile',
                    ],
                    'image' => [
                        'title' => __( 'Image', 'telnet-core' ),
                        'icon'  => 'fa fa-image',
                    ],
                ],
                'default'        => 'icon',
                'toggle'         => false,
                'style_transfer' => true,
                'condition' => [
                    'option_style' => ['style_3'],
                ],
            ]
        );

        // list icon
        $repeater->add_control(
            'btn_icon',
            [
                'label'       => __( 'Button Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'default'     => [
                    'value'   => 'fas fa-arrow-right',
                    'library' => 'solid',
                ],
                'label_block' => true,
                'condition'   => [
                    'btn_type' => 'icon',
                    'option_style' => ['style_3'],
                ],
            ]
        );

        // list image
        $repeater->add_control(
            'btn_image',
            [
                'label'       => __( 'Button Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition'   => [
                    'btn_type' => 'image',
                    'option_style' => ['style_3'],
                ],
            ]
        );

        // CALL INFO ICON
        if ( elh_element_is_elementor_version( '<', '2.6.0' ) ) {
            $repeater->add_control(
                'call_info_icon',
                [
                    'label' => __( 'Call Info Icon', 'telnet-core' ),
                    'label_block' => true,
                    'type' => Controls_Manager::ICON,
                    'options' => elh_element_get_elh_element_icons(),
                    'default' => 'fal fa-long-arrow-right',
                    'condition' => [
                        'option_style' => ['style_1'],
                    ],
                ]
            );
        }
        else {
            $repeater->add_control(
                'selected_call_info_icon',
                [
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'fal fa-long-arrow-right',
                        'library' => 'fa-solid',
                    ],
                    'condition' => [
                        'option_style' => ['style_1'],
                    ],
                ]
            );
        }

        // CALL INFO TEXT
        $repeater->add_control(
            'call_info_text',
            [
                'label' => __( 'Call Info Text', 'telnet-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'Call Info Text', 'telnet-core' ),
                'placeholder' => __( 'Type call info text here', 'telnet-core' ),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'option_style' => ['style_1'],
                ],
            ]
        );

        // NUMBER
        $repeater->add_control(
            'number',
            [
                'label' => __( 'Number', 'telnet-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( '123456789', 'telnet-core' ),
                'placeholder' => __( 'Type number here', 'telnet-core' ),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'option_style' => ['style_1'],
                ],
            ]
        );

        // NUMBER LINK
        $repeater->add_control(
            'number_link',
            [
                'label' => __( 'Number Link', 'telnet-core' ),
                'type' => Controls_Manager::URL,
                'placeholder' => __( 'http://elementor.themexriver.com', 'telnet-core' ),
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'option_style' => ['style_1'],
                ],
            ]
        );

        // ALL REPEATER FIELDS END

        // ALL SLIDES
        $this->add_control(
            'slides',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '<# print(title || "Carousel Item"); #>',
                'default' => [
                    [
                        'image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                ]
            ]
        );

        // IMAGE SIZE
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail',
                'default' => 'full',
                'separator' => 'before',
                'exclude' => [
                    'custom'
                ]
            ]
        );

        $this->end_controls_section();

        // SETTINGS SECTION
        $this->start_controls_section(
            '_section_settings',
            [
                'label' => __( 'SETTINGS', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // TITLE ON/OFF
        $this->add_control(
            'title_on_off',
            [
                'label' => __( 'Title On/Off', 'telnet-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __( 'On', 'telnet-core' ),
                'label_off' => __( 'Off', 'telnet-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        // SUBTITLE ON/OFF
        $this->add_control(
            'subtitle_on_off',
            [
                'label' => __( 'Sub Title On/Off', 'telnet-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __( 'On', 'telnet-core' ),
                'label_off' => __( 'Off', 'telnet-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        // CERCLE BOX ON/OFF
        $this->add_control(
            'cercle_box_on_off',
            [
                'label' => __( 'Cercle Box On/Off', 'telnet-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __( 'On', 'telnet-core' ),
                'label_off' => __( 'Off', 'telnet-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        // PRICE ON/OFF
        $this->add_control(
            'price_on_off',
            [
                'label' => __( 'Price On/Off', 'telnet-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __( 'On', 'telnet-core' ),
                'label_off' => __( 'Off', 'telnet-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        // BUTTON ON/OFF
        $this->add_control(
            'button_on_off',
            [
                'label' => __( 'Button On/Off', 'telnet-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __( 'On', 'telnet-core' ),
                'label_off' => __( 'Off', 'telnet-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        // CALL INFO ON/OFF
        $this->add_control(
            'call_info_on_off',
            [
                'label' => __( 'Call Info On/Off', 'telnet-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __( 'On', 'telnet-core' ),
                'label_off' => __( 'Off', 'telnet-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        // SLIDER NAVIGATION ON/OFF
        $this->add_control(
            'slider_navigation_on_off',
            [
                'label' => __( 'Slider Navigation On/Off', 'telnet-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __( 'On', 'telnet-core' ),
                'label_off' => __( 'Off', 'telnet-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        // SLIDER DOT ON/OFF
        $this->add_control(
            'slider_dot_on_off',
            [
                'label' => __( 'Slider Dot On/Off', 'telnet-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __( 'On', 'telnet-core' ),
                'label_off' => __( 'Off', 'telnet-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        // PACKAGE FEATUREs ON/OFF
        $this->add_control(
            'feature_package_on_off',
            [
                'label' => __( 'Feature Package On/Off', 'telnet-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __( 'On', 'telnet-core' ),
                'label_off' => __( 'Off', 'telnet-core' ),
                'return_value' => 'yes',
            ]
        );

        $this->end_controls_section();

    }

    protected function register_style_controls() {
        $dir = dirname( __FILE__ );

        include $dir . '/styles/slide-style.php';
        include $dir . '/styles/sub-title-style.php';
        include $dir . '/styles/title-style.php';
        include $dir . '/styles/description-style.php';
        include $dir . '/styles/cercle-box-style.php';
        include $dir . '/styles/price-style.php';
        include $dir . '/styles/button-style.php';

    }

    private static function get_currency_symbol($symbol_name)
    {
        $symbols = [
            'baht' => '&#3647;',
            'bdt' => '&#2547;',
            'dollar' => '&#36;',
            'euro' => '&#128;',
            'franc' => '&#8355;',
            'guilder' => '&fnof;',
            'indian_rupee' => '&#8377;',
            'pound' => '&#163;',
            'peso' => '&#8369;',
            'peseta' => '&#8359',
            'lira' => '&#8356;',
            'ruble' => '&#8381;',
            'shekel' => '&#8362;',
            'rupee' => '&#8360;',
            'real' => 'R$',
            'krona' => 'kr',
            'won' => '&#8361;',
            'yen' => '&#165;',
        ];

        return isset($symbols[$symbol_name]) ? $symbols[$symbol_name] : '';
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $dir = dirname(__FILE__);

        if ( empty( $settings['slides'] ) ) {
            return;
        }

        if (!empty($settings['design_style']) && $settings['design_style'] == 'style_3') :
            include $dir . '/views/view-3.php';

        elseif (!empty($settings['design_style']) && $settings['design_style'] == 'style_2') :
            include $dir . '/views/view-2.php';
        else :
            include $dir . '/views/view-1.php';
        endif;
    }
}