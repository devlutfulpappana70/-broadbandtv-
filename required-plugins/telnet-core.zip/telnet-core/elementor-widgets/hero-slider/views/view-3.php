<?php
use \Elementor\Group_Control_Image_Size;
?>

<section id="tel-slider" class="tel-slider-section position-relative" data-background="<?php echo $settings['bg_image']['url'] ? esc_url($settings['bg_image']['url']) : ''; ?>">
    <div class="tel-slider-side d-flex align-items-center position-absolute justify-content-center">
        <?php if(!empty( $settings['social_list_1_lists'] )) : ?>
        <div class="side-social">
            <?php foreach($settings['social_list_1_lists'] as $list ) : ?>
            <a href="<?php echo esc_url($list['social_list_1_link']['url']); ?>">
                <?php
                    if ($list['social_list_1_btn_type'] === 'image' && ($list['social_list_1_image']['url'] || $list['social_list_1_image']['id'])) {
                        $this->get_render_attribute_string('social_list_1_image');
                        $list['hover_animation'] = 'disable-animation';
                        echo Group_Control_Image_Size::get_attachment_image_html($list, 'thumbnail', 'social_list_1_image');
                    } elseif (!empty($list['social_list_1_icon'])) {
                        elh_element_render_icon($list, '', 'social_list_1_icon');
                    }
                ?>
            </a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <?php if(!empty( $settings['social_heading'] )) : ?>
        <div class="side-inner-text text-uppercase">
            <?php echo elh_element_kses_intermediate($settings['social_heading']); ?>
        </div>
        <?php endif; ?>
        <?php if(!empty( $settings['social_list_2_lists'] )) : ?>
        <div class="side-cta">
            <?php foreach($settings['social_list_2_lists'] as $list ) : ?>
            <a href="<?php echo esc_url($list['social_list_2_link']['url']); ?>"
            target="<?php echo esc_attr($list['social_list_2_link']['is_external'] ? '_blank' : '_self'); ?>"
            rel="<?php echo esc_attr($list['social_list_2_link']['nofollow'] ? 'nofollow' : ''); ?>">
                <?php
                    if ($list['social_list_2_btn_type'] === 'image' && ($list['social_list_2_image']['url'] || $list['social_list_2_image']['id'])) {
                        $this->get_render_attribute_string('social_list_2_image');
                        $list['hover_animation'] = 'disable-animation';
                        echo Group_Control_Image_Size::get_attachment_image_html($list, 'thumbnail', 'social_list_2_image');
                    } elseif (!empty($list['social_list_2_icon'])) {
                        elh_element_render_icon($list, '', 'social_list_2_icon');
                    }
                ?>
            </a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
    <div class="tel-main-slider-area swiper-container">
        <div class="swiper-wrapper">
            <?php foreach ( $settings['slides'] as $key => $slide ) :

                if ($slide['currency'] === 'custom') {
                    $currency = $slide['currency_custom'];
                } else {
                    $currency = self::get_currency_symbol($slide['currency']);
                }
            ?>
            <div class="swiper-slide">
                <div class="tel-main-slider-item position-relative">
                    <?php if(!empty( $slide['shape_image']['url'] )) : ?>
                    <span class="slider-side-img1 position-absolute"><img src="<?php echo esc_url($slide['shape_image']['url']); ?>" alt=""></span>
                    <?php endif; ?>

                    <?php if(!empty( $slide['shape_image_2']['url'] )) : ?>
                    <span class="slider-side-img2 position-absolute"><img src="<?php echo esc_url($slide['shape_image_2']['url']); ?>" alt=""></span>
                    <?php endif; ?>

                    <div class="container">
                        <div class="tel-main-slider-text-img position-relative">
                            <div class="tel-main-slider-text">
                                <?php if(!empty( $slide['title'] )) : ?>
                                <h1>
                                    <?php echo elh_element_kses_intermediate($slide['title']); ?>
                                </h1>
                                <?php endif; ?>
                                <div class="tel-slider-video-area d-flex align-items-center">
                                    <div class="tel-slide-video-btn d-flex align-items-center justify-content-center" data-background="<?php echo $slide['video_bg']['url'] ? esc_url($slide['video_bg']['url']) : ''; ?>">
                                        <?php if(!empty( $slide['video_link']['url'] )) : ?>
                                        <a class="d-flex video_box justify-content-center align-items-center" href="<?php echo esc_url($slide['video_link']['url']); ?>" data-rel="ligthcase">
                                            <i class="fas fa-play"></i>
                                        </a>
                                        <?php endif; ?>
                                    </div>
                                    <?php if(!empty( $slide['subtitle'] )) : ?>
                                    <h2><?php echo elh_element_kses_intermediate($slide['subtitle']); ?></h2>
                                    <?php endif; ?>
                                </div>
                                <div class="slider-pricing-btn-area d-flex align-items-center">
                                    <?php if(!empty( $currency || $slide['price'] || $slide['period'] || $slide['package_feature'] )) : ?>
                                    <div class="slider-pricing headline text-uppercase pera-content">
                                        <h3>
                                            <?php if(!empty( $currency )) : ?>
                                            <sup><?php echo esc_html($currency); ?></sup>
                                            <?php endif; ?>

                                            <?php echo $slide['price'] ? esc_html($slide['price']) : ''; ?>

                                            <?php if(!empty( $slide['period'] )) : ?>
                                            <sub><?php echo esc_html($slide['period']); ?></sub>
                                            <?php endif; ?>
                                        </h3>

                                        <?php if(!empty( $slide['package_feature'] )) : ?>
                                        <p><?php echo esc_html($slide['package_feature']); ?></p>
                                        <?php endif; ?>
                                    </div>
                                    <?php endif; ?>

                                    <?php if(!empty( $slide['button_text'] )) : ?>
                                    <div class="tel-btn-1 text-uppercase">
                                        <a
                                        href="<?php echo esc_url($slide['button_link']['url']); ?>"
                                        target="<?php echo esc_attr($slide['button_link']['is_external'] ? '_blank' : '_self'); ?>"
                                        rel="<?php echo esc_attr($slide['button_link']['nofollow'] ? 'nofollow' : ''); ?>"
                                        >
                                            <?php echo esc_html($slide['button_text']); ?>

                                            <?php
                                                if ($slide['btn_type'] === 'image' && ($slide['btn_image']['url'] || $slide['btn_image']['id'])) {
                                                    $this->get_render_attribute_string('btn_image');
                                                    $slide['hover_animation'] = 'disable-animation';
                                                    echo Group_Control_Image_Size::get_attachment_image_html($slide, 'thumbnail', 'btn_image');
                                                } elseif (!empty($slide['btn_icon'])) {
                                                    elh_element_render_icon($slide, '', 'btn_icon');
                                                }
                                            ?>
                                        </a>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php if(!empty( $slide['big_image']['url'] )) : ?>
                            <div class="tel-main-slider-img position-absolute">
                                <img src="<?php echo esc_url($slide['big_image']['url']); ?>" alt="">
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="swiper-pagination text-center"></div>
    </div>
</section>