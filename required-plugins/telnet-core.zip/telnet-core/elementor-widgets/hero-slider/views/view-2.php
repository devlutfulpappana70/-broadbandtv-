<section class="tx-hero-slider tx-hero-slider__styleOne tx-hero-slider__styleTwo pt-75 pb-75" data-background="<?php echo $settings['bg_image']['url'] ? esc_url($settings['bg_image']['url']) : ''; ?>">
    <div class="swiper-container" data-txHeroSlider>
        <div class="swiper-wrapper">
            <?php foreach ( $settings['slides'] as $key => $slide ) :
                if (!empty($slide['big_image']['id'])) {
                    $big_image = wp_get_attachment_image_url($slide['big_image']['id'], $settings['thumbnail_size']);
                }
                if (!empty($slide['shape_image']['id'])) {
                    $shape_image = wp_get_attachment_image_url($slide['shape_image']['id'], $settings['thumbnail_size']);
                }

                if ($slide['currency'] === 'custom') {
                    $currency = $slide['currency_custom'];
                } else {
                    $currency = self::get_currency_symbol($slide['currency']);
                }
            ?>
            <div class="swiper-slide tx-slideItem">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="tx-sliderContent position-relative tx-z1 pt-190 pl-100 pr-100" data-background="<?php echo $big_image ? esc_url($big_image) : ''; ?>">

                                <?php if(!empty( $shape_image )) : ?>
                                <div class="tx-pattern position-absolute">
                                    <img class="w-100" src="<?php echo esc_url($shape_image); ?>" alt="">
                                </div>
                                <?php endif; ?>

                                <?php if(!empty( $slide['subtitle'] )) : ?>
                                <h6 class="tx-subHeading tx-uppercase"><?php echo elh_element_kses_intermediate($slide['subtitle']); ?></h6>
                                <?php endif; ?>

                                <?php if(!empty( $slide['title'] )) : ?>
                                <h2 class="tx-heading mt-15">
                                    <?php echo elh_element_kses_intermediate($slide['title']); ?>
                                </h2>
                                <?php endif; ?>

                                <div class="tx-bottomWrapper mt-30">
                                    <?php if(!empty( $slide['button_link']['url'] || $slide['button_text'] )) : ?>
                                    <a href="<?php echo esc_html($slide['button_link']['url']); ?>"
                                    target="<?php echo esc_attr($slide['button_link']['is_external'] ? '_blank' : '_self'); ?>"
                                    rel="<?php echo esc_attr($slide['button_link']['nofollow'] ? 'nofollow' : ''); ?>"
                                     class="tx-button tx-button__styleTheme">
                                        <?php echo esc_html($slide['button_text']); ?>
                                    </a>
                                    <?php endif; ?>

                                    <?php if(!empty( $currency || $slide['price'] || $slide['period'] || $slide['package_feature'] )) : ?>
                                    <div class="tx-price">
                                        <?php if(!empty( $currency )) : ?>
                                        <sub class="tx-price__currency tx-fwLight"><?php echo esc_html($currency); ?></sub>
                                        <?php endif; ?>

                                        <?php if(!empty( $slide['price'] )) : ?>
                                        <span class="tx-price__price">
                                            <?php echo esc_html($slide['price']); ?>
                                        </span>
                                        <?php endif; ?>

                                        <?php if(!empty( $slide['period'] )) : ?>
                                        <sub class="tx-price__period tx-fwLight"><?php echo esc_html($slide['period']); ?></sub>
                                        <?php endif; ?>

                                        <?php if(!empty( $slide['package_feature'] )) : ?>
                                        <span class="tx-price__package d-block"><?php echo esc_html($slide['package_feature']); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- slider pagination -->
        <div class="swiper-pagination tx-slidePagination tx-slidePagination__styleMiddle"></div>

        <!-- slider navigation -->
        <div class="tx-slideNav tx-slideNav__styleMiddle tx-slideNav__styleLight">
            <div class="swiper-button-prev">
                <i class="fa-regular fa-arrow-left-long"></i>
            </div>
            <div class="swiper-button-next">
                <i class="fa-regular fa-arrow-right-long"></i>
            </div>
        </div>
    </div>

</section>