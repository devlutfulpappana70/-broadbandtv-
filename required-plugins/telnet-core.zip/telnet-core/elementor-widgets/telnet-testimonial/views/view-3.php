<?php
    use \Elementor\Group_Control_Image_Size;
?>
<div class="tx-testimonialWrapper">
    <div class="row tx-column-gap-30">
        <?php
            foreach($settings['testimonial_lists'] as $testimonial_list) :

                // choose columns
                $col = 'col-xl-4 col-lg-4 col-md-6 col-sm-6 mt-30';
                if( $testimonial_list['columns'] == 'column_1' ) {
                    $col = 'col-xl-12 mt-30';
                } elseif( $testimonial_list['columns'] == 'column_2' ) {
                    $col = 'col-xl-6 col-lg-6 col-md-6 col-sm-6 mt-30';
                } elseif( $testimonial_list['columns'] == 'column_3' ) {
                    $col = 'col-xl-3 col-lg-3 col-md-6 col-sm-6 mt-30';
                } else {
                    $col = 'col-xl-4 col-lg-4 col-md-6 col-sm-6 mt-30';
                }
        ?>
        <div class="<?php echo esc_attr($col); ?>">
            <div class="tx-testimonial tx-testimonial__styleThree">
                <div class="tx-wrapper">
                    <div class="tx-content">
                        <div class="tx-comment">
                            <div class="tx-icon">
                                <?php
                                    if ($testimonial_list['type'] === 'image' && ($testimonial_list['quote_image']['url'] || $testimonial_list['quote_image']['id'])) {
                                        $this->get_render_attribute_string('quote_image');
                                        $testimonial_list['hover_animation'] = 'disable-animation';
                                        echo Group_Control_Image_Size::get_attachment_image_html($testimonial_list, 'thumbnail', 'quote_image');
                                    } elseif (!empty($testimonial_list['quote_icon'])) {
                                        elh_element_render_icon($testimonial_list, '', 'quote_icon');
                                    }
                                ?>
                            </div>
                            <?php if(!empty( $testimonial_list['comment'] )) : ?>
                            <p class="mt-25"><?php echo esc_html($testimonial_list['comment']); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="txBottomWrapper d-flex align-items-center mt-20">
                            <?php if(!empty( $testimonial_list['image']['url'] )) : ?>
                            <div class="tx-thumb tx-radious-50">
                                <img src="<?php echo esc_url($testimonial_list['image']['url']); ?>" alt="">
                            </div>
                            <?php endif; ?>

                            <div class="tx-nameDesignation">
                                <?php if(!empty( $testimonial_list['name'] )) : ?>
                                <h5 class="tx-name">
                                    <?php echo esc_html($testimonial_list['name']); ?>
                                </h5>
                                <?php endif; ?>

                                <?php if(!empty( $testimonial_list['designation'] )) : ?>
                                <span class="tx-designation"><?php echo esc_html($testimonial_list['designation']); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
