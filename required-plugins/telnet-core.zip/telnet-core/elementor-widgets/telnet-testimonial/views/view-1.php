<?php
use \Elementor\Group_Control_Image_Size;
?>
<div class="tx-testimonialWrapper swiper-container" data-txTestimonialOne>
    <div class="swiper-wrapper">
        <?php foreach($settings['testimonial_lists'] as $testimonial_list) : ?>
        <div class="swiper-slide">
            <div class="tx-testimonial tx-testimonial__styleOne">
                <div class="tx-wrapper">
                    <?php if(!empty( $testimonial_list['image']['url'] )) : ?>
                    <div class="tx-thumb">
                        <img class="tx-radious-60" src="<?php echo esc_url($testimonial_list['image']['url']); ?>" alt="">
                    </div>
                    <?php endif; ?>
                    <div class="tx-content pl-80">
                        <div class="tx-comment">
                            <?php if(!empty( $testimonial_list['comment'] )) : ?>
                            <p><?php echo esc_html($testimonial_list['comment']); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="mt-35">
                            <?php if(!empty( $testimonial_list['name'] )) : ?>
                            <h5 class="tx-name">
                                <?php echo esc_html($testimonial_list['name']); ?>
                            </h5>
                            <?php endif; ?>

                            <?php if(!empty( $testimonial_list['designation'] )) : ?>
                            <span class="tx-designation"><?php echo esc_html($testimonial_list['designation']); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <div class="txNavPagi-wrapper justify-content-between d-flex align-items-center ml-55">
        <div class="tx-testimonialNextPrev" data-txTestimonialNext><i class="far fa-long-arrow-left"></i></div>
        <div class="tx-testimonialPagination" data-txTestimonialPagination></div>
        <div class="tx-testimonialNextPrev" data-txTestimonialPrev><i class="far fa-long-arrow-right"></i></div>
    </div>
</div>
