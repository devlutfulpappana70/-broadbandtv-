<div class="tel-testimonials-slider-wrapper-2 position-relative">
    <?php if(!empty($settings['shape']['url'])):?>
        <span class="tel-testi-floating-img1 position-absolute"><img src="<?php echo esc_url($settings['shape']['url']);?>" alt=""></span>
    <?php endif;?>
    <?php if(!empty($settings['shape2']['url'])):?>
    <span class="tel-testi-floating-img2 position-absolute"><img src="<?php echo esc_url($settings['shape2']['url']);?>" alt=""></span>
    <?php endif;?>
    <?php if(!empty($settings['shape3']['url'])):?>
        <span class="tel-testi-floating-img3 position-absolute"><img src="<?php echo esc_url($settings['shape3']['url']);?>" alt=""></span>
    <?php endif;?>

    <?php if(!empty($settings['shape4']['url'])):?>
        <span class="tel-testi-floating-img4 position-absolute"><img src="<?php echo esc_url($settings['shape4']['url']);?>" alt=""></span>
    <?php endif;?>

    <div class="tel-testimonials-slider-2 swiper-container">
        <div class="swiper-wrapper">
        <?php foreach($settings['testimonial_lists'] as $testimonial_list) : ?>
            <div class="swiper-slide">
                <div class="tel-testimonial-item-2">
                    <div class="testimonial-img">
                        <img src="<?php echo esc_url($testimonial_list['image']['url']); ?>" alt="">
                    </div>
                    <div class="testimonial-text  text-center">
                        <?php echo esc_html($testimonial_list['comment']); ?>
                    </div>
                    <div class="testimonial-author d-flex align-items-center justify-content-center">
                        <div class="author-img">
                            <img src="<?php echo esc_url($testimonial_list['image']['url']); ?>" alt="">
                        </div>
                        <div class="author-text">
                            <h4><?php echo esc_html($testimonial_list['name']); ?></h4>
                            <span><?php echo esc_html($testimonial_list['designation']); ?></span>
                        </div>
                    </div>
                </div>
            </div> 
            <?php endforeach; ?>
        </div>
        <div class="swiper-test-pagination text-center"></div>
    </div>
</div>