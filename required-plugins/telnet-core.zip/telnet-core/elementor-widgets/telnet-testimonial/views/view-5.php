<div class="tel-testimonials-slider-3 position-relative swiper-container">
    <div class="swiper-wrapper">
        <?php foreach($settings['testimonial_lists'] as $testimonial_list) : ?>
        <div class="swiper-slide">
            <div class="tel-testimonials-item-3 d-flex ">
                <div class="testimonial-img">
                    <img src="<?php echo esc_url($testimonial_list['image']['url']); ?>" alt="">
                </div>
                <div class="testimonial-text">
                    <?php if(!empty($testimonial_list['quote_image']['url'])):?>
                        <div class="qoute-icon">
                            <img src="<?php echo esc_url($testimonial_list['quote_image']['url']);?>" alt="">
                        </div>
                    <?php endif;?>

                    <?php if(!empty($testimonial_list['short_info'])):?>
                        <h3><?php echo wp_kses($testimonial_list['short_info'], true);?></h3>
                    <?php endif;?>

                    <p><?php echo esc_html($testimonial_list['comment']); ?></p>
                    <div class="testimonial-author">
                        <h4><?php echo esc_html($testimonial_list['name']); ?></h4>
                        <span><?php echo esc_html($testimonial_list['designation']); ?></span>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <div class="tel-carousel-next-prev-area position-absolute d-flex align-items-center justify-content-center">
        <div class="carousel-next-prev d-flex justify-content-center align-items-center testi-carousel-prev"><i class="fas fa-long-arrow-left"></i></div>
        <div class="carousel-next-prev d-flex justify-content-center align-items-center testi-carousel-next"><i class="fas fa-long-arrow-right"></i></div>
    </div>
</div>