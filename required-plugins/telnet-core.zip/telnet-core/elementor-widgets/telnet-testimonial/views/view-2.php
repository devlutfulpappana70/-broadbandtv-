<div class="tx-testimonialWrapper swiper-container" data-txTestimonialTwo>
    <div class="swiper-wrapper">
        <?php foreach($settings['testimonial_lists'] as $testimonial_list) : ?>
        <div class="swiper-slide">
            <div class="tx-testimonial tx-testimonial__styleTwo">
                <div class="tx-wrapper">
                    <?php if(!empty( $testimonial_list['image']['url'] )) : ?>
                    <div class="tx-thumb">
                        <img src="<?php echo esc_url($testimonial_list['image']['url']); ?>" alt="">
                    </div>
                    <?php endif; ?>
                    <div class="tx-content">
                        <div class="tx-comment">
                            <?php if(!empty( $testimonial_list['comment'] )) : ?>
                            <p><?php echo esc_html($testimonial_list['comment']); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="txBottomWrapper d-flex align-items-center mt-25">
                            <?php if(!empty( $testimonial_list['signature_image']['url'] )) : ?>
                            <div class="tx-signature">
                                <img src="<?php echo esc_url($testimonial_list['signature_image']['url']); ?>" alt="">
                            </div>
                            <?php endif; ?>

                            <div class="tx-nameDesignation">
                                <?php if(!empty( $testimonial_list['name'] )) : ?>
                                <h5 class="tx-name">
                                    <?php echo esc_html($testimonial_list['name']); ?>
                                </h5>
                                <?php endif; ?>

                                <?php if(!empty( $testimonial_list['designation'] )) : ?>
                                <span class="tx-designation"><?php echo esc_html($testimonial_list['designation']); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
