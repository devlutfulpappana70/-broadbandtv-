<div class="tna-section-title text-<?php echo $settings['align'] ? esc_attr($settings['align']) : ''; ?>">
    <?php if(!empty( $settings['sub_title'] )) : ?>
    <h4 class="tna-subtitle-1 wow fadeInLeft"><?php echo elh_element_kses_intermediate($settings['sub_title']); ?></h4>
    <?php endif; ?>

    <?php printf('<%1$s %2$s>%3$s</%1$s>',
        tag_escape($settings['title_tag']),
        $this->get_render_attribute_string('title5'),
        $title
    ); ?>

    <?php if(!empty( $settings['description'] )) : ?>
    <p class="tna-para-1 wow fadeInLeft"><?php echo elh_element_kses_intermediate($settings['description']); ?></p>
    <?php endif; ?>
</div>