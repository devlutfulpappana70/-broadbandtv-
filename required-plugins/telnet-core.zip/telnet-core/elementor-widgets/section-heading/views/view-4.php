<div class="tel-section-title telnet-text text-<?php echo $settings['align'] ? esc_attr($settings['align']) : ''; ?>">
<?php if(!empty( $settings['sub_title'] )) : ?>
    <div class="subtitle text-uppercase wow fadeInRight"  data-wow-delay="200ms" data-wow-duration="1000ms">
        <?php if(!empty($settings['sub_icon']['url'])):?>
        <img src="<?php echo esc_url($settings['sub_icon']['url']);?>" alt="">
        <?php endif;?>
        <?php echo elh_element_kses_intermediate($settings['sub_title']); ?>
    </div>
    <?php endif; ?>
    <?php printf('<%1$s %2$s>%3$s</%1$s>',
        tag_escape($settings['title_tag']),
        $this->get_render_attribute_string('title'),
        $title
    ); ?>
    <?php if(!empty($settings['description'])):?>
    <p><?php echo wp_kses($settings['description'], true)?></p>
    <?php endif;?>
</div>