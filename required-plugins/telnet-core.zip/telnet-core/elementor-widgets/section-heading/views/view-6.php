<div class="tel-section-title-4">
    <?php if(!empty( $settings['sub_title'] )) : ?>
    <div class="sub-title text-uppercase position-relative  d-inline-block wow fadeInRight"  data-wow-delay="200ms" data-wow-duration="2000ms">
        <span><?php echo elh_element_kses_intermediate($settings['sub_title']); ?></span>
    </div>
    <?php endif; ?>
    <?php printf('<%1$s %2$s>%3$s</%1$s>',
        tag_escape($settings['title_tag']),
        $this->get_render_attribute_string('title2'),
        $title
    ); ?>
    <?php if(!empty($settings['description'])):?>
    <p><?php echo wp_kses($settings['description'], true)?></p>
    <?php endif;?>
</div>