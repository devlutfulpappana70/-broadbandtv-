<?php
    if($settings['align'] == 'center') {
        $align = 'has-center';
    }
?>
<div class="tna-section-title text-<?php echo esc_attr($settings['align']); ?>">
<?php if(!empty( $settings['sub_title'] )) : ?>
    <h4 class="tna-subtitle-2 has-4 has-center <?php echo esc_attr($align); ?> <?php echo $settings['anim_name'] ? esc_attr($settings['anim_name']) : ''; ?>"
data-wow-delay="<?php echo $settings['anim_delay'] ? esc_attr($settings['anim_delay']) : ''; ?>"
data-wow-duration="<?php echo $settings['anim_duration'] ? esc_attr($settings['anim_duration']) : ''; ?>">
        <?php echo elh_element_kses_intermediate($settings['sub_title']); ?>
    </h4>
    <?php endif; ?>

    <?php printf('<%1$s %2$s>%3$s</%1$s>',
        tag_escape($settings['title_tag']),
        $this->get_render_attribute_string('title7'),
        $title
    ); ?>
    <?php if(!empty( $settings['description'] )) : ?>
    <p class="tna-para-2 wow fadeInUp"><?php echo elh_element_kses_intermediate($settings['description']); ?></p>
    <?php endif; ?>
</div>
