<div class="sec-title-five text-<?php echo $settings['align'] ? esc_attr($settings['align']) : ''; ?>">
    <?php if(!empty( $settings['sub_title'] )) : ?>
    <div class="sec-title-five_title"><?php echo elh_element_kses_intermediate($settings['sub_title']); ?></div>
    <?php endif; ?>

    <?php
        printf('<%1$s %2$s>%3$s</%1$s>',
            tag_escape($settings['title_tag']),
            $this->get_render_attribute_string('title3'),
            $title
        );
    ?>

    <?php if(!empty($settings['description'])) : ?>
    <div class="sec-title-five_text"><?php echo wp_kses($settings['description'], true)?></div>
    <?php endif; ?>
</div>