<div class="tx-sectionHeading tx-sectionHeading__styleRotate text-<?php echo $settings['align'] ? esc_attr($settings['align']) : ''; ?>">
    <?php printf('<%1$s %2$s>%3$s</%1$s>',
        tag_escape($settings['title_tag']),
        $this->get_render_attribute_string('title'),
        $title
    ); ?>
</div>