<?php

namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Background;

defined( 'ABSPATH' ) || die();

class Section_Heading extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name() {
        return 'section_heading';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title() {
        return __( 'Section Heading', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/gradient-heading/';
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-t-letter';
    }

    public function get_keywords() {
        return ['section', 'heading', 'title'];
    }

    public function elh_element_animations() {
        return [
            'none' => __( 'None', 'telnet-core' ),
            'fadeIn' => __( 'Fade In', 'telnet-core' ),
            'fadeInUp' => __( 'Fade In Up', 'telnet-core' ),
            'fadeInDown' => __( 'Fade In Down', 'telnet-core' ),
            'fadeInLeft' => __( 'Fade In Left', 'telnet-core' ),
            'fadeInRight' => __( 'Fade In Right', 'telnet-core' ),
            'fadeInUpBig' => __( 'Fade In Up Big', 'telnet-core' ),
            'fadeInDownBig' => __( 'Fade In Down Big', 'telnet-core' ),
            'fadeInLeftBig' => __( 'Fade In Left Big', 'telnet-core' ),
            'fadeInRightBig' => __( 'Fade In Right Big', 'telnet-core' ),
            'bounceIn' => __( 'Bounce In', 'telnet-core' ),
            'bounceInUp' => __( 'Bounce In Up', 'telnet-core' ),
            'bounceInDown' => __( 'Bounce In Down', 'telnet-core' ),
            'bounceInLeft' => __( 'Bounce In Left', 'telnet-core' ),
            'bounceInRight' => __( 'Bounce In Right', 'telnet-core' ),
            'rotateIn' => __( 'Rotate In', 'telnet-core' ),
            'rotateInUpLeft' => __( 'Rotate In Up Left', 'telnet-core' ),
            'rotateInDownLeft' => __( 'Rotate In Down Left', 'telnet-core' ),
            'rotateInUpRight' => __( 'Rotate In Up Right', 'telnet-core' ),
            'rotateInDownRight' => __( 'Rotate In Down Right', 'telnet-core' ),
            'lightSpeedIn' => __( 'Light Speed In', 'telnet-core' ),
            'rollIn' => __( 'Roll In', 'telnet-core' ),
            'zoomIn' => __( 'Zoom In', 'telnet-core' ),
            'zoomInUp' => __( 'Zoom In Up', 'telnet-core' ),
            'zoomInDown' => __( 'Zoom In Down', 'telnet-core' ),
            'zoomInLeft' => __( 'Zoom In Left', 'telnet-core' ),
            'zoomInRight' => __( 'Zoom In Right', 'telnet-core' ),
            'slideInUp' => __( 'Slide In Up', 'telnet-core' ),
            'slideInDown' => __( 'Slide In Down', 'telnet-core' ),
            'slideInLeft' => __( 'Slide In Left', 'telnet-core' ),
            'slideInRight' => __( 'Slide In Right', 'telnet-core' ),
        ];
    }

    protected function register_content_controls() {

        //Settings
        $this->start_controls_section(
            '_section_settings',
            [
                'label' => __( 'Settings', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'design_style',
            [
                'label'              => __( 'Design Style', 'telnet-core' ),
                'type'               => Controls_Manager::SELECT,
                'options'            => [
                    'style_1' => __( 'Style 1', 'telnet-core' ),
                    'style_2' => __( 'Style 2', 'telnet-core' ),
                    'style_3' => __( 'Style 3', 'telnet-core' ),
                    'style_4' => __( 'Style 4', 'telnet-core' ),
                    'style_5' => __( 'Style 5', 'telnet-core' ),
                    'style_6' => __( 'Style 6', 'telnet-core' ),
                    'style_7' => __( 'Style 7', 'telnet-core' ),
                    'style_8' => __( 'Style 8', 'telnet-core' ),
                    'style_9' => __( 'Style 9', 'telnet-core' ),
                    'style_10' => __( 'Style 10', 'telnet-core' ),
                    'style_11' => __( 'Style 11', 'telnet-core' ),
                ],
                'default'            => 'style_1',
                'frontend_available' => true,
                'style_transfer'     => true,
            ]
        );

         // anim name list for animation
         $this->add_control(
            'anim_name',
            [
                'label'       => __( 'Animation Name', 'telnet-core' ),
                'type'        => Controls_Manager::SELECT,
                'options'     => $this->elh_element_animations(),
                'default'     => 'fadeInUp',
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );

        // anim delay
        $this->add_control(
            'anim_delay',
            [
                'label'       => __( 'Animation Delay', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );

        // anim duration
        $this->add_control(
            'anim_duration',
            [
                'label'       => __( 'Animation Duration', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );

        //

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_title',
            [
                'label' => __( 'Title & Description', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // sub title
        $this->add_control(
            'sub_title',
            [
                'label'       => __( 'Sub Title', 'telnet-core' ),
                'label_block' => true,
                'type'        => Controls_Manager::TEXTAREA,
                'rows'        => 4,
                'default'     => 'Sub Title',
                'placeholder' => __( 'Sub Title Text', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
                'condition'   => [
                    'design_style' => [
                        'style_1',
                        'style_4',
                        'style_5',
                        'style_6',
                        'style_7',
                        'style_9',
                        'style_10',
                        'style_11'
                    ],
                ],
            ]
        );
        $this->add_control(
            'sub_icon',
            [
                'label'       => __( 'Sub Icon', 'telnet-core' ),
                'label_block' => true,
                'type'        => Controls_Manager::MEDIA,
                'condition'   => [
                    'design_style' => ['style_4'],
                ],
            ]
        );
        $this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'check-thumb-shape',
				'types' => [ 'classic' ],
				'exclude' => [ 'color' ],
				'selector' => '{{WRAPPER}} .tel-section-title-4 .sub-title:before',
                'fields_options' => [
                    'background' => [
                        'label' => esc_html__( 'Sub Title Icon Image', 'invite-plugin' ),
                        'separator' => 'before',
                    ]
                    ],
                    'condition'   => [
                        'design_style' => ['style_6'],
                    ],
			]
		);


        $this->add_control(
            'title',
            [
                'label'       => __( 'Title', 'telnet-core' ),
                'label_block' => true,
                'type'        => Controls_Manager::TEXTAREA,
                'rows'        => 4,
                'default'     => 'Heading Title',
                'placeholder' => __( 'Heading Text', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );

        $this->add_control(
            'description',
            [
                'label'       => __( 'Description', 'telnet-core' ),
                'label_block' => true,
                'type'        => Controls_Manager::TEXTAREA,
                'rows'        => 4,
                'default'     => 'The opportunity to work abroad is a popular prospect, one',
                'placeholder' => __( 'Description Text', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
                'condition'   => [
                    'design_style' => ['style_1', 'style_4', 'style_5', 'style_6', 'style_7', 'style_9', 'style_10', 'style_11'],
                ],
            ]
        );

        $this->add_responsive_control(
            'align',
            [
                'label'     => __( 'Alignment', 'telnet-core' ),
                'type'      => Controls_Manager::CHOOSE,
                'options'   => [
                    'left'   => [
                        'title' => __( 'Left', 'telnet-core' ),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'telnet-core' ),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'end'  => [
                        'title' => __( 'Right', 'telnet-core' ),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'toggle'    => true,
            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label'   => __( 'Title HTML Tag', 'telnet-core' ),
                'type'    => Controls_Manager::CHOOSE,
                'options' => [
                    'h1' => [
                        'title' => __( 'H1', 'telnet-core' ),
                        'icon'  => 'eicon-editor-h1',
                    ],
                    'h2' => [
                        'title' => __( 'H2', 'telnet-core' ),
                        'icon'  => 'eicon-editor-h2',
                    ],
                    'h3' => [
                        'title' => __( 'H3', 'telnet-core' ),
                        'icon'  => 'eicon-editor-h3',
                    ],
                    'h4' => [
                        'title' => __( 'H4', 'telnet-core' ),
                        'icon'  => 'eicon-editor-h4',
                    ],
                    'h5' => [
                        'title' => __( 'H5', 'telnet-core' ),
                        'icon'  => 'eicon-editor-h5',
                    ],
                    'h6' => [
                        'title' => __( 'H6', 'telnet-core' ),
                        'icon'  => 'eicon-editor-h6',
                    ],
                ],
                'default' => 'h2',
                'toggle'  => false,
            ]
        );

        $this->end_controls_section();

    }

    protected function register_style_controls() {

        $this->start_controls_section(
            '_section_style_CONTAINER',
            [
                'label' => __( 'SECTION CONTAINER STYLE', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition'   => [
                    'design_style' => 'style_1',
                ],
            ]
        );

        // container bg color
        $this->add_control(
            'container_bg_color',
            [
                'label'     => __( 'Background Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-sectionHeading' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        // padding
        $this->add_responsive_control(
            'container_padding',
            [
                'label'      => __( 'Padding', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-sectionHeading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // margin
        $this->add_responsive_control(
            'container_margin',
            [
                'label'      => __( 'Margin', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-sectionHeading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_style_sub_title',
            [
                'label' => __( 'SUB HEADING STYLE', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // sub title color
        $this->add_control(
            'sub_title_color',
            [
                'label'     => __( 'Sub Title Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-sectionHeading__subTitle' => 'color: {{VALUE}};',
                ],
            ]
        );

        // sub title bg color
        $this->add_control(
            'sub_title_bg_color',
            [
                'label'     => __( 'Background Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-sectionHeading__subTitle' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        // sub title padding
        $this->add_responsive_control(
            'sub_title_padding',
            [
                'label'      => __( 'Padding', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-sectionHeading__subTitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // sub title margin
        $this->add_responsive_control(
            'sub_title_margin',
            [
                'label'      => __( 'Margin', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-sectionHeading__subTitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // sub title typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'sub_title_typography',
                'label'    => __( 'Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-sectionHeading__subTitle',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_style_title',
            [
                'label' => __( 'HEADING STYLE', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // title color
        $this->add_control(
            'title_color',
            [
                'label'     => __( 'Title Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-sectionHeading__title' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .tx-footer-widget-title' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .sec-title-five_heading' => 'color: {{VALUE}};',
                ],
            ]
        );

        // title span color
        $this->add_control(
            'title_span_color',
            [
                'label'     => __( 'Title Span Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-sectionHeading__title span' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .tx-footer-widget-title span' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .sec-title-five_heading span' => 'color: {{VALUE}};',
                ],
            ]
        );

        // title padding
        $this->add_responsive_control(
            'title_padding',
            [
                'label'      => __( 'Padding', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-sectionHeading__title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .tx-footer-widget-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .tsec-title-five_heading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // title margin
        $this->add_responsive_control(
            'title_margin',
            [
                'label'      => __( 'Margin', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-sectionHeading__title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .tx-footer-widget-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title-five_heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],
            ]
        );

        // title typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typography',
                'label'    => __( 'Typography', 'telnet-core' ),
                'selector' => '
                {{WRAPPER}} .tx-sectionHeading__title,
                {{WRAPPER}} .tx-footer-widget-title,
                {{WRAPPER}} .sec-title-five_heading
                ',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_style_description',
            [
                'label' => __( 'DESCRIPTION STYLE', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // description color
        $this->add_control(
            'description_color',
            [
                'label'     => __( 'Description Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-sectionHeading p' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .sec-title-five_text' => 'color: {{VALUE}};',
                ],
            ]
        );

        // description padding
        $this->add_responsive_control(
            'description_padding',
            [
                'label'      => __( 'Padding', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-sectionHeading p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title-five_text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // description margin
        $this->add_responsive_control(
            'description_margin',
            [
                'label'      => __( 'Margin', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-sectionHeading p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title-five_text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // description typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'description_typography',
                'label'    => __( 'Typography', 'telnet-core' ),
                'selector' => '
                {{WRAPPER}} .tx-sectionHeading p,
                {{WRAPPER}} .sec-title-five_text
                ',
            ]
        );

        $this->end_controls_section();

    }

    protected function render() {

        $settings = $this->get_settings_for_display();
        $dir = dirname( __FILE__ );
        $style = !empty($settings['design_style']) ? $settings['design_style'] : 'style_1';

        $this->add_inline_editing_attributes( 'title', 'basic' );
        $this->add_render_attribute( 'title', 'class', 'tx-sectionHeading__title tx-split-text split-in-right' );
        $this->add_render_attribute( 'title2', 'class', 'headline-title tx-sectionHeading__title' );
        $this->add_render_attribute( 'title3', 'class', 'sec-title-five_heading' );
        $this->add_render_attribute( 'title4', 'class', 'tx-footer-widget-title' );
        $this->add_render_attribute( 'title5', 'class', 'tna-title-1 txa-split-text txa-split-in-up' );
        $this->add_render_attribute( 'title6', 'class', 'tna-title-2 txa-split-text txa-split-in-up' );
        $this->add_render_attribute( 'title7', 'class', 'tna-title-2 font-56 txa-split-text txa-split-in-up' );

        $title = elh_element_kses_basic( $settings['title'] );

        switch ($style) {
            case 'style_11':
                include $dir . '/views/view-11.php';
                break;
            case 'style_10':
                include $dir . '/views/view-10.php';
                break;
            case 'style_9':
                include $dir . '/views/view-9.php';
                break;
            case 'style_8':
                include $dir . '/views/view-8.php';
                break;
            case 'style_7':
                include $dir . '/views/view-7.php';
                break;
            case 'style_6':
                include $dir . '/views/view-6.php';
                break;
            case 'style_5':
                include $dir . '/views/view-5.php';
                break;
            case 'style_4':
                include $dir . '/views/view-4.php';
                break;
            case 'style_3':
                include $dir . '/views/view-3.php';
                break;
            case 'style_2':
                include $dir . '/views/view-2.php';
                break;
            default:
                include $dir . '/views/view-1.php';
        }
    }
}
