<?php
namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;

defined( 'ABSPATH' ) || die();

class Cta_Content extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'cta_content';
    }

    /**
     * Get widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'CTA Content', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/icon-box/';
    }

    /**
     * Get widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-preview-medium';
    }

    public function get_keywords() {
        return ['telnet', 'skill', 'speed', 'progress', 'bar'];
    }

    protected function register_content_controls() {
        $this->start_controls_section(
            '_section_exp_title',
            [
                'label' => __( 'Expriencr ', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
			'brands',
			[
				'label' => esc_html__( 'Add Brand Logo Images', 'telnet-core' ),
				'type' => Controls_Manager::GALLERY,
				'show_label' => false,
				'default' => [],
			]
		);
        $this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bg-image',
				'types' => [ 'classic' ],
				'exclude' => [ 'color' ],
				'selector' => '{{WRAPPER}} .tel-sponsor-cta-section:before',
                'fields_options' => [
                    'background' => [
                        'label' => esc_html__( 'Background Image', 'invite-plugin' ),
                        'separator' => 'before',
                    ]
                ]
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_design_title',
            [
                'label' => __( 'Content', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'subtitle',
            [
                'label'       => __( 'Sub Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );
        $this->add_control(
            'title',
            [
                'label'       => __( 'Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'description',
            [
                'label'       => __( 'Description', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'label_block' => true,
            ]
        );
        $this->add_control(
            'package_title',
            [
                'label'       => __( 'Package Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );
        $this->add_control(
            'package_feature_lists',
            [
                'label' => __('Package List', 'telnet-core'),
                'type' => Controls_Manager::TEXTAREA,
                'dynamic' => [
                    'active' => true
                ],
            ]
        );
        $this->add_control(
            'currency',
            [
                'label' => __('Currency', 'telnet-core'),
                'type' => Controls_Manager::SELECT,
                'label_block' => false,
                'options' => [
                    '' => __('None', 'telnet-core'),
                    'baht' => '&#3647; ' . _x('Baht', 'Currency Symbol', 'telnet-core'),
                    'bdt' => '&#2547; ' . _x('BD Taka', 'Currency Symbol', 'telnet-core'),
                    'dollar' => '&#36; ' . _x('Dollar', 'Currency Symbol', 'telnet-core'),
                    'euro' => '&#128; ' . _x('Euro', 'Currency Symbol', 'telnet-core'),
                    'franc' => '&#8355; ' . _x('Franc', 'Currency Symbol', 'telnet-core'),
                    'guilder' => '&fnof; ' . _x('Guilder', 'Currency Symbol', 'telnet-core'),
                    'krona' => 'kr ' . _x('Krona', 'Currency Symbol', 'telnet-core'),
                    'lira' => '&#8356; ' . _x('Lira', 'Currency Symbol', 'telnet-core'),
                    'peseta' => '&#8359 ' . _x('Peseta', 'Currency Symbol', 'telnet-core'),
                    'peso' => '&#8369; ' . _x('Peso', 'Currency Symbol', 'telnet-core'),
                    'pound' => '&#163; ' . _x('Pound Sterling', 'Currency Symbol', 'telnet-core'),
                    'real' => 'R$ ' . _x('Real', 'Currency Symbol', 'telnet-core'),
                    'ruble' => '&#8381; ' . _x('Ruble', 'Currency Symbol', 'telnet-core'),
                    'rupee' => '&#8360; ' . _x('Rupee', 'Currency Symbol', 'telnet-core'),
                    'indian_rupee' => '&#8377; ' . _x('Rupee (Indian)', 'Currency Symbol', 'telnet-core'),
                    'shekel' => '&#8362; ' . _x('Shekel', 'Currency Symbol', 'telnet-core'),
                    'won' => '&#8361; ' . _x('Won', 'Currency Symbol', 'telnet-core'),
                    'yen' => '&#165; ' . _x('Yen/Yuan', 'Currency Symbol', 'telnet-core'),
                    'custom' => __('Custom', 'telnet-core'),
                ],
                'default' => 'dollar',
            ]
        );

        $this->add_control(
            'currency_custom',
            [
                'label' => __('Custom Symbol', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'condition' => [
                    'currency' => 'custom',
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        // PRICE
        $this->add_control(
            'price',
            [
                'label' => __('Price', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '9.99',
                'dynamic' => [
                    'active' => true
                ]
            ]
        );

        // PERIOD
        $this->add_control(
            'period',
            [
                'label' => __('Period', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Per Month', 'telnet-core'),
                'dynamic' => [
                    'active' => true
                ],
            ]
        );
        $this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'check-thumb-shape',
				'types' => [ 'classic' ],
				'exclude' => [ 'color' ],
				'selector' => '{{WRAPPER}} .tel-cta-pricing-area li:before',
                'fields_options' => [
                    'background' => [
                        'label' => esc_html__( 'Check Icon Image', 'invite-plugin' ),
                        'separator' => 'before',
                    ]
                ]
			]
		);

        $this->add_control(
            'btn_label',
            [
                'label'       => __( 'Button Label', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );
        $this->add_control(
            'btn_icon',
            [
                'label'       => __( 'Button Icon', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );
        $this->add_control(
            'btn_link',
            [
                'label'       => __( 'Button Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'label_block' => true,
            ]
        );
        $this->add_control(
            'phone_icon',
            [
                'label'       => __( 'Phone Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'label_block' => true,
            ]
        );
        $this->add_control(
            'phone_title',
            [
                'label'       => __( 'Phone Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );
        $this->add_control(
            'phone_no',
            [
                'label'       => __( 'Phone Number', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );
        $this->add_control(
            'video_img',
            [
                'label'       => __( 'Video Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );
        $this->add_control(
            'video_link',
            [
                'label'       => __( 'Video Link', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );
        $this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'check-shape-shape',
				'types' => [ 'classic' ],
				'exclude' => [ 'color' ],
				'selector' => '{{WRAPPER}} .tel-sponsor-video-play:after',
                'fields_options' => [
                    'background' => [
                        'label' => esc_html__( 'BG SHAPE', 'invite-plugin' ),
                        'separator' => 'before',
                    ]
                ]
			]
		);

        $this->end_controls_section();

    }

    protected function register_style_controls() {

    }


    /**
     * Render widget output on the frontend.
     *
     * Used to generate the final HTML displayed on the frontend.
     *
     * Note that if skin is selected, it will be rendered by the skin itself,
     * not the widget.
     *
     * @since 1.0.0
     * @access public
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $this->add_render_attribute( 'title2', 'class', 'headline-title tx-sectionHeading__title' );
        ?>
        <section id="tel-sponsor-cta" class="tel-sponsor-cta-section position-relative">
            <div class="tel-sponsor-cta-video-content d-flex">
                <div class="tel-sponsor-cta-content">
                    <div class="tel-main-slider-sponsor-area">
                        <div class="tel-main-slider-sponsor swiper-container">
                            <div class="swiper-wrapper">
                                <?php foreach($settings['brands'] as $item):?>
                                <div class="swiper-slide">
                                    <div class="main-sponsor-img">
                                        <img src="<?php echo esc_Url($item['url']);?>" alt="">
                                    </div>
                                </div>
                                <?php endforeach;?>
                            </div>
                        </div>
                    </div>
                    <div class="tel-cta-content d-flex justify-content-center">
                        <div class="tel-cta-text">
                            <div class="tel-section-title-2 telnet-text">
                                <?php if(!empty( $settings['sub_title'] )) : ?>
                                <div class="sub-title text-uppercase wow fadeInRight"  data-wow-delay="200ms" data-wow-duration="1000ms">
                                    <?php echo elh_element_kses_intermediate($settings['sub_title']); ?>
                                </div>
                                <?php endif; ?>
                                <h3 class="headline-title"><?php echo wp_kses($settings['title'], true);?></h3>
                                <p><?php echo wp_kses($settings['description'], true);?></p>
                            </div>
                            <div class="tel-cta-pricing-area d-flex justify-content-between align-items-center flex-wrap ul-li-block wow fadeInUp"  data-wow-delay="300ms" data-wow-duration="1200ms">
                                <div class="cta-price">
                                    <h3>
                                        <?php if(!empty( $currency )) : ?>
                                        <sub><?php echo esc_html($currency); ?></sub>
                                        <?php endif; ?>
                                        <?php if(!empty( $settings['price'] )) : ?>
                                            <?php echo esc_html($settings['price']); ?>
                                        <?php endif;?>
                                        <?php if(!empty( $settings['period'] )) : ?>
                                            <sup><?php echo esc_html($settings['period']); ?></sup>
                                        <?php endif;?>
                                    </h3>
                                    <p><?php echo wp_kses($settings['title'], true);?></p>
                                </div>
                                <?php if(!empty( $settings['package_title'] )) : ?>
                                    <ul>
                                        <?php
                                            $list_item = $settings['package_feature_lists'];
                                            $list_item = explode("\n", ($list_item));
                                            foreach($list_item as $list):
                                        ?>
                                        <li><?php echo wp_kses($list, true)?></li>
                                        <?php endforeach;?>
                                    </ul>
                                <?php endif; ?>
                            </div>
                            <div class="tel-about-cta-btn d-flex align-items-center flex-wrap wow fadeInUp"  data-wow-delay="400ms" data-wow-duration="1200ms">
                                <?php if(!empty($settings['btn_label'])):?>
                                <div class="tel-btn-2 text-uppercase">
                                    <a
                                    href="<?php echo esc_url($settings['btn_link']['url']);?>"
                                    target="<?php echo esc_attr($settings['btn_link']['is_external'] ? '_blank' : '_self');?>"
                                    rel="<?php echo esc_attr($settings['btn_link']['nofollow'] ? 'nofollow' : ''); ?>"
                                    >
                                        <?php echo esc_html($settings['btn_label']);?>
                                    <?php if(!empty($settings['btn_icon']['url'])):?>
                                        <img src="<?php echo esc_url($settings['btn_icon']['url']);?>" alt="">
                                    <?php endif;?>
                                </a>
                                </div>
                                <?php endif;?>

                                <div class="tel-about-cta d-flex align-items-center">
                                    <div class="cta-icon d-flex align-items-center justify-content-center">
                                        <?php \Elementor\Icons_Manager::render_icon( $settings['phone_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                    </div>
                                    <div class="cta-text">
                                        <span><?php echo wp_kses($settings['phone_title'], true);?></span>
                                        <a href="<?php echo $settings['phone_no'];?>"><?php echo wp_kses($settings['phone_no'], true);?></a>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <?php if(!empty($settings['video_img']['url'])):?>
                <div class="tel-sponsor-video-play position-relative" data-background="<?php echo esc_url($settings['video_img']['url']);?>">
                    <div class="play-icon position-absolute">
                        <a class="d-flex justify-content-center align-items-center" href="<?php echo esc_url($settings['video_link']);?>"><i class="fas fa-play"></i></a>
                    </div>
                </div>
                <?php endif;?>
            </div>
        </section>
    <?php }

}