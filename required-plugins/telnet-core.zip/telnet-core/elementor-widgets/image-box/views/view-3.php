<?php
// image
$image  = $settings['image']['url'];
$image_2 = $settings['image_2']['url'];
?>

<div class="tx-imageBox tx-imageBox__styleThree position-relative">
    <?php if ( !empty( $image ) ): ?>
    <div class="tx-thumb tel-img-animation">
        <img class="w-100" src="<?php echo esc_url( $image ); ?>" alt="">
    </div>
    <?php endif;?>

    <?php if ( !empty( $image_2 ) ): ?>
    <div class="tx-thumbSmall position-absolute tel-img-animation">
        <img src="<?php echo esc_url( $image_2 ); ?>" alt="">
    </div>
    <?php endif;?>
</div>