<?php
// image
$image  = $settings['image']['url'];
?>

<div class="tx-imageBox tx-imageBox__styleFour position-relative tel-img-animation">
    <?php if ( !empty( $image ) ): ?>
    <div class="tx-thumb position-relative tx-z1">
        <img class="w-100" src="<?php echo esc_url( $image ); ?>" alt="">
    </div>
    <?php endif;?>
    <div class="tx-content position-relative tx-z1 pl-30 pr-30 pb-30 mt-none-65">
        <?php if(!empty( $settings['video_link']['url'] )) : ?>
        <a href="<?php echo esc_url($settings['video_link']['url']); ?>"
        target="<?php echo esc_attr($settings['video_link']['is_external'] ? '_blank' : '_self'); ?>"
        rel="<?php echo esc_attr($settings['video_link']['nofollow'] ? 'nofollow' : ''); ?>"
         class="tx-round-btn" data-rel="lightcase">
            <i class="fa fa-play"></i>
        </a>
        <?php endif; ?>

        <?php if(!empty( $settings['discount_text'] )) : ?>
        <p class="mt-15 pl-15"><?php echo elh_element_kses_intermediate( $settings['discount_text'] ); ?></p>
        <?php endif; ?>
    </div>
</div>