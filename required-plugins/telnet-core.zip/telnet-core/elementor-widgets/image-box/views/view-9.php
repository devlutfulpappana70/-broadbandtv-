<div class="tna-about-1-img">
    <?php if(!empty( $settings['image']['url'] )) : ?>
    <div class="main-img tna-img-cover txa-slide-right">
        <img src="<?php echo esc_url($settings['image']['url']) ?>" alt="">
    </div>
    <?php endif; ?>

    <?php if(!empty( $settings['image_2']['url'] )) : ?>
    <div class="secend-img tna-img-cover txa-slide-right">
        <img src="<?php echo esc_url($settings['image_2']['url']) ?>" alt="">
    </div>
    <?php endif; ?>

    <div class="tard-img tna-img-cover txa-slide-right">
        <?php if(!empty( $settings['image_3']['url'] )) : ?>
        <img src="<?php echo esc_url($settings['image_3']['url']) ?>" alt="">
        <?php endif; ?>

        <?php if(!empty( $settings['image_4']['url'] )) : ?>
        <span class="animation-img-wrap" >
            <img src="<?php echo esc_url($settings['image_4']['url']) ?>" alt="">
        </span>
        <?php endif; ?>
    </div>

    <?php if(!empty( $settings['image_5']['url'] )) : ?>
    <img src="<?php echo esc_url($settings['image_5']['url']) ?>" alt="" class="il-shape-1 txa-zoomout">
    <?php endif; ?>
</div>