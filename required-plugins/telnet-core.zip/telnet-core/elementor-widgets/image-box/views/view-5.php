<?php
// image
$image  = $settings['image']['url'];
?>

<div class="tx-imageBox tx-imageBox__styleFive position-relative tel-img-animation">
    <?php if ( !empty( $image ) ): ?>
    <div class="tx-thumb position-relative tx-z1">
        <img class="w-100" src="<?php echo esc_url( $image ); ?>" alt="">
    </div>
    <?php endif;?>

    <?php if(!empty( $settings['discount_text'] )) : ?>
    <div class="tx-cercleBadge tx-cercleBadge__styleDark position-absolute">
        <?php echo elh_element_kses_intermediate( $settings['discount_text'] ); ?>
    </div>
    <?php endif; ?>
</div>