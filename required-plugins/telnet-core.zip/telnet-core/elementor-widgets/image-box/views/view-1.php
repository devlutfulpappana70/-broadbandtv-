<?php
// image
$image  = $settings['image']['url'];
$image_2 = $settings['image_2']['url'];
?>

<div class="tx-imageBox tx-imageBox__styleOne position-relative tel-img-animation">
    <?php if ( !empty( $image ) ): ?>
    <div class="tx-thumb">
        <img class="w-100" src="<?php echo esc_url( $image ); ?>" alt="">
    </div>
    <?php endif;?>

    <?php if ( !empty( $settings['discount_text'] ) ): ?>
    <div class="tx-discountBox position-absolute" data-background="<?php echo $image_2 ? esc_url($image_2) : ''; ?>">
        <?php echo elh_element_kses_intermediate( $settings['discount_text'] ); ?>
    </div>
    <?php endif;?>
</div>