<div class="tna-speed-1-img">
    <?php if(!empty( $settings['image']['url'] )) : ?>
    <div class="main-img">
        <img class="txa-zoomout" src="<?php echo esc_url($settings['image']['url']) ?>" alt="">
    </div>
    <?php endif; ?>
    <div class="popup-img-1">
        <?php if(!empty( $settings['image_2']['url'] )) : ?>
        <img class="txa-zoomout" src="<?php echo esc_url($settings['image_2']['url']) ?>" alt="">
        <?php endif; ?>

        <?php if(!empty( $settings['image_3']['url'] )) : ?>
        <img class="tna-s1-wifi-signal" src="<?php echo esc_url($settings['image_3']['url']) ?>" alt="">
        <?php endif; ?>
    </div>
    <?php if(!empty( $settings['image_4']['url'] )) : ?>
    <div class="popup-img-2">
        <img class="txa-zoomout" src="<?php echo esc_url($settings['image_4']['url']) ?>" alt="">
    </div>
    <?php endif; ?>
</div>