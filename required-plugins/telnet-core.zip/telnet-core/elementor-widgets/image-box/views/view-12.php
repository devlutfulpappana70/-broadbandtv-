<div class="tna-about-2-area">
    <span class="bg-shape-1 wow slideInDown" data-wow-duration="5s"></span>
    <div class="bg-il-1-position">
        <div class="bg-il-1-wrap wow fadeInRight" data-wow-delay="1s">
            <?php if(!empty( $settings['image']['url'] )) : ?>
            <img  src="<?php echo esc_url($settings['image']['url']) ?>" alt="" class="bg-il-1">
            <?php endif; ?>

            <?php if(!empty( $settings['image_2']['url'] )) : ?>
            <img class="wifi-signal" src="<?php echo esc_url($settings['image_2']['url']) ?>" alt="">
            <?php endif; ?>
        </div>
    </div>
</div>