<div class="about-one_image-outer">
    <?php if(!empty( $settings['image']['url'] )) : ?>
    <div class="about-one_image">
        <img src="<?php echo esc_url($settings['image']['url']) ?>" alt="" />
    </div>
    <?php endif; ?>
    <?php if(!empty( $settings['image_2']['url'] )) : ?>
    <div class="about-one_image-two">
        <img src="<?php echo esc_url($settings['image_2']['url']) ?>" alt="" />
    </div>
    <?php endif; ?>
</div>