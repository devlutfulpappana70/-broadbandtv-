<?php
// image
$image  = $settings['image']['url'];
$image_2 = $settings['image_2']['url'];
$image_3 = $settings['image_3']['url'];
?>

<div class="tx-imageBox tx-imageBox__styleSeven position-relative">
    <div class="tx-wrapper">
        <?php if ( !empty( $image ) ): ?>
        <div class="tx-thumb tx-thumb__1 tel-img-animation">
            <img class="w-100" src="<?php echo esc_url( $image ); ?>" alt="">
        </div>
        <?php endif;?>

        <?php if ( !empty( $image_3 ) ): ?>
        <div class="tx-thumb tx-thumb__2 start-0 position-absolute tel-img-animation">
            <img src="<?php echo esc_url( $image_3 ); ?>" alt="">
        </div>
        <?php endif;?>

        <?php if ( !empty( $image_2 ) ): ?>
        <div class="tx-thumb tx-thumb__3 position-absolute end-0 tel-img-animation">
            <img src="<?php echo esc_url( $image_2 ); ?>" alt="">
        </div>
        <?php endif;?>
    </div>
</div>