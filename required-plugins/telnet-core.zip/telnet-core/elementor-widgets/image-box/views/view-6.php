<?php
// image
$image  = $settings['image']['url'];
$image_2 = $settings['image_2']['url'];
$image_3 = $settings['image_3']['url'];
?>

<div class="tx-imageBox tx-imageBox__styleSix position-relative">
    <div class="tx-wrapper tx-radious-25">
        <div class="tx-innerWrapper text-end tel-img-animation">
            <?php if ( !empty( $image ) ): ?>
            <div class="tx-thumb">
                <img class="w-100" src="<?php echo esc_url( $image ); ?>" alt="">
            </div>
            <?php endif;?>
            <?php if ( !empty( $image_2 ) ): ?>
            <div class="tx-thumb mt-15">
                <img src="<?php echo esc_url( $image_2 ); ?>" alt="">
            </div>
            <?php endif;?>
        </div>
        <?php if ( !empty( $image_3 ) ): ?>
        <div class="tx-thumb tx-innerWrapper tel-img-animation">
            <img class="w-100" src="<?php echo esc_url( $image_3 ); ?>" alt="">
        </div>
        <?php endif;?>
    </div>

    <?php if(!empty( $settings['discount_text'] )) : ?>
    <div class="tx-cercleBadge position-absolute start-50 top-50 translate-middle">
        <?php echo elh_element_kses_intermediate( $settings['discount_text'] ); ?>
    </div>
    <?php endif; ?>
</div>