<?php
namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Core\Schemes\Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;

defined( 'ABSPATH' ) || die();

class Image_Box extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'image_box';
    }

    /**
     * Get widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Image Box', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/icon-box/';
    }

    /**
     * Get widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-preview-medium';
    }

    public function get_keywords() {
        return ['service', 'gird', 'icon'];
    }

    protected function register_content_controls() {

        $this->start_controls_section(
            '_section_design_title',
            [
                'label' => __( 'Design Style', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'design_style',
            [
                'label'              => __( 'Design Style', 'telnet-core' ),
                'type'               => Controls_Manager::SELECT,
                'options'            => [
                    'style_1' => __( 'Style 1', 'telnet-core' ),
                    'style_2' => __( 'Style 2', 'telnet-core' ),
                    'style_3' => __( 'Style 3', 'telnet-core' ),
                    'style_4' => __( 'Style 4', 'telnet-core' ),
                    'style_5' => __( 'Style 5', 'telnet-core' ),
                    'style_6' => __( 'Style 6', 'telnet-core' ),
                    'style_7' => __( 'Style 7', 'telnet-core' ),
                    'style_8' => __( 'Style 8', 'telnet-core' ),
                    'style_9' => __( 'Style 9', 'telnet-core' ),
                    'style_10' => __( 'Style 10', 'telnet-core' ),
                    'style_11' => __( 'Style 11', 'telnet-core' ),
                    'style_12' => __( 'Style 12', 'telnet-core' ),
                ],
                'default'            => 'style_1',
                'frontend_available' => true,
                'style_transfer'     => true,
            ]
        );

        $this->end_controls_section();

        // BUTTON & TEXT
        $this->start_controls_section(
            '_section_image_box',
            [
                'label' => __( 'Image Box', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // image
        $this->add_control(
            'image',
            [
                'label'              => __( 'Image', 'telnet-core' ),
                'type'               => Controls_Manager::MEDIA,
                'default'            => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'frontend_available' => true,
                'style_transfer'     => true,
            ]
        );

        // discount text
        $this->add_control(
            'discount_text',
            [
                'label'              => __( 'Text', 'telnet-core' ),
                'type'               => Controls_Manager::TEXTAREA,
                'default'            => __( 'Discount', 'telnet-core' ),
                'frontend_available' => true,
                'style_transfer'     => true,
                'condition'          => [
                    'design_style' => ['style_1', 'style_4', 'style_5', 'style_6', 'style_10'],
                ],
            ]
        );

        // image 2
        $this->add_control(
            'image_2',
            [
                'label'              => __( 'Image 2', 'telnet-core' ),
                'type'               => Controls_Manager::MEDIA,
                'default'            => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'frontend_available' => true,
                'style_transfer'     => true,
                'condition'          => [
                    'design_style' => ['style_1', 'style_2', 'style_3', 'style_6', 'style_7', 'style_8', 'style_9', 'style_10', 'style_11', 'style_12'],
                ],
            ]
        );

        // image 3
        $this->add_control(
            'image_3',
            [
                'label'              => __( 'Image 3', 'telnet-core' ),
                'type'               => Controls_Manager::MEDIA,
                'default'            => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'frontend_available' => true,
                'style_transfer'     => true,
                'condition'          => [
                    'design_style' => ['style_6', 'style_7', 'style_9',  'style_10', 'style_11'],
                ],
            ]
        );

        // image 4
        $this->add_control(
            'image_4',
            [
                'label'              => __( 'Image 4', 'telnet-core' ),
                'type'               => Controls_Manager::MEDIA,
                'default'            => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'frontend_available' => true,
                'style_transfer'     => true,
                'condition'          => [
                    'design_style' => ['style_9', 'style_10'],
                ],
            ]
        );

        // image 5
        $this->add_control(
            'image_5',
            [
                'label'              => __( 'Image 5', 'telnet-core' ),
                'type'               => Controls_Manager::MEDIA,
                'default'            => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'frontend_available' => true,
                'style_transfer'     => true,
                'condition'          => [
                    'design_style' => ['style_9'],
                ],
            ]
        );

        // video link
        $this->add_control(
            'video_link',
            [
                'label'              => __( 'Video Link', 'telnet-core' ),
                'type'               => Controls_Manager::URL,
                'placeholder'        => __( 'https://your-link.com', 'telnet-core' ),
                'default'            => [
                    'url' => 'https://www.youtube.com/watch?v=9No-FiEInLA',
                ],
                'show_external'      => true,
                'frontend_available' => true,
                'style_transfer'     => true,
                'condition'          => [
                    'design_style' => 'style_4',
                ],
            ]
        );

        $this->end_controls_section();

    }

    protected function register_style_controls() {
    }

    /**
     * Render widget output on the frontend.
     *
     * Used to generate the final HTML displayed on the frontend.
     *
     * Note that if skin is selected, it will be rendered by the skin itself,
     * not the widget.
     *
     * @since 1.0.0
     * @access public
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $dir = dirname( __FILE__ );
        $style = !empty($settings['design_style']) ? $settings['design_style'] : 'style_1';

        switch ($style) {
            case 'style_12':
                include $dir . '/views/view-12.php';
                break;
            case 'style_11':
                include $dir . '/views/view-11.php';
                break;
            case 'style_10':
                include $dir . '/views/view-10.php';
                break;
            case 'style_9':
                include $dir . '/views/view-9.php';
                break;
            case 'style_8':
                include $dir . '/views/view-8.php';
                break;
            case 'style_7':
                include $dir . '/views/view-7.php';
                break;
            case 'style_6':
                include $dir . '/views/view-6.php';
                break;
            case 'style_5':
                include $dir . '/views/view-5.php';
                break;
            case 'style_4':
                include $dir . '/views/view-4.php';
                break;
            case 'style_3':
                include $dir . '/views/view-3.php';
                break;
            case 'style_2':
                include $dir . '/views/view-2.php';
                break;
            default:
                include $dir . '/views/view-1.php';
        }
    }
}