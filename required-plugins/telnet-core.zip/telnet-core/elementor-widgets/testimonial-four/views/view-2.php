<div class="tna-testimonial-2-slider-wrap flat_3">
    <div class="swiper tna-testimonial-2-slider">
        <div class="swiper-container tna_testimonial_2_active tna-fix">
            <div class="swiper-wrapper">

                <?php foreach( $settings['testimonial_lists'] as $list ) : ?>
                <div class="swiper-slide">
                    <div class="tna-testimonial-2-item">
                        <?php if(!empty( $list['image']['url'] )) : ?>
                        <div class="main-img">
                            <img src="<?php echo esc_url($list['image']['url']); ?>" alt="">
                        </div>
                        <?php endif; ?>
                        <div class="contente-wrap">
                            <div class="quote">
                                <i class="flaticon-quotation"></i>
                            </div>

                            <?php if(!empty( $list['comment'] )) : ?>
                            <h6 class="tna-heading-2 comment"><?php echo elh_element_kses_intermediate($list['comment']); ?></h6>
                            <?php endif; ?>

                            <div class="person-info">
                                <div class="name-wrap">
                                    <?php if(!empty( $list['name'] )) : ?>
                                    <span class="tna-heading-2 name"><?php echo elh_element_kses_intermediate($list['name']); ?></span>
                                    <?php endif; ?>

                                    <?php if(!empty( $list['designation'] )) : ?>
                                    <p class="tna-para-2 bio"><?php echo elh_element_kses_intermediate($list['designation']); ?></p>
                                    <?php endif; ?>
                                </div>
                                <div class="reating">
                                    <?php
                                        for ( $i = 1; $i < $list['rating_star']; $i++ ) {
                                            echo '<i class="fa-solid fa-star"></i>';
                                        }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <div class="swiper tna-tesimonial-2-slider-preview">
        <div class="swiper-container tna_testimonial_2_preview_active">
            <div class="swiper-wrapper">
                <?php foreach( $settings['testimonial_lists'] as $list ) : ?>
                <div class="swiper-slide">
                    <?php if(!empty( $list['image']['url'] )) : ?>
                    <div class="tna-testimonial-2-preview-item">
                        <img src="<?php echo esc_url($list['image']['url']); ?>" alt="">
                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>
