<div class="tna-testimonial-1-area">
    <div class="container tna-container-1">
        <div class="swiper tna-testimonial-1-slider">

            <div class="quetion-icon">
                <i class="flaticon_3-quote"></i>
            </div>

            <div class="swiper-container tna_t1_slider_active">
                <div class="swiper-wrapper">

                    <?php foreach( $settings['testimonial_lists'] as $list ) : ?>
                    <div class="swiper-slide">
                        <div class="tna-testimonial-1-slider-item">
                            <?php if(!empty( $list['image']['url'] )) : ?>
                            <div class="main-img">
                                <img src="<?php echo esc_url($list['image']['url']); ?>" alt="">
                            </div>
                            <?php endif; ?>

                            <div class="content-wrap">
                                <h6 class="tna-heading-1  comment"><?php echo elh_element_kses_intermediate($list['comment']); ?></h6>
                                <div class="user-info">
                                    <div class="name-wrap">
                                        <?php if(!empty( $list['name'] )) : ?>
                                        <h5 class="tna-heading-1 name"><?php echo elh_element_kses_intermediate($list['name']); ?></h5>
                                        <?php endif; ?>

                                        <?php if(!empty( $list['designation'] )) : ?>
                                        <p class="tna-para-1 bio"><?php echo elh_element_kses_intermediate($list['designation']); ?></p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="reating">
                                        <?php
                                            for ( $i = 1; $i < $list['rating_star']; $i++ ) {
                                                echo '<i class="fa-solid fa-star"></i>';
                                            }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>

                </div>
            </div>

            <div class="tna-t1-pagination"></div>
        </div>
    </div>
</div>