<?php

namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
use \Elementor\Core\Schemes\Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;

defined( 'ABSPATH' ) || die();

class Counter_Two extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name() {
        return 'counter_two';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title() {
        return __( 'Counter Two', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/gradient-heading/';
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-t-letter';
    }

    public function get_keywords() {
        return ['count', 'telnet', 'telnet counter'];
    }

    public function elh_element_animations() {
        return [
            'none' => __( 'None', 'telnet-core' ),
            'fadeIn' => __( 'Fade In', 'telnet-core' ),
            'fadeInUp' => __( 'Fade In Up', 'telnet-core' ),
            'fadeInDown' => __( 'Fade In Down', 'telnet-core' ),
            'fadeInLeft' => __( 'Fade In Left', 'telnet-core' ),
            'fadeInRight' => __( 'Fade In Right', 'telnet-core' ),
            'fadeInUpBig' => __( 'Fade In Up Big', 'telnet-core' ),
            'fadeInDownBig' => __( 'Fade In Down Big', 'telnet-core' ),
            'fadeInLeftBig' => __( 'Fade In Left Big', 'telnet-core' ),
            'fadeInRightBig' => __( 'Fade In Right Big', 'telnet-core' ),
            'bounceIn' => __( 'Bounce In', 'telnet-core' ),
            'bounceInUp' => __( 'Bounce In Up', 'telnet-core' ),
            'bounceInDown' => __( 'Bounce In Down', 'telnet-core' ),
            'bounceInLeft' => __( 'Bounce In Left', 'telnet-core' ),
            'bounceInRight' => __( 'Bounce In Right', 'telnet-core' ),
            'rotateIn' => __( 'Rotate In', 'telnet-core' ),
            'rotateInUpLeft' => __( 'Rotate In Up Left', 'telnet-core' ),
            'rotateInDownLeft' => __( 'Rotate In Down Left', 'telnet-core' ),
            'rotateInUpRight' => __( 'Rotate In Up Right', 'telnet-core' ),
            'rotateInDownRight' => __( 'Rotate In Down Right', 'telnet-core' ),
            'lightSpeedIn' => __( 'Light Speed In', 'telnet-core' ),
            'rollIn' => __( 'Roll In', 'telnet-core' ),
            'zoomIn' => __( 'Zoom In', 'telnet-core' ),
            'zoomInUp' => __( 'Zoom In Up', 'telnet-core' ),
            'zoomInDown' => __( 'Zoom In Down', 'telnet-core' ),
            'zoomInLeft' => __( 'Zoom In Left', 'telnet-core' ),
            'zoomInRight' => __( 'Zoom In Right', 'telnet-core' ),
            'slideInUp' => __( 'Slide In Up', 'telnet-core' ),
            'slideInDown' => __( 'Slide In Down', 'telnet-core' ),
            'slideInLeft' => __( 'Slide In Left', 'telnet-core' ),
            'slideInRight' => __( 'Slide In Right', 'telnet-core' ),
        ];
    }

    protected function register_content_controls() {

        $this->start_controls_section(
            '_section_title',
            [
                'label' => __( 'Counter', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'video_link',
            [
                'label'       => __( 'Video Link', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true
            ]
        );
        
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'counterbg',
				'types' => [ 'classic' ],
				'exclude' => [ 'color' ],
				'selector' => '{{WRAPPER}} .tel-counter-section-4:before',
                'fields_options' => [
                    'background' => [
                        'label' => esc_html__( 'Counter BG', 'invite-plugin' ),
                        'description' => esc_html__( 'Choose background type and style.', 'invite-plugin' ),
                        'separator' => 'before',
                    ]
                ]
			]
		);
        $repeater = new Repeater();
        $repeater->add_control(
			'icon_type',
			[
				'label' => esc_html__( 'Type', 'textdomain' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'image' => [
						'title' => esc_html__( 'Upload Image', 'textdomain' ),
						'icon' => 'eicon-image',
					],
					'icon' => [
						'title' => esc_html__( 'Choose or Upload Svg Icon', 'textdomain' ),
						'icon' => 'eicon-nerd-wink',
					]
				],
				'default' => 'image',
				'toggle' => true,
			]
		);
        // counter icon
        $repeater->add_control(
            'counter_icon',
            [
                'label'       => __( 'Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'label_block' => true,
                'default'     => [
                    'value'   => 'fas fa-check',
                    'library' => 'solid',
                ],
                'condition' => [
                    'icon_type' => 'icon',
                ],
            ]
        );
        $repeater->add_control(
            'icon_img',
            [
                'label'       => __( 'Icon Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition' => [
                    'icon_type' => 'image',
                ],
            ]
        );

        // count number
        $repeater->add_control(
            'count_number',
            [
                'label'       => __( 'Count Number', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __( '100', 'telnet-core' ),
            ]
        );

        // count title
        $repeater->add_control(
            'count_title',
            [
                'label'       => __( 'Count Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __( 'Happy Clients', 'telnet-core' ),
            ]
        );

        $this->add_control(
            'counters',
            [
                'label'       => __( 'Add Counter Item', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
            ]
        );

        $this->end_controls_section();

    }

    protected function register_style_controls() {
        // Icon style
        $this->start_controls_section(
            '_section_icon_style',
            [
                'label' => __( 'Icon', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // icon size
        $this->add_responsive_control(
            'icon_size',
            [
                'label'      => __( 'Size', 'telnet-core' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range'      => [
                    'px' => [
                        'min'  => 10,
                        'max'  => 200,
                        'step' => 1,
                    ],
                    'em' => [
                        'min'  => 0.1,
                        'max'  => 20,
                        'step' => 0.1,
                    ],
                    '%'  => [
                        'min'  => 10,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .tx-counterItem .tx-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // icon width & height
        $this->add_responsive_control(
            'icon_width_height',
            [
                'label'      => __( 'Width & Height', 'telnet-core' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range'      => [
                    'px' => [
                        'min'  => 10,
                        'max'  => 200,
                        'step' => 1,
                    ],
                    'em' => [
                        'min'  => 0.1,
                        'max'  => 20,
                        'step' => 0.1,
                    ],
                    '%'  => [
                        'min'  => 10,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .tx-counterItem .tx-icon' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // icon bg color
        $this->add_control(
            'icon_bg_color',
            [
                'label'     => __( 'Background Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-counterItem .tx-icon' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        // icon color
        $this->add_control(
            'icon_color',
            [
                'label'     => __( 'Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-counterItem .tx-icon' => 'color: {{VALUE}};',
                ],
            ]
        );

        // icon border
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'icon_border',
                'label'    => __( 'Border', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-counterItem .tx-icon',
            ]
        );

        // icon gap
        $this->add_responsive_control(
            'icon_gap',
            [
                'label'      => __( 'Gap', 'telnet-core' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                    'em' => [
                        'min'  => 0,
                        'max'  => 10,
                        'step' => 0.1,
                    ],
                    '%'  => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .tx-counterItem .tx-icon' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // end icon style
        $this->end_controls_section();

        // number style
        $this->start_controls_section(
            '_section_number_style',
            [
                'label' => __( 'Number', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // number color
        $this->add_control(
            'number_color',
            [
                'label'     => __( 'Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-counterItem .tx-count span' => 'color: {{VALUE}};',
                ],
            ]
        );

        // number typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'number_typography',
                'label'    => __( 'Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-counterItem .tx-count span',
            ]
        );

        // number margin
        $this->add_responsive_control(
            'number_margin',
            [
                'label'      => __( 'Margin', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-counterItem .tx-count span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // number padding
        $this->add_responsive_control(
            'number_padding',
            [
                'label'      => __( 'Padding', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-counterItem .tx-count span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // number end
        $this->end_controls_section();

        // title style
        $this->start_controls_section(
            '_section_title_style',
            [
                'label' => __( 'Title', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // title color
        $this->add_control(
            'title_color',
            [
                'label'     => __( 'Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-counterItem p' => 'color: {{VALUE}};',
                ],
            ]
        );

        // title typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typography',
                'label'    => __( 'Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-counterItem p',
            ]
        );


        // title margin
        $this->add_responsive_control(
            'title_margin',
            [
                'label'      => __( 'Margin', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-counterItem p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // title padding
        $this->add_responsive_control(
            'title_padding',
            [
                'label'      => __( 'Padding', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-counterItem p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // end title style
        $this->end_controls_section();

    }

    protected function render() {

        $settings = $this->get_settings_for_display();
        $dir = dirname( __FILE__ );?>
        <div class="tel-counter-section-4 position-relative">
            <div class="container">
                <div class="tel-counter-content-4 position-relative">
                    <?php if(!empty($settings['video_link'])):?>
                    <div class="tel-counter-video-play">
                        <a class="video_box d-flex align-items-center justify-content-center" href="<?php echo esc_url($settings['video_link']);?>"><i class="d-flex align-items-center justify-content-center fas fa-play"></i></a>
                    </div>
                    <?php endif;?>
                    <div class="tel-counter-content-item-4">
                        <div class="row">
                            <?php foreach($settings['counters'] as $item):?>
                            <div class="col-lg-3 col-sm-6">
                                <div class="tel-counter-item-4">
                                    <div class="counter-icon d-flex align-items-center justify-content-center">
                                        <?php if($item['icon_type'] == 'image'):?>
                                        <img src="<?php echo esc_url($item['icon_img']['url']);?>" alt="">
                                        <?php else:?>
                                            <?php \Elementor\Icons_Manager::render_icon( $item['counter_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                        <?php endif;?>
                                    </div>
                                    <div class="counter-text text-uppercase">
                                        <h3>
                                            <span class="counter odometer" data-count="<?php echo esc_html($item['count_number']);?>">00</span></h3>
                                        <p><?php echo wp_kses($item['count_title'], true);?></p>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach;?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php 
    }
}
