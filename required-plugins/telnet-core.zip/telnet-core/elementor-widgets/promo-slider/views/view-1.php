<div id="tel-promotion-video" class="tel-promotion-video-section position-relative">
    <?php if($settings['enable_shape_image'] == 'yes' && !empty( $settings['shape_image']['url'] )) : ?>
	<span class="tel_line_shape position-absolute" data-parallax='{"x" : 60}'>
        <img src="<?php echo esc_url($settings['shape_image']['url']); ?>" alt="">
    </span>
    <?php endif; ?>
    <div class="container">
        <div class="tel-promotion-video-content telnet-text">
            <div class="tel-promotion-video-slider swiper-container position-relative" data-txPromoSlider>
                <div class="swiper-wrapper">
                    <?php
                        foreach( $settings['promo_sliders'] as $id => $list ) :
                            $image = $list['image']['url'];
                            $small_image_1 = $list['small_image_1']['url'];
                            $small_image_text = $list['small_image_text'];
                            $small_image_2 = $list['small_image_2']['url'];
                            $small_image_text_2 = $list['small_image_text_2'];
                            $video_link = $list['video_link']['url'];
                            $slide_text = $list['slide_text'];

                    ?>
                    <div class="swiper-slide">
                        <div class="tel-promotion-video-item position-relative">
                            <div class="promo-video-play-img-text position-relative">
                                <?php if(!empty( $image )) : ?>
                                <div class="promo-video-play-img position-absolute" data-background="<?php echo esc_url($image); ?>">
                                </div>
                                <?php endif; ?>
                                <div class="promo-video-play-text text-center ul-li">
                                    <?php if(!empty( $video_link )) : ?>
                                    <div class="tel-video-wrapper">
                                        <a class="video_box d-flex justify-content-center align-items-center play-btn" href="<?php echo esc_url($video_link); ?>" data-rel="lightcase">
                                        <i class="fas fa-play"></i>
                                        </a>
                                    </div>
                                    <?php endif; ?>

                                    <?php if(!empty( $slide_text )) : ?>
                                    <h6 class="tx-title"><?php echo elh_element_kses_intermediate($slide_text); ?></h6>
                                    <?php endif; ?>

                                    <?php if ( !empty( $list['feature_lists'] )): ?>
                                    <ul class="list-unstyled tx-listItems tx-listItems__styleOne">
                                        <?php foreach ( $list['feature_lists'] as $key => $f_list ): ?>
                                        <li>
                                            <?php if(!empty( $f_list['feature_icon'] )) : ?>
                                            <span class="tx-icon">
                                                <?php elh_element_render_icon($f_list, '', 'feature_icon'); ?>
                                            </span>
                                            <?php endif; ?>
                                            <span class="tx-text"><?php echo elh_element_kses_intermediate( $f_list['feature_text'] ); ?></span>
                                        </li>
                                        <?php endforeach;?>
                                    </ul>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php if(!empty( $small_image_2 || $small_image_text_2 )) : ?>
                            <div class="promo-indicator indicator-1 position-absolute">
                                <div class="indicator-img position-absolute">
                                    <span class="indicator-bg position-absolute" data-background="<?php echo esc_url($small_image_2); ?>"></span>
                                </div>
                                <?php if(!empty( $small_image_text )) : ?>
                                <div class="indicator-text">
                                    <?php echo elh_element_kses_intermediate($small_image_text_2); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>

                            <?php if(!empty( $small_image_1 || $small_image_text )) : ?>
                            <div class="promo-indicator indicator-2 position-absolute">
                                <?php if(!empty( $small_image_1 )) : ?>
                                <div class="indicator-img position-absolute">
                                    <span class="indicator-bg position-absolute" data-background="<?php echo esc_url($small_image_1); ?>"></span>
                                </div>
                                <?php endif; ?>

                                <?php if(!empty( $small_image_text )) : ?>
                                <div class="indicator-text">
                                    <?php echo elh_element_kses_intermediate($small_image_text); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <div class="tel-promo-arrow position-absolute d-flex justify-content-center align-items-center promo-button-prev">
                    <i class="fal fa-long-arrow-left"></i>
                </div>
                <div class="tel-promo-arrow position-absolute d-flex justify-content-center align-items-center promo-button-next">
                    <i class="fal fa-long-arrow-right"></i>
                </div>
            </div>
        </div>
    </div>
</div>