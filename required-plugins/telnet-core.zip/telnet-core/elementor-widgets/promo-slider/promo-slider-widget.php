<?php

namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
use \Elementor\Core\Schemes\Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;

defined( 'ABSPATH' ) || die();

class Promo_Slider extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name() {
        return 'promo_slider';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title() {
        return __( 'Promo Slider', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/gradient-heading/';
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-t-letter';
    }

    public function get_keywords() {
        return ['btn', 'slider', 'promo', 'promo slider'];
    }

    protected function register_content_controls() {

        //Settings
        $this->start_controls_section(
            '_section_settings',
            [
                'label' => __( 'Settings', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'design_style',
            [
                'label'              => __( 'Design Style', 'telnet-core' ),
                'type'               => Controls_Manager::SELECT,
                'options'            => [
                    'style_1' => __( 'Style 1', 'telnet-core' ),
                ],
                'default'            => 'style_1',
                'frontend_available' => true,
                'style_transfer'     => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_slider',
            [
                'label' => __( 'Sliders', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // enable shape image
        $this->add_control(
            'enable_shape_image',
            [
                'label'        => __( 'Enable Shape Image', 'telnet-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Show', 'telnet-core' ),
                'label_off'    => __( 'Hide', 'telnet-core' ),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        // shape image
        $this->add_control(
            'shape_image',
            [
                'label'       => __( 'Shape Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition'   => [
                    'enable_shape_image' => 'yes',
                ],
            ]
        );

        $repeater = new \Elementor\Repeater();

        // list image
        $repeater->add_control(
            'image',
            [
                'label'       => __( 'Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );

        // small image 1
        $repeater->add_control(
            'small_image_1',
            [
                'label'       => __( 'Small Image 1', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );

        // small image text
        $repeater->add_control(
            'small_image_text',
            [
                'label'       => __( 'Small Image Text', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        // small image 2
        $repeater->add_control(
            'small_image_2',
            [
                'label'       => __( 'Small Image 2', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );

        // small image text
        $repeater->add_control(
            'small_image_text_2',
            [
                'label'       => __( 'Small Image Text 2', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        // video link
        $repeater->add_control(
            'video_link',
            [
                'label'       => __( 'Video Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'label_block' => true,
            ]
        );

        // slide text
        $repeater->add_control(
            'slide_text',
            [
                'label'       => __( 'Slide Text', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'label_block' => true,
            ]
        );

        // PCACKAGE FEATURES
        $repeater->add_control(
            'feature_lists',
            [
                'label' => __('Features', 'telnet-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'feature_icon',
                        'label' => __('Feature Icon', 'telnet-core'),
                        'type' => Controls_Manager::ICONS,
                        'default' => [
                            'value' => 'fas fa-check',
                            'library' => 'fa-solid',
                        ],
                    ],
                    [
                        'name' => 'feature_text',
                        'label' => __('Feature Text', 'telnet-core'),
                        'type' => Controls_Manager::TEXT,
                        'default' => __('Ultra Fast inernet', 'telnet-core'),
                        'label_block' => true,
                    ],
                ],
                'default' => [
                    [
                        'feature_text' => __('Ultra Fast inernet', 'telnet-core'),
                    ],
                    [
                        'feature_text' => __('Ultra Fast inernet', 'telnet-core'),
                    ],
                ],
                'title_field' => '{{{ feature_text }}}',
            ],

        );


        // slide items
        $this->add_control(
            'promo_sliders',
            [
                'label'       => __( 'Slide Items', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ slide_text  }}}',
            ]
        );

        $this->end_controls_section();

    }

    protected function register_style_controls() {


    }

    protected function render() {

        $settings = $this->get_settings_for_display();
        $dir = dirname( __FILE__ );

        if ( !empty( $settings['design_style'] ) && $settings['design_style'] == 'style_3' ):
            include $dir . '/views/view-3.php';

        elseif ( !empty( $settings['design_style'] ) && $settings['design_style'] == 'style_2' ):
            include $dir . '/views/view-2.php';
        else:
            include $dir . '/views/view-1.php';
        endif;
    }
}
