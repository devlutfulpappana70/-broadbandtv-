<?php if ( !empty( $settings['info_items'] ) ): ?>
<div class="marque-one">
    <div class="outer-container">
        <div class="marque" data-parallax='{"x" : <?php echo esc_attr($settings['parala_position']); ?>}'>
            <?php foreach ( $settings['info_items'] as $list ): ?>
                <?php if(!empty( $list['info_text'] )) : ?>
                <strong><?php echo elh_element_kses_intermediate( $list['info_text'] ); ?></strong>
                <?php endif; ?>

                <?php if(!empty( $list['info_image'] )) : ?>
                <i><img src="<?php echo esc_url($list['info_image']['url']); ?>" alt="" /></i>
                <?php endif; ?>

                <?php if(!empty( $list['info_text_2'] )) : ?>
                <span><?php echo elh_element_kses_intermediate( $list['info_text_2'] ); ?></span>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>
