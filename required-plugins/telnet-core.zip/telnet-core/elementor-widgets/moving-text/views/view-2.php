<?php if ( !empty( $settings['info_items'] ) ): ?>
<div class="tna-marquee-text-1-area pt-45 pb-45 tna-fix">
    <div class="tna-marquee-text-1-wrap">
        <div class="tna-marquee-text-1-item">
            <?php foreach ( $settings['info_items'] as $list ): ?>
            <h5 class="tna-heading-2">
                <?php if(!empty( $list['info_text'] )) : ?>
                <span class="style-1"><?php echo elh_element_kses_intermediate( $list['info_text'] ); ?></span>
                <?php endif; ?>

                <?php if(!empty( $list['info_text_2'] )) : ?>
                <span class="style-2"><?php echo elh_element_kses_intermediate( $list['info_text_2'] ); ?></span>
                <?php endif; ?>

                <?php if(!empty( $list['info_text_3'] )) : ?>
                <span class="style-3"><?php echo elh_element_kses_intermediate( $list['info_text_3'] ); ?></span>
                <?php endif; ?>

                <?php if(!empty( $list['info_image'] )) : ?>
                <i><img src="<?php echo esc_url($list['info_image']['url']); ?>" alt="" /></i>
                <?php endif; ?>
            </h5>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>