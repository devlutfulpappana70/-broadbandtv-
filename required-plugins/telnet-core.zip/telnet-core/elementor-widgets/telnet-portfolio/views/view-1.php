<div class="tel-portfolio-section">
    <div class="tel-portfolio-content grid">
        <div class="grid-sizer"></div>
        <?php foreach( $settings['portfolio_lists'] as $list ) :

            $grid_size = 'grid-size-25';
            if($list['grid_size'] == 'big') {
                $grid_size = 'grid-size-50';
                $text_class = 'portfolio-text';
            } else {
                $grid_size = 'grid-size-25';
                $text_class = 'portfolio-text-2';
            }
        ?>
        <div class="grid-item <?php echo esc_attr($grid_size); ?>">
            <div class="tel-portfolio-item position-relative">
                <a class="tel-portfolio-link position-absolute" href="#"></a>
                <?php if(!empty( $list['image']['url'] )) : ?>
                <div class="portfolio-img">
                    <img src="<?php echo esc_url($list['image']['url']); ?>">
                </div>
                <?php endif; ?>
                <div class="<?php echo esc_attr($text_class); ?>">
                    <?php if(!empty( $list['tag'] )) : ?>
                    <span>
                        <a href="<?php echo esc_url($list['link']['url']) ?>">
                        <?php echo elh_element_kses_intermediate( $list['tag'] ); ?></a>
                    </span>
                    <?php endif; ?>
                    <?php if(!empty( $list['title'] )) : ?>
                    <h3><a href="<?php echo esc_url($list['link']['url']) ?>"><?php echo elh_element_kses_intermediate( $list['title'] ); ?></a></h3>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>