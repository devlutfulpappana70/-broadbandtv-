<div class="tna-movie-2-area flat_3">
    <?php if(!empty( $settings['bg_image']['url'] )) : ?>
    <div class="bg-img">
        <img src="<?php echo esc_url($settings['bg_image']['url']) ?>" alt="">
    </div>
    <?php endif; ?>

    <!-- section-title -->
    <div class="tna-section-title text-center mb-50">
        <?php if(!empty( $settings['subtitle'] )) : ?>
        <h4 class="tna-subtitle-3 has-center wow fadeInDown" ><?php echo wp_kses($settings['subtitle'], true)?></h4>
        <?php endif; ?>

        <?php if(!empty( $settings['title'] )) : ?>
        <h2 class="tna-title-2 txa-split-text txa-split-in-up"><?php echo wp_kses($settings['title'], true)?></h2>
        <?php endif; ?>
    </div>

    <div class="swiper tna-movie-2-slider">

        <?php if(!empty( $settings['image_1']['url'] )) : ?>
        <img src="<?php echo esc_url($settings['image_1']['url']) ?>" alt="" class="fg-shape-1">
        <?php endif; ?>

        <?php if(!empty( $settings['image_2']['url'] )) : ?>
        <img src="<?php echo esc_url($settings['image_2']['url']) ?>" alt="" class="fg-shape-2">
        <?php endif; ?>

        <div class="swiper-container tna_movie_2_active">
            <div class="swiper-wrapper">

                <?php foreach($settings['list_items'] as $item):?>
                <div class="swiper-slide">
                    <div class="tna-movie-2-item tna-img-cover">
                        <?php if(!empty( $item['poster']['url'] )) : ?>
                        <img src="<?php echo esc_url($item['poster']['url']);?>" alt="">
                        <?php endif; ?>
                        <div class="btn-wrap">
                            <a href="<?php echo esc_url($item['video_link']);?>" class="tna-playbtn-1 popup-video">
                                <i class="fa-solid fa-play"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach;?>
            </div>
        </div>

        <div class="tna-movie-2-btn">
            <div class="tna_movie_2_prev"><i class="flaticon-slide"></i></div>
            <div class="tna_movie_2_next"><i class="flaticon-slide"></i></div>
        </div>
    </div>
</div>