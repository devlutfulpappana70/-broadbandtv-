<div class="container">
    <div class="tel-streaming-top-content d-flex justify-content-between align-items-end">
        <div class="tel-section-title-4">
            <?php if(!empty($settings['subtitle'])):?>
            <div class="sub-title text-uppercase position-relative  d-inline-block wow fadeInRight"  data-wow-delay="200ms" data-wow-duration="1000ms">
                <span><?php echo wp_kses($settings['subtitle'], true)?></span>
            </div>
            <?php endif;?>
            <h2 class="headline-title"><?php echo wp_kses($settings['title'], true)?></h2>
        </div>
        <div class="tel-carousel-next-prev-area  d-flex align-items-center justify-content-center wow fadeInRight"  data-wow-delay="300ms" data-wow-duration="1000ms">
            <div class="carousel-next-prev d-flex justify-content-center align-items-center stream-carousel-prev"><i class="fas fa-long-arrow-left"></i></div>
            <div class="carousel-next-prev d-flex justify-content-center align-items-center stream-carousel-next"><i class="fas fa-long-arrow-right"></i></div>
        </div>
    </div>
</div>
<div class="tel-streaming-slider swiper-container">
    <div class="swiper-wrapper">
        <?php foreach($settings['list_items'] as $item):?>
        <div class="swiper-slide">
            <div class="tel-streaming-item position-relative">
                <img src="<?php echo esc_url($item['poster']['url']);?>" alt="">
                <a class="streaming-play-btn video_box position-absolute" href="<?php echo esc_url($item['video_link']);?>"><img src="<?php echo esc_url($item['play_icon']['url']);?>" alt=""></a>
            </div>
        </div>
        <?php endforeach;?>
    </div>
</div>