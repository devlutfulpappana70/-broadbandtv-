<?php
namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Telnet_Streaming extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'telnet_streaming';
    }

    /**
     * Get widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Telnet Streaming', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/icon-box/';
    }

    /**
     * Get widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-preview-medium';
    }

    public function get_keywords() {
        return ['telnet', 'skill', 'speed', 'progress', 'bar'];
    }

    protected function register_content_controls() {

         //Settings
         $this->start_controls_section(
            '_section_settings',
            [
                'label' => __( 'Settings', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'design_style',
            [
                'label'              => __( 'Design Style', 'telnet-core' ),
                'type'               => Controls_Manager::SELECT,
                'options'            => [
                    'style_1' => __( 'Style 1', 'telnet-core' ),
                    'style_2' => __( 'Style 2', 'telnet-core' ),
                ],
                'default'            => 'style_1',
                'frontend_available' => true,
                'style_transfer'     => true,
            ]
        );

        $this->end_controls_section();

        // image
        $this->start_controls_section(
            '_section_image',
            [
                'label' => __( 'Image', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'design_style' => 'style_2'
                ]
            ]
        );

        // bg image
        $this->add_control(
            'bg_image',
            [
                'label'       => __( 'Background Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );

        // image 1
        $this->add_control(
            'image_1',
            [
                'label'       => __( 'Image 1', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );

        // image 2
        $this->add_control(
            'image_2',
            [
                'label'       => __( 'Image 2', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );

        // end
        $this->end_controls_section();

        $this->start_controls_section(
            '_section_design_title',
            [
                'label' => __( 'Content', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'subtitle',
            [
                'label'       => __( 'Sub Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );
        $this->add_control(
            'title',
            [
                'label'       => __( 'Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'label_block' => true,
            ]
        );
        $repeater = new \Elementor\Repeater();


        // list image
        $repeater->add_control(
            'poster',
            [
                'label'       => __( 'Movie Poster', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );

        // list text
        $repeater->add_control(
            'play_icon',
            [
                'label'       => __( 'Play Icon', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'video_link',
            [
                'label'       => __( 'Video Link', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'list_items',
            [
                'label'       => __( 'List Items', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
            ]
        );

        $this->end_controls_section();

    }

    protected function register_style_controls() {

        //  PROGRESS BAR STYLE
        $this->start_controls_section(
            '_section_progress_bar_style',
            [
                'label' => __( 'Progress Bar', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // progress size
        $this->add_control(
            'progress_size',
            [
                'label'       => __( 'Progress Size', 'telnet-core' ),
                'type'        => Controls_Manager::SLIDER,
                'size_units'  => ['px'],
                'range'       => [
                    'px' => [
                        'min'  => 1,
                        'max'  => 500,
                        'step' => 1,
                    ],
                ],
                'default'     => [
                    'unit' => 'px',
                    'size' => 180,
                ],
                'label_block' => true,
                'selectors'   => [
                    '{{WRAPPER}} .tx-progressBox__styleOne' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // progress color
        $this->add_control(
            'progress_color',
            [
                'label'     => __( 'Progress Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#d40418',
            ]
        );

        // progress background color
        $this->add_control(
            'progress_bg_color',
            [
                'label'     => __( 'Progress Background Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#fff',
            ]
        );

        // progress thickness
        $this->add_control(
            'progress_thickness',
            [
                'label'       => __( 'Progress Thickness', 'telnet-core' ),
                'type'        => Controls_Manager::SLIDER,
                'size_units'  => ['px'],
                'range'       => [
                    'px' => [
                        'min'  => 0.01,
                        'max'  => 1,
                        'step' => 0.01,
                    ],
                ],
                'default'     => [
                    'unit' => 'px',
                    'size' => 0.5,
                ],
                'label_block' => true,
            ]
        );

        // END SECTION
        $this->end_controls_section();


    }

    /**
     * Render widget output on the frontend.
     *
     * Used to generate the final HTML displayed on the frontend.
     *
     * Note that if skin is selected, it will be rendered by the skin itself,
     * not the widget.
     *
     * @since 1.0.0
     * @access public
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $dir = dirname( __FILE__ );
        $style = !empty($settings['design_style']) ? $settings['design_style'] : 'style_1';

        switch ($style) {
            case 'style_2':
                include $dir . '/views/view-2.php';
                break;
            default:
                include $dir . '/views/view-1.php';
        }
    }

}