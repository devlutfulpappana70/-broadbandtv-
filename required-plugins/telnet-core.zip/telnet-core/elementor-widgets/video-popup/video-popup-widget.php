<?php

namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;

defined( 'ABSPATH' ) || die();

class Video_Popup extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name() {
        return 'video_popup';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title() {
        return __( 'Video Popup', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/gradient-heading/';
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-t-letter';
    }

    public function get_keywords() {
        return ['btn', 'video', 'telnet', 'telnet video'];
    }

    protected function register_content_controls() {


        $this->start_controls_section(
            '_section_title',
            [
                'label' => __( 'Button', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // video button bg image
        $this->add_control(
            'shape',
            [
                'label'   => __( 'Image', 'telnet-core' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        // video button bg image
        $this->add_control(
            'shape2',
            [
                'label'   => __( 'Image 2', 'telnet-core' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        // Button link
        $this->add_control(
            'video_link',
            [
                'label'       => __( 'Video Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'telnet-core' ),
                'default'     => [
                    'url' => '#'
                ],
                'show_external' => true,
                'label_block'   => false,
            ]
        );



        $this->end_controls_section();

    }

    protected function register_style_controls() {



    }

    protected function render() {

        $settings = $this->get_settings_for_display();?>
        <section id="tel-video-play-2" class="tel-video-play-section-2 position-relative">
            <span class="tel-video-side-img1 position-absolute"><img src="<?php echo esc_url($settings['shape']['url']);?>" alt=""></span>
            <span class="tel-video-side-img2 position-absolute"><img src="<?php echo esc_url($settings['shape2']['url']);?>" alt=""></span>
            <div class="tel-video-play-content x-videoBtnWrapper">
                <a data-rel="lightcase" class="d-flex justify-content-center align-items-center" data-rel="lightcase" href="<?php echo esc_url($settings['video_link']['url']); ?>"><i class="fas fa-play"></i></a>
            </div>
        </section>
       <?php
    }
}
