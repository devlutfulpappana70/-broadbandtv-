<?php

namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
use \Elementor\Core\Schemes\Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;

defined( 'ABSPATH' ) || die();

class Movie_Poster_Two extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name() {
        return 'movie_poster_two';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title() {
        return __( 'Movie Poster Two', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/gradient-heading/';
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-t-letter';
    }

    public function get_keywords() {
        return ['movie', 'poster', 'info', 'info lists'];
    }

    protected function register_content_controls() {

        //Settings
        $this->start_controls_section(
            '_section_settings',
            [
                'label' => __( 'Settings', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'design_style',
            [
                'label'              => __( 'Design Style', 'telnet-core' ),
                'type'               => Controls_Manager::SELECT,
                'options'            => [
                    'style_1' => __( 'Style 1', 'telnet-core' ),
                ],
                'default'            => 'style_1',
                'frontend_available' => true,
                'style_transfer'     => true,
            ]
        );

        $this->end_controls_section();

        // movie post gallery
        $this->start_controls_section(
            '_section_gallery',
            [
                'label' => __( 'Movie Post Gallery', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // heading
        $this->add_control(
            'movie_poster_gallery_heading_1',
            [
                'label'       => __( 'Movie Post Gallery 1', 'telnet-core' ),
                'type'        => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
			'movie_poster_gallery_1',
			[
				'label' => esc_html__( 'Add Images', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::GALLERY,
				'show_label' => false,
				'default' => [],
			]
		);

        $this->add_control(
            'movie_poster_gallery_heading_2',
            [
                'label'       => __( 'Movie Post Gallery 2', 'telnet-core' ),
                'type'        => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
			'movie_poster_gallery_2',
			[
				'label' => esc_html__( 'Add Images', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::GALLERY,
				'show_label' => false,
				'default' => [],
			]
		);

        $this->add_control(
            'movie_poster_gallery_heading_3',
            [
                'label'       => __( 'Movie Post Gallery 3', 'telnet-core' ),
                'type'        => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
			'movie_poster_gallery_3',
			[
				'label' => esc_html__( 'Add Images', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::GALLERY,
				'show_label' => false,
				'default' => [],
			]
		);

        $this->add_control(
            'movie_poster_gallery_heading_4',
            [
                'label'       => __( 'Movie Post Gallery 4', 'telnet-core' ),
                'type'        => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
			'movie_poster_gallery_4',
			[
				'label' => esc_html__( 'Add Images', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::GALLERY,
				'show_label' => false,
				'default' => [],
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_lists',
            [
                'label' => __( 'Movie Posters', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // big banner image
        $this->add_control(
            'big_banner_image',
            [
                'label'   => __( 'Big Banner Image', 'telnet-core' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        // movie name
        $this->add_control(
            'movie_name',
            [
                'label'       => __( 'Movie Name', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Movie Name', 'telnet-core' ),
                'placeholder' => __( 'Movie Name', 'telnet-core' ),
            ]
        );

        // date
        $this->add_control(
            'date',
            [
                'label'       => __( 'Date', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Date', 'telnet-core' ),
                'placeholder' => __( 'Date', 'telnet-core' ),
            ]
        );

        // quality
        $this->add_control(
            'quality',
            [
                'label'       => __( 'Quality', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Quality', 'telnet-core' ),
                'placeholder' => __( 'Quality', 'telnet-core' ),
            ]
        );

        // rating
        $this->add_control(
            'rating',
            [
                'label'       => __( 'Rating', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Rating', 'telnet-core' ),
                'placeholder' => __( 'Rating', 'telnet-core' ),
            ]
        );

        // short description
        $this->add_control(
            'short_description',
            [
                'label'       => __( 'Short Description', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'default'     => __( 'Short Description', 'telnet-core' ),
                'placeholder' => __( 'Short Description', 'telnet-core' ),
            ]
        );

        // button text
        $this->add_control(
            'btn_text',
            [
                'label'       => __( 'Button Text', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Button Text', 'telnet-core' ),
                'placeholder' => __( 'Button Text', 'telnet-core' ),
            ]
        );

        // button link
        $this->add_control(
            'btn_link',
            [
                'label'       => __( 'Button Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'telnet-core' ),
                'default'     => [
                    'url' => '#',
                ],
            ]
        );

        // button icons
        $this->add_control(
            'btn_icon',
            [
                'label'            => __( 'Button Icon', 'telnet-core' ),
                'type'             => Controls_Manager::ICONS,
                'fa4compatibility' => 'icon',
                'default'          => [
                    'value'   => 'fas fa-angle-right',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $this->end_controls_section();


    }

    protected function register_style_controls() {

    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $dir = dirname( __FILE__ );
        $style = !empty($settings['design_style']) ? $settings['design_style'] : 'style_1';

        switch ($style) {
            case 'style_2':
                include $dir . '/views/view-2.php';
                break;
            default:
                include $dir . '/views/view-1.php';
        }
    }
}
