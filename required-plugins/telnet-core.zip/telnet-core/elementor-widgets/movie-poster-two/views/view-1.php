<div class="tna-movie-1-area flat_3 tna-fix">
	<div class="tna-movie-1-wrap">
		<div class="tna-movie-1-tabs-item-wrap d-flex justify-content-between ">
			<div class="left-side">
				<!-- row-1 -->
				<ul class="tna-movie-1-tabs-item tna-movie-1-tabs-item-1 txa-slide-up">
					<?php foreach ( $settings['movie_poster_gallery_1'] as $key => $list_1 ) : ?>
					<li class="nav-item" role="presentation">
						<?php if(!empty( $list_1['url'] )) : ?>
							<img src="<?php echo $list_1['url'] ? esc_url($list_1['url']) : ''; ?>" alt="">
						<?php endif; ?>
					</li>
					<?php endforeach; ?>

				</ul>

				<!-- row-2 -->
				<ul class="tna-movie-1-tabs-item tna-movie-1-tabs-item-2 txa-slide-down">

					<?php foreach ( $settings['movie_poster_gallery_2'] as $key => $list_1 ) : ?>
					<li class="nav-item" role="presentation">
						<?php if(!empty( $list_1['url'] )) : ?>
							<img src="<?php echo $list_1['url'] ? esc_url($list_1['url']) : ''; ?>" alt="">
						<?php endif; ?>
					</li>
					<?php endforeach; ?>

				</ul>

			</div>

			<div class="right-side">

				<!-- row-3 -->
				<ul class="tna-movie-1-tabs-item tna-movie-1-tabs-item-3 txa-slide-up">

					<?php foreach ( $settings['movie_poster_gallery_3'] as $key => $list_1 ) : ?>
					<li class="nav-item" role="presentation">
						<?php if(!empty( $list_1['url'] )) : ?>
							<img src="<?php echo $list_1['url'] ? esc_url($list_1['url']) : ''; ?>" alt="">
						<?php endif; ?>
					</li>
					<?php endforeach; ?>

				</ul>

				<!-- row-4 -->
				<ul class="tna-movie-1-tabs-item tna-movie-1-tabs-item-4 txa-slide-down">

					<?php foreach ( $settings['movie_poster_gallery_4'] as $key => $list_1 ) : ?>
					<li class="nav-item" role="presentation">
						<?php if(!empty( $list_1['url'] )) : ?>
							<img src="<?php echo $list_1['url'] ? esc_url($list_1['url']) : ''; ?>" alt="">
						<?php endif; ?>
					</li>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>

		<div class="tna-movie-1-tabs-content">
			<div class="tna-movie-1-tabs-content-item bg-default" tna-data-background="<?php echo $settings['big_banner_image']['url'] ? esc_url($settings['big_banner_image']['url']) : ''; ?>">
				<?php if(!empty( $settings['movie_name'] )) : ?>
				<h5 class="tna-heading-1 movie-name"><?php echo elh_element_kses_intermediate( $settings['movie_name'] ); ?></h5>
				<?php endif; ?>

				<p class="tna-para-1 movie-date">
					<?php echo elh_element_kses_intermediate( $settings['date'] ); ?>

					<?php if(!empty( $settings['quality'] )) : ?>
					<span class="qoulity"><?php echo elh_element_kses_intermediate( $settings['quality'] ); ?></span>
					<?php endif; ?>

					<?php if(!empty( $settings['rating'] )) : ?>
					<span class="reating"><?php echo elh_element_kses_intermediate( $settings['rating'] ); ?></span>
					<?php endif; ?>
				</p>

				<?php if(!empty( $settings['short_description'] )) : ?>
				<p class="tna-para-1 movie-disc"><?php echo elh_element_kses_intermediate( $settings['short_description'] ); ?></p>
				<?php endif; ?>

				<?php if(!empty( $settings['btn_text'] )) : ?>
				<a class="tna-pr-btn-2 wow fadeInLeft" href="<?php echo esc_url($settings['btn_link']['url']); ?>">
					<?php echo elh_element_kses_intermediate( $settings['btn_text'] ); ?>
					<?php \Elementor\Icons_Manager::render_icon( $settings['btn_icon'], [ 'aria-hidden' => 'true' ] ); ?>
				</a>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>
<!-- movie-end -->