<?php
	if ($settings['currency'] === 'custom') {
		$currency = $settings['currency_custom'];
	} else {
		$currency = self::get_currency_symbol($settings['currency']);
	}
?>
<div class="tna-discount-2-area bg-default tna-fix flat_3" tna-data-background="<?php echo $settings['bg_image']['url'] ? esc_url($settings['bg_image']['url']) : ''; ?>">
	<span class="tna-discount-2-bg-animation"></span>

	<?php if(!empty( $settings['bg_shape_image']['url'] )) : ?>
	<div class="tna-discount-2-img">
		<img src="<?php echo esc_url($settings['bg_shape_image']['url']); ?>" alt="">
	</div>
	<?php endif; ?>

	<?php if(!empty( $settings['bg_shape_image_2']['url'] )) : ?>
	<img src="<?php echo esc_url($settings['bg_shape_image_2']['url']); ?>" alt="" class="il-img-1">
	<?php endif; ?>

	<div class="container tna-container-1">
		<div class="row">
			<div class="col-xl-6 offset-xl-6">
				<div class="tna-discount-2-content">
					<!-- section-title -->
					<div class="tna-section-title mb-25">

						<?php if(!empty( $settings['sub_title'] )) : ?>
						<h4 class="tna-subtitle-3 wow fadeInUp">
							<?php echo elh_element_kses_intermediate($settings['sub_title']); ?>
						</h4>
						<?php endif; ?>

						<?php printf('<%1$s %2$s>%3$s</%1$s>',
							tag_escape($settings['title_tag']),
							$this->get_render_attribute_string('title3'),
							$title
						); ?>

						<?php if(!empty( $settings['description'] )) : ?>
						<p class="tna-para-2 wow fadeInUp"><?php echo elh_element_kses_intermediate($settings['description']); ?></p>
						<?php endif; ?>
					</div>

					<?php if(!empty( $currency || $settings['price'] || $settings['period'] )) : ?>
					<h4 class="tna-heading-2 price wow fadeInUp"><span><?php echo esc_html($currency . $settings['price']); ?></span> <?php echo esc_html($settings['period']); ?></h4>
					<?php endif; ?>

					<a class="tna-pr-btn-3 wow fadeInUp" href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>">
						<?php if(!empty( $settings['button_text'] )) : ?>
						<span class="text"><?php echo elh_element_kses_intermediate($settings['button_text']); ?></span>
						<?php endif; ?>

						<?php if($settings['enable_icon'] === 'yes') : ?>
							<?php if($settings['btn_type'] == 'icon') : ?>
								<?php \Elementor\Icons_Manager::render_icon( $settings['selected_icon'], [ 'aria-hidden' => 'true' ] ); ?>
							<?php else : ?>
								<img src="<?php echo esc_url($settings['btn_image']['url']); ?>" alt="" />
							<?php endif; ?>
						<?php endif; ?>
					</a>
				</div>
			</div>
		</div>
	</div>
</div>