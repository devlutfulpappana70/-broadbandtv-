<?php
$bg_image = $settings['bg_image']['url'];

?>

<div class="tx-ctaSection tx-ctaSection__styleOne" data-background="<?php echo $bg_image ? esc_url($bg_image) : ''; ?>" data-overlay="dark" data-opacity="6">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-10">
                <div class="tx-wrapper d-flex align-items-center justify-content-center flex-column">
                    <div class="tx-cercleBadgeWrapper text-center tx-z1">
                        <span class="tx-cercleBadge position-relative">
                            <?php
                                if ($settings['type'] === 'image' && ($settings['list_image']['url'] || $settings['list_image']['id'])) {
                                    $this->get_render_attribute_string('list_image');
                                    $settings['hover_animation'] = 'disable-animation';
                                    echo Group_Control_Image_Size::get_attachment_image_html($settings, 'thumbnail', 'list_image');
                                } elseif (!empty($settings['icon'])) {
                                    elh_element_render_icon($settings, '', 'icon');
                                }
                            ?>
                        </span>
                    </div>

                    <?php printf('<%1$s %2$s>%3$s</%1$s>',
                        tag_escape($settings['title_tag']),
                        $this->get_render_attribute_string('title'),
                        $title
                    ); ?>
                    <div class="btn-wrapper text-center">
                        <?php if(!empty( $settings['button_text'] )) : ?>
                            <a href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>" class="tx-button tx-button__styleTheme">
                                <?php echo elh_element_kses_intermediate($settings['button_text']); ?>
                                <span class="tx-icon">
                                <?php if($settings['enable_icon'] === 'yes') : ?>
                                    <?php if($settings['btn_type'] == 'icon') : ?>
                                        <?php \Elementor\Icons_Manager::render_icon( $settings['selected_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                    <?php else : ?>
                                        <img src="<?php echo esc_url($settings['btn_image']['url']); ?>" alt="" />
                                    <?php endif; ?>
                                <?php endif; ?>
                                </span>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>