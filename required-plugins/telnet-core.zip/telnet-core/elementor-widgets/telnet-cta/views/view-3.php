<?php
$bg_image = $settings['bg_image']['url'];

?>
<div class="tna-discount-1-area bg-default" tna-data-background="<?php echo $bg_image ? esc_url($bg_image) : ''; ?>">
	<?php if(!empty( $settings['bg_shape_image']['url'] )) : ?>
	<img src="<?php echo esc_url($settings['bg_shape_image']['url']); ?>" alt="" class="bg-shape tna-d1-ani-shpae">
	<?php endif; ?>

	<div class="container tna-container-1 z-index-3">
		<div class="row">
			<div class="col-xl-7 col-lg-6">
				<?php if(!empty( $settings['bg_shape_image_2']['url'] )) : ?>
				<div class="tna-discount-1-img">
					<img src="<?php echo esc_url($settings['bg_shape_image_2']['url']); ?>" alt="">
				</div>
				<?php endif; ?>
			</div>

			<!-- right-content -->
			<div class="col-xl-5 col-lg-6">
				<div class="tna-discount-1-content">

					<!-- section-title -->
					<div class="tna-section-title mb-55">
						<?php if(!empty( $settings['sub_title'] )) : ?>
						<h4 class="tna-subtitle-1 wow fadeInRight">
							<?php echo elh_element_kses_intermediate($settings['sub_title']); ?>
						</h4>
						<?php endif; ?>

						<?php printf('<%1$s %2$s>%3$s</%1$s>',
							tag_escape($settings['title_tag']),
							$this->get_render_attribute_string('title2'),
							$title
						); ?>

						<?php if(!empty( $settings['description'] )) : ?>
						<p class="tna-para-1 wow fadeInRight"><?php echo elh_element_kses_intermediate($settings['description']); ?></p>
						<?php endif; ?>
					</div>
					<a class="tna-pr-btn-2 wow fadeInLeft" href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>">
						<?php echo elh_element_kses_intermediate($settings['button_text']); ?>
						<?php if($settings['enable_icon'] === 'yes') : ?>
							<?php if($settings['btn_type'] == 'icon') : ?>
								<?php \Elementor\Icons_Manager::render_icon( $settings['selected_icon'], [ 'aria-hidden' => 'true' ] ); ?>
							<?php else : ?>
								<img src="<?php echo esc_url($settings['btn_image']['url']); ?>" alt="" />
							<?php endif; ?>
						<?php endif; ?>
					</a>
				</div>
			</div>
		</div>

	</div>
</div>