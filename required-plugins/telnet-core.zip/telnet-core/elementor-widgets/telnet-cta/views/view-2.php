<?php
$bg_image = $settings['bg_image']['url'];

?>
<div class="tna-internet-1-area txa-class-add pt-130 pb-140 bg-default" tna-data-background="<?php echo $bg_image ? esc_url($bg_image) : ''; ?>">
		<span class="bg-color"></span>
		<div class="container tna-container-1 z-index-3">
			<div class="row">
				<div class="col-lg-6 offset-lg-6 col-md-8 offset-md-4">
					<div class="tna-internet-1-content " >
						<div class="tna-section-title mb-60">

                            <?php if(!empty( $settings['sub_title'] )) : ?>
							<h4 class="tna-subtitle-1 wow fadeInRight"><?php echo elh_element_kses_intermediate($settings['sub_title']); ?></h4>
                            <?php endif; ?>

							<?php printf('<%1$s %2$s>%3$s</%1$s>',
                                tag_escape($settings['title_tag']),
                                $this->get_render_attribute_string('title2'),
                                $title
                            ); ?>

                            <?php if(!empty( $settings['description'] )) : ?>
							<p class="tna-para-1 wow fadeInRight">
                                <?php echo elh_element_kses_intermediate($settings['description']); ?>
                            </p>
                            <?php endif; ?>

						</div>
						<a class="tna-pr-btn-2 wow fadeInRight" href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>">
                            <?php echo elh_element_kses_intermediate($settings['button_text']); ?>
							<?php if($settings['enable_icon'] === 'yes') : ?>
                                <?php if($settings['btn_type'] == 'icon') : ?>
                                    <?php \Elementor\Icons_Manager::render_icon( $settings['selected_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                <?php else : ?>
                                    <img src="<?php echo esc_url($settings['btn_image']['url']); ?>" alt="" />
                                <?php endif; ?>
                            <?php endif; ?>
						 </a>
					</div>
				</div>
			</div>
		</div>
	</div>