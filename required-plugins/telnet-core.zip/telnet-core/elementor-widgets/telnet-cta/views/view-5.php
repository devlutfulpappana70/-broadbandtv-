<div class="tna-discount-3-area flat_3 tna-fix">

	<?php if(!empty( $settings['bg_image']['url'] )) : ?>
	<div class="bg-img">
		<div class="txa-zoomout tna-img-cover">
			<img src="<?php echo esc_url($settings['bg_image']['url']); ?>" alt="">
		</div>
	</div>
	<?php endif; ?>

	<div class="container tna-container-1">
		<div class="row">
			<div class="col-xl-5 offset-xl-7 col-lg-7 col-md-8">
				<div class="tna-discount-3-content">
					<!-- section-title -->
					<div class="tna-section-title mb-45">
						<?php if(!empty( $settings['sub_title'] )) : ?>
						<h4 class="tna-subtitle-2 has-4 wow fadeInUp">
							<?php echo elh_element_kses_intermediate($settings['sub_title']); ?>
						</h4>
						<?php endif; ?>
						<?php printf('<%1$s %2$s>%3$s</%1$s>',
							tag_escape($settings['title_tag']),
							$this->get_render_attribute_string('title4'),
							$title
						); ?>
						<?php if(!empty( $settings['description'] )) : ?>
						<p class="tna-para-2 wow fadeInUp"><?php echo elh_element_kses_intermediate($settings['description']); ?></p>
						<?php endif; ?>
					</div>

					<?php if(!empty( $settings['button_text'] )) : ?>
					<a class="tna-pr-btn-4 wow fadeInUp">
						<span class="text"><?php echo elh_element_kses_intermediate($settings['button_text']); ?></span>
						<?php if($settings['enable_icon'] === 'yes') : ?>
							<?php if($settings['btn_type'] == 'icon') : ?>
								<?php \Elementor\Icons_Manager::render_icon( $settings['selected_icon'], [ 'aria-hidden' => 'true' ] ); ?>
							<?php else : ?>
								<img src="<?php echo esc_url($settings['btn_image']['url']); ?>" alt="" />
							<?php endif; ?>
						<?php endif; ?>
					</a>
					<?php endif; ?>
				</div>

			</div>
		</div>
	</div>
</div>