<?php
namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
use \Elementor\Core\Schemes\Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;


defined( 'ABSPATH' ) || die();

class Telnet_Cta extends Element_El_Widget {


    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'telnet_cta';
    }

    /**
     * Get widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'TelNet CTA', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/gradient-heading/';
    }

    /**
     * Get widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-elementor';
    }

    public function get_keywords() {
        return [ 'telnet', 'cta' ];
    }

    protected function register_content_controls() {

        //Settings
        $this->start_controls_section(
            '_section_settings',
            [
                'label' => __( 'Design Style', 'telnet-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'design_style',
            [
                'label' => __( 'Design Style', 'telnet-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'telnet-core' ),
                    'style_2' => __( 'Style 2', 'telnet-core' ),
                    'style_3' => __( 'Style 3', 'telnet-core' ),
                    'style_4' => __( 'Style 4', 'telnet-core' ),
                    'style_5' => __( 'Style 5', 'telnet-core' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        $this->end_controls_section();


        // image
        $this->start_controls_section(
            '_section_content',
            [
                'label' => __( 'Cta Content', 'telnet-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        // image
        $this->add_control(
            'bg_image',
            [
                'label' => __( 'Choose Bg Image', 'telnet-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        // image_1
        $this->add_control(
            'bg_shape_image',
            [
                'label' => __( 'Choose Bg Shape Image', 'telnet-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'design_style' => [ 'style_3' , 'style_4'],
                ],
            ]
        );

        // image 2
        $this->add_control(
            'bg_shape_image_2',
            [
                'label' => __( 'Choose Bg Shape Image', 'telnet-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'design_style' => [ 'style_3', 'style_4'],
                ],
            ]
        );

        // type image or icon
        $this->add_control(
            'type',
            [
                'label'          => __( 'Service Icon', 'telnet-core' ),
                'type'           => Controls_Manager::CHOOSE,
                'label_block'    => false,
                'options'        => [
                    'icon'  => [
                        'title' => __( 'Icon', 'telnet-core' ),
                        'icon'  => 'far fa-smile',
                    ],
                    'image' => [
                        'title' => __( 'Image', 'telnet-core' ),
                        'icon'  => 'fa fa-image',
                    ],
                ],
                'default'        => 'icon',
                'toggle'         => false,
                'style_transfer' => true,
                'condition'      => [
                    'design_style' => 'style_1',
                ],
            ]
        );

        // icon
        $this->add_control(
            'icon',
            [
                'label'       => __( 'Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'default'     => [
                    'value'   => 'fas fa-check',
                    'library' => 'solid',
                ],
                'label_block' => true,
                'condition'   => [
                    'type' => 'icon',
                    'design_style' => 'style_1',
                ],
            ]
        );

        // image
        $this->add_control(
            'list_image',
            [
                'label'       => __( 'Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition'   => [
                    'type' => 'image',
                    'design_style' => 'style_1',
                ],
            ]
        );

        // sub title
        $this->add_control(
            'sub_title',
            [
                'label' => __( 'Title', 'telnet-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'Title', 'telnet-core' ),
                'placeholder' => __( 'Type your title here', 'telnet-core' ),
                'label_block' => true,
                'condition'   => [
                    'design_style' => ['style_2', 'style_3', 'style_4', 'style_5'],
                ],
            ]
        );

        // title
        $this->add_control(
            'title',
            [
                'label' => __( 'Title', 'telnet-core' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __( 'Title', 'telnet-core' ),
                'placeholder' => __( 'Type your title here', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        // description
        $this->add_control(
            'description',
            [
                'label' => __( 'Description', 'telnet-core' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __( 'Description', 'telnet-core' ),
                'placeholder' => __( 'Type your description here', 'telnet-core' ),
                'label_block' => true,
                'condition'   => [
                    'design_style' => ['style_2', 'style_3', 'style_4', 'style_5'],
                ],
            ]
        );

        $this->add_responsive_control(
            'align',
            [
                'label'     => __( 'Alignment', 'telnet-core' ),
                'type'      => Controls_Manager::CHOOSE,
                'options'   => [
                    'left'   => [
                        'title' => __( 'Left', 'telnet-core' ),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'telnet-core' ),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right'  => [
                        'title' => __( 'Right', 'telnet-core' ),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'toggle'    => true,
                'selectors' => [
                    '{{WRAPPER}} .tx-title' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label'   => __( 'Title HTML Tag', 'telnet-core' ),
                'type'    => Controls_Manager::CHOOSE,
                'options' => [
                    'h1' => [
                        'title' => __( 'H1', 'telnet-core' ),
                        'icon'  => 'eicon-editor-h1',
                    ],
                    'h2' => [
                        'title' => __( 'H2', 'telnet-core' ),
                        'icon'  => 'eicon-editor-h2',
                    ],
                    'h3' => [
                        'title' => __( 'H3', 'telnet-core' ),
                        'icon'  => 'eicon-editor-h3',
                    ],
                    'h4' => [
                        'title' => __( 'H4', 'telnet-core' ),
                        'icon'  => 'eicon-editor-h4',
                    ],
                    'h5' => [
                        'title' => __( 'H5', 'telnet-core' ),
                        'icon'  => 'eicon-editor-h5',
                    ],
                    'h6' => [
                        'title' => __( 'H6', 'telnet-core' ),
                        'icon'  => 'eicon-editor-h6',
                    ],
                ],
                'default' => 'h2',
                'toggle'  => false,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_button',
            [
                'label' => __( 'Button', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'enable_icon',
            [
                'label'        => __( 'Enable Icon', 'vistro-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Show', 'vistro-core' ),
                'label_off'    => __( 'Hide', 'vistro-core' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        // type icon or image
        $this->add_control(
            'btn_type',
            [
                'label'          => __( 'Icon', 'telnet-core' ),
                'type'           => Controls_Manager::CHOOSE,
                'label_block'    => false,
                'options'        => [
                    'icon'  => [
                        'title' => __( 'Icon', 'telnet-core' ),
                        'icon'  => 'far fa-smile',
                    ],
                    'image' => [
                        'title' => __( 'Image', 'telnet-core' ),
                        'icon'  => 'fa fa-image',
                    ],
                ],
                'default'        => 'icon',
                'toggle'         => false,
                'style_transfer' => true,
                'condition'      => [
                    'enable_icon' => 'yes',
                ],
            ]
        );

        // image
        $this->add_control(
            'btn_image',
            [
                'label'       => __( 'Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition'   => [
                    'btn_type'        => 'image',
                    'enable_icon' => 'yes',
                ],
            ]
        );

        // icon
        $this->add_control(
            'selected_icon',
            [
                'label'       => __( 'Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'label_block' => true,
                'default'     => [
                    'value'   => 'fas fa-check',
                    'library' => 'solid',
                ],
                'condition'   => [
                    'btn_type'        => 'icon',
                    'enable_icon' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label'       => __( 'Button Text', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Button Text', 'telnet-core' ),
                'placeholder' => __( 'Type your title here', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        // Button link
        $this->add_control(
            'button_link',
            [
                'label'       => __( 'Button Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'telnet-core' ),
                'default'     => [
                    'url' => '#',
                ],
                'show_external' => true,
                'label_block'   => false,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_feature_package_price',
            [
                'label' => __( 'Feature Package Price', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'design_style' => [ 'style_4'],
                ],
            ]
        );

        // CURRENCY SYMBOL
        $this->add_control(
            'currency',
            [
                'label' => __('Currency', 'telnet-core'),
                'type' => Controls_Manager::SELECT,
                'label_block' => false,
                'options' => [
                    '' => __('None', 'telnet-core'),
                    'baht' => '&#3647; ' . _x('Baht', 'Currency Symbol', 'telnet-core'),
                    'bdt' => '&#2547; ' . _x('BD Taka', 'Currency Symbol', 'telnet-core'),
                    'dollar' => '&#36; ' . _x('Dollar', 'Currency Symbol', 'telnet-core'),
                    'euro' => '&#128; ' . _x('Euro', 'Currency Symbol', 'telnet-core'),
                    'franc' => '&#8355; ' . _x('Franc', 'Currency Symbol', 'telnet-core'),
                    'guilder' => '&fnof; ' . _x('Guilder', 'Currency Symbol', 'telnet-core'),
                    'krona' => 'kr ' . _x('Krona', 'Currency Symbol', 'telnet-core'),
                    'lira' => '&#8356; ' . _x('Lira', 'Currency Symbol', 'telnet-core'),
                    'peseta' => '&#8359 ' . _x('Peseta', 'Currency Symbol', 'telnet-core'),
                    'peso' => '&#8369; ' . _x('Peso', 'Currency Symbol', 'telnet-core'),
                    'pound' => '&#163; ' . _x('Pound Sterling', 'Currency Symbol', 'telnet-core'),
                    'real' => 'R$ ' . _x('Real', 'Currency Symbol', 'telnet-core'),
                    'ruble' => '&#8381; ' . _x('Ruble', 'Currency Symbol', 'telnet-core'),
                    'rupee' => '&#8360; ' . _x('Rupee', 'Currency Symbol', 'telnet-core'),
                    'indian_rupee' => '&#8377; ' . _x('Rupee (Indian)', 'Currency Symbol', 'telnet-core'),
                    'shekel' => '&#8362; ' . _x('Shekel', 'Currency Symbol', 'telnet-core'),
                    'won' => '&#8361; ' . _x('Won', 'Currency Symbol', 'telnet-core'),
                    'yen' => '&#165; ' . _x('Yen/Yuan', 'Currency Symbol', 'telnet-core'),
                    'custom' => __('Custom', 'telnet-core'),
                ],
                'default' => 'dollar',
            ]
        );

        $this->add_control(
            'currency_custom',
            [
                'label' => __('Custom Symbol', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'condition' => [
                    'currency' => 'custom',
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        // PRICE
        $this->add_control(
            'price',
            [
                'label' => __('Price', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '9.99',
                'dynamic' => [
                    'active' => true
                ]
            ]
        );

        // PERIOD
        $this->add_control(
            'period',
            [
                'label' => __('Period', 'telnet-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Per Month', 'telnet-core'),
                'dynamic' => [
                    'active' => true
                ],
            ]
        );

        // end
        $this->end_controls_section();



    }

    protected function register_style_controls() {
        // cta bg style
        $this->start_controls_section(
            '_section_style_bg',
            [
                'label' => __( 'Cta Bg', 'telnet-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        // overlay color
        $this->add_control(
            'overlay_color',
            [
                'label' => __( 'Overlay Color', 'telnet-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-ctaSection__styleOne::before' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        // overlay opacity
        $this->add_control(
            'overlay_opacity',
            [
                'label' => __( 'Overlay Opacity', 'telnet-core' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1,
                        'step' => 0.1,
                    ],
                ],
                'default' => [
                    'unit' => 0.6,
                ],
                'selectors' => [
                    '{{WRAPPER}} .tx-ctaSection__styleOne::before' => 'opacity: {{SIZE}};',
                ],
            ]
        );

        // end cta bg style
        $this->end_controls_section();

        $this->start_controls_section(
            '_section_style_title',
            [
                'label' => __( 'HEADING STYLE', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // title color
        $this->add_control(
            'title_color',
            [
                'label'     => __( 'Title Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        // title span color
        $this->add_control(
            'title_span_color',
            [
                'label'     => __( 'Title Span Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-title span' => 'color: {{VALUE}};',
                ],
            ]
        );

        // title padding
        $this->add_responsive_control(
            'title_padding',
            [
                'label'      => __( 'Padding', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // title margin
        $this->add_responsive_control(
            'title_margin',
            [
                'label'      => __( 'Margin', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // title typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typography',
                'label'    => __( 'Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-title',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_style_button',
            [
                'label' => __( 'BUTTON STYLE', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // icon gap
        $this->add_responsive_control(
            'icon_gap',
            [
                'label'      => __( 'Icon Gap', 'telnet-core' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .tx-icon' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
                'condition'  => [
                    'enable_icon' => 'yes',
                ],
            ]
        );

        // typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'button_typography',
                'label'    => __( 'Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-button',
            ]
        );

        // Border radious
        $this->add_responsive_control(
            'button_border_radius',
            [
                'label'      => __( 'Border Radius', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Group_Control_Border
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'button_border',
                'label'    => __( 'Border', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-button',
            ]
        );

        // padding
        $this->add_responsive_control(
            'button_padding',
            [
                'label'      => __( 'Padding', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // margin
        $this->add_responsive_control(
            'button_margin',
            [
                'label'      => __( 'Margin', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs('_tabs_button');

        $this->start_controls_tab(
            '_tab_button_normal',
            [
                'label' => __( 'Normal', 'telnet-core' ),
            ]
        );

        // color
        $this->add_control(
            'button_color',
            [
                'label'     => __( 'Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-button' => 'color: {{VALUE}};',
                ],
            ]
        );

        // background color
        $this->add_control(
            'button_bg_color',
            [
                'label'     => __( 'Background Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-button' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            '_tab_button_hover',
            [
                'label' => __( 'Hover', 'telnet-core' ),
            ]
        );

        // color
        $this->add_control(
            'button_color_hover',
            [
                'label'     => __( 'Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-button:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        // background color
        $this->add_control(
            'button_bg_color_hover',
            [
                'label'     => __( 'Background Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-button:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
    }


    private static function get_currency_symbol($symbol_name)
    {
        $symbols = [
            'baht' => '&#3647;',
            'bdt' => '&#2547;',
            'dollar' => '&#36;',
            'euro' => '&#128;',
            'franc' => '&#8355;',
            'guilder' => '&fnof;',
            'indian_rupee' => '&#8377;',
            'pound' => '&#163;',
            'peso' => '&#8369;',
            'peseta' => '&#8359',
            'lira' => '&#8356;',
            'ruble' => '&#8381;',
            'shekel' => '&#8362;',
            'rupee' => '&#8360;',
            'real' => 'R$',
            'krona' => 'kr',
            'won' => '&#8361;',
            'yen' => '&#165;',
        ];

        return isset($symbols[$symbol_name]) ? $symbols[$symbol_name] : '';
    }


    protected function render() {

        $settings = $this->get_settings_for_display();
        $dir = dirname( __FILE__ );
        $style = !empty($settings['design_style']) ? $settings['design_style'] : 'style_1';

        $this->add_inline_editing_attributes( 'title', 'basic' );
        $this->add_render_attribute( 'title', 'class', 'tx-title' );
        $this->add_render_attribute( 'title2', 'class', 'tna-title-1 txa-split-text txa-split-in-up' );
        $this->add_render_attribute( 'title3', 'class', 'tna-title-2 txa-split-text txa-split-in-up' );
        $this->add_render_attribute( 'title4', 'class', 'tna-title-2 font-56  txa-split-text txa-split-in-up' );

        $title = elh_element_kses_basic( $settings['title'] );

        switch ($style) {
            case 'style_5':
                include $dir . '/views/view-5.php';
                break;
            case 'style_4':
                include $dir . '/views/view-4.php';
                break;
            case 'style_3':
                include $dir . '/views/view-3.php';
                break;
            case 'style_2':
                include $dir . '/views/view-2.php';
                break;
            default:
                include $dir . '/views/view-1.php';
        }
    }
}
