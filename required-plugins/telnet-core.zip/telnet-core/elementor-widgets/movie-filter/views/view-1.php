<?php if ( !empty($terms_ids) && count( $posts ) !== 0 ) : ?>
<div class="tx-movieFilterWrapper">
    <div class="container">
        <?php if(!empty( $filter_list )) : ?>
        <div class="row">
            <div class="col-xl-12">
                <ul class="tx-movieFilters d-flex align-items-center justify-content-center list-unstyled" data-txMovieFilters>
                    <?php foreach ( $filter_list as $list ):
                        $active = ( $list->slug == 'all' ) ? 'active' : '';
                    ?>
                    <li data-filter=".<?php echo esc_attr( $list->slug ); ?>"><?php echo esc_html( $list->name ); ?></li>
                    <?php endforeach;?>
                </ul>
            </div>
        </div>
        <?php endif; ?>
        <div class="row tx-column-gap-20 mt-15" data-txGrid>
            <?php
                if ( have_posts() ) : while ( have_posts() ) : the_post();
                $item_classes = '';
                $item_cat_names = '';
                $item_cats = get_the_terms( get_the_id(), $taxonomy );
                if( !empty($item_cats) ):
                    $count = count($item_cats) - 1;
                    foreach($item_cats as $key => $item_cat) {
                        $item_classes .= $item_cat->slug . ' ';
                        $item_cat_names .= ( $count > $key ) ? $item_cat->name  . ', ' : $item_cat->name;
                    }
                endif;

                $id = get_the_id();

                $telnet_movie_meta = get_post_meta($id, 'telnet_movie_meta', true) ? get_post_meta($id, 'telnet_movie_meta', true) : [];
                $movie_year_label = array_key_exists('movie_year_label', $telnet_movie_meta) ? $telnet_movie_meta['movie_year_label'] : '';
                $movie_release_year = array_key_exists('movie_release_year', $telnet_movie_meta) ? $telnet_movie_meta['movie_release_year'] : '';
                $movie_rating_label = array_key_exists('movie_rating_label', $telnet_movie_meta) ? $telnet_movie_meta['movie_rating_label'] : '';
                $movie_rating = array_key_exists('movie_rating', $telnet_movie_meta) ? $telnet_movie_meta['movie_rating'] : '';
                $movie_video_link = array_key_exists('movie_video_link', $telnet_movie_meta) ? $telnet_movie_meta['movie_video_link'] : '';
            ?>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mt-20 <?php echo esc_attr($item_classes); ?>" data-txGridItem>
                <div class="tx-movieBlock tx-movieBlock__styleTwo position-relative">
                    <?php if ( has_post_thumbnail() ): ?>
                    <div class="tx-thumb position-relative">
                        <img class="w-100" src="<?php echo get_the_post_thumbnail_url(); ?>" alt="">
                        <?php if(!empty( $movie_video_link )) : ?>
                        <a href="<?php echo esc_url($movie_video_link); ?>" data-rel="lightcase" class="tx-round-btn position-absolute">
                            <i class="fas fa-play"></i>
                        </a>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                    <div class="tx-content position-absolute">
                        <h6 class="tx-title"><a href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a></h6>
                        <div class="txMeta-info d-flex align-items-center justify-content-between">
                            <?php if(!empty( $movie_year_label || $movie_release_year )) : ?>
                            <p>
                                <?php if(!empty( $movie_year_label )) : ?>
                                <span class="tx-label"><?php echo esc_html($movie_year_label); ?></span>
                                <?php endif; ?>

                                <?php if(!empty( $movie_release_year )) : ?>
                                <span class="tx-text"><?php echo esc_html($movie_release_year); ?></span>
                                <?php endif; ?>
                            </p>
                            <?php endif; ?>

                            <?php if(!empty( $movie_rating_label || $movie_rating )) : ?>
                            <p>
                                <?php if(!empty( $movie_rating_label )) : ?>
                                <span class="tx-label"><i class="fas fa-star"></i> <?php echo esc_html($movie_rating_label); ?></span>
                                <?php endif; ?>

                                <?php if(!empty( $movie_rating )) : ?>
                                <span class="tx-text"><?php echo esc_html($movie_rating); ?></span>
                                <?php endif; ?>
                            </p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; wp_reset_query(); endif; ?>
        </div>
    </div>
</div>
<?php endif; ?>