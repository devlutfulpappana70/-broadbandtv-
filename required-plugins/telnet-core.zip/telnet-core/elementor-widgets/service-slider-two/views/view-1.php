<?php

$this->add_inline_editing_attributes( 'title', 'basic' );
$this->add_render_attribute( 'title', 'class', 'sec-title-five_heading' );
$title = elh_element_kses_basic( $settings['title'] );
if($settings['slider_navigation_on_off'] == 'yes') {
    $nav_class = 'hasNav';
} else {
    $nav_class = 'noNav';
}
?>
<section class="service-one">
    <div class="auto-container">
        <div class="row clearfix">
            <!-- Title Column -->
            <div class="service-one_title-column col-lg-5 col-md-12 col-sm-12">
                <div class="service-one_title-outer">
                    <!-- Sec Title Five -->
                    <div class="sec-title-five">
                        <?php if(!empty( $settings['sub_title'] )) : ?>
                        <div class="sec-title-five_title"><?php echo elh_element_kses_intermediate($settings['sub_title']); ?></div>
                        <?php endif; ?>

                        <?php
                            printf('<%1$s %2$s>%3$s</%1$s>',
                                tag_escape($settings['title_tag']),
                                $this->get_render_attribute_string('title'),
                                $title
                            );
                        ?>

                        <?php if(!empty($settings['description'])) : ?>
                        <div class="sec-title-five_text"><?php echo wp_kses($settings['description'], true)?></div>
                        <?php endif; ?>
                    </div>
                    <div class="service-one_button">
                        <a href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>" class="theme-btn btn-style-eighteen">
                            <?php if(!empty( $settings['button_text'] )) : ?>
                            <span class="txt"><?php echo elh_element_kses_intermediate($settings['button_text']); ?></span>
                            <?php endif; ?>

                            <?php \Elementor\Icons_Manager::render_icon( $settings['btn_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                        </a>
                    </div>
                </div>
            </div>
            <!-- Carousel Column -->
            <div class="service-one_carousel-column col-lg-7 col-md-12 col-sm-12">
                <div class="service-one_carousel-outer <?php echo esc_attr($nav_class); ?>">

                    <div class="services_carousel owl-carousel owl-theme">

                        <?php foreach( $settings['services'] as $list ) : ?>
                        <div class="slide">
                            <!-- Service Block One -->
                            <div class="service-block_one">
                                <div class="service-block_one-inner">
                                    <div class="service-block_one-content">
                                        <?php if( $list['enable_icon'] === 'yes' ) : ?>
                                        <div class="service-block_one-icon">
                                            <?php if($list['icon_type'] == 'icon') : ?>
                                                <?php \Elementor\Icons_Manager::render_icon( $list['service_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                            <?php else : ?>
                                                <img src="<?php echo esc_url($list['service_image']['url']); ?>" alt="" />
                                            <?php endif; ?>
                                        </div>
                                        <?php endif; ?>

                                        <?php if(!empty( $list['title'] )) : ?>
                                        <h4 class="service-block_one-heading">
                                            <?php echo elh_element_kses_intermediate($list['title']); ?>
                                        </h4>
                                        <?php endif; ?>

                                        <?php if(!empty( $list['description'] )) : ?>
                                        <div class="service-block_one-text">
                                            <?php echo elh_element_kses_intermediate($list['description']); ?>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <!-- OverlayBox -->
                                    <div class="service-block_one-overlay">
                                        <?php if(!empty( $list['bg_shape']['url'] )) : ?>
                                        <div class="service-block_one-image-layer" style="background-image: url(<?php echo esc_url($list['bg_shape']['url']); ?>)"></div>
                                        <?php endif; ?>

                                        <?php if( $list['enable_icon'] === 'yes' ) : ?>
                                        <div class="service-block_one-icon">
                                            <?php if($list['icon_type'] == 'icon') : ?>
                                                <?php \Elementor\Icons_Manager::render_icon( $list['service_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                            <?php else : ?>
                                                <img src="<?php echo esc_url($list['service_image']['url']); ?>" alt="" />
                                            <?php endif; ?>
                                        </div>
                                        <?php endif; ?>

                                        <?php if(!empty( $list['title'] )) : ?>
                                        <h4 class="service-block_one-heading">
                                            <?php echo elh_element_kses_intermediate($list['title']); ?>
                                        </h4>
                                        <?php endif; ?>

                                        <?php if(!empty( $list['description'] )) : ?>
                                        <div class="service-block_one-text">
                                            <?php echo elh_element_kses_intermediate($list['description']); ?>
                                        </div>
                                        <?php endif; ?>

                                        <?php if(!empty( $list['btn_label'] )) : ?>
                                        <a class="service-block_one-more" href="<?php echo esc_url($list['list_link']['url']); ?>">
                                            <?php echo elh_element_kses_intermediate($list['btn_label']); ?>
                                        </a>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>