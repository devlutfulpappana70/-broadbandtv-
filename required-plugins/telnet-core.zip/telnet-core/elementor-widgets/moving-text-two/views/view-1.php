<section class="tna-marquee-2-area">
    <div class="tna-marquee-2-wrap">
        <?php if ( !empty( $settings['info_items'] ) ): ?>
        <div class="tna-marquee-2-content-1-bg">
            <div class="tna-marquee-2-content-1">
                <div class="tna-marquee-2-content-1-item">
                    <?php foreach ( $settings['info_items'] as $list ): ?>
                    <h5 class="text" >
                        <img class="icon" src="<?php echo esc_url($list['info_image']['url']); ?>" alt="">
                        <?php echo elh_element_kses_intermediate( $list['info_text'] ); ?>
                    </h5>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php if ( !empty( $settings['info_items_2'] ) ): ?>
        <div class="tna-marquee-2-content-2-bg">
            <div class="tna-marquee-2-content-2">
                <div class="tna-marquee-2-content-2-item">
                    <?php foreach ( $settings['info_items_2'] as $list ): ?>
                    <h5 class="text" >
                        <img class="icon" src="<?php echo esc_url($list['info_image']['url']); ?>" alt="">
                        <?php echo elh_element_kses_intermediate( $list['info_text'] ); ?>
                    </h5>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

    </div>
</section>