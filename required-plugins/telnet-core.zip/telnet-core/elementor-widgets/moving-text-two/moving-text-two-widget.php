<?php

namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
use \Elementor\Core\Schemes\Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;

defined( 'ABSPATH' ) || die();

class Moving_Text_Two extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name() {
        return 'moving_text_two';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title() {
        return __( 'Moving Text Two', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/gradient-heading/';
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-t-letter';
    }

    public function get_keywords() {
        return ['btn', 'lists', 'info', 'info lists'];
    }

    protected function register_content_controls() {

        //Settings
        $this->start_controls_section(
            '_section_settings',
            [
                'label' => __( 'Settings', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'design_style',
            [
                'label'              => __( 'Design Style', 'telnet-core' ),
                'type'               => Controls_Manager::SELECT,
                'options'            => [
                    'style_1' => __( 'Style 1', 'telnet-core' ),
                ],
                'default'            => 'style_1',
                'frontend_available' => true,
                'style_transfer'     => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_list_1',
            [
                'label' => __( 'Lists 1', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        // list text
        $repeater->add_control(
            'info_text',
            [
                'label'       => __( 'List Text', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'List Text', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        // image
        $repeater->add_control(
            'info_image',
            [
                'label'       => __( 'List Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'info_items',
            [
                'label'       => __( 'Info Lists', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [
                    [
                        'info_text' => __( 'Info Text', 'telnet-core' ),
                    ],
                ],
                'title_field' => '{{{ info_text }}}',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_list_2',
            [
                'label' => __( 'Lists 2', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        // list text
        $repeater->add_control(
            'info_text',
            [
                'label'       => __( 'List Text', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'List Text', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        // image
        $repeater->add_control(
            'info_image',
            [
                'label'       => __( 'List Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'info_items_2',
            [
                'label'       => __( 'Info Lists', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [
                    [
                        'info_text' => __( 'Info Text', 'telnet-core' ),
                    ],
                ],
                'title_field' => '{{{ info_text }}}',
            ]
        );

        $this->end_controls_section();

    }

    protected function register_style_controls() {

    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $dir = dirname( __FILE__ );
        $style = !empty($settings['design_style']) ? $settings['design_style'] : 'style_1';

        switch ($style) {
            case 'style_2':
                include $dir . '/views/view-2.php';
                break;
            default:
                include $dir . '/views/view-1.php';
        }
    }
}
