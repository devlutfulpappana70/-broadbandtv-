<?php
namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Utils;

defined( 'ABSPATH' ) || die();

class Service_Grid extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'service_grid';
    }

    /**
     * Get widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Service Grid', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/icon-box/';
    }

    /**
     * Get widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-preview-medium';
    }

    public function get_keywords() {
        return ['service', 'gird', 'icon'];
    }

    public function elh_element_animations() {
        return [
            'none'              => __( 'None', 'telnet-core' ),
            'fadeIn'            => __( 'Fade In', 'telnet-core' ),
            'fadeInUp'          => __( 'Fade In Up', 'telnet-core' ),
            'fadeInDown'        => __( 'Fade In Down', 'telnet-core' ),
            'fadeInLeft'        => __( 'Fade In Left', 'telnet-core' ),
            'fadeInRight'       => __( 'Fade In Right', 'telnet-core' ),
            'fadeInUpBig'       => __( 'Fade In Up Big', 'telnet-core' ),
            'fadeInDownBig'     => __( 'Fade In Down Big', 'telnet-core' ),
            'fadeInLeftBig'     => __( 'Fade In Left Big', 'telnet-core' ),
            'fadeInRightBig'    => __( 'Fade In Right Big', 'telnet-core' ),
            'bounceIn'          => __( 'Bounce In', 'telnet-core' ),
            'bounceInUp'        => __( 'Bounce In Up', 'telnet-core' ),
            'bounceInDown'      => __( 'Bounce In Down', 'telnet-core' ),
            'bounceInLeft'      => __( 'Bounce In Left', 'telnet-core' ),
            'bounceInRight'     => __( 'Bounce In Right', 'telnet-core' ),
            'rotateIn'          => __( 'Rotate In', 'telnet-core' ),
            'rotateInUpLeft'    => __( 'Rotate In Up Left', 'telnet-core' ),
            'rotateInDownLeft'  => __( 'Rotate In Down Left', 'telnet-core' ),
            'rotateInUpRight'   => __( 'Rotate In Up Right', 'telnet-core' ),
            'rotateInDownRight' => __( 'Rotate In Down Right', 'telnet-core' ),
            'lightSpeedIn'      => __( 'Light Speed In', 'telnet-core' ),
            'rollIn'            => __( 'Roll In', 'telnet-core' ),
            'zoomIn'            => __( 'Zoom In', 'telnet-core' ),
            'zoomInUp'          => __( 'Zoom In Up', 'telnet-core' ),
            'zoomInDown'        => __( 'Zoom In Down', 'telnet-core' ),
            'zoomInLeft'        => __( 'Zoom In Left', 'telnet-core' ),
            'zoomInRight'       => __( 'Zoom In Right', 'telnet-core' ),
            'slideInUp'         => __( 'Slide In Up', 'telnet-core' ),
            'slideInDown'       => __( 'Slide In Down', 'telnet-core' ),
            'slideInLeft'       => __( 'Slide In Left', 'telnet-core' ),
            'slideInRight'      => __( 'Slide In Right', 'telnet-core' ),
        ];
    }

    protected function register_content_controls() {

        $this->start_controls_section(
            '_section_design_title',
            [
                'label' => __( 'Design Style', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'design_style',
            [
                'label'              => __( 'Design Style', 'telnet-core' ),
                'type'               => Controls_Manager::SELECT,
                'options'            => [
                    'style_1' => __( 'Style 1', 'telnet-core' ),
                    'style_2' => __( 'Style 2', 'telnet-core' ),
                    'style_3' => __( 'Style 3', 'telnet-core' ),
                    'style_4' => __( 'Style 4', 'telnet-core' ),
                    'style_5' => __( 'Style 5', 'telnet-core' ),
                    'style_6' => __( 'Style 6', 'telnet-core' ),
                ],
                'default'            => 'style_1',
                'frontend_available' => true,
                'style_transfer'     => true,
            ]
        );

        // anim name list for animation
        $this->add_control(
            'anim_name',
            [
                'label'   => __( 'Animation Name', 'telnet-core' ),
                'type'    => Controls_Manager::SELECT,
                'options' => $this->elh_element_animations(),
                'default' => 'fadeInUp',
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        // anim delay
        $this->add_control(
            'anim_delay',
            [
                'label'   => __( 'Animation Delay', 'telnet-core' ),
                'type'    => Controls_Manager::TEXT,
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        // anim duration
        $this->add_control(
            'anim_duration',
            [
                'label'   => __( 'Animation Duration', 'telnet-core' ),
                'type'    => Controls_Manager::TEXT,
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $this->end_controls_section();

        // SERVICES
        $this->start_controls_section(
            '_section_service_box',
            [
                'label' => __( 'Services Boxs', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'type',
            [
                'label'          => __( 'Service Icon', 'telnet-core' ),
                'type'           => Controls_Manager::CHOOSE,
                'label_block'    => false,
                'options'        => [
                    'icon'  => [
                        'title' => __( 'Icon', 'telnet-core' ),
                        'icon'  => 'far fa-smile',
                    ],
                    'image' => [
                        'title' => __( 'Image', 'telnet-core' ),
                        'icon'  => 'fa fa-image',
                    ],
                ],
                'default'        => 'icon',
                'toggle'         => false,
                'style_transfer' => true,
                'condition'      => [
                    'design_style' => ['style_1', 'style_3'],
                ],
            ]
        );

        $this->add_control(
            'active_item',
            [
                'label'        => esc_html__( 'Active', 'textdomain' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'textdomain' ),
                'label_off'    => esc_html__( 'Hide', 'textdomain' ),
                'return_value' => 'yes',
                'default'      => 'no',
                'condition'    => [
                    'design_style' => ['style_5'],
                ],
            ]
        );

        $this->add_control(
            'image',
            [
                'label'     => __( 'Service Icon', 'telnet-core' ),
                'type'      => Controls_Manager::MEDIA,
                'default'   => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'type'         => 'image',
                    'design_style' => ['style_1', 'style_3', 'style_4'],
                ],
                'dynamic'   => [
                    'active' => true,
                ],
            ]
        );

        if ( elh_element_is_elementor_version( '<', '2.6.0' ) ) {
            $this->add_control(
                'icon',
                [
                    'label'       => __( 'Icon', 'telnet-core' ),
                    'label_block' => true,
                    'type'        => Controls_Manager::ICON,
                    'options'     => elh_element_get_elh_element_icons(),
                    'default'     => 'fa fa-smile-o',
                    'condition'   => [
                        'type'         => 'icon',
                        'design_style' => ['style_1', 'style_3'],
                    ],
                ]
            );
        } else {
            $this->add_control(
                'selected_icon',
                [
                    'type'             => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block'      => true,
                    'default'          => [
                        'value'   => 'fal fa-long-arrow-right',
                        'library' => 'fa-solid',
                    ],
                    'condition'        => [
                        'type'         => 'icon',
                        'design_style' => ['style_1', 'style_3'],
                    ],
                ]
            );
        }

        $this->add_control(
            'service_thumb',
            [
                'label'   => __( 'Service Image', 'telnet-core' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        // Group_Control_Image_Size
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name'      => 'thumbnail',
                'default'   => 'medium_large',
                'separator' => 'none',
                'exclude'   => [
                    'full',
                    'custom',
                    'large',
                    'shop_catalog',
                    'shop_single',
                    'shop_thumbnail',
                ],
            ]
        );

        // image shape
        $this->add_control(
            'shape',
            [
                'label'     => __( 'Shape Image', 'telnet-core' ),
                'type'      => Controls_Manager::MEDIA,
                'default'   => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic'   => [
                    'active' => true,
                ],
                'condition' => [
                    'design_style' => ['style_3'],
                ],
            ]
        );

        // cercle_box_text
        $this->add_control(
            'cercle_box_text',
            [
                'label'       => __( 'Cercle Box Text', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __( 'Super 20 off', 'telnet-core' ),
                'placeholder' => __( 'Type Cercle Box Text', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
                'condition'   => [
                    'design_style' => ['style_2'],
                ],
            ]
        );

        $this->add_control(
            'title',
            [
                'label'       => __( 'Service Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __( 'Service title', 'telnet-core' ),
                'placeholder' => __( 'Type Icon Box Title', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );

        // short_description
        $this->add_control(
            'short_description',
            [
                'label'       => __( 'Short Description', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'default'     => __( 'Short Description', 'telnet-core' ),
                'placeholder' => __( 'Type Short Description', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
                'condition'   => [
                    'design_style' => ['style_2', 'style_5', 'style_6'],
                ],
            ]
        );

        if ( elh_element_is_elementor_version( '<', '2.6.0' ) ) {
            $this->add_control(
                'button_icon',
                [
                    'label'     => __( 'Button Icon', 'telnet-core' ),
                    'type'      => Controls_Manager::ICON,
                    'options'   => elh_element_get_elh_element_icons(),
                    'default'   => 'fal fa-long-arrow-right',
                    'condition' => [
                        'design_style' => ['style_1', 'style_2', 'style_6'],
                    ],
                ]
            );
        } else {
            $this->add_control(
                'selected_button_icon',
                [
                    'type'             => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'default'          => [
                        'value'   => 'fal fa-long-arrow-right',
                        'library' => 'fa-solid',
                    ],
                    'condition'        => [
                        'design_style' => ['style_1', 'style_2', 'style_6'],
                    ],
                ]
            );
        }

        // button_text
        $this->add_control(
            'button_text',
            [
                'label'       => __( 'Button Text', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __( 'Read More', 'telnet-core' ),
                'placeholder' => __( 'Type Button Text', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
                'condition'   => [
                    'design_style' => ['style_2', 'style_3', 'style_4'],
                ],
            ]
        );

        // button_link
        $this->add_control(
            'button_link',
            [
                'label'         => __( 'Button Link', 'telnet-core' ),
                'type'          => Controls_Manager::URL,
                'placeholder'   => __( 'https://your-link.com', 'telnet-core' ),
                'show_external' => true,
                'default'       => [
                    'url'         => '#',
                    'is_external' => true,
                    'nofollow'    => true,
                ],
                'dynamic'       => [
                    'active' => true,
                ],
            ]
        );

        $this->end_controls_section();

        // feature_lists_2
        $this->start_controls_section(
            '_section_design_title_2',
            [
                'label'     => __( 'Feature Boxs', 'telnet-core' ),
                'tab'       => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'design_style' => ['style_6'],
                ],
            ]
        );

        $repeater = new \Elementor\Repeater();

        // icon
        $repeater->add_control(
            'feature_icon',
            [
                'label'       => __( 'Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'default'     => [
                    'value'   => 'fas fa-star',
                    'library' => 'solid',
                ],
                'label_block' => true,
            ]
        );

        // list text
        $repeater->add_control(
            'title',
            [
                'label'       => __( 'Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'List Text', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'feature_lists_2',
            [
                'label'       => __( 'Feature Lists', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ title }}}',
            ]
        );

        $this->end_controls_section();

    }

    protected function register_style_controls() {

        $this->start_controls_section(
            '_section_style_description',
            [
                'label'     => __( 'DESCRIPTION STYLE', 'telnet-core' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'design_style' => 'style_5',
                ],
            ]
        );

        // description color
        $this->add_control(
            'box_border_color',
            [
                'label'     => __( 'Box Border Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tel-service-item-2:before, .tel-service-item-2:after' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'           => 'check-active-shape',
                'types'          => ['gradient'],
                'selector'       => '{{WRAPPER}} .tel-service-item-2:after',
                'fields_options' => [
                    'background' => [
                        'label'     => esc_html__( 'Box Active BG COlor', 'invite-plugin' ),
                        'separator' => 'before',
                    ],
                ],
            ]
        );

        $this->end_controls_section();

    }

    /**
     * Render widget output on the frontend.
     *
     * Used to generate the final HTML displayed on the frontend.
     *
     * Note that if skin is selected, it will be rendered by the skin itself,
     * not the widget.
     *
     * @since 1.0.0
     * @access public
     */
    protected function render() {

        $settings = $this->get_settings_for_display();
        $dir = dirname( __FILE__ );
        $style = !empty( $settings['design_style'] ) ? $settings['design_style'] : 'style_1';

        switch ( $style ) {
        case 'style_6':
            include $dir . '/views/view-6.php';
            break;
        case 'style_5':
            include $dir . '/views/view-5.php';
            break;
        case 'style_4':
            include $dir . '/views/view-4.php';
            break;
        case 'style_3':
            include $dir . '/views/view-3.php';
            break;
        case 'style_2':
            include $dir . '/views/view-2.php';
            break;
        default:
            include $dir . '/views/view-1.php';
        }
    }

}