<?php
    if (!empty($settings['service_thumb']['id'])) {
        $service_thumb = wp_get_attachment_image_url($settings['service_thumb']['id'], $settings['thumbnail_size']);
    }
?>
<div class="tna-best-services-item flat_3 wow <?php echo $settings['anim_name'] ? esc_attr($settings['anim_name']) : ''; ?>"
data-wow-delay="<?php echo $settings['anim_delay'] ? esc_attr($settings['anim_delay']) : ''; ?>"
data-wow-duration="<?php echo $settings['anim_duration'] ? esc_attr($settings['anim_duration']) : ''; ?>">
    <?php if(!empty( $service_thumb )) : ?>
    <div class="main-img tna-img-cover">
        <img src="<?php echo esc_url($service_thumb); ?>" alt="">
    </div>
    <?php endif; ?>
    <div class="contenet-wrap-2">
        <?php if(!empty( $settings['title'] )) : ?>
        <h4 class="tna-heading-2 title">
            <a class="tna-inherit" href="<?php echo $settings['button_link']['url'] ? esc_url( $settings['button_link']['url'] ) : '';  ?>"><?php echo elh_element_kses_intermediate( $settings['title'] ); ?></a>
        </h4>
        <?php endif; ?>

        <?php if(!empty( $settings['button_link']['url'] )) : ?>
        <a href="<?php echo $settings['button_link']['url'] ? esc_url( $settings['button_link']['url'] ) : '';  ?>" class="bs3-btn">
            <?php elh_element_render_icon( $settings, 'button_icon', 'selected_button_icon' ); ?>
        </a>
        <?php endif; ?>
    </div>
    <div class="contenet-wrap">
        <div class="left">
            <?php if(!empty( $settings['title'] )) : ?>
            <h4 class="tna-heading-2 title">
                <a class="tna-inherit" href="<?php echo $settings['button_link']['url'] ? esc_url( $settings['button_link']['url'] ) : '';  ?>">
                <?php echo elh_element_kses_intermediate( $settings['title'] ); ?></a>
            </h4>
            <?php endif; ?>
            <?php if(!empty( $settings['short_description'] )) : ?>
            <p class="tna-para-2 disc"><?php echo elh_element_kses_intermediate( $settings['short_description'] ); ?></p>
            <?php endif; ?>

            <?php if(!empty( $settings['feature_lists_2'] )) : ?>
            <ul class="list-item list-unstyled">
                <?php foreach($settings['feature_lists_2'] as $list ) : ?>
                <li>
                    <?php \Elementor\Icons_Manager::render_icon( $list['feature_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                    <?php echo elh_element_kses_intermediate($list['title']); ?>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
        </div>

        <?php if(!empty( $settings['button_link']['url'] )) : ?>
        <div class="right">
            <a href="<?php echo $settings['button_link']['url'] ? esc_url( $settings['button_link']['url'] ) : '';  ?>" class="bs3-btn">
                <?php elh_element_render_icon( $settings, 'button_icon', 'selected_button_icon' ); ?>
            </a>
        </div>
        <?php endif; ?>
    </div>
</div>