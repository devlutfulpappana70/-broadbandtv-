<div class="wow <?php echo $settings['anim_name'] ? esc_attr($settings['anim_name']) : ''; ?>"
data-wow-delay="<?php echo $settings['anim_delay'] ? esc_attr($settings['anim_delay']) : ''; ?>"
data-wow-duration="<?php echo $settings['anim_duration'] ? esc_attr($settings['anim_duration']) : ''; ?>">
    <div class="tel-service-item-2 <?php if($settings['active_item'] == 'yes'):?> active <?php endif;?> text-center position-relative">
        <div class="service-icon d-flex justify-content-center align-items-center">
            <img src="<?php echo esc_url($settings['service_thumb']['url']);?>" alt="">
        </div>
        <div class="service-text">
            <h3><a href="<?php echo esc_url($settings['button_link']['url']);?>"><?php echo wp_kses($settings['title'], true)?></a></h3>
            <p><?php echo wp_kses($settings['short_description'], true)?></p>
        </div>
    </div>
</div>