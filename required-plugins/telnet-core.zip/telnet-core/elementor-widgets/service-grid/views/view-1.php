<?php
    if (!empty($settings['service_thumb']['id'])) {
        $service_thumb = wp_get_attachment_image_url($settings['service_thumb']['id'], $settings['thumbnail_size']);
    }
?>
<div class="wow <?php echo $settings['anim_name'] ? esc_attr($settings['anim_name']) : ''; ?>"
data-wow-delay="<?php echo $settings['anim_delay'] ? esc_attr($settings['anim_delay']) : ''; ?>"
data-wow-duration="<?php echo $settings['anim_duration'] ? esc_attr($settings['anim_duration']) : ''; ?>">
    <div class="tx-serviceBox tx-serviceBox__styleOne position-relative">
        <?php if ( ! empty( $settings['button_icon'] ) || ! empty( $settings['selected_button_icon']['value'] ) ) : ?>
        <a href="<?php echo $settings['button_link']['url'] ? esc_url( $settings['button_link']['url'] ) : '';  ?>" class="tx-buttonCercle position-absolute start-50 top-50 translate-middle">
            <?php elh_element_render_icon( $settings, 'button_icon', 'selected_button_icon' ); ?>
        </a>
        <?php endif; ?>

        <div class="tx-thumb">
            <?php if(!empty( $service_thumb )) : ?>
            <img src="<?php echo esc_url($service_thumb); ?>" alt="">
            <?php endif; ?>
        </div>
        <div class="tx-content">
            <div class="tx-icon">
                <?php if ($settings['type'] === 'image' && ($settings['image']['url'] || $settings['image']['id'])) :
                    $this->get_render_attribute_string('image');
                    $settings['hover_animation'] = 'disable-animation'; ?>
                    <?php echo Group_Control_Image_Size::get_attachment_image_html($settings, 'thumbnail', 'image'); ?>
                <?php elseif (!empty($settings['icon']) || !empty($settings['selected_icon']['value'])) : ?>
                    <?php elh_element_render_icon($settings, 'icon', 'selected_icon'); ?>
                <?php endif; ?>
            </div>
            <h4 class="tx-title mt-15">
                <a href="<?php echo $settings['button_link']['url'] ? esc_url( $settings['button_link']['url'] ) : '';  ?>">
                    <?php echo elh_element_kses_intermediate( $settings['title'] ); ?>
                </a>
            </h4>
        </div>
    </div>
</div>