<?php
    if (!empty($settings['service_thumb']['id'])) {
        $service_thumb = wp_get_attachment_image_url($settings['service_thumb']['id'], 'full');
    }
?>
<div class="wow <?php echo $settings['anim_name'] ? esc_attr($settings['anim_name']) : ''; ?>"
data-wow-delay="<?php echo $settings['anim_delay'] ? esc_attr($settings['anim_delay']) : ''; ?>"
data-wow-duration="<?php echo $settings['anim_duration'] ? esc_attr($settings['anim_duration']) : ''; ?>">
<div class="tx-serviceBox tx-serviceBox__styleTwo position-relative">
    <div class="tx-thumb">
        <?php if(!empty( $service_thumb )) : ?>
        <img src="<?php echo esc_url($service_thumb); ?>" alt="">
        <?php endif; ?>

        <div class="tx-cercleBadgeWrapper position-absolute tx-uppercase text-center tx-z1">
            <span class="tx-cercleBadge position-relative">
                <?php echo elh_element_kses_intermediate($settings['cercle_box_text']); ?>
            </span>
        </div>
    </div>
    <div class="tx-content text-center pt-25 position-relative">
        <h4 class="tx-title">
            <a href="<?php echo $settings['button_link']['url'] ? esc_url( $settings['button_link']['url'] ) : '';  ?>">
                <?php echo elh_element_kses_intermediate( $settings['title'] ); ?>
            </a>
        </h4>

        <?php if(!empty( $settings['short_description'] )) : ?>
        <p class="tx-excerpt">
            <?php echo elh_element_kses_intermediate( $settings['short_description'] ); ?>
        </p>
        <?php endif; ?>

        <?php if ( ! empty( $settings['button_icon'] ) || ! empty( $settings['selected_button_icon']['value'] ) || $settings['button_text'] ) : ?>
        <a href="<?php echo $settings['button_link']['url'] ? esc_url( $settings['button_link']['url'] ) : '';  ?>" class="tx-inline-btn tx-inline-btn__styleTheme position-absolute bottom-0 start-50 translate-middle-x">
            <?php echo $settings['button_text'] ? elh_element_kses_basic( $settings['button_text'] ) : ''; ?>
            <?php elh_element_render_icon( $settings, '', 'selected_button_icon' ); ?>
        </a>
        <?php endif; ?>
    </div>
</div>
</div>