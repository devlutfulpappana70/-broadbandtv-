<div class="wow <?php echo $settings['anim_name'] ? esc_attr($settings['anim_name']) : ''; ?>"
data-wow-delay="<?php echo $settings['anim_delay'] ? esc_attr($settings['anim_delay']) : ''; ?>"
data-wow-duration="<?php echo $settings['anim_duration'] ? esc_attr($settings['anim_duration']) : ''; ?>">
    <div class="tel-service-item position-relative">
        <div class="service_more">
            <a class="d-flex justify-content-between align-items-center" href="<?php echo $settings['button_link']['url'] ? esc_url( $settings['button_link']['url'] ) : '';  ?>">
                <?php echo elh_element_kses_intermediate( $settings['button_text'] ); ?>
                <i class="fas fa-long-arrow-right"></i></a>
        </div>
        <?php if(!empty( $settings['service_thumb']['url'] )) : ?>
        <div class="service-img position-relative">
            <img src="<?php echo esc_url($settings['service_thumb']['url']); ?>" alt="">
        </div>
        <?php endif; ?>
        <div class="service-text text-center">
            <h3>
                <a href="<?php echo $settings['button_link']['url'] ? esc_url( $settings['button_link']['url'] ) : '';  ?>">
                <?php echo elh_element_kses_intermediate( $settings['title'] ); ?>
                </a>
            </h3>
        </div>
    </div>
</div>