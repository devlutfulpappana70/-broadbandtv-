<div class="tel-pricing-item-3 position-relative <?php if($settings['active'] == 'yes'){echo esc_attr('active');}?> d-flex wow fadeInUp"  data-wow-delay="300ms" data-wow-duration="1000ms" <?php if(!empty($settings['p_bg']['url'])):?> data-background="<?php echo esc_url($settings['p_bg']['url']);?>" <?php endif;?>>
    <div class="tel-price-text">
        <span><?php echo wp_kses($settings['title'], true);?></span>
        <h2>
            <?php if(!empty( $currency )) : ?>
                <sub><?php echo esc_html($currency); ?></sub>
            <?php endif; ?>
            <?php if(!empty( $settings['price'] )) : ?>
                <?php echo esc_html($settings['price']); ?>
            <?php endif;?>
            <?php if(!empty( $settings['period'] )) : ?>
                <sup><?php echo esc_html($settings['period']); ?></sup>
            <?php endif;?>
        </h2>
        <p><?php echo wp_kses($settings['desc'], true);?></p>
        <?php if(!empty($settings['button_text'])):?>
        <div class="tel-btn-3 text-uppercase">
            <a href="<?php echo esc_url($settings['button_link']['url']);?>"><?php echo esc_html($settings['button_text']);?><i class="fas fa-arrow-right"></i></a>
        </div>
        <?php endif;?>
    </div>
    <div class="tel-price-icon-list">
        <?php if(!empty($settings['badges'])):?>
        <div class="tel-price-icon ul-li">
            <ul>
                <?php foreach($settings['badges'] as $item):?>
                    <li><?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?></li>
                <?php endforeach;?>
            </ul>
        </div>
        <?php endif;?>
        <?php if(!empty( $settings['package_feature_lists'] )) : ?>
            <div class="tel-price-list ul-li-block">
                <ul>
                    <?php
                        $list_item = $settings['package_feature_lists'];
                        $list_item = explode("\n", ($list_item));
                        foreach($list_item as $list):
                    ?>
                    <li><?php echo wp_kses($list, true)?></li>
                    <?php endforeach;?>
                </ul>
            </div>
        <?php endif; ?>
    </div>
</div>