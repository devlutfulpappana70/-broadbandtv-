<!-- Price Block One -->
<div class="price-block_one <?php if($settings['active'] == 'yes'){echo esc_attr('active');}?>">
    <div class="price-block_one-inner">
        <div class="price-block_one-hover"></div>
        <div class="price-block_one-hover_two"></div>
        <?php if(!empty( $settings['p_bg']['url'] )) : ?>
        <div class="price-block_one-image" style="background-image: url(<?php echo esc_url($settings['p_bg']['url']);?>)"></div>
        <?php endif;?>
        <div class="row clearfix">
            <!-- Column -->
            <div class="title-column col-lg-5 col-md-12 col-sm-12">
                <?php if(!empty( $settings['title'] )) : ?>
                <div class="price-block_one-title"><?php echo wp_kses($settings['title'], true);?></div>
                <?php endif;?>

                <div class="price-block_one-price"><?php if(!empty( $currency )) : ?>
                <sub><?php echo esc_html($currency); ?></sub>
                <?php endif; ?><?php if(!empty( $settings['price'] )) : ?>
                <?php echo esc_html($settings['price']); ?>
                <?php endif;?><?php if(!empty( $settings['period'] )) : ?>
                <sup><?php echo esc_html($settings['period']); ?></sup>
                <?php endif;?></div>

                <?php if(!empty( $settings['desc'] )) : ?>
                <div class="price-block_one-text"><?php echo wp_kses($settings['desc'], true);?></div>
                <?php endif;?>

                <?php if(!empty($settings['button_text'])):?>
                <div class="price-block_one-button">
                    <a href="<?php echo esc_url($settings['button_link']['url']);?>" class="theme-btn btn-style-nineteen"><span class="txt"><?php echo esc_html($settings['button_text']);?></span></a>
                </div>
                <?php endif;?>
            </div>
            <!-- Column -->
            <div class="content-column col-lg-7 col-md-12 col-sm-12">
                <div class="row clearfix">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="left-list-box">
                            <div class="price-block_one-icons">
                                <?php foreach($settings['badges'] as $item):?>
                                <div class="icon">
                                    <?php \Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                </div>
                                <?php endforeach;?>
                            </div>
                            <?php if(!empty( $settings['package_feature_lists'] )) : ?>
                            <ul class="price-block_one-list list-unstyled">
                                <?php
                                    $list_item = $settings['package_feature_lists'];
                                    $list_item = explode("\n", ($list_item));
                                    foreach($list_item as $list):
                                ?>
                                <li>
                                <?php \Elementor\Icons_Manager::render_icon( $settings['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                <?php echo wp_kses($list, true)?></li>
                                <?php endforeach;?>
                            </ul>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="right-list-box">
                            <?php if(!empty( $settings['package_feature_lists_2'] )) : ?>
                            <ul class="price-block_one-list list-unstyled">
                                <?php
                                    $list_item = $settings['package_feature_lists_2'];
                                    $list_item = explode("\n", ($list_item));
                                    foreach($list_item as $list):
                                ?>
                                <li>
                                <?php \Elementor\Icons_Manager::render_icon( $settings['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                <?php echo wp_kses($list, true)?></li>
                                <?php endforeach;?>
                            </ul>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>