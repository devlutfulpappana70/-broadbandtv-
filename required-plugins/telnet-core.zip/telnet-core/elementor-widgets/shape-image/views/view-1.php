<span class="tel_line_shape tx-z1 position-absolute" data-parallax='{"x":<?php echo $settings['y_offset']['size'] ? esc_attr($settings['x_offset']['size']) : '0'; ?>,"y":<?php echo $settings['y_offset']['size'] ? esc_attr($settings['y_offset']['size']) : '0'; ?>,"rotateY":<?php echo $settings['rotate_offset']['size'] ? esc_attr($settings['rotate_offset']['size']) : '0'; ?>}
    '>
    <img src="<?php echo esc_url( $settings['image']['url'] ) ?>" alt="">
</span>