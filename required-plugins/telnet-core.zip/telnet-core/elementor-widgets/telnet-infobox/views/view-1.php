<?php
use \Elementor\Group_Control_Image_Size;
?>
<div class="wow <?php echo $settings['anim_name'] ? esc_attr($settings['anim_name']) : ''; ?>"
data-wow-delay="<?php echo $settings['anim_delay'] ? esc_attr($settings['anim_delay']) : ''; ?>"
data-wow-duration="<?php echo $settings['anim_duration'] ? esc_attr($settings['anim_duration']) : ''; ?>">
    <div class="tx-infoBox tx-infoBox__styleOne">
        <?php if(!empty( $settings['type'] === 'image' && ( $settings['image']['url'] || $settings['image']['id'] ) || $settings['icon'] || $settings['icon']['value'] )) : ?>
        <div class="tx-thumb">
            <?php if ( $settings['type'] === 'image' && ( $settings['image']['url'] || $settings['image']['id'] ) ):
                    $this->get_render_attribute_string( 'image' );
                    $settings['hover_animation'] = 'disable-animation';?>
                    <?php echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'thumbnail', 'image' ); ?>
                <?php elseif ( !empty( $settings['icon']['value'] ) ): ?>
                <?php elh_element_render_icon( $settings, '', 'icon' );?>
            <?php endif;?>
        </div>
        <?php endif; ?>
        <div class="tx-content mt-25">
            <?php if(!empty( $settings['title'] )) : ?>
            <h3 class="tx-title">
                <a href="<?php echo esc_url($settings['button_link']['url']) ?>"><?php echo elh_element_kses_intermediate( $settings['title'] ); ?></a>
            </h3>
            <?php endif; ?>

            <?php if(!empty( $settings['description'] )) : ?>
            <p class="mt-20"><?php echo elh_element_kses_intermediate( $settings['description'] ); ?></p>
            <?php endif; ?>

            <?php if(!empty( $settings['button_text'] || $settings['button_link']['url'] )) : ?>
            <a href="<?php echo esc_url($settings['button_link']['url']) ?>" class="tx-inline-btn tx-inline-btn__styleTheme mt-25">
                <?php echo elh_element_kses_intermediate( $settings['button_text'] ); ?>
                <span class="tx-icon">
                    <?php elh_element_render_icon( $settings, '', 'button_icon' ); ?>
                </span>
            </a>
            <?php endif; ?>
        </div>
    </div>
</div>