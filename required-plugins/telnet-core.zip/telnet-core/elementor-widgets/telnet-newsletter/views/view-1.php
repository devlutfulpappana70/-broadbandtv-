<?php
     $this->add_render_attribute( 'title', 'class', 'cta-one_heading' );
?>
<section class="cta-one">
    <div class="auto-container">
        <div class="inner-container">
            <div class="cta-one_pattern" style="background-image: url(<?php echo $settings['bg_image']['url'] ? esc_url($settings['bg_image']['url']) : ''; ?>)"></div>
            <div class="row clearfix">
                <!-- CTA One Image Column -->
                <div class="cta-one_image-column col-lg-5 col-md-12 col-sm-12">
                    <div class="parallax-scene-2">
                        <?php if(!empty( $settings['image_1']['url'] )) : ?>
                        <div class="cta-one_image" data-depth="0.30">
                            <img src="<?php echo esc_url($settings['image_1']['url']); ?>" alt="" />
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- CTA One Content Column -->
                <div class="cta-one_content-column col-lg-7 col-md-12 col-sm-12">
                    <div class="cta-one_content">
                        <div class="cta-one_title">
                            <span class="map">
                                <?php \Elementor\Icons_Manager::render_icon( $settings['sub_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                            </span>
                            <?php echo elh_element_kses_intermediate($settings['sub_title']); ?>
                        </div>
                            <?php
                                printf('<%1$s %2$s>%3$s</%1$s>',
                                    tag_escape($settings['title_tag']),
                                    $this->get_render_attribute_string('title'),
                                    $title
                                );
                            ?>
                        <div class="services-form">
                            <?php echo do_shortcode($settings['newsletter_form']); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>