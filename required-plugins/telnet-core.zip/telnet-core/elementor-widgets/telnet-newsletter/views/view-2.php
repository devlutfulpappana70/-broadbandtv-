<?php
     $this->add_render_attribute( 'title', 'class', 'tna-heading-1 title-1 tna-touch-title-2' );
     $this->add_render_attribute( 'title_2', 'class', 'tna-heading-1 title-2 tna-touch-title-2' );
     $title_2 = elh_element_kses_basic( $settings['title_bottom'] );
?>
<div class="tna-footer-top">
    <div class="tna-form-1-wrap">
        <?php if(!empty( $settings['sub_title'] )) : ?>
        <h3 class="tna-heading-1 title"><?php echo elh_element_kses_intermediate($settings['sub_title']); ?></h3>
        <?php endif; ?>
        <?php if(!empty( $settings['newsletter_form'] )) : ?>
        <div class="tna-form-1">
            <?php echo do_shortcode($settings['newsletter_form']); ?>
        </div>
        <?php endif; ?>
    </div>
    <div class="tna-contact-touch">
        <?php
            printf('<%1$s %2$s>%3$s</%1$s>',
                tag_escape($settings['title_tag']),
                $this->get_render_attribute_string('title'),
                $title
            );
        ?>
        <?php if(!empty( $settings['description'] )) : ?>
        <p class="tna-para-1 disc"><?php echo elh_element_kses_intermediate($settings['description']); ?></p>
        <?php endif; ?>
        <?php
            printf('<%1$s %2$s>%3$s</%1$s>',
                tag_escape($settings['title_tag']),
                $this->get_render_attribute_string('title_2'),
                $title_2
            );
        ?>
    </div>
</div>