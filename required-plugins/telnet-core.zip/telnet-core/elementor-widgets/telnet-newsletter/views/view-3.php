<?php
     $this->add_render_attribute( 'title', 'class', 'tna-heading-2 title' );
?>
<div class="tna-cta-1-area wow slideInUp">
    <div class="container tna-container-1">
        <div class="tna-cta-1-wrap bg-default" tna-data-background="<?php echo $settings['bg_image']['url'] ? esc_url($settings['bg_image']['url']) : ''; ?>">
            <div class="left">
                <?php if(!empty( $settings['sub_title'] )) : ?>
                <h5 class="tna-heading-2 subtitle">
                    <?php  Elementor\Icons_Manager::render_icon( $settings['sub_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                    <?php echo elh_element_kses_intermediate($settings['sub_title']); ?>
                </h5>
                <?php endif; ?>
                <?php
                    printf('<%1$s %2$s>%3$s</%1$s>',
                        tag_escape($settings['title_tag']),
                        $this->get_render_attribute_string('title'),
                        $title
                    );
                ?>
            </div>
            <?php if(!empty( $settings['newsletter_form'] )) : ?>
            <div class="tna-cta-1-form">
                <?php echo do_shortcode($settings['newsletter_form']); ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
