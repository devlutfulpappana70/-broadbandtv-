<div class="tna-services-2-area flat_3">

    <?php if(!empty( $settings['service_image']['url'] )) : ?>
    <img src="<?php echo esc_url($settings['service_image']['url']); ?>" alt="" class="tna-services-2-img">
    <?php endif; ?>

    <div class="tna-services-2-wrap racesWrapper bg-default" tna-data-background="<?php echo $settings['bg_image']['url'] ? esc_url($settings['bg_image']['url']) : ''; ?>">
        <div class="races ">
            <?php foreach( $settings['services'] as $list ) : ?>
            <div class="tna-services-1-item">
                <?php if(!empty( $list['bg_shape']['url'] )) : ?>
                <img src="<?php echo esc_url($list['bg_shape']['url']); ?>" alt="" class="bg-il-1">
                <?php endif; ?>

                <div class="icon-position">
                    <?php if( $list['enable_icon'] === 'yes' ) : ?>
                    <div class="icon">
                        <?php if($list['icon_type'] == 'icon') : ?>
                            <?php \Elementor\Icons_Manager::render_icon( $list['service_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                        <?php else : ?>
                            <img src="<?php echo esc_url($list['service_image']['url']); ?>" alt="" />
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="content-wrap">
                    <?php if(!empty( $list['title'] )) : ?>
                    <h5 class="tna-heading-2 title"><?php echo elh_element_kses_intermediate($list['title']); ?></h5>
                    <?php endif; ?>

                    <?php if(!empty( $list['description'] )) : ?>
                    <p class="tna-para-2 disc"><?php echo elh_element_kses_intermediate($list['description']); ?></p>
                    <?php endif; ?>
                </div>

                <?php if(!empty( $list['list_link']['url'] )) : ?>
                <a href="<?php echo esc_url($list['list_link']['url']); ?>" class="s2-btn">
                    <?php \Elementor\Icons_Manager::render_icon( $list['btn_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                </a>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>