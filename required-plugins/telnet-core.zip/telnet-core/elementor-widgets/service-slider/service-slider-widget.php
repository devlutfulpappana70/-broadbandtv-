<?php
namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Core\Schemes\Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;

defined( 'ABSPATH' ) || die();

class Service_Slider extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'service_slider';
    }

    /**
     * Get widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Service Slider', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/icon-box/';
    }

    /**
     * Get widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-preview-medium';
    }

    public function get_keywords() {
        return ['service', 'gird', 'icon'];
    }

    protected function register_content_controls() {


        // SERVICES
        $this->start_controls_section(
            '_section_service_box',
            [
                'label' => __( 'Services Boxs', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $repeater = new \Elementor\Repeater();

        // list icon
        $repeater->add_control(
            'icon',
            [
                'label'       => __( 'Icon', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'default'     => [
                    'value'   => 'fas fa-check',
                    'library' => 'solid',
                ],
                'label_block' => true,
            ]
        );

        // list image
        $repeater->add_control(
            'image',
            [
                'label'       => __( 'Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );

        // list text
        $repeater->add_control(
            'title',
            [
                'label'       => __( 'Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );
        // list text
        $repeater->add_control(
            'description',
            [
                'label'       => __( 'Description', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'label_block' => true,
            ]
        );
        // list text
        $repeater->add_control(
            'btn_label',
            [
                'label'       => __( 'Button Label', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );


        // list link
        $repeater->add_control(
            'list_link',
            [
                'label'       => __( 'List Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'label_block' => true,
                'default'     => [
                    'url' => '#',
                ],
            ]
        );

        $this->add_control(
            'services',
            [
                'label'       => __( 'Service Items', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ title }}}',
            ]
        );
        $this->add_control(
            'arrwo1',
            [
                'label'       => __( 'Arrow 1', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
            ]
        );
        $this->add_control(
            'arrwo2',
            [
                'label'       => __( 'Arrow 1', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
            ]
        );
        $this->end_controls_section();

    }

    protected function register_style_controls() {
        // Style
    }

    /**
     * Render widget output on the frontend.
     *
     * Used to generate the final HTML displayed on the frontend.
     *
     * Note that if skin is selected, it will be rendered by the skin itself,
     * not the widget.
     *
     * @since 1.0.0
     * @access public
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
    <div class="tel-service-slider-area d-flex justify-content-end">
        <div class="tel-service-slider swiper-container">
            <div class="swiper-wrapper">
                <?php foreach($settings['services'] as $item):?>
                <div class="swiper-slide">
                    <div class="tel-service-slide-item position-relative">
                        <div class="service-flipbox">
                            <div class="service-front-part">
                                <div class="service-icon position-absolute d-flex align-items-center justify-content-center">
                                    <img src="<?php echo esc_url($item['icon']['url']);?>" alt="">
                                </div>
                                <div class="service-img">
                                    <img src="<?php echo esc_url($item['image']['url']);?>" alt="">
                                </div>
                                <div class="service-text position-absolute">
                                    <h3><a href="<?php echo esc_url($item['list_link']['url']);?>"><?php echo esc_html($item['title']);?></a></h3>
                                    <a class="more_icon d-flex align-items-center justify-content-center position-absolute" href="<?php echo esc_url($item['list_link']['url']);?>"><img src="<?php echo esc_url($settings['arrwo1']['url']);?>"></a>
                                </div>
                            </div>
                            <div class="service-hover-item position-absolute">
                                <span class="service-bg position-absolute" data-background="<?php echo esc_url($item['image']['url']);?>"></span>
                                <div class="service-hvr-icon d-flex align-items-end justify-content-center position-absolute text-center">
                                    <img src="<?php echo esc_url($item['icon']['url']);?>" alt="">
                                </div>
                                <div class="service-hvr-text text-center">
                                    <h3><a href="<?php echo esc_url($item['list_link']['url']);?>"><?php echo esc_html($item['title']);?></a></h3>
                                    <p><?php echo wp_kses($item['description'], true);?></p>
                                    <a class="service-hvr-more position-relative d-flex justify-content-between text-uppercase" href="<?php echo esc_url($item['list_link']['url']);?>"><?php echo esc_html($item['btn_label']);?> <span class="d-flex justify-content-center align-items-center"><img src="<?php echo esc_url($settings['arrwo2']['url']);?>" alt=""></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach;?>
            </div>
        </div>
        </div>
        <div class="tel-service-pagination-carousel-area">
        <div class="container">
            <div class="tel-service-pagination-carousel d-flex justify-content-between align-items-center">
                <div class="swiper-service-paginations"></div>
                <div class="tel-service-carousel d-flex">
                    <div class="tel-slider-arrow d-flex justify-content-center align-items-center tel-service-button-prev_3"><i class="fal fa-long-arrow-left"></i></div>
                    <div class="tel-slider-arrow d-flex justify-content-center align-items-center tel-service-button-next_3"><i class="fal fa-long-arrow-right"></i></div>
                </div>
            </div>
        </div>
        </div>
    <?php
    }

}