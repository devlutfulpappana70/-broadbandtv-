<div class="tx-videoBtnWrapper tx-videoBtnWrapper__styleOne" data-background="<?php echo $settings['button_bg_image']['url'] ? esc_url($settings['button_bg_image']['url']) : ''; ?>">
    <a href="<?php echo $settings['video_link']['url'] ? esc_url($settings['video_link']['url']) : ''; ?>" class="tx-round-btn position-absolute start-50 top-50 translate-middle" data-rel="lightcase">
        <?php echo elh_element_render_icon($settings, '', 'button_icon'); ?>
    </a>
</div>