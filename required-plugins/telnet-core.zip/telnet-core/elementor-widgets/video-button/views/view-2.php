<a href="<?php echo $settings['video_link']['url'] ? esc_url($settings['video_link']['url']) : ''; ?>"
class="tx-round-btn <?php if($settings['button_center_align'] === 'yes') {echo 'm-auto';} ?>" data-rel="lightcase">
    <?php echo elh_element_render_icon($settings, '', 'button_icon'); ?>
</a>