<?php
namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Repeater;
use \Elementor\Utils;

defined( 'ABSPATH' ) || die();

class Hero_Section extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'hero_section';
    }

    /**
     * Get widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Hero Section', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/slider/';
    }

    /**
     * Get widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-slider-full-screen';
    }

    public function get_keywords() {
        return ['hero', 'image', 'gallery', 'carousel'];
    }

    public function get_style_depends() {
        return ['tf-hero-slider-style'];
    }

    protected function register_content_controls() {

        $this->start_controls_section(
            '_section_design_title',
            [
                'label' => __( 'CHOOSE STYLE', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'design_style',
            [
                'label'              => __( 'CHOOSE STYLE', 'telnet-core' ),
                'type'               => Controls_Manager::SELECT,
                'options'            => [
                    'style_1' => __( 'Style 1', 'telnet-core' ),
                    'style_2' => __( 'Style 2', 'telnet-core' ),
                    'style_3' => __( 'Style 3', 'telnet-core' ),
                ],
                'default'            => 'style_1',
                'frontend_available' => true,
                'style_transfer'     => true,
            ]
        );

        $this->end_controls_section();

        // HERO SECTION CONTENT
        $this->start_controls_section(
            '_section_hero_content',
            [
                'label' => __( 'HERO SECTION CONTENT', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // sub title
        $this->add_control(
            'sub_title',
            [
                'label'       => __( 'Sub Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __( 'Best IT Solution', 'telnet-core' ),
            ]
        );

        // title
        $this->add_control(
            'title',
            [
                'label'       => __( 'Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'default'     => __( 'The Best <strong>Internet</strong> <i>Services</i> Provide <span>In</span> <strong>Town</strong>', 'telnet-core' ),
            ]
        );

        // description
        $this->add_control(
            'description',
            [
                'label'       => __( 'Description', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'default'     => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.', 'telnet-core' ),
            ]
        );

        // end
        $this->end_controls_section();

        // HERO SECTION IMAGE
        $this->start_controls_section(
            '_section_hero_image',
            [
                'label'     => __( 'HERO SECTION IMAGE', 'telnet-core' ),
                'tab'       => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'design_style' => ['style_1', 'style_3'],
                ],
            ]
        );

        // bg_image
        $this->add_control(
            'bg_image',
            [
                'label'   => __( 'Background Image', 'telnet-core' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],

            ]
        );

        // image_1
        $this->add_control(
            'image_1',
            [
                'label'   => __( 'Image 1', 'telnet-core' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        // image_2
        $this->add_control(
            'image_2',
            [
                'label'   => __( 'Image 2', 'telnet-core' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        // image_3
        $this->add_control(
            'image_3',
            [
                'label'   => __( 'Image 3', 'telnet-core' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        // image_4
        $this->add_control(
            'image_4',
            [
                'label'   => __( 'Image 4', 'telnet-core' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'design_style' => 'style_1',
                ],
            ]
        );

        // image_5
        $this->add_control(
            'image_5',
            [
                'label'   => __( 'Image 5', 'telnet-core' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'design_style' => 'style_1',
                ],
            ]
        );

        // end
        $this->end_controls_section();

        // HERO SECTION BUTTON
        $this->start_controls_section(
            '_section_button',
            [
                'label' => __( 'Button', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // enable icon
        $this->add_control(
            'enable_icon',
            [
                'label'        => __( 'Enable Icon', 'telnet-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'telnet-core' ),
                'label_off'    => __( 'No', 'telnet-core' ),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        // list icon
        $this->add_control(
            'btn_icon',
            [
                'label'       => __( 'Button Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'default'     => [
                    'value'   => 'fas fa-arrow-right',
                    'library' => 'solid',
                ],
                'label_block' => true,
                'condition'   => [
                    'enable_icon' => 'yes',
                ],
            ]
        );

        // Button text
        $this->add_control(
            'button_text',
            [
                'label'       => __( 'Button Text', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Button Text', 'telnet-core' ),
                'placeholder' => __( 'Type your title here', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        // Button link
        $this->add_control(
            'button_link',
            [
                'label'         => __( 'Button Link', 'telnet-core' ),
                'type'          => Controls_Manager::URL,
                'placeholder'   => __( 'https://your-link.com', 'telnet-core' ),
                'default'       => [
                    'url' => '#',
                ],
                'show_external' => true,
                'label_block'   => false,
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );

        $this->end_controls_section();

        // video SECTION
        $this->start_controls_section(
            '_section_video',
            [
                'label' => __( 'VIDEO', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // video text
        $this->add_control(
            'video_text',
            [
                'label'       => __( 'Video Text', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __( 'Watch Our Video', 'telnet-core' ),
                'condition'   => [
                    'design_style' => 'style_1',
                ],
            ]
        );

        // video button icon
        $this->add_control(
            'video_btn_icon',
            [
                'label'       => __( 'Button Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'default'     => [
                    'value'   => 'fas fa-play',
                    'library' => 'solid',
                ],
                'label_block' => true,
                'condition'   => [
                    'design_style' => 'style_1',
                ],
            ]
        );

        // vide link
        $this->add_control(
            'video_link',
            [
                'label'         => __( 'Video Link', 'telnet-core' ),
                'type'          => Controls_Manager::URL,
                'placeholder'   => __( 'https://your-link.com', 'telnet-core' ),
                'default'       => [
                    'url' => '#',
                ],
                'show_external' => true,
                'label_block'   => false,
            ]
        );

        // remove lightbox
        $this->add_control(
            'remove_lightbox',
            [
                'label'        => __( 'Remove Lightbox', 'telnet-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'telnet-core' ),
                'label_off'    => __( 'No', 'telnet-core' ),
                'return_value' => 'yes',
                'default'      => 'no',
                'condition'    => [
                    'design_style' => 'style_1',
                ],
            ]
        );

        // end
        $this->end_controls_section();

        $this->start_controls_section(
            '_section_icon_list',
            [
                'label'     => __( 'SOCIAL ICON LISTS', 'telnet-core' ),
                'tab'       => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'design_style' => 'style_1',
                ],
            ]
        );

        // social heading
        $this->add_control(
            'social_heading',
            [
                'label'       => __( 'SOCIAL HEADING', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => false,
            ]
        );

        $repeater = new Repeater();

        // details icon
        $repeater->add_control(
            'social_list_btn_type',
            [
                'label'          => __( 'Button Icon', 'telnet-core' ),
                'type'           => Controls_Manager::CHOOSE,
                'label_block'    => false,
                'options'        => [
                    'icon'  => [
                        'title' => __( 'Icon', 'telnet-core' ),
                        'icon'  => 'far fa-smile',
                    ],
                    'image' => [
                        'title' => __( 'Image', 'telnet-core' ),
                        'icon'  => 'fa fa-image',
                    ],
                ],
                'default'        => 'icon',
                'toggle'         => false,
                'style_transfer' => true,
            ]
        );

        // list icon
        $repeater->add_control(
            'social_list_icon',
            [
                'label'       => __( 'Button Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'default'     => [
                    'value'   => 'fas fa-arrow-right',
                    'library' => 'solid',
                ],
                'label_block' => true,
                'condition'   => [
                    'social_list_btn_type' => 'icon',
                ],
            ]
        );

        // list image
        $repeater->add_control(
            'social_list_image',
            [
                'label'       => __( 'Button Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition'   => [
                    'social_list_1_btn_type' => 'image',
                ],
            ]
        );

        // link
        $repeater->add_control(
            'social_list_link',
            [
                'label'       => __( 'Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'label_block' => true,
                'default'     => [
                    'url' => '#',
                ],
                'placeholder' => __( 'https://your-link.com', 'telnet-core' ),
            ]
        );

        $this->add_control(
            'social_list_lists',
            [
                'label'  => __( 'Social lists', 'telnet-core' ),
                'type'   => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
            ]
        );

        $this->end_controls_section();

        // feature package price
        $this->start_controls_section(
            '_section_feature_package_price',
            [
                'label'     => __( 'Feature Package Price', 'telnet-core' ),
                'tab'       => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'design_style' => ['style_3'],
                ],
            ]
        );

        // CURRENCY SYMBOL
        $this->add_control(
            'currency',
            [
                'label'       => __( 'Currency', 'telnet-core' ),
                'type'        => Controls_Manager::SELECT,
                'label_block' => false,
                'options'     => [
                    ''             => __( 'None', 'telnet-core' ),
                    'baht'         => '&#3647; ' . _x( 'Baht', 'Currency Symbol', 'telnet-core' ),
                    'bdt'          => '&#2547; ' . _x( 'BD Taka', 'Currency Symbol', 'telnet-core' ),
                    'dollar'       => '&#36; ' . _x( 'Dollar', 'Currency Symbol', 'telnet-core' ),
                    'euro'         => '&#128; ' . _x( 'Euro', 'Currency Symbol', 'telnet-core' ),
                    'franc'        => '&#8355; ' . _x( 'Franc', 'Currency Symbol', 'telnet-core' ),
                    'guilder'      => '&fnof; ' . _x( 'Guilder', 'Currency Symbol', 'telnet-core' ),
                    'krona'        => 'kr ' . _x( 'Krona', 'Currency Symbol', 'telnet-core' ),
                    'lira'         => '&#8356; ' . _x( 'Lira', 'Currency Symbol', 'telnet-core' ),
                    'peseta'       => '&#8359 ' . _x( 'Peseta', 'Currency Symbol', 'telnet-core' ),
                    'peso'         => '&#8369; ' . _x( 'Peso', 'Currency Symbol', 'telnet-core' ),
                    'pound'        => '&#163; ' . _x( 'Pound Sterling', 'Currency Symbol', 'telnet-core' ),
                    'real'         => 'R$ ' . _x( 'Real', 'Currency Symbol', 'telnet-core' ),
                    'ruble'        => '&#8381; ' . _x( 'Ruble', 'Currency Symbol', 'telnet-core' ),
                    'rupee'        => '&#8360; ' . _x( 'Rupee', 'Currency Symbol', 'telnet-core' ),
                    'indian_rupee' => '&#8377; ' . _x( 'Rupee (Indian)', 'Currency Symbol', 'telnet-core' ),
                    'shekel'       => '&#8362; ' . _x( 'Shekel', 'Currency Symbol', 'telnet-core' ),
                    'won'          => '&#8361; ' . _x( 'Won', 'Currency Symbol', 'telnet-core' ),
                    'yen'          => '&#165; ' . _x( 'Yen/Yuan', 'Currency Symbol', 'telnet-core' ),
                    'custom'       => __( 'Custom', 'telnet-core' ),
                ],
                'default'     => 'dollar',
            ]
        );

        $this->add_control(
            'currency_custom',
            [
                'label'     => __( 'Custom Symbol', 'telnet-core' ),
                'type'      => Controls_Manager::TEXT,
                'condition' => [
                    'currency' => 'custom',
                ],
                'dynamic'   => [
                    'active' => true,
                ],
            ]
        );

        // PRICE
        $this->add_control(
            'price',
            [
                'label'   => __( 'Price', 'telnet-core' ),
                'type'    => Controls_Manager::TEXT,
                'default' => '9.99',
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        // PERIOD
        $this->add_control(
            'period',
            [
                'label'   => __( 'Period', 'telnet-core' ),
                'type'    => Controls_Manager::TEXT,
                'default' => __( 'Per Month', 'telnet-core' ),
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        // PCACKAGE FEATURE
        $this->add_control(
            'package_feature',
            [
                'label'   => __( 'Package Feature Text', 'telnet-core' ),
                'type'    => Controls_Manager::TEXT,
                'default' => __( 'Ultra Fast inernet', 'telnet-core' ),
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        // end
        $this->end_controls_section();

        // SETTINGS SECTION
        $this->start_controls_section(
            '_section_settings',
            [
                'label' => __( 'SETTINGS', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // sub title ON/OFF
        $this->add_control(
            'sub_title_on_off',
            [
                'label'        => __( 'Sub Title On/Off', 'telnet-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'On', 'telnet-core' ),
                'label_off'    => __( 'Off', 'telnet-core' ),
                'return_value' => 'yes',
                'default'      => 'yes',
                'condition'    => [
                    'design_style' => [
                        'style_2',
                        'style_3',
                    ],
                ],
            ]
        );

        // TITLE ON/OFF
        $this->add_control(
            'title_on_off',
            [
                'label'        => __( 'Title On/Off', 'telnet-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'On', 'telnet-core' ),
                'label_off'    => __( 'Off', 'telnet-core' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        // Description ON/OFF
        $this->add_control(
            'description_on_off',
            [
                'label'        => __( 'Description On/Off', 'telnet-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'On', 'telnet-core' ),
                'label_off'    => __( 'Off', 'telnet-core' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        // BUTTON ON/OFF
        $this->add_control(
            'button_on_off',
            [
                'label'        => __( 'Button On/Off', 'telnet-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'On', 'telnet-core' ),
                'label_off'    => __( 'Off', 'telnet-core' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        // video ON/OFF
        $this->add_control(
            'video_on_off',
            [
                'label'        => __( 'Video On/Off', 'telnet-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'On', 'telnet-core' ),
                'label_off'    => __( 'Off', 'telnet-core' ),
                'return_value' => 'yes',
                'default'      => 'yes',
                'condition'    => [
                    'design_style' => 'style_1',
                ],
            ]
        );

        // social ON/OFF
        $this->add_control(
            'social_on_off',
            [
                'label'        => __( 'Social On/Off', 'telnet-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'On', 'telnet-core' ),
                'label_off'    => __( 'Off', 'telnet-core' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        // price on off
        $this->add_control(
            'price_on_off',
            [
                'label'        => __( 'Price On/Off', 'telnet-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'On', 'telnet-core' ),
                'label_off'    => __( 'Off', 'telnet-core' ),
                'return_value' => 'yes',
                'default'      => 'yes',
                'condition'    => [
                    'design_style' => ['style_3'],
                ],
            ]
        );

        $this->end_controls_section();

    }

    private static function get_currency_symbol( $symbol_name ) {
        $symbols = [
            'baht'         => '&#3647;',
            'bdt'          => '&#2547;',
            'dollar'       => '&#36;',
            'euro'         => '&#128;',
            'franc'        => '&#8355;',
            'guilder'      => '&fnof;',
            'indian_rupee' => '&#8377;',
            'pound'        => '&#163;',
            'peso'         => '&#8369;',
            'peseta'       => '&#8359',
            'lira'         => '&#8356;',
            'ruble'        => '&#8381;',
            'shekel'       => '&#8362;',
            'rupee'        => '&#8360;',
            'real'         => 'R$',
            'krona'        => 'kr',
            'won'          => '&#8361;',
            'yen'          => '&#165;',
        ];

        return isset( $symbols[$symbol_name] ) ? $symbols[$symbol_name] : '';
    }

    protected function register_style_controls() {
        $dir = dirname( __FILE__ );

        include $dir . '/styles/slide-style.php';
        include $dir . '/styles/sub-title-style.php';
        include $dir . '/styles/title-style.php';
        include $dir . '/styles/description-style.php';
        include $dir . '/styles/cercle-box-style.php';
        include $dir . '/styles/price-style.php';
        include $dir . '/styles/button-style.php';
        include $dir . '/styles/video-button-style.php';
        include $dir . '/styles/social-style.php';
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $dir = dirname( __FILE__ );
        $style = !empty( $settings['design_style'] ) ? $settings['design_style'] : 'style_1';

        switch ( $style ) {
        case 'style_3':
            include $dir . '/views/view-3.php';
            break;
        case 'style_2':
            include $dir . '/views/view-2.php';
            break;
        default:
            include $dir . '/views/view-1.php';
        }
    }
}