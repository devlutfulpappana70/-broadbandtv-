<?php

if ($settings['currency'] === 'custom') {
	$currency = $settings['currency_custom'];
} else {
	$currency = self::get_currency_symbol($settings['currency']);
}
?>

<div class="tna-hero-2-area bg-default flat_3" tna-data-background="<?php echo $settings['bg_image']['url'] ? esc_url($settings['bg_image']['url']) : ''; ?>">
    <span class="bg-shape-1 wow slideInRight" data-wow-duration="2s"></span>

    <div class="container tna-container-1">
        <div class="tna-hero-2-wrap">
            <div class="row z-index-3">
                <div class="col-lg-7">
                    <div class="tna-hero-2-content">
                        <?php if( $settings['sub_title_on_off'] === 'yes' ) : ?>
                        <h4 class="tna-subtitle-2 wow slideInLeft" data-wow-duration="2s"><?php echo elh_element_kses_intermediate($settings['sub_title']); ?></h4>
                        <?php endif; ?>

                        <?php if( $settings['title_on_off'] === 'yes' ) : ?>
                        <h1 class="hero-2-title tna-heading-2 txa-split-text txa-split-in-up">
                            <?php echo elh_element_kses_intermediate($settings['title']); ?>
                        </h1>
                        <?php endif; ?>

                        <?php if( $settings['description_on_off'] === 'yes' ) : ?>
                        <p class="hero-2-disc tna-para-2 wow fadeInUp" data-wow-duration="2s" data-wow-delay=".3s">
                            <?php echo elh_element_kses_intermediate($settings['description']); ?>
                        </p>
                        <?php endif; ?>

                        <div class="btn-wrap">
                            <?php if( $settings['button_on_off'] === 'yes' ) : ?>
                            <a class="tna-pr-btn-3 wow fadeInLeft" data-wow-delay=".9s" data-wow-duration="2s" href="<?php echo esc_url($settings['button_link']['url']); ?>">
                                <span class="text"><?php echo elh_element_kses_intermediate($settings['button_text']); ?></span>
                                <?php
                                    if( !empty( $settings['btn_icon'] ) ) {
                                        \Elementor\Icons_Manager::render_icon( $settings['btn_icon'], [ 'aria-hidden' => 'true' ] );
                                    }
                                ?>
                            </a>
                            <?php endif; ?>

                            <?php if( $settings['price_on_off'] === 'yes' ) : ?>
                            <div class="tna-services-1-price hero-2 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".6s" >
                                <h3 class="tna-heading-1 price"><?php if(!empty( $currency )) : ?><span class="dollar-sing"><?php echo esc_html($currency); ?></span><?php endif; ?><?php echo esc_html($settings['price']); ?> <?php if(!empty( $settings['period'] )) : ?><span class="month"><?php echo esc_html($settings['period']); ?></span><?php endif; ?></h3>

                                <?php if(!empty( $settings['package_feature'] )) : ?>
                                <p class="tna-para-1 para"><?php echo esc_html($settings['package_feature']); ?></p>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>

            <?php if(!empty( $settings['image_1']['url'] )) : ?>
            <div class="bg-il-1">
                <img src="<?php echo esc_url($settings['image_1']['url']); ?>" alt="">
            </div>
            <?php endif; ?>

            <?php if(!empty( $settings['image_2']['url'] )) : ?>
            <div class="bg-il-2 wow zoomIn" data-wow-duration="3s">
                <img src="<?php echo esc_url($settings['image_2']['url']); ?>" alt="">
            </div>
            <?php endif; ?>

            <?php if(!empty( $settings['image_3']['url'] )) : ?>
            <div class="tna-hero-2-img wow slideInRight" data-wow-duration="2s" data-wow-delay=".5s">
                <img class="js-tilt" data-tilt data-tilt-max="4"  src="<?php echo esc_url($settings['image_3']['url']); ?>" alt="">
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>