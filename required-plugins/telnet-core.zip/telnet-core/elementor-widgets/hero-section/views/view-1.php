<section class="banner-one" style="background-image: url(<?php echo $settings['bg_image']['url'] ? esc_url($settings['bg_image']['url']) : ''; ?>)">
    <!-- Social Box -->
    <div class="banner-two_socials">
        <?php if(!empty( $settings['social_heading'] )) : ?>
        <span><?php echo elh_element_kses_intermediate($settings['social_heading']); ?></span>
        <?php endif; ?>

        <?php foreach($settings['social_list_lists'] as $list ) : ?>
        <a href="<?php echo esc_url($list['social_list_link']['url']); ?>"
            target="<?php echo esc_attr($list['social_list_link']['is_external'] ? '_blank' : '_self'); ?>"
            rel="<?php echo esc_attr($list['social_list_link']['nofollow'] ? 'nofollow' : ''); ?>">
            <?php if($list['social_list_btn_type'] == 'icon') : ?>
                <?php \Elementor\Icons_Manager::render_icon( $list['social_list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
            <?php else : ?>
                <img src="<?php echo esc_url($list['social_list_image']['url']); ?>" alt="" />
            <?php endif; ?>
        </a>
        <?php endforeach; ?>
    </div>
    <div class="banner-one_pattern" style="background-image: url(<?php echo $settings['image_1']['url'] ? esc_url($settings['image_1']['url']) : ''; ?>)"></div>
    <div class="auto-container">
        <div class="row clearfix">

            <!-- Title Column -->
            <div class="banner-one_title-column col-lg-4 col-md-6 col-sm-12">
                <div class="banner-one_title-outer wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                    <?php if(!empty( $settings['image_2']['url'] )) : ?>
                    <div class="banner-one_cloud-icon">
                        <img src="<?php echo esc_url($settings['image_2']['url']); ?>" alt="" />
                    </div>
                    <?php endif; ?>

                    <?php if( $settings['title_on_off'] === 'yes' ) : ?>
                    <h1 class="banner-one_title"><?php echo elh_element_kses_intermediate($settings['title']); ?></h1>
                    <?php endif; ?>

                    <div class="banner-one_play">
                        <?php
                            if($settings['remove_lightbox'] == 'yes') {
                                $lightbox = '';
                            } else {
                                $lightbox = 'lightbox-image';
                            }

                        ?>
                        <a
                        href="<?php echo esc_url($settings['video_link']['url']); ?>"
                        class="<?php echo esc_attr($lightbox); ?> banner-one_play-box"
                        target="<?php echo esc_attr($settings['video_link']['is_external'] ? '_blank' : '_self'); ?>"
                        rel="<?php echo esc_attr($settings['video_link']['nofollow'] ? 'nofollow' : ''); ?>"
                        >
                            <span>
                                <?php \Elementor\Icons_Manager::render_icon( $settings['video_btn_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                            </span>

                            <?php if(!empty( $settings['video_text'] )) : ?>
                            <i><?php echo elh_element_kses_intermediate($settings['video_text']); ?></i>
                            <?php endif; ?>
                        </a>
                    </div>

                </div>
            </div>

            <!-- Title Column -->
            <div class="banner-one_image-column col-lg-5 col-md-12 col-sm-12">
                <div class="banner-one_image-outer">
                    <?php if(!empty( $settings['image_3']['url'] )) : ?>
                    <div class="banner-one_color-layer" style="background-image: url(<?php echo $settings['image_3']['url'] ? esc_url($settings['image_3']['url']) : ''; ?>)"></div>
                    <?php endif; ?>

                    <?php if(!empty( $settings['image_4']['url'] )) : ?>
                    <div class="banner-one_wifi">
                        <img src="<?php echo esc_url($settings['image_4']['url']); ?>" alt="" />
                    </div>
                    <?php endif; ?>

                    <?php if(!empty( $settings['image_5']['url'] )) : ?>
                    <div class="banner-one_image wow slideInUp" data-wow-delay="0ms" data-wow-duration="2000ms">
                        <img src="<?php echo esc_url($settings['image_5']['url']); ?>" alt="" />
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Title Column -->
            <div class="banner-one_content-column col-lg-3 col-md-6 col-sm-12">
                <div class="banner-one_content-outer wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
                    <?php if( $settings['description_on_off'] === 'yes' ) : ?>
                    <div class="banner-one_text"><?php echo elh_element_kses_intermediate($settings['description']); ?></div>
                    <?php endif; ?>

                    <?php if( $settings['button_on_off'] === 'yes' ) : ?>
                    <div class="banner-one_content-button">
                        <a href="<?php echo esc_url($settings['button_link']['url']); ?>"
                        target="<?php echo esc_attr($settings['button_link']['is_external'] ? '_blank' : '_self'); ?>"
                        rel="<?php echo esc_attr($settings['button_link']['nofollow'] ? 'nofollow' : ''); ?>"
                         class="theme-btn btn-style-eighteen">
                            <?php if(!empty( $settings['button_text'] )) : ?>
                            <span class="txt"><?php echo elh_element_kses_intermediate($settings['button_text']); ?></span>
                            <?php endif; ?>

                            <?php if( $settings['enable_icon'] === 'yes' ) : ?>
                            <?php \Elementor\Icons_Manager::render_icon( $settings['btn_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                            <?php endif; ?>
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>