<div class="tna-hero-1-area pt-135 pb-135 tna-fix" >

    <?php if(!empty( $settings['video_link']['url'] )) : ?>
    <div class="bg-video tna-img-cover">
        <video src="<?php echo esc_url($settings['video_link']['url']); ?>" loop muted autoplay playsinline></video>
    </div>
    <?php endif; ?>


    <div class="container tna-container-1">
        <div class="tna-hero-1-content ">
            <?php if( $settings['sub_title_on_off'] === 'yes' ) : ?>
            <h4 class="tna-subtitle-1 wow fadeInDown" data-wow-duration="1s" >
                <?php echo elh_element_kses_intermediate($settings['sub_title']); ?>
            </h4>
            <?php endif; ?>

            <?php if( $settings['title_on_off'] === 'yes' ) : ?>
            <h1 class="tna-heading-1 title txa-split-text txa-split-in-up">
                <?php echo elh_element_kses_intermediate($settings['title']); ?>
            </h1>
            <?php endif; ?>

            <?php if( $settings['description_on_off'] === 'yes' ) : ?>
            <p class="tna-para-1 hero-para wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s">
                <?php echo elh_element_kses_intermediate($settings['description']); ?>
            </p>
            <?php endif; ?>

            <?php if( $settings['button_on_off'] === 'yes' ) : ?>
            <a class="tna-pr-btn-1 wow fadeInUp" data-wow-duration="1s" data-wow-delay="1s" href="#">
                <?php echo elh_element_kses_intermediate($settings['button_text']); ?>
                <?php
                    if( !empty( $settings['btn_icon'] ) ) {
                        \Elementor\Icons_Manager::render_icon( $settings['btn_icon'], [ 'aria-hidden' => 'true' ] );
                    }
                ?>
                </a>
            <?php endif; ?>
        </div>
    </div>
</div>