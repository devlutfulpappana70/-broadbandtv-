<?php

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

 // SECTION CERCLE BADGE STYLE
 $this->start_controls_section(
    '_section_price_style',
    [
        'label' => __( 'PRICE STYLE', 'telnet-core' ),
        'tab'   => Controls_Manager::TAB_STYLE,
    ]
);

// price currency color
$this->add_control(
    'price_currency_color',
    [
        'label' => __( 'Currency Color', 'telnet-core' ),
        'type' => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tel-slider-item-4 .tel-slider-text-4 .slider-btn-price .slider-pricing h3 sup' => 'color: {{VALUE}};',
        ],
    ]
);

// typography
$this->add_group_control(
    Group_Control_Typography::get_type(),
    [
        'name' => 'price_currency_typography',
        'label' => __( 'Typography', 'telnet-core' ),
        'selector' => '{{WRAPPER}} .tel-slider-item-4 .tel-slider-text-4 .slider-btn-price .slider-pricing h3 sup',
    ]
);

// price color
$this->add_control(
    'price_color',
    [
        'label' => __( 'Price Color', 'telnet-core' ),
        'type' => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tel-slider-item-4 .tel-slider-text-4 .slider-btn-price .slider-pricing h3' => 'color: {{VALUE}};',
        ],
    ]
);

// typography
$this->add_group_control(
    Group_Control_Typography::get_type(),
    [
        'name' => 'price_typography',
        'label' => __( 'Typography', 'telnet-core' ),
        'selector' => '{{WRAPPER}} .tel-slider-item-4 .tel-slider-text-4 .slider-btn-price .slider-pricing h3',
    ]
);

// duration color
$this->add_control(
    'duration_color',
    [
        'label' => __( 'Duration Color', 'telnet-core' ),
        'type' => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tel-slider-item-4 .tel-slider-text-4 .slider-btn-price .slider-pricing h3 span' => 'color: {{VALUE}};',
        ],
    ]
);

// typography
$this->add_group_control(
    Group_Control_Typography::get_type(),
    [
        'name' => 'duration_typography',
        'label' => __( 'Typography', 'telnet-core' ),
        'selector' => '{{WRAPPER}} .tel-slider-item-4 .tel-slider-text-4 .slider-btn-price .slider-pricing h3 span',
    ]
);

// features color
$this->add_control(
    'features_color',
    [
        'label' => __( 'Features Color', 'telnet-core' ),
        'type' => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tel-slider-item-4 .tel-slider-text-4 .slider-btn-price .slider-pricing span' => 'color: {{VALUE}};',
        ],
    ]
);

// features typography
$this->add_group_control(
    Group_Control_Typography::get_type(),
    [
        'name' => 'features_typography',
        'label' => __( 'Typography', 'telnet-core' ),
        'selector' => '{{WRAPPER}} .tel-slider-item-4 .tel-slider-text-4 .slider-btn-price .slider-pricing span',
    ]
);

// END SECTION CERCLE BADGE STYLE
$this->end_controls_section();