<?php

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

// SECTION STYLE
$this->start_controls_section(
    '_section_slide_style',
    [
        'label' => __( 'SLIDE STYLE', 'telnet-core' ),
        'tab'   => Controls_Manager::TAB_STYLE,
    ]
);

// slide clip path
$this->add_control(
    'slide_clip_path',
    [
        'label'     => __( 'Slide Clip Path Hide?', 'telnet-core' ),
        'type'      => Controls_Manager::SWITCHER,
        'label_on'  => __( 'On', 'telnet-core' ),
        'label_off' => __( 'Off', 'telnet-core' ),
    ]
);

// padding
$this->add_responsive_control(
    'slide_padding',
    [
        'label'      => __( 'Slide Padding', 'telnet-core' ),
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => ['px', '%', 'em'],
        'selectors'  => [
            '{{WRAPPER}} .tx-hero-slider__styleOne .tx-slideItem' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
    ]
);

// BORDER RADIOUS
$this->add_control(
    'tab_border_radius',
    [
        'label'      => __( 'Border Radius', 'telnet-core' ),
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => ['px', '%'],
        'selectors'  => [
            '{{WRAPPER}} .tx-hero-slider__styleOne .swiper-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
    ]
);

// END SECTION STYLE
$this->end_controls_section();