<?php

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

$this->start_controls_section(
    '_section_style_sub_title',
    [
        'label' => __( 'HEADING STYLE', 'telnet-core' ),
        'tab'   => Controls_Manager::TAB_STYLE,
    ]
);

// sub title color
$this->add_control(
    'sub_title_color',
    [
        'label'     => __( 'Sub Title Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tel-main-slider-4 .swiper-slide-active .tel-slider-text-4 h1' => 'color: {{VALUE}};',
        ],
    ]
);

// sub title bg color
$this->add_control(
    'sub_title_bg_color',
    [
        'label'     => __( 'Background Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tel-main-slider-4 .swiper-slide-active .tel-slider-text-4 h1' => 'background-color: {{VALUE}};',
        ],
    ]
);

// sub title padding
$this->add_responsive_control(
    'sub_title_padding',
    [
        'label'      => __( 'Padding', 'telnet-core' ),
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => ['px', 'em', '%'],
        'selectors'  => [
            '{{WRAPPER}} .tel-main-slider-4 .swiper-slide-active .tel-slider-text-4 h1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
    ]
);

// sub title margin
$this->add_responsive_control(
    'sub_title_margin',
    [
        'label'      => __( 'Margin', 'telnet-core' ),
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => ['px', 'em', '%'],
        'selectors'  => [
            '{{WRAPPER}} .tel-main-slider-4 .swiper-slide-active .tel-slider-text-4 h1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
    ]
);

// sub title typography
$this->add_group_control(
    Group_Control_Typography::get_type(),
    [
        'name'     => 'sub_title_typography',
        'label'    => __( 'Typography', 'telnet-core' ),
        'selector' => '{{WRAPPER}} .tel-main-slider-4 .swiper-slide-active .tel-slider-text-4 h1',
    ]
);

$this->end_controls_section();
