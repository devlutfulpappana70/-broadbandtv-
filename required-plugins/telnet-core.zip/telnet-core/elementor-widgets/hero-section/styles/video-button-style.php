<?php

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;


$this->start_controls_section(
    '_section_style_video_button',
    [
        'label' => __( 'VIDEO BUTTON STYLE', 'telnet-core' ),
        'tab'   => Controls_Manager::TAB_STYLE,
    ]
);

// typography
$this->add_group_control(
    Group_Control_Typography::get_type(),
    [
        'name'     => 'video_button_typography',
        'label'    => __( 'Typography', 'telnet-core' ),
        'selector' => '{{WRAPPER}} .banner-one_play-box i',
    ]
);

$this->start_controls_tabs('_tabs_video_button');

$this->start_controls_tab(
    '_tab_video_button_normal',
    [
        'label' => __( 'Normal', 'telnet-core' ),
    ]
);

$this->add_group_control(
    Group_Control_Background::get_type(),
    [
        'name'     => 'video_btn_gradient_background',
        'label'    => __( 'Background', 'telnet-core' ),
        'types'    => [ 'classic', 'gradient' ],
        'exclude'  => [ 'image' ],
        'selector' => '{{WRAPPER}} .banner-one_play-box i',
    ]
);

// icon bg color
$this->add_group_control(
    Group_Control_Background::get_type(),
    [
        'name'     => 'video_btn_icon_background',
        'label'    => __( 'Background', 'telnet-core' ),
        'types'    => [ 'classic', 'gradient' ],
        'selector' => '{{WRAPPER}} .banner-one_play-box span i',
        'exclude'  => [ 'image' ],
    ]
);

$this->end_controls_tab();

$this->start_controls_tab(
    '_tab_video_button_hover',
    [
        'label' => __( 'Hover', 'telnet-core' ),
    ]
);

$this->add_group_control(
    Group_Control_Background::get_type(),
    [
        'name'     => 'video_btn_hover_gradient_background',
        'label'    => __( 'Background', 'telnet-core' ),
        'types'    => [ 'classic', 'gradient' ],
        'selector' => '{{WRAPPER}} .banner-one_play-box:hover i',
        'exclude'  => [ 'image' ],
    ]
);

// icon bg color
$this->add_group_control(
    Group_Control_Background::get_type(),
    [
        'name'     => 'video_btn_hover_icon_background',
        'label'    => __( 'Background', 'telnet-core' ),
        'types'    => [ 'classic', 'gradient' ],
        'selector' => '{{WRAPPER}} .banner-one_play-box:hover span i',
        'exclude'  => [ 'image' ],
    ]
);

$this->end_controls_tab();

$this->end_controls_tabs();

$this->end_controls_section();