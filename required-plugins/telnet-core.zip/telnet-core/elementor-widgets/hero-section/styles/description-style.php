<?php

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

$this->start_controls_section(
    '_section_style_description',
    [
        'label' => __( 'DESCRIPTION STYLE', 'telnet-core' ),
        'tab'   => Controls_Manager::TAB_STYLE,
    ]
);

// description color
$this->add_control(
    'description_color',
    [
        'label'     => __( 'Description Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tel-main-slider-4 .swiper-slide-active .tel-slider-text-4 p' => 'color: {{VALUE}};',
            '{{WRAPPER}} .banner-one_text' => 'color: {{VALUE}};',
        ],
    ]
);

// description padding
$this->add_responsive_control(
    'description_padding',
    [
        'label'      => __( 'Padding', 'telnet-core' ),
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => ['px', 'em', '%'],
        'selectors'  => [
            '{{WRAPPER}} .tel-main-slider-4 .swiper-slide-active .tel-slider-text-4 p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            '{{WRAPPER}} .banner-one_text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

        ],
    ]
);

// description margin
$this->add_responsive_control(
    'description_margin',
    [
        'label'      => __( 'Margin', 'telnet-core' ),
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => ['px', 'em', '%'],
        'selectors'  => [
            '{{WRAPPER}} .tel-main-slider-4 .swiper-slide-active .tel-slider-text-4 p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            '{{WRAPPER}} .banner-one_text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
    ]
);

// description typography
$this->add_group_control(
    Group_Control_Typography::get_type(),
    [
        'name'     => 'description_typography',
        'label'    => __( 'Typography', 'telnet-core' ),
        'selector' => '
            {{WRAPPER}} .tel-main-slider-4 .swiper-slide-active .tel-slider-text-4 p,
            {{WRAPPER}} .banner-one_text
        ',

    ]
);

$this->end_controls_section();