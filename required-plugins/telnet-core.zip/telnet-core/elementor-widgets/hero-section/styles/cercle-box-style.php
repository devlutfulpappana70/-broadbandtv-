<?php

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

 // SECTION CERCLE BADGE STYLE
 $this->start_controls_section(
    '_section_cercle_badge_style',
    [
        'label' => __( 'CERCLE BADGE STYLE', 'telnet-core' ),
        'tab'   => Controls_Manager::TAB_STYLE,
    ]
);

// cercle badge background color
$this->add_control(
    'cercle_badge_bg_color',
    [
        'label' => __( 'Background Color', 'telnet-core' ),
        'type' => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tx-cercleBadge::after' => 'background-color: {{VALUE}};',
        ],
    ]
);

// cercle badge color
$this->add_control(
    'cercle_badge_color',
    [
        'label' => __( 'Text Color', 'telnet-core' ),
        'type' => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tx-cercleBadge' => 'color: {{VALUE}};',
        ],
    ]
);

// typography
$this->add_group_control(
    Group_Control_Typography::get_type(),
    [
        'name' => 'cercle_badge_typography',
        'label' => __( 'Typography', 'telnet-core' ),
        'selector' => '{{WRAPPER}} .tx-cercleBadge',
    ]
);

// END SECTION CERCLE BADGE STYLE
$this->end_controls_section();