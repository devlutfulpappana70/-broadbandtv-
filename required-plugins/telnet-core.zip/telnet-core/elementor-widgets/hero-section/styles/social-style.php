<?php

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;


$this->start_controls_section(
    '_section_style_social',
    [
        'label' => __( 'SOCIAL STYLE', 'telnet-core' ),
        'tab'   => Controls_Manager::TAB_STYLE,
    ]
);

// social title color
$this->add_control(
    'social_title_color',
    [
        'label'     => __( 'Title Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .banner-two_socials span' => 'color: {{VALUE}};',
        ],
    ]
);

// typography
$this->add_group_control(
    Group_Control_Typography::get_type(),
    [
        'name'     => 'social_typography',
        'label'    => __( 'Typography', 'telnet-core' ),
        'selector' => '{{WRAPPER}} .banner-two_socials a',
    ]
);

// line color
$this->add_control(
    'social_line_color',
    [
        'label'     => __( 'Line Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .banner-two_socials span::before' => 'background-color: {{VALUE}};',
        ],
    ]
);

// font size
$this->add_responsive_control(
    'social_font_size',
    [
        'label'      => __( 'Icon Size', 'telnet-core' ),
        'type'       => Controls_Manager::SLIDER,
        'size_units' => ['px', 'em'],
        'range'      => [
            'px' => [
                'min' => 10,
                'max' => 100,
            ],
            'em' => [
                'min' => 1,
                'max' => 10,
            ],
        ],
        'selectors'  => [
            '{{WRAPPER}} .banner-two_socials a' => 'font-size: {{SIZE}}{{UNIT}};',
        ],
    ]
);

$this->start_controls_tabs('_tabs_button');

$this->start_controls_tab(
    '_tab_button_normal',
    [
        'label' => __( 'Normal', 'telnet-core' ),
    ]
);

// color
$this->add_control(
    'social_color',
    [
        'label'     => __( 'Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .banner-two_socials a' => 'color: {{VALUE}};',
        ],
    ]
);

// background image
$this->add_control(
    'social_bg_image',
    [
        'label'     => __( 'Background Image', 'telnet-core' ),
        'type'      => Controls_Manager::MEDIA,
        'selectors' => [
            '{{WRAPPER}} .banner-two_socials a::after' => 'background-image: url({{URL}});',
        ],
    ]
);


$this->end_controls_tab();

$this->start_controls_tab(
    '_tab_button_hover',
    [
        'label' => __( 'Hover', 'telnet-core' ),
    ]
);

// color
$this->add_control(
    'social_icon_color_hover',
    [
        'label'     => __( 'Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .banner-two_socials a:hover' => 'color: {{VALUE}};',
        ],
    ]
);

// background color
$this->add_control(
    'social_icon_bg_image',
    [
        'label'     => __( 'Background Image', 'telnet-core' ),
        'type'      => Controls_Manager::MEDIA,
        'selectors' => [
            '{{WRAPPER}} .banner-two_socials a:hover::after' => 'background-image: url({{URL}});',
        ],
    ]
);

$this->end_controls_tab();

$this->end_controls_tabs();

$this->end_controls_section();