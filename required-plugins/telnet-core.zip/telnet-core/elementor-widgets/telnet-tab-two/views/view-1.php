<?php

$this->add_inline_editing_attributes( 'title', 'basic' );
$this->add_render_attribute( 'title', 'class', 'sec-title-five_heading' );
$title = elh_element_kses_basic( $settings['title'] );
$rand = rand(0, 9999);
?>

<section class="speed-one" style="background-image: url(<?php echo $settings['bg_image']['url'] ? esc_url($settings['bg_image']['url']) : ''; ?>)">
    <div class="auto-container">
        <?php if(!empty( $settings['image_2']['url'] )) : ?>
        <div class="speed-one_hand">
            <img src="<?php echo esc_url($settings['image_2']['url']); ?>" alt="" />
        </div>
        <?php endif; ?>

        <?php if(!empty( $settings['image_3']['url'] )) : ?>
        <div class="speed-one_rocket">
            <img src="<?php echo esc_url($settings['image_3']['url']); ?>" alt="" />
        </div>
        <?php endif; ?>

        <!-- Sec Title Five -->
        <div class="sec-title-five centered">
            <?php if(!empty( $settings['sub_title'] )) : ?>
            <div class="sec-title-five_title"><?php echo elh_element_kses_intermediate($settings['sub_title']); ?></div>
            <?php endif; ?>

            <?php
                printf('<%1$s %2$s>%3$s</%1$s>',
                    tag_escape($settings['title_tag']),
                    $this->get_render_attribute_string('title'),
                    $title
                );
            ?>

            <?php if(!empty($settings['description'])) : ?>
            <div class="sec-title-five_text"><?php echo wp_kses($settings['description'], true)?></div>
            <?php endif; ?>
        </div>

        <!-- Video Info Tabs -->
        <div class="speed-info-tabs">
            <!-- Video Tabs -->
            <div class="speed-tabs tabs-box">

                <!-- Tab Btns -->
                <ul class="tab-btns tab-buttons d-flex flex-wrap justify-content-center align-item-center clearfix">
                    <?php
                        foreach( $settings['tab_lists'] as $id => $list ) :
                        $active = ($id == 0) ? 'active-btn' : '';

                    ?>
                    <li data-tab="#speed-<?php echo esc_attr($id . $rand); ?>" class="tab-btn <?php echo esc_attr($active); ?>">
                        <?php if($list['type'] == 'icon') : ?>
                            <?php \Elementor\Icons_Manager::render_icon( $list['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                        <?php else : ?>
                            <img src="<?php echo esc_url($list['list_image']['url']); ?>" alt="" />
                        <?php endif; ?>

                        <?php echo elh_element_kses_intermediate($list['tab_title']); ?>
                    </li>
                    <?php endforeach; ?>

                </ul>

                <!-- Tabs Container -->
                <div class="tabs-content">
                    <?php
                        foreach( $settings['tab_lists'] as $id => $list ) :
                        $active = ($id == 0) ? 'active-tab' : '';

                    ?>
                    <div class="tab <?php echo esc_attr($active); ?>" id="speed-<?php echo esc_attr($id . $rand); ?>">
                        <div class="content">
                            <?php if(!empty( $list['tab_content_image']['url'] )) : ?>
                            <div class="image">
                                <img src="<?php echo esc_url($list['tab_content_image']['url']); ?>" alt="" />
                            </div>
                            <?php endif; ?>

                            <!-- Speed Info Box -->
                            <div class="speed-info_box d-flex justify-content-between align-item-center flex-wrap">
                                <?php
                                    foreach( $list['speed_lists'] as $id => $speed_list ) :
                                ?>
                                <div class="speed-info">
                                    <div class="d-flex justify-content-between align-item-center flex-wrap">
                                        <div class="speed">
                                        <?php \Elementor\Icons_Manager::render_icon( $speed_list['speed_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                            <?php echo elh_element_kses_intermediate($speed_list['speed_title']); ?>
                                        </div>
                                        <div class="speed-mb"><span><?php echo elh_element_kses_intermediate($speed_list['speed_value']); ?></span> <?php echo elh_element_kses_intermediate($speed_list['speed_unit']); ?></div>
                                    </div>

                                    <?php if(!empty( $speed_list['bg_image']['url'] )) : ?>
                                    <div class="graph-image">
                                        <img src="<?php echo esc_url($speed_list['bg_image']['url']); ?>" alt="" />
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>