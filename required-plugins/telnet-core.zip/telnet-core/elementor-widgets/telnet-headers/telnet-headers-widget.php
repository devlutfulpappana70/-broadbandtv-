<?php

namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
use \Elementor\Core\Schemes\Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Background;
use \Elementor\Utils;

defined( 'ABSPATH' ) || die();

class Telnet_Headers extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name() {
        return 'telnet_headers';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title() {
        return __( 'TelNet Headers', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/gradient-heading/';
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-t-letter';
    }

    public function get_keywords() {
        return ['btn', 'header', 'telnet', 'telnet header'];
    }

    // get menu by slug
    public function get_menu() {
        $menus = wp_get_nav_menus();
        $menu_list = array();
        if ( $menus ) {
            foreach ( $menus as $menu ) {
                $menu_list[ $menu->slug ] = $menu->name;
            }
        }
        return $menu_list;
    }

    protected function register_content_controls() {

        //Settings
        $this->start_controls_section(
            '_section_design_settings',
            [
                'label' => __( 'Choose Design Stylr', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'design_style',
            [
                'label'              => __( 'Design Style', 'telnet-core' ),
                'type'               => Controls_Manager::SELECT,
                'options'            => [
                    'style_1' => __( 'Header One', 'telnet-core' ),
                    'style_2' => __( 'Header two', 'telnet-core' ),
                    'style_3' => __( 'Header three', 'telnet-core' ),
                    'style_4' => __( 'Header Four', 'telnet-core' ),
                    'style_5' => __( 'Header Five', 'telnet-core' ),
                    'style_6' => __( 'Header Six', 'telnet-core' ),
                    'style_7' => __( 'Header Seven', 'telnet-core' ),
                    'style_8' => __( 'Header Eight', 'telnet-core' ),
                    'style_9' => __( 'Header Nine', 'telnet-core' ),
                ],
                'default'            => 'style_1',
                'frontend_available' => true,
                'style_transfer'     => true,
            ]
        );

        $this->end_controls_section();

        // contact info section
        $this->start_controls_section(
            '_section_contact_info',
            [
                'label' => __( 'Contact Info', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'design_style' => 'style_2',
                ],
            ]
        );

        // repeater
        $repeater = new Repeater();

        // contact info icon
        $repeater->add_control(
            'info_icon',
            [
                'label'       => __( 'Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'default'     => [
                    'value'   => 'fas fa-check',
                    'library' => 'solid',
                ],
                'label_block' => true,
            ]
        );

        // editor
        $repeater->add_control(
            'info_text',
            [
                'label'       => __( 'Text', 'telnet-core' ),
                'type'        => Controls_Manager::WYSIWYG,
                'default'     => __( 'This is the heading', 'telnet-core' ),
                'placeholder' => __( 'Enter your text', 'telnet-core' ),
                'show_label'  => false,
            ]
        );

        // contact info list
        $this->add_control(
            'contact_info_lists',
            [
                'label'       => __( 'Contact Info List', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [
                    [
                        'info_text' => __( 'This is the heading', 'telnet-core' ),
                    ],
                    [
                        'info_text' => __( 'This is the heading', 'telnet-core' ),
                    ],
                ],
                'title_field' => '{{{ info_text }}}',
            ]
        );

        // end contact info section
        $this->end_controls_section();

        // social icons section
        $this->start_controls_section(
            '_section_social_icons',
            [
                'label' => __( 'Social Icons', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'design_style' => ['style_2', 'style_4', 'style_5', 'style_9'],
                ],
            ]
        );
        $this->add_control(
            'social_title',
            [
                'label'       => __( 'Social Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'show_label'  => false,
                'condition' => [
                    'design_style' => ['style_4', 'style_5', 'style_9'],
                ],
            ]
        );
        // repeater
        $repeater = new Repeater();

        // social icon
        $repeater->add_control(
            'social_icon',
            [
                'label'       => __( 'Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'default'     => [
                    'value'   => 'fab fa-facebook-f',
                    'library' => 'solid',
                ],
                'label_block' => true,
            ]
        );

        // social link
        $repeater->add_control(
            'social_link',
            [
                'label'       => __( 'Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'telnet-core' ),
                'show_label'  => false,
                'default'     => [
                    'url' => '#',
                ],
            ]
        );

        // social icons list
        $this->add_control(
            'social_icons_lists',
            [
                'label'       => __( 'Social Icons List', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [
                    [
                        'social_link' => __( 'https://your-link.com', 'telnet-core' ),
                    ],
                ],
                'title_field' => '{{{ social_link.url }}}',
            ]
        );

        // end social icons section
        $this->end_controls_section();

        // logo section
        $this->start_controls_section(
            '_section_logo',
            [
                'label' => __( 'Logo', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // logo
        $this->add_control(
            'logo',
            [
                'label'       => __( 'Logo', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'label_block' => true,
            ]
        );

        // mobile_logo
        $this->add_control(
            'mobile_logo',
            [
                'label'       => __( 'Mobile Logo', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'label_block' => true,
            ]
        );

        // logo width responsive control
        $this->add_responsive_control(
            'logo_width',
            [
                'label'      => __( 'Logo Width', 'telnet-core' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 500,
                        'step' => 1,
                    ],
                    '%'  => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .tx-logo' => 'width: {{SIZE}}{{UNIT}} !important;',
                    '{{WRAPPER}} .tx-logo img' => 'max-width: {{SIZE}}{{UNIT}} !important;',
                ],
            ]
        );


        // enable custom link
        $this->add_control(
            'enable_custom_link',
            [
                'label'        => __( 'Enable Custom Link', 'telnet-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'telnet-core' ),
                'label_off'    => __( 'No', 'telnet-core' ),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        // custom link
        $this->add_control(
            'custom_link',
            [
                'label'       => __( 'Custom Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'telnet-core' ),
                'show_label'  => false,
                'default'     => [
                    'url' => '#',
                ],
                'condition'   => [
                    'enable_custom_link' => 'yes',
                ],
            ]
        );

        // enable sticky logo
        $this->add_control(
            'enable_sticky_logo',
            [
                'label'        => __( 'Enable Sticky Logo', 'telnet-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'telnet-core' ),
                'label_off'    => __( 'No', 'telnet-core' ),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        // sticky logo
        $this->add_control(
            'sticky_logo',
            [
                'label'       => __( 'Sticky Logo', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'label_block' => true,
                'condition'   => [
                    'enable_sticky_logo' => 'yes',
                ],
            ]
        );

        // end logo section
        $this->end_controls_section();

        $this->start_controls_section(
            '_section_menu',
            [
                'label' => __( 'Menu Options', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // select menu
        $this->add_control(
            'select_menu',
            [
                'label'       => __( 'Select Menu', 'telnet-core' ),
                'type'        => Controls_Manager::SELECT2,
                'options'     => $this->get_menu(),
                'label_block' => true,
                'multiple'    => false,
            ]
        );

        $this->end_controls_section();

        // CONTACT NUMBER
        $this->start_controls_section(
            '_section_contact_number',
            [
                'label' => __( 'Contact Number', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'design_style' => ['style_1', 'style_4', 'style_5', 'style_7', 'style_9'],
                ],
            ]
        );

        // ICON
        $this->add_control(
            'contact_number_icon',
            [
                'label'       => __( 'Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'default'     => [
                    'value'   => 'fas fa-phone',
                    'library' => 'solid',
                ],
                'label_block' => true,
            ]
        );

        // TEXT
        $this->add_control(
            'contact_number_label',
            [
                'label'       => __( 'Label', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Call Us Now', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        // NUMBER
        $this->add_control(
            'contact_number',
            [
                'label'       => __( 'Number', 'telnet-core' ),
                'type'        => Controls_Manager::WYSIWYG,
                'default'     => __( '+880 123 456 789', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        // address icon
        $this->add_control(
            'address_icon',
            [
                'label'       => __( 'Address Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'default'     => [
                    'value'   => 'fas fa-map-marker-alt',
                    'library' => 'solid',
                ],
                'label_block' => true,
                'condition' => [
                    'design_style' => ['style_4', 'style_5', 'style_9'],
                ],
            ]
        );
        $this->add_control(
            'address',
            [
                'label'       => __( 'Address', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'default'     => __( 'Type Address Here', 'telnet-core' ),
                'label_block' => true,
                'condition' => [
                    'design_style' => ['style_4', 'style_5', 'style_9'],
                ],
            ]
        );

        // END CONTACT NUMBER
        $this->end_controls_section();

        // LANGUAGE LISTS
        $this->start_controls_section(
            '_section_language_lists',
            [
                'label' => __( 'Language Lists', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // active language flag
        $this->add_control(
            'active_language_flag',
            [
                'label'       => __( 'Active Language Flag', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'label_block' => true,
            ]
        );

        // active language title
        $this->add_control(
            'active_language_title',
            [
                'label'       => __( 'Active Language Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'English', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        // add repeater control
        $repeater = new Repeater();

        // language title
        $repeater->add_control(
            'language_title',
            [
                'label'       => __( 'Language Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'English', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        // link
        $repeater->add_control(
            'language_link',
            [
                'label'       => __( 'Language Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'telnet-core' ),
                'show_label'  => false,
                'default'     => [
                    'url' => '#',
                ],
            ]
        );

        // add control
        $this->add_control(
            'language_lists',
            [
                'label'       => __( 'Language Lists', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [
                    [
                        'language_title' => __( 'English', 'telnet-core' ),
                    ],
                    [
                        'language_title' => __( 'Spanish', 'telnet-core' ),
                    ],
                    [
                        'language_title' => __( 'French', 'telnet-core' ),
                    ],
                ],
                'title_field' => '{{{ language_title }}}',
            ]
        );

        // END LANGUAGE LISTS
        $this->end_controls_section();

        // settings section
        $this->start_controls_section(
            '_section_settings',
            [
                'label' => __( 'Settings', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // enable header top
        $this->add_control(
            'enable_header_top',
            [
                'label'        => __( 'Enable Header Top', 'telnet-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'telnet-core' ),
                'label_off'    => __( 'No', 'telnet-core' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        // enable sticky header
        $this->add_control(
            'enable_sticky_header',
            [
                'label'        => __( 'Enable Sticky Header', 'telnet-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'telnet-core' ),
                'label_off'    => __( 'No', 'telnet-core' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        // enable header right
        $this->add_control(
            'enable_header_right',
            [
                'label'        => __( 'Enable Header Right', 'telnet-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'telnet-core' ),
                'label_off'    => __( 'No', 'telnet-core' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        // enable search popup
        $this->add_control(
            'enable_search_popup',
            [
                'label'        => __( 'Enable Search Popup', 'telnet-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'telnet-core' ),
                'label_off'    => __( 'No', 'telnet-core' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        // enable mini cart
        $this->add_control(
            'enable_mini_cart',
            [
                'label'        => __( 'Enable Mini Cart', 'telnet-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'telnet-core' ),
                'label_off'    => __( 'No', 'telnet-core' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        // enable language switcher
        $this->add_control(
            'enable_language_switcher',
            [
                'label'        => __( 'Enable Language Switcher', 'telnet-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'telnet-core' ),
                'label_off'    => __( 'No', 'telnet-core' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        // enable header social icons
        $this->add_control(
            'enable_header_social_icons',
            [
                'label'        => __( 'Enable Header Social Icons', 'telnet-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'telnet-core' ),
                'label_off'    => __( 'No', 'telnet-core' ),
                'return_value' => 'yes',
                'default'      => 'yes',
                'condition' => [
                    'design_style' => ['style_1', 'style_2', 'style_4', 'style_5', 'style_9'],
                ],
            ]
        );

        // end settings section
        $this->end_controls_section();

    }

    protected function register_style_controls() {
        $dir = dirname( __FILE__ );

        include $dir . '/styles/sticky-header-style.php';
        include $dir . '/styles/header-top-style.php';
        include $dir . '/styles/contact-info-style.php';
        include $dir . '/styles/social-links-style.php';
        include $dir . '/styles/header-middle-style.php';
        include $dir . '/styles/menu-style.php';
        include $dir . '/styles/call-style.php';
        include $dir . '/styles/header-right-style.php';

    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $dir = dirname( __FILE__ );
        $style = !empty($settings['design_style']) ? $settings['design_style'] : 'style_1';

        switch ($style) {
            case 'style_9':
                include $dir . '/views/view-9.php';
                break;
            case 'style_8':
                include $dir . '/views/view-8.php';
                break;
            case 'style_7':
                include $dir . '/views/view-7.php';
                break;
            case 'style_6':
                include $dir . '/views/view-6.php';
                break;
            case 'style_5':
                include $dir . '/views/view-5.php';
                break;
            case 'style_4':
                include $dir . '/views/view-4.php';
                break;
            case 'style_3':
                include $dir . '/views/view-3.php';
                break;
            case 'style_2':
                include $dir . '/views/view-2.php';
                break;
            default:
                include $dir . '/views/view-1.php';
        }
    }
}
