<?php
    $enable_custom_link = $settings['enable_custom_link'];

    if($enable_custom_link == 'yes') {
        $custom_link = $settings['custom_link']['url'];
    } else {
        $custom_link = home_url( '/' );
    }

    // enable position
    $enable_position_absolute = $settings['enable_position_absolute'];

    if($enable_position_absolute == 'yes') {
        $position_absolute = 'position-absolute';
    } else {
        $position_absolute = '';
    }

?>

<div class="tx-header tx-header__styleTwo <?php echo esc_attr($position_absolute); ?>">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-11">
                <div class="tx-topWrapper position-relative tx-z1">
                    <div class="row">
                        <div class="col-md-7 align-self-center">
                            <ul class="list-unstyled tx-listItems d-flex align-items-center">
                                <?php foreach ( $settings['contact_info_lists'] as $key => $list ): ?>
                                <li>
                                    <span class="tx-icon">
                                        <?php
                                            if (!empty($list['info_icon'])) {
                                                elh_element_render_icon($list, '', 'info_icon');
                                            }
                                        ?>
                                    </span>
                                    <p><?php echo elh_element_kses_intermediate( $list['info_text'] ); ?></p>
                                </li>
                                <?php endforeach;?>
                            </ul>
                        </div>
                        <div class="col-md-5 align-self-center">
                            <div class="tx-social-links d-flex align-items-center justify-content-end">
                                <?php foreach ( $settings['social_icons_lists'] as $key => $list ): ?>
                                <a href="<?php echo esc_url($list['social_link']['url']); ?>">
                                    <?php
                                        if (!empty($list['social_icon'])) {
                                            elh_element_render_icon($list, '', 'social_icon');
                                        }
                                    ?>
                                </a>
                                <?php endforeach;?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="inner-wrapper position-relative">
            <div class="tx-bottomWrapper pt-15 mt-none-15">
                <div class="row">
                    <div class="col-xl-2 col-lg-4 col-md-5 col-sm-5 col-5 align-self-center">
                        <?php if(!empty( $settings['logo']['url'] )) : ?>
                        <a href="<?php echo esc_url($custom_link); ?>" class="tx-logo">
                            <img src="<?php echo esc_url($settings['logo']['url']); ?>" alt="">
                        </a>
                        <?php endif; ?>
                    </div>
                    <div class="col-xl-8 d-none d-xl-block">
                        <?php if ( !empty( $settings['select_menu'] ) ) : ?>
                        <div class="tx-main-menu tx-main-menu__styleTwo txMenuWrapper">
                            <div id="tx-navbar">
                                <?php
                                    echo wp_nav_menu( [
                                        'menu'        => '' . $settings['select_menu'] . '',
                                        'menu_class'  => 'navigation clearfix justify-content-center',
                                        'container'   => '',
                                        'fallback_cb' => 'Navwalker_Class::fallback',
                                        'walker'      => class_exists( 'Telnet_Mega_Menu_Walker' ) ? new Telnet_Mega_Menu_Walker : '',
                                    ] );
                                ?>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-xl-2 col-lg-8 col-md-7 col-sm-7 col-7 align-self-center">
                        <div class="tx-searchCartLang-wrapper d-flex align-items-center">

                            <?php if(TELNET_CORE_WOOCOMMERCE_ACTIVED && $settings['enable_mini_cart'] == 'yes' ) : ?>
                            <div class="tx-miniCartBtn-wrapper position-relative">
                                <button class="tx-cart-btn" data-txMiniCartTrigger>
                                    <i class="fas fa-shopping-cart"></i>
                                    <span class="tx-cart-count tx-radious-50" id="tx-cart-count">
                                        <?php
                                            if (class_exists('WooCommerce') && WC()->cart) {
                                                $count = WC()->cart->cart_contents_count;
                                            } else {
                                                $count = 0;
                                            }

                                            if ( $count == 0 ) {
                                                echo '0';
                                            } else {
                                                echo '' . esc_html( $count ) . '';
                                            }
                                        ?>
                                    </span>
                                </button>
                            </div>
                            <?php endif; ?>

                            <?php if( $settings['enable_language_switcher'] == 'yes' ) : ?>
                            <div class="tx-lang-wrapper d-sm-block d-none">
                                <button class="dropdown-toggle" type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="inside">
                                    <?php if(!empty( $settings['active_language_flag']['url'] )) : ?>
                                    <span class="tx-lang-flag tx-radious-50">
                                        <img src="<?php echo esc_url($settings['active_language_flag']['url']); ?>" alt="" />
                                    </span>
                                    <?php endif; ?>
                                    <?php echo $settings['active_language_title'] ? esc_html($settings['active_language_title']) : ''; ?>
                                    <i class="fas fa-caret-down"></i>
                                </button>
                                <?php if(!empty( $settings['language_lists'] )) : ?>
                                <ul class="dropdown-menu list-unstyled" aria-labelledby="dropdownMenuButton2">
                                    <?php foreach($settings['language_lists'] as $list) : ?>
                                    <li><a class="dropdown-item" href="<?php echo esc_url($list['language_link']['url']); ?>"><?php echo esc_html($list['language_title']) ?></a></li>
                                    <?php endforeach; ?>
                                </ul>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                            <button class="tx-sideInfo-btn d-flex align-items-center flex-column d-xl-none" data-txSideInfoTrigger>
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tx-lines d-flex align-items-center justify-content-center">
                <span class="tx-line tx-line__1"></span>
                <span class="tx-line tx-line__2"></span>
                <span class="tx-line tx-line__3"></span>
            </div>
        </div>
    </div>
</div>