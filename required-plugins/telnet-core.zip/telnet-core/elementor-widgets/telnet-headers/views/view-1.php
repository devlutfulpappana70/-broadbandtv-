<?php
    $enable_custom_link = $settings['enable_custom_link'];

    if($enable_custom_link == 'yes') {
        $custom_link = $settings['custom_link']['url'];
    } else {
        $custom_link = home_url( '/' );
    }

    // enable position
    $enable_position_absolute = $settings['enable_position_absolute'];

    if($enable_position_absolute == 'yes') {
        $position_absolute = 'position-absolute';
    } else {
        $position_absolute = '';
    }

?>

<header class="tx-header tx-header__styleDefault pt-30 <?php echo esc_attr($position_absolute); ?>">
    <div class="container-fluid tx-container-fluid">
        <div class="row">
            <div class="col-xl-12">
                <div class="tx-wrapper position-relative pl-65 pr-65">
                    <div class="row">
                        <div class="col-lg-7 col-md-4 col-sm-4 col-5 align-self-center">
                            <div class="tx-wraper d-flex align-items-center">
                                <div class="tx-logo-wrapper mr-125">
                                    <?php if(!empty( $settings['logo']['url'] )) : ?>
                                        <a href="<?php echo esc_url($custom_link); ?>" class="tx-logo">
                                            <img src="<?php echo esc_url($settings['logo']['url']); ?>" alt="">
                                        </a>
                                        <?php endif; ?>
                                    </div>
                                    <?php if ( !empty( $settings['select_menu'] ) ) : ?>
                                    <div class="tx-menu-wrapper txMenuWrapper">
                                        <div class="tx-main-menu">
                                            <div id="tx-navbar">
                                                <?php
                                                    echo wp_nav_menu( [
                                                        'menu'        => '' . $settings['select_menu'] . '',
                                                        'menu_class'  => 'navigation clearfix justify-content-center',
                                                        'container'   => '',
                                                        'fallback_cb' => 'Navwalker_Class::fallback',
                                                        'walker'      => class_exists( 'Telnet_Mega_Menu_Walker' ) ? new Telnet_Mega_Menu_Walker : '',
                                                    ] );
                                                ?>
                                            </div>
                                        </div>
                                        <button class="tx-sideInfo-btn d-flex align-items-center flex-column d-xl-none" data-txsideinfotrigger>
                                            <span></span>
                                            <span></span>
                                            <span></span>
                                        </button>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <div class="col-lg-5 col-md-8 col-sm-8 col-7 align-self-center">
                            <div class="tx-right-wrapper d-flex align-items-center justify-content-end">
                                <div class="tx-contact-info tx-contact-info__horizntal pr-115 d-none d-xl-flex">
                                    <?php if(!empty( $settings['contact_number_icon'] )) : ?>
                                    <div class="tx-icon bg-white tx-radious-50 mr-15 tx-rotate-45">
                                        <?php
                                            echo elh_element_render_icon($settings, '', 'contact_number_icon');
                                        ?>
                                    </div>
                                    <?php endif; ?>
                                    <div class="tx-content">
                                        <?php if(!empty( $settings['contact_number_label'] )) : ?>
                                        <p class="tx-label tx-white">
                                            <?php echo esc_html($settings['contact_number_label']); ?>
                                        </p>
                                        <?php endif; ?>

                                        <?php if(!empty( $settings['contact_number'] )) : ?>
                                        <div class="tx-number tx-white">
                                            <?php echo elh_element_kses_intermediate($settings['contact_number']); ?>
                                        </div>
                                        <?php endif; ?>

                                    </div>
                                </div>

                                <div class="tx-searchCartLang-wrapper d-flex align-items-center">
                                    <?php if( $settings['enable_search_popup'] == 'yes' ) : ?>
                                    <button class="tx-search-btn tx-white" data-tx-searchtrigger>
                                        <i class="far fa-search"></i>
                                    </button>
                                    <?php endif; ?>

                                    <?php if(TELNET_CORE_WOOCOMMERCE_ACTIVED && $settings['enable_mini_cart'] == 'yes' ) : ?>
                                    <div class="tx-miniCartBtn-wrapper position-relative">
                                        <button class="tx-cart-btn tx-white" data-txMiniCartTrigger>
                                            <i class="fas fa-shopping-cart"></i>
                                            <span class="tx-cart-count tx-radious-50" id="tx-cart-count">
                                                <?php
                                                    if (class_exists('WooCommerce') && WC()->cart) {
                                                        $count = WC()->cart->cart_contents_count;
                                                    } else {
                                                        $count = 0;
                                                    }

                                                    if ( $count == 0 ) {
                                                        echo '0';
                                                    } else {
                                                        echo '' . esc_html( $count ) . '';
                                                    }
                                                ?>
                                            </span>
                                        </button>
                                    </div>
                                    <?php endif; ?>

                                    <?php if( $settings['enable_language_switcher'] == 'yes' ) : ?>
                                    <div class="tx-lang-wrapper d-md-block d-none">
                                        <button class="dropdown-toggle tx-white" type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="inside">
                                            <?php if(!empty( $settings['active_language_flag']['url'] )) : ?>
                                            <span class="tx-lang-flag tx-radious-50">
                                                <img src="<?php echo esc_url($settings['active_language_flag']['url']); ?>" alt="" />
                                            </span>
                                            <?php endif; ?>
                                            <?php echo $settings['active_language_title'] ? esc_html($settings['active_language_title']) : ''; ?>
                                            <i class="fas fa-caret-down"></i>
                                        </button>
                                        <?php if(!empty( $settings['language_lists'] )) : ?>
                                        <ul class="dropdown-menu list-unstyled" aria-labelledby="dropdownMenuButton2">
                                            <?php foreach($settings['language_lists'] as $list) : ?>
                                            <li><a class="dropdown-item" href="<?php echo esc_url($list['language_link']['url']); ?>"><?php echo esc_html($list['language_title']) ?></a></li>
                                            <?php endforeach; ?>
                                        </ul>
                                        <?php endif; ?>
                                    </div>
                                    <?php endif; ?>

                                    <button class="tx-sideInfo-btn d-flex align-items-center flex-column d-xl-none" data-txsideinfotrigger="">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>