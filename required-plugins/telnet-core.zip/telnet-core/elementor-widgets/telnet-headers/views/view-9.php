<?php
 $enable_custom_link = $settings['enable_custom_link'];

 if($enable_custom_link == 'yes') {
     $custom_link = $settings['custom_link']['url'];
 } else {
     $custom_link = home_url( '/' );
 }

 // enable position
 $enable_position_absolute = $settings['enable_position_absolute'];

 if($enable_position_absolute == 'yes') {
     $position_absolute = 'position-absolute';
 } else {
     $position_absolute = '';
 }
?>
<header class="tx-header main-header tna-header-3 tna-tranfer-header flat_3 <?php echo esc_attr($position_absolute); ?>">

    <?php if( $settings['enable_header_top'] === 'yes' ) : ?>
    <div class="header-top">
        <div class="auto-container">
            <div class="inner-container">
                <div class="tna-top-header-3 d-flex justify-content-between align-items-center flex-wrap">
                    <?php if(!empty( $settings['address'] )) : ?>
                    <ul class="header-list">
                        <li>
                            <?php \Elementor\Icons_Manager::render_icon( $settings['address_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                            <?php echo wp_kses($settings['address'], true);?>
                        </li>
                    </ul>
                    <?php endif; ?>

                    <?php if( $settings['enable_header_social_icons'] === 'yes' ) : ?>
                    <div class="header-social_box">
                        <?php if(!empty($settings['social_title'])):?>
                        <span class="tna-heading-2"><?php echo wp_kses($settings['social_title'], true);?></span>
                        <?php endif;?>

                        <?php foreach ( $settings['social_icons_lists'] as $key => $list ): ?>
                        <a href="<?php echo esc_url($list['social_link']['url']); ?>">
                            <?php
                                if (!empty($list['social_icon'])) {
                                    elh_element_render_icon($list, '', 'social_icon');
                                }
                            ?>
                        </a>
                        <?php endforeach;?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php endif;?>

    <!-- Header Lower -->
    <div class="header-lower">
        <div class="auto-container">
            <div class="inner-container d-flex align-items-center justify-content-between position-relative">

                <!-- Logo Box -->
                <div class="logo-box d-flex align-items-center">
                    <div class="logo">
                        <?php if(!empty( $settings['logo']['url'] )) : ?>
                        <a href="<?php echo esc_url($custom_link); ?>" class="tx-logo">
                            <img src="<?php echo esc_url($settings['logo']['url']); ?>" alt="">
                        </a>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="nav-outer d-lg-flex d-none align-items-center ">

                    <!-- Main Menu -->
                    <nav class="main-menu show navbar-expand-md">
                        <div class="navbar-header">
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>

                        <div class="navbar-collapse collapse clearfix txMenuWrapper" id="navbarSupportedContent">
                            <div id="tx-navbar">
                                <?php
                                    $menu_args = [
                                        'menu'        => '' . $settings['select_menu'] . '',
                                        'menu_class'     => 'navigation clearfix list-unstyled',
                                        'walker'         => class_exists( 'Telnet_Mega_Menu_Walker' ) ? new Telnet_Mega_Menu_Walker : '',
                                        'fallback_cb'    => ['Navwalker_Class', 'fallback'],
                                        'echo'           => false,
                                    ];
                                    $menu = wp_nav_menu($menu_args);
                                    $menu = str_replace('menu-item-has-children', 'dropdown', $menu);
                                    echo wp_kses_post( $menu );
                                ?>
                            </div>
                        </div>

                    </nav>
                    <!-- Main Menu End-->

                </div>

                <!-- Outer Box -->
                <div class="tna-header-3-action">

                    <!-- call-btn -->
                    <div class="tna-call-btn-1 d-none d-xxl-flex">
                        <?php if(!empty( $settings['contact_number_icon'] )) : ?>
                        <div class="icon">
                            <?php \Elementor\Icons_Manager::render_icon( $settings['contact_number_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                        </div>
                        <?php endif; ?>
                        <div class="content">
                            <?php if(!empty( $settings['contact_number_label'] )) : ?>
                            <span class="text"><?php echo wp_kses($settings['contact_number_label'], true);?></span>
                            <?php endif; ?>

                            <?php if(!empty( $settings['contact_number'] )) : ?>
                            <a class="number" href="tel:<?php echo esc_attr($settings['contact_number']); ?>"><?php echo esc_html($settings['contact_number']); ?></a>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- search-btn -->
                    <?php if( $settings['enable_search_popup'] == 'yes' ) : ?>
                    <div class="tna-search-btn-1 d-none d-sm-block" data-tx-searchtrigger>
                        <i class="far fa-search fa-fw"></i>
                    </div>
                    <?php endif; ?>

                    <!-- cart-btn -->
                    <?php if(TELNET_CORE_WOOCOMMERCE_ACTIVED && $settings['enable_mini_cart'] == 'yes' ) : ?>
                    <div class="tna-cart-btn-1 d-none d-sm-block" data-txMiniCartTrigger>
                        <i class="fas fa-shopping-cart fa-fw"></i>
                        <span>
                        <?php
                            if (class_exists('WooCommerce') && WC()->cart) {
                                $count = WC()->cart->cart_contents_count;
                            } else {
                                $count = 0;
                            }

                            if ( $count == 0 ) {
                                echo '0';
                            } else {
                                echo '' . esc_html( $count ) . '';
                            }
                        ?>
                        </span>
                    </div>
                    <?php endif; ?>

                    <!-- Language -->
                    <?php if( $settings['enable_language_switcher'] == 'yes' ) : ?>
                    <div class="language-dropdown d-none d-sm-block">
                        <button class="dropdown-toggle" type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="inside">
                            <?php if(!empty( $settings['active_language_flag']['url'] )) : ?>
                            <span class="tx-lang-flag tx-radious-50">
                                <img src="<?php echo esc_url($settings['active_language_flag']['url']); ?>" alt="" />
                            </span>
                            <?php endif; ?>
                            <?php echo $settings['active_language_title'] ? esc_html($settings['active_language_title']) : ''; ?>
                            <i class="fas fa-caret-down"></i>
                        </button>
                        <?php if(!empty( $settings['language_lists'] )) : ?>
                        <ul class="dropdown-menu list-unstyled" aria-labelledby="dropdownMenuButton2">
                            <?php foreach($settings['language_lists'] as $list) : ?>
                            <li><a class="dropdown-item" href="<?php echo esc_url($list['language_link']['url']); ?>"><?php echo esc_html($list['language_title']) ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <!-- Mobile Navigation Toggler -->
                    <div class="mobile-nav-toggler d-block d-xl-none" data-txsideinfotrigger>
                        <span class="icon">
                            <i class="fa-regular fa-bars-staggered"></i>
                        </span>
                    </div>

                </div>
                <!-- End Outer Box -->
            </div>
        </div>
    </div>
    <!-- End Header Lower -->

    <!-- Mobile Menu  -->
    <div class="mobile-menu">
        <div class="menu-backdrop"></div>
        <div class="close-btn"><span class="icon far fa-times fa-fw"></span></div>
        <nav class="menu-box">
            <div class="nav-logo">
            <?php if(!empty( $settings['mobile_logo']['url'] )) : ?>
            <a href="<?php echo esc_url($custom_link); ?>" class="tx-logo">
                <img src="<?php echo esc_url($settings['mobile_logo']['url']); ?>" alt="">
            </a>
            <?php endif; ?>
            </div>
            <!-- Search -->
            <?php if( $settings['enable_search_popup'] == 'yes' ) : ?>
            <div class="search-box">
                <form method="get" action="<?php print esc_url( home_url( '/' ) );?>">
                    <div class="form-group">
                        <input type="search" name="s" placeholder="<?php print esc_attr__( 'Search Here.', 'telnet' );?>" value="<?php print esc_attr( get_search_query() )?>">
                        <button type="submit"><span class="icon far fa-search fa-fw"></span></button>
                    </div>
                </form>
            </div>
            <?php endif; ?>
            <div class="menu-outer"></div>
        </nav>
    </div>
    <!-- End Mobile Menu -->

</header>