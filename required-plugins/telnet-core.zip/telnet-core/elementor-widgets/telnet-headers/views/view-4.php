<?php
 $enable_custom_link = $settings['enable_custom_link'];

 if($enable_custom_link == 'yes') {
     $custom_link = $settings['custom_link']['url'];
 } else {
     $custom_link = home_url( '/' );
 }

 // enable position
 $enable_position_absolute = $settings['enable_position_absolute'];

 if($enable_position_absolute == 'yes') {
     $position_absolute = 'position-absolute';
 } else {
     $position_absolute = '';
 }
?>
<header id="tel-header" class="tx-header tx-header__styleDefault header_style_five <?php echo esc_attr($position_absolute); ?>">
    <div class="header-top-content-area position-relative">
        <div class="container">
            <div class="header-top-content d-flex align-items-center justify-content-between">
                <?php if(!empty($settings['address'])):?>
                <div class="top-cta-info">
                    <?php \Elementor\Icons_Manager::render_icon( $settings['address_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                    <?php echo wp_kses($settings['address'], true);?>
                </div>
                <?php endif;?>
                <div class="top-cta-social d-flex align-items-center">

                    <?php if(!empty($settings['social_title'])):?>
                        <span><?php echo wp_kses($settings['social_title'], true);?></span>
                    <?php endif;?>

                    <?php foreach ( $settings['social_icons_lists'] as $key => $list ): ?>
                        <a href="<?php echo esc_url($list['social_link']['url']); ?>"
                        target="<?php echo esc_attr($list['social_link']['is_external'] ? '_blank' : '_self'); ?>"
                        rel="<?php echo esc_attr($list['social_link']['nofollow'] ? 'nofollow' : ''); ?>"
                        >
                            <?php
                                if (!empty($list['social_icon'])) {
                                    elh_element_render_icon($list, '', 'social_icon');
                                }
                            ?>
                        </a>
                    <?php endforeach;?>
                </div>
            </div>
        </div>
    </div>
    <div class="tel-header-content-area">
        <div class="container">
            <div class="tel-header-content d-flex justify-content-between align-items-center">
                <div class="tx-logo-wrapper">
                    <?php if(!empty( $settings['logo']['url'] )) : ?>
                        <a href="<?php echo esc_url($custom_link); ?>" class="tx-logo">
                            <img src="<?php echo esc_url($settings['logo']['url']); ?>" alt="">
                        </a>
                    <?php endif; ?>
                </div>
                <div class="tx-menu-wrapper">
                    <div class="tx-main-menu txMenuWrapper">
                        <div id="tx-navbar">
                            <?php
                                echo wp_nav_menu( [
                                    'menu'        => '' . $settings['select_menu'] . '',
                                    'menu_class'  => 'navigation clearfix justify-content-center',
                                    'container'   => '',
                                    'fallback_cb' => 'Navwalker_Class::fallback',
                                    'walker'      => class_exists( 'Telnet_Mega_Menu_Walker' ) ? new Telnet_Mega_Menu_Walker : '',
                                ] );
                            ?>
                        </div>
                    </div>
                </div>
                <div class="tx-searchCartLang-wrapper d-flex align-items-center">
                    <?php if(!empty($settings['contact_number_label'])):?>
                    <div class="tx-header-cta d-flex align-items-center">
                        <div class="inner-icon d-flex justify-content-center align-items-center">
                            <?php \Elementor\Icons_Manager::render_icon( $settings['contact_number_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                        </div>
                        <div class="inner-text">
                            <span><?php echo wp_kses($settings['contact_number_label'], true);?></span>
                            <?php echo wp_kses($settings['contact_number'], true);?>
                        </div>
                    </div>
                    <?php endif;?>
                    <?php if( $settings['enable_search_popup'] == 'yes' ) : ?>
                        <button class="tx-search-btn" data-tx-searchTrigger>
                            <i class="far fa-search"></i>
                        </button>
                    <?php endif;?>
                    <?php if(TELNET_CORE_WOOCOMMERCE_ACTIVED && $settings['enable_mini_cart'] == 'yes' ) : ?>
                    <div class="tx-miniCartBtn-wrapper position-relative">
                        <button class="tx-cart-btn" data-txMiniCartTrigger>
                            <i class="fas fa-shopping-cart"></i>
                            <span class="tx-cart-count tx-radious-50" id="tx-cart-count">
                                <?php
                                    if (class_exists('WooCommerce') && WC()->cart) {
                                        $count = WC()->cart->cart_contents_count;
                                    } else {
                                        $count = 0;
                                    }

                                    if ( $count == 0 ) {
                                        echo '0';
                                    } else {
                                        echo '' . esc_html( $count ) . '';
                                    }
                                ?>
                            </span>
                        </button>
                    </div>
                    <?php endif;?>

                <button class="tx-sideInfo-btn d-flex align-items-center flex-column d-xl-none" data-txsideinfotrigger="">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                </div>

            </div>
        </div>
    </div>

</header>