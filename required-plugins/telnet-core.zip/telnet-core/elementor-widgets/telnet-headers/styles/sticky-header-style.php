<?php

use Elementor\Controls_Manager;

// HEADER STYLE
$this->start_controls_section(
    '_section_style_header',
    [
        'label' => __( 'STICKY HEADER', 'telnet-core' ),
        'tab'   => Controls_Manager::TAB_STYLE,
    ]
);

// ENABLE POSITION ABSOLUTE
$this->add_control(
    'enable_position_absolute',
    [
        'label'        => __( 'ENABLE STICKY HEADER', 'telnet-core' ),
        'type'         => Controls_Manager::SWITCHER,
        'label_on'     => __( 'Yes', 'telnet-core' ),
        'label_off'    => __( 'No', 'telnet-core' ),
        'return_value' => 'yes',
    ]
);

// HEADER TOP POSITION
$this->add_responsive_control(
    'header_top_position',
    [
        'label'     => __( 'HEADER TOP POSITION', 'telnet-core' ),
        'type'      => Controls_Manager::SLIDER,
        'size_units'=> [ 'px', '%' ],
        'range'     => [
            'px' => [
                'min' => 0,
                'max' => 200,
            ],
            '%' => [
                'min' => 0,
                'max' => 100,
            ],
        ],
        'selectors' => [
            '{{WRAPPER}} .tx-header' => 'top: {{SIZE}}{{UNIT}};',
        ],
        'condition' => [
            'enable_position_absolute' => 'yes',
        ],
    ]
);

// sticky header background color
$this->add_control(
    'sticky_header_bg_color',
    [
        'label'     => __( 'STICKY HEADER BACKGROUND COLOR', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .main-header.header-style-eight .sticky-header' => 'background-color: {{VALUE}};',
        ],
        'condition' => [
            'enable_position_absolute' => 'yes',
        ],
    ]
);

// END HEADER STYLE
$this->end_controls_section();