<?php
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;

// HEADER TOP STYLE
$this->start_controls_section(
    '_section_style_header_top',
    [
        'label'     => __( 'Header Top', 'telnet-core' ),
        'tab'       => Controls_Manager::TAB_STYLE,
        'condition' => [
            'enable_header_top' => 'yes',
        ],
    ]
);

// background control
$this->add_group_control(
    Group_Control_Background::get_type(),
    [
        'name'     => 'header_top_background',
        'label'    => __( 'Background', 'telnet-core' ),
        'types'    => ['classic', 'gradient'],
        'exclude'  => [
            'image',
            'video',
        ],
        'selector' => '
            {{WRAPPER}} .header-top-content-area,
            {{WRAPPER}} .tx-header__styleTwo .tx-topWrapper,
            {{WRAPPER}} .header-top-content-area:before
        ',
    ]
);

// header top half bg
$this->add_group_control(
    Group_Control_Background::get_type(),
    [
        'name'      => 'header_top_half_background',
        'label'     => __( 'Background', 'telnet-core' ),
        'types'     => ['classic', 'gradient'],
        'exclude'   => [
            'image',
            'video',
        ],
        'selector'  => '{{WRAPPER}} .header-top-content-area',
        'condition' => [
            'design_style' => 'style_4',
        ],
    ]
);

$this->end_controls_section();