<?php

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

// CALL STYLE SECTION
$this->start_controls_section(
    '_section_style_call',
    [
        'label' => __( 'CALL STYLE', 'telnet-core' ),
        'tab'   => Controls_Manager::TAB_STYLE,
    ]
);

// CALL ICON COLOR BG COLOR
$this->add_control(
    'call_icon_bg_color',
    [
        'label'     => __( 'CALL ICON BG COLOR', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tx-header-cta .inner-icon' => 'background: {{VALUE}};',
            '{{WRAPPER}} .tx-contact-info__horizntal .tx-icon' => 'background: {{VALUE}};',
        ],
    ]
);

// CALL ICON COLOR
$this->add_control(
    'call_icon_color',
    [
        'label'     => __( 'CALL ICON COLOR', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tx-header-cta .inner-icon' => 'color: {{VALUE}};',
            '{{WRAPPER}} .tx-contact-info__horizntal .tx-icon' => 'color: {{VALUE}};',
        ],
    ]
);

// CALL LABEL COLOR
$this->add_control(
    'call_label_color',
    [
        'label'     => __( 'CALL LABEL COLOR', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tx-header-cta .inner-text span' => 'color: {{VALUE}};',
            '{{WRAPPER}} .tx-contact-info__horizntal .tx-label' => 'color: {{VALUE}};',
        ],
    ]
);

// TYPOGRAPHY
$this->add_group_control(
    Group_Control_Typography::get_type(),
    [
        'name'     => 'call_label_typography',
        'label'    => __( 'CALL LABEL TYPOGRAPHY', 'telnet-core' ),
        'selector' => '
        {{WRAPPER}} .tx-header-cta .inner-text span,
        {{WRAPPER}} .tx-contact-info__horizntal .tx-label
        ',
    ]
);

// CALL NUMBER COLOR
$this->add_control(
    'call_number_color',
    [
        'label'     => __( 'CALL NUMBER COLOR', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tx-header-cta .inner-text a' => 'color: {{VALUE}};',
            '{{WRAPPER}} .tx-contact-info__horizntal .tx-number' => 'color: {{VALUE}};',
        ],
    ]
);

// TYPOGRAPHY
$this->add_group_control(
    Group_Control_Typography::get_type(),
    [
        'name'     => 'call_number_typography',
        'label'    => __( 'CALL NUMBER TYPOGRAPHY', 'telnet-core' ),
        'selector' => '
        {{WRAPPER}} .tx-header-cta .inner-text a,
        {{WRAPPER}} .tx-contact-info__horizntal .tx-number
        ',
    ]
);

// END CALL STYLE SECTION
$this->end_controls_section();