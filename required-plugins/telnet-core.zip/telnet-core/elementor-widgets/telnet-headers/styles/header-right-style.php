<?php

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

// CALL STYLE SECTION
$this->start_controls_section(
    '_section_style_search',
    [
        'label' => __( 'SEARCH & CART', 'telnet-core' ),
        'tab'   => Controls_Manager::TAB_STYLE,
    ]
);

// CALL ICON COLOR BG COLOR
$this->add_control(
    'search_icon_color',
    [
        'label'     => __( 'SEARCH ICON COLOR', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tx-search-btn' => 'color: {{VALUE}};',
        ],
    ]
);

// CART ICON COLOR
$this->add_control(
    'cart_icon_color',
    [
        'label'     => __( 'CART ICON COLOR', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tx-cart-btn' => 'color: {{VALUE}};',
        ],
    ]
);

// CART COUNT BG COLOR
$this->add_control(
    'cart_count_bg_color',
    [
        'label'     => __( 'CART COUNT BG COLOR', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tx-cart-count' => 'background-color: {{VALUE}};',
        ],
    ]
);

// CART COUNT TEXT COLOR
$this->add_control(
    'cart_count_text_color',
    [
        'label'     => __( 'CART COUNT TEXT COLOR', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .tx-cart-count' => 'color: {{VALUE}};',
        ],
    ]
);

// TYPOGRAPHY
$this->add_group_control(
    Group_Control_Typography::get_type(),
    [
        'name'     => 'cart_count_typography',
        'label'    => __( 'CART COUNT TYPOGRAPHY', 'telnet-core' ),
        'selector' => '{{WRAPPER}} .tx-cart-count',
    ]
);

// END CALL STYLE SECTION
$this->end_controls_section();