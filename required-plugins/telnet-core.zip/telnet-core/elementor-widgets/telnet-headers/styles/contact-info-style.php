<?php
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
// HEADER TOP CONTACT INFO STYLE
$this->start_controls_section(
    '_section_style_header_top_contact_info',
    [
        'label'     => __( 'Header Top Contact Info', 'telnet-core' ),
        'tab'       => Controls_Manager::TAB_STYLE,
        'condition' => [
            'enable_header_top' => 'yes',
        ],
    ]
);

// contact info text color
$this->add_control(
    'contact_info_text_color',
    [
        'label'     => __( 'Contact Info Text Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .header-top-content-area .top-cta-info' => 'color: {{VALUE}};',
            '{{WRAPPER}} .tx-header__styleTwo .tx-listItems p' => 'color: {{VALUE}};',
        ],
    ]
);

// contact info typography
$this->add_group_control(
    Group_Control_Typography::get_type(),
    [
        'name'     => 'contact_info_typography',
        'label'    => __( 'Contact Info Typography', 'telnet-core' ),
        'selector' => '
        {{WRAPPER}} .header-top-content-area .top-cta-info,
        {{WRAPPER}} .tx-header__styleTwo .tx-listItems p
        ',
    ]
);

// END HEADER TOP CONTACT INFO STYLE
$this->end_controls_section();