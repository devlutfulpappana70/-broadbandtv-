<?php
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Typography;
// Menu Style
$this->start_controls_section(
    '_section_style_menu',
    [
        'label' => __( 'MENU STYLE', 'telnet-core' ),
        'tab'   => Controls_Manager::TAB_STYLE,
    ]
);

// typography
$this->add_group_control(
    Group_Control_Typography::get_type(),
    [
        'name'     => 'menu_typography',
        'label'    => __( 'Typography', 'telnet-core' ),
        'selector' => '
        {{WRAPPER}} .txMenuWrapper ul li a
        ',
    ]
);

// menu padding
$this->add_responsive_control(
    'menu_padding',
    [
        'label'      => __( 'Padding', 'telnet-core' ),
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', 'em', '%' ],
        'selectors'  => [
            '{{WRAPPER}} .txMenuWrapper li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
    ]
);

// menu margin
$this->add_responsive_control(
    'menu_margin',
    [
        'label'      => __( 'Margin', 'telnet-core' ),
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', 'em', '%' ],
        'selectors'  => [
            '{{WRAPPER}} .txMenuWrapper li a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
    ]
);

// add tab for normal state
$this->start_controls_tabs( '_tabs_menu_style' );

// normal state
$this->start_controls_tab(
    '_tab_menu_normal',
    [
        'label' => __( 'Normal', 'telnet-core' ),
    ]
);

// menu color
$this->add_control(
    'menu_color',
    [
        'label'     => __( 'Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .txMenuWrapper li a' => 'color: {{VALUE}};',
        ],
    ]
);

// menu background color
$this->add_control(
    'menu_bg_color',
    [
        'label'     => __( 'Background Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .txMenuWrapper li a' => 'background-color: {{VALUE}};',
        ],
    ]
);

// for menu hover state
$this->end_controls_tab();

// add tab for hover state
$this->start_controls_tab(
    '_tab_menu_hover',
    [
        'label' => __( 'Hover', 'telnet-core' ),
    ]
);

// menu hover color
$this->add_control(
    'menu_hover_color',
    [
        'label'     => __( 'Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .txMenuWrapper li:hover > a' => 'color: {{VALUE}};',
            '{{WRAPPER}} .txMenuWrapper li:hover > a' => 'background: unset;',
            '{{WRAPPER}} .txMenuWrapper li:hover > a' => '-webkit-text-fill-color: {{VALUE}};',
        ],
    ]
);

// menu hover background color
$this->add_control(
    'menu_hover_bg_color',
    [
        'label'     => __( 'Background Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .txMenuWrapper li:hover a' => 'background-color: {{VALUE}};',
        ],
    ]
);

// for menu active state
$this->end_controls_tab();

// add tab for active state
$this->start_controls_tab(
    '_tab_menu_active',
    [
        'label' => __( 'Active', 'telnet-core' ),
    ]
);

// menu active color
$this->add_control(
    'menu_active_color',
    [
        'label'     => __( 'Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .txMenuWrapper li.current-menu-item a' => 'color: {{VALUE}};',
        ],
    ]
);

// menu active background color
$this->add_control(
    'menu_active_bg_color',
    [
        'label'     => __( 'Background Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .txMenuWrapper li.current-menu-item a' => 'background-color: {{VALUE}};',
        ],
    ]
);

// end
$this->end_controls_tab();

// end tab
$this->end_controls_tabs();


$this->end_controls_section();

// sub menu style
$this->start_controls_section(
    '_section_style_submenu',
    [
        'label' => __( 'SUB MENU STYLE', 'telnet-core' ),
        'tab'   => Controls_Manager::TAB_STYLE,
    ]
);

// sub menu bg
$this->add_control(
    'submenu_bg_color',
    [
        'label'     => __( 'Background Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .txMenuWrapper li ul' => 'background-color: {{VALUE}};',
        ],
    ]
);

// sub menu typography
$this->add_group_control(
    Group_Control_Typography::get_type(),
    [
        'name'     => 'submenu_typography',
        'label'    => __( 'Typography', 'telnet-core' ),
        'selector' => '
        {{WRAPPER}} .txMenuWrapper li ul li a
        ',
    ]
);

// sub menu padding
$this->add_responsive_control(
    'submenu_padding',
    [
        'label'      => __( 'Padding', 'telnet-core' ),
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', 'em', '%' ],
        'selectors'  => [
            '{{WRAPPER}} .txMenuWrapper li ul li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
        ],
    ]
);

// sub menu margin
$this->add_responsive_control(
    'submenu_margin',
    [
        'label'      => __( 'Margin', 'telnet-core' ),
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => [ 'px', 'em', '%' ],
        'selectors'  => [
            '{{WRAPPER}} .txMenuWrapper li ul li a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
    ]
);

// add tab for normal state
$this->start_controls_tabs( '_tabs_submenu_style' );

// add tab for normal state
$this->start_controls_tab(
    '_tab_submenu_normal',
    [
        'label' => __( 'Normal', 'telnet-core' ),
    ]
);

// sub menu color
$this->add_control(
    'submenu_color',
    [
        'label'     => __( 'Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .txMenuWrapper li ul li a' => 'color: {{VALUE}};',
            '{{WRAPPER}} .txMenuWrapper li ul li a' => 'background: unset;',
            '{{WRAPPER}} .txMenuWrapper li ul li a' => '-webkit-text-fill-color: {{VALUE}} !important;',
        ],
    ]
);

// sub menu background color
$this->add_control(
    'submenu_text_bg_color',
    [
        'label'     => __( 'Background Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .txMenuWrapper li ul li a' => 'background-color: {{VALUE}};',
        ],
    ]
);

// for sub menu hover state
$this->end_controls_tab();

// add tab for hover state
$this->start_controls_tab(
    '_tab_submenu_hover',
    [
        'label' => __( 'Hover', 'telnet-core' ),
    ]
);

// sub menu hover color
$this->add_control(
    'submenu_hover_color',
    [
        'label'     => __( 'Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .txMenuWrapper li ul li a:hover' => 'color: {{VALUE}};',
            '{{WRAPPER}} .txMenuWrapper li ul li a:hover' => '-webkit-text-fill-color: {{VALUE}} !important;',
        ],
    ]
);

// sub menu hover background color
$this->add_control(
    'submenu_hover_bg_color',
    [
        'label'     => __( 'Background Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .txMenuWrapper li ul li a:hover' => 'background-color: {{VALUE}};',
        ],
    ]
);

// for sub menu hover state
$this->end_controls_tab();

// end tab
$this->end_controls_tabs();

// end section
$this->end_controls_section();

// menu icon style
$this->start_controls_section(
    '_section_style_menu_icon',
    [
        'label' => __( 'MENU ICON STYLE', 'telnet-core' ),
        'tab'   => Controls_Manager::TAB_STYLE,
    ]
);

// menu icon color
$this->add_control(
    'menu_icon_color',
    [
        'label'     => __( 'Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .txMenuWrapper .menu-item-has-children > a::after' => 'color: {{VALUE}};',
        ],
    ]
);

// menu icon hover color
$this->add_control(
    'menu_icon_hover_color',
    [
        'label'     => __( 'Hover Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .txMenuWrapper li.menu-item-has-children > a:hover:after' => 'color: {{VALUE}};',
            '{{WRAPPER}} .txMenuWrapper li.menu-item-has-children > a:hover:after' => '-webkit-text-fill-color: {{VALUE}};',
        ],
    ]
);

// menu icon size
$this->add_responsive_control(
    'menu_icon_size',
    [
        'label'      => __( 'Size', 'telnet-core' ),
        'type'       => Controls_Manager::SLIDER,
        'size_units' => [ 'px', 'em' ],
        'range'      => [
            'px' => [
                'min'  => 5,
                'max'  => 50,
                'step' => 1,
            ],
            'em' => [
                'min'  => 0.5,
                'max'  => 5,
                'step' => 0.1,
            ],
        ],
        'selectors'  => [
            '{{WRAPPER}} .txMenuWrapper .menu-item-has-children > a::after' => 'font-size: {{SIZE}}{{UNIT}};',
        ],
    ]
);

// dot icon size
$this->add_responsive_control(
    'dot_icon_size',
    [
        'label'      => __( 'Dot Size', 'telnet-core' ),
        'type'       => Controls_Manager::SLIDER,
        'size_units' => [ 'px', 'em' ],
        'range'      => [
            'px' => [
                'min'  => 5,
                'max'  => 50,
                'step' => 1,
            ],
            'em' => [
                'min'  => 0.5,
                'max'  => 5,
                'step' => 0.1,
            ],
        ],
        'selectors'  => [
            '{{WRAPPER}} .txMenuWrapper li a::before' => 'font-size: {{SIZE}}{{UNIT}};',
        ],
    ]
);

// Dot icon color
$this->add_control(
    'dot_icon_color',
    [
        'label'     => __( 'Dot Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .txMenuWrapper li a::before' => 'background: {{VALUE}};',
        ],
    ]
);

// submenu icon color
$this->add_control(
    'submenu_icon_color',
    [
        'label'     => __( 'Submenu Icon Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .txMenuWrapper li ul li.menu-item-has-children > a::after' => 'color: {{VALUE}};',
        ],
    ]
);

// submenu icon hover color
$this->add_control(
    'submenu_icon_hover_color',
    [
        'label'     => __( 'Submenu Icon Hover Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .txMenuWrapper li ul li.menu-item-has-children > a:hover:after' => 'color: {{VALUE}};',
        ],
    ]
);

// submenu icon size
$this->add_responsive_control(
    'submenu_icon_size',
    [
        'label'      => __( 'Submenu Icon Size', 'telnet-core' ),
        'type'       => Controls_Manager::SLIDER,
        'size_units' => [ 'px', 'em' ],
        'range'      => [
            'px' => [
                'min'  => 5,
                'max'  => 50,
                'step' => 1,
            ],
            'em' => [
                'min'  => 0.5,
                'max'  => 5,
                'step' => 0.1,
            ],
        ],
        'selectors'  => [
            '{{WRAPPER}} .txMenuWrapper li ul li.menu-item-has-children > a::after' => 'font-size: {{SIZE}}{{UNIT}};',
        ],
    ]
);

// sub menu left icon size
$this->add_responsive_control(
    'submenu_left_icon_size',
    [
        'label'      => __( 'Submenu Left Icon Size', 'telnet-core' ),
        'type'       => Controls_Manager::SLIDER,
        'size_units' => [ 'px', 'em' ],
        'range'      => [
            'px' => [
                'min'  => 5,
                'max'  => 50,
                'step' => 1,
            ],
            'em' => [
                'min'  => 0.5,
                'max'  => 5,
                'step' => 0.1,
            ],
        ],
        'selectors'  => [
            '{{WRAPPER}} .txMenuWrapper li ul li a::before' => 'font-size: {{SIZE}}{{UNIT}};',
        ],
    ]
);

// sub menu left icon color
$this->add_control(
    'submenu_left_icon_color',
    [
        'label'     => __( 'Submenu Left Icon Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .txMenuWrapper li ul li a::before' => 'color: {{VALUE}};',
        ],
    ]
);

// sub menu left icon hover color
$this->add_control(
    'submenu_left_icon_hover_color',
    [
        'label'     => __( 'Submenu Left Icon Hover Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .txMenuWrapper li ul li a:hover::before' => 'color: {{VALUE}};',
        ],
    ]
);

// end
$this->end_controls_section();