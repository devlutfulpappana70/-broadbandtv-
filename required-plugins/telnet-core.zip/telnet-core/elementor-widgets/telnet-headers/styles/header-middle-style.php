<?php
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
// HEADER STYLE SECTION
$this->start_controls_section(
    '_section_style_header_style',
    [
        'label' => __( 'Header Style', 'telnet-core' ),
        'tab'   => Controls_Manager::TAB_STYLE,
    ]
);

// headiing
$this->add_control(
    'header_style_heading',
    [
        'label'     => __( 'HEADER BACKGROUND', 'telnet-core' ),
        'type'      => Controls_Manager::HEADING,
        'separator' => 'before',
    ]
);

// background control
$this->add_group_control(
    Group_Control_Background::get_type(),
    [
        'name'     => 'header_style_background',
        'label'    => __( 'Background', 'telnet-core' ),
        'types'    => ['classic', 'gradient'],
        'exclude'  => [
            'image',
            'video',
        ],
        'selector' => '
        {{WRAPPER}} .header_style_six .tel-header-content-area,
        {{WRAPPER}} .header-style-eight .header-lower .inner-container
        ',
    ]
);

$this->add_control(
    'header_half_style_heading',
    [
        'label'     => __( 'HEADER HALF BACKGROUND', 'telnet-core' ),
        'type'      => Controls_Manager::HEADING,
        'separator' => 'before',
    ]
);

// LEFT HALF BG
$this->add_group_control(
    Group_Control_Background::get_type(),
    [
        'name'     => 'header_style_left_half_bg',
        'label'    => __( 'Left Half Background', 'telnet-core' ),
        'types'    => ['classic', 'gradient'],
        'exclude'  => [
            'image',
            'video',
        ],
        'selector' => '{{WRAPPER}} .header_style_six .tel-header-content-area:before',
    ]
);


// end header style section
$this->end_controls_section();