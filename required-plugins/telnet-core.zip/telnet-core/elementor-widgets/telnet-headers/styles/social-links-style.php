<?php
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;


// SOCIAL ICONS STYLE
$this->start_controls_section(
    '_section_style_social_icons',
    [
        'label' => __( 'Social Icons', 'telnet-core' ),
        'tab'   => Controls_Manager::TAB_STYLE,
    ]
);

// social heading color
$this->add_control(
    'social_heading_color',
    [
        'label'     => __( 'Social Heading Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} .header-top-content-area .top-cta-social span' => 'color: {{VALUE}};',
        ],
    ]
);

// social heading typography
$this->add_group_control(
    Group_Control_Typography::get_type(),
    [
        'name'     => 'social_heading_typography',
        'label'    => __( 'Social Heading Typography', 'telnet-core' ),
        'selector' => '{{WRAPPER}} .header-top-content-area .top-cta-social span',
    ]
);

// social icon border control
$this->add_group_control(
    Group_Control_Border::get_type(),
    [
        'name'     => 'social_icon_border',
        'label'    => __( 'Social Icon Border', 'telnet-core' ),
        'selector' => '
        {{WRAPPER}} .header-top-content-area .top-cta-social a,
        {{WRAPPER}} .tx-social-links a,
        {{WRAPPER}} .header-top-content-area .top-cta-social a,
        {{WRAPPER}} .top-cta-social a
        ',
    ]
);

// border radius control
$this->add_responsive_control(
    'social_icon_border_radius',
    [
        'label'      => __( 'Social Icon Border Radius', 'telnet-core' ),
        'type'       => Controls_Manager::DIMENSIONS,
        'size_units' => ['px', '%'],
        'selectors'  => [
            '{{WRAPPER}} .header-top-content-area .top-cta-social a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            '{{WRAPPER}} .tx-social-links a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            '{{WRAPPER}} .top-cta-social a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        ],
    ]
);

// add tab
$this->start_controls_tabs( '_tabs_button' );

$this->start_controls_tab(
    '_tab_button_normal',
    [
        'label' => __( 'Normal', 'telnet-core' ),
    ]
);

// social icon color
$this->add_control(
    'social_icon_color',
    [
        'label'     => __( 'Social Icon Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}}.header-top-content-area .top-cta-social a' => 'color: {{VALUE}};',
            '{{WRAPPER}} .tx-social-links a' => 'color: {{VALUE}};',
            '{{WRAPPER}} .top-cta-social a' => 'color: {{VALUE}};',
        ],
    ]
);

// social icon bg control
$this->add_group_control(
    Group_Control_Background::get_type(),
    [
        'name'     => 'social_icon_bg',
        'label'    => __( 'Social Icon Background', 'telnet-core' ),
        'types'    => ['classic', 'gradient'],
        'exclude'  => [
            'image',
            'video',
        ],
        'selector' => '
        {{WRAPPER}} .header-top-content-area .top-cta-social a,
        {{WRAPPER}} .tx-social-links a,
        {{WRAPPER}} .top-cta-social a
        ',
    ]
);

// end normal tab
$this->end_controls_tab();

$this->start_controls_tab(
    '_tab_button_hover',
    [
        'label' => __( 'Hover', 'telnet-core' ),
    ]
);

$this->add_control(
    'social_icon_hover_color',
    [
        'label'     => __( 'Social Icon Color', 'telnet-core' ),
        'type'      => Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}}.header-top-content-area .top-cta-social a:hover' => 'color: {{VALUE}};',
            '{{WRAPPER}} .tx-social-links a:hover' => 'color: {{VALUE}};',
            '{{WRAPPER}} .top-cta-social a:hover' => 'color: {{VALUE}};',
        ],
    ]
);

// hover border control
$this->add_group_control(
    Group_Control_Background::get_type(),
    [
        'name'     => 'social_icon_hover_bg_color',
        'label'    => __( 'Social Icon Background', 'telnet-core' ),
        'types'    => ['classic', 'gradient'],
        'exclude'  => [
            'image',
            'video',
        ],
        'selector' => '
        {{WRAPPER}} .header-top-content-area .top-cta-social a:hover,
        {{WRAPPER}} .tx-social-links a:hover,
        {{WRAPPER}} .top-cta-social a:hover
        ',
    ]
);

// end hover tab
$this->end_controls_tab();

$this->end_controls_tabs();

// END SOCIAL ICONS STYLE
$this->end_controls_section();