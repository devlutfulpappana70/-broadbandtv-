<div class="tna-call-btn-1 has-2 wow <?php echo $settings['anim_name'] ? esc_attr($settings['anim_name']) : ''; ?>"
data-wow-delay="<?php echo $settings['anim_delay'] ? esc_attr($settings['anim_delay']) : ''; ?>"
data-wow-duration="<?php echo $settings['anim_duration'] ? esc_attr($settings['anim_duration']) : ''; ?>">

    <?php if( $settings['enable_icon'] === 'yes' ) : ?>
    <div class="icon">
        <?php if($settings['type'] == 'icon') : ?>
            <?php \Elementor\Icons_Manager::render_icon( $settings['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
        <?php else : ?>
            <img src="<?php echo esc_url($settings['list_image']['url']); ?>" alt="" />
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <div class="content">
        <?php if(!empty( $settings['list_title']  )) : ?>
        <span class="text"><?php echo elh_element_kses_intermediate( $settings['list_title'] ); ?></span>
        <?php endif; ?>

        <?php if(!empty( $settings['list_text'] )) : ?>
        <a class="number" href="tel:<?php echo esc_attr($settings['list_text']); ?>"><?php echo elh_element_kses_intermediate( $settings['list_text'] ); ?></a>
        <?php endif; ?>
    </div>
</div>
