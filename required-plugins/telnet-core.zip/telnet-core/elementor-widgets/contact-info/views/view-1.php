<div class="tna-about-1-content">
    <div class="tna-call-btn-1">
        <div class="icon">
            <?php
                if ($settings['type'] === 'image' && ($settings['list_image']['url'] || $settings['list_image']['id'])) {
                    $this->get_render_attribute_string('list_image');
                    $settings['hover_animation'] = 'disable-animation';
                    echo Group_Control_Image_Size::get_attachment_image_html($settings, 'thumbnail', 'list_image');
                } elseif (!empty($settings['list_icon'])) {
                    elh_element_render_icon($settings, '', 'list_icon');
                }
            ?>
        </div>
        <div class="content">
            <?php if(!empty( $settings['list_title']  )) : ?>
            <span class="text"><?php echo elh_element_kses_intermediate( $settings['list_title'] ); ?></span>
            <?php endif; ?>

            <?php if(!empty( $settings['list_text'] )) : ?>
            <a class="number" href="tel:<?php echo esc_attr($settings['list_text']); ?>"><?php echo elh_element_kses_intermediate( $settings['list_text'] ); ?></a>
            <?php endif; ?>

        </div>
    </div>
</div>