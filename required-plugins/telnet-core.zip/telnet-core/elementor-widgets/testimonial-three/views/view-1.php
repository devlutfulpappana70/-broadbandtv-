<?php

$this->add_inline_editing_attributes( 'title', 'basic' );
$this->add_render_attribute( 'title', 'class', 'sec-title-five_heading' );
$title = elh_element_kses_basic( $settings['title'] );

?>
<div class="testimonial-one">
    <div class="auto-container">
        <div class="sec-title-five centered">
            <?php if(!empty( $settings['sub_title'] )) : ?>
            <div class="sec-title-five_title"><?php echo elh_element_kses_intermediate($settings['sub_title']); ?></div>
            <?php endif; ?>

            <?php
                printf('<%1$s %2$s>%3$s</%1$s>',
                    tag_escape($settings['title_tag']),
                    $this->get_render_attribute_string('title'),
                    $title
                );
            ?>

            <?php if(!empty($settings['description'])) : ?>
            <div class="sec-title-five_text"><?php echo wp_kses($settings['description'], true)?></div>
            <?php endif; ?>
        </div>

        <div class="inner-container" style="background-image: url(<?php echo $settings['bg_image']['url'] ? esc_url($settings['bg_image']['url']) : ''; ?>)">
            <?php foreach( $settings['testimonial_lists'] as $list ) : ?>
            <div class="testimonial-author-box <?php echo esc_attr($list['position']) ?>">
                <?php if(!empty( $list['image']['url'] )) : ?>
                <div class="testimonial-author_image wdt-hotspot-soft-beat">
                    <img src="<?php echo esc_url($list['image']['url']); ?>" alt="" />
                </div>
                <?php endif; ?>
                <div class="testimonial-author-box_content">
                    <?php if(!empty( $list['comment'] )) : ?>
                    <div class="testimonial-author-box_text"><?php echo elh_element_kses_intermediate($list['comment']); ?></div>
                    <?php endif; ?>
                    <div class="testimonial-author-box_info d-flex align-items-center justify-content-between flex-wrap">
                        <div class="testimonial-author_info">
                            <?php if(!empty( $list['name'] )) : ?>
                            <span><?php echo elh_element_kses_intermediate($list['name']); ?></span>
                            <?php endif; ?>
                            <br>
                            <?php echo elh_element_kses_intermediate($list['designation']); ?>
                        </div>
                        <div class="testimonial-author-box_rating">
                            <?php
                                for ( $i = 1; $i < $list['rating_star']; $i++ ) {
                                    echo '<span class="fa fa-star"></span>';
                                }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>