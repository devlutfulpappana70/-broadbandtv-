<?php

namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
use \Elementor\Core\Schemes\Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;

defined( 'ABSPATH' ) || die();

class Telnet_Nav_Menu extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name() {
        return 'telnet_nav_menu';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title() {
        return __( 'TelNet Nav Menu', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/gradient-heading/';
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-t-letter';
    }

    public function get_keywords() {
        return ['btn', 'menu', 'telnet', 'telnet menu'];
    }

    // get menu
    public function get_menu() {
        $menus = wp_get_nav_menus();
        $menu_list = array();
        if ( $menus ) {
            foreach ( $menus as $menu ) {
                $menu_list[ $menu->slug ] = $menu->name;
            }
        }
        return $menu_list;
    }

    protected function register_content_controls() {

        //Settings
        $this->start_controls_section(
            '_section_settings',
            [
                'label' => __( 'Settings', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'design_style',
            [
                'label'              => __( 'Design Style', 'telnet-core' ),
                'type'               => Controls_Manager::SELECT,
                'options'            => [
                    'style_1' => __( 'Style One', 'telnet-core' ),
                    'style_2' => __( 'Style Two', 'telnet-core' ),
                ],
                'default'            => 'style_1',
                'frontend_available' => true,
                'style_transfer'     => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_menu',
            [
                'label' => __( 'Menu Options', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // select menu
        $this->add_control(
            'select_menu',
            [
                'label'       => __( 'Select Menu', 'telnet-core' ),
                'type'        => Controls_Manager::SELECT2,
                'options'     => $this->get_menu(),
                'label_block' => true,
                'multiple'    => false,
            ]
        );


        $this->end_controls_section();

    }

    protected function register_style_controls() {

        // Menu Style
        $this->start_controls_section(
            '_section_style_menu',
            [
                'label' => __( 'MENU STYLE', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'menu_typography',
                'label'    => __( 'Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-main-menu ul li a',
            ]
        );

        // menu padding
        $this->add_responsive_control(
            'menu_padding',
            [
                'label'      => __( 'Padding', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors'  => [
                    '{{WRAPPER}} .tx-main-menu ul li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // menu margin
        $this->add_responsive_control(
            'menu_margin',
            [
                'label'      => __( 'Margin', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors'  => [
                    '{{WRAPPER}} .tx-main-menu ul li a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // add tab for normal state
        $this->start_controls_tabs( '_tabs_menu_style' );

        // normal state
        $this->start_controls_tab(
            '_tab_menu_normal',
            [
                'label' => __( 'Normal', 'telnet-core' ),
            ]
        );

        // menu color
        $this->add_control(
            'menu_color',
            [
                'label'     => __( 'Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-main-menu ul li a' => 'color: {{VALUE}};',
                ],
            ]
        );

        // menu background color
        $this->add_control(
            'menu_bg_color',
            [
                'label'     => __( 'Background Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-main-menu ul li a' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        // for menu hover state
        $this->end_controls_tab();

        // add tab for hover state
        $this->start_controls_tab(
            '_tab_menu_hover',
            [
                'label' => __( 'Hover', 'telnet-core' ),
            ]
        );

        // menu hover color
        $this->add_control(
            'menu_hover_color',
            [
                'label'     => __( 'Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-main-menu ul li:hover a' => 'color: {{VALUE}};',
                ],
            ]
        );

        // menu hover background color
        $this->add_control(
            'menu_hover_bg_color',
            [
                'label'     => __( 'Background Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-main-menu ul li:hover a' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        // for menu active state
        $this->end_controls_tab();

        // add tab for active state
        $this->start_controls_tab(
            '_tab_menu_active',
            [
                'label' => __( 'Active', 'telnet-core' ),
            ]
        );

        // menu active color
        $this->add_control(
            'menu_active_color',
            [
                'label'     => __( 'Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-main-menu ul li.current-menu-item a' => 'color: {{VALUE}};',
                ],
            ]
        );

        // menu active background color
        $this->add_control(
            'menu_active_bg_color',
            [
                'label'     => __( 'Background Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-main-menu ul li.current-menu-item a' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        // end
        $this->end_controls_tab();

        // end tab
        $this->end_controls_tabs();


        $this->end_controls_section();

        // sub menu style
        $this->start_controls_section(
            '_section_style_submenu',
            [
                'label' => __( 'SUB MENU STYLE', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // sub menu bg
        $this->add_control(
            'submenu_bg_color',
            [
                'label'     => __( 'Background Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-main-menu ul li .sub-menu' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        // sub menu typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'submenu_typography',
                'label'    => __( 'Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-main-menu ul li .sub-menu li a',
            ]
        );

        // sub menu padding
        $this->add_responsive_control(
            'submenu_padding',
            [
                'label'      => __( 'Padding', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors'  => [
                    '{{WRAPPER}} .tx-main-menu ul li .sub-menu li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // sub menu margin
        $this->add_responsive_control(
            'submenu_margin',
            [
                'label'      => __( 'Margin', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors'  => [
                    '{{WRAPPER}} .tx-main-menu ul li .sub-menu li a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // add tab for normal state
        $this->start_controls_tabs( '_tabs_submenu_style' );

        // add tab for normal state
        $this->start_controls_tab(
            '_tab_submenu_normal',
            [
                'label' => __( 'Normal', 'telnet-core' ),
            ]
        );

        // sub menu color
        $this->add_control(
            'submenu_color',
            [
                'label'     => __( 'Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-main-menu ul li .sub-menu li a' => 'color: {{VALUE}};',
                ],
            ]
        );

        // sub menu background color
        $this->add_control(
            'submenu_text_bg_color',
            [
                'label'     => __( 'Background Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-main-menu ul li .sub-menu li a' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        // for sub menu hover state
        $this->end_controls_tab();

        // add tab for hover state
        $this->start_controls_tab(
            '_tab_submenu_hover',
            [
                'label' => __( 'Hover', 'telnet-core' ),
            ]
        );

        // sub menu hover color
        $this->add_control(
            'submenu_hover_color',
            [
                'label'     => __( 'Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-main-menu ul li .sub-menu li a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        // sub menu hover background color
        $this->add_control(
            'submenu_hover_bg_color',
            [
                'label'     => __( 'Background Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-main-menu ul li .sub-menu li a:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        // for sub menu hover state
        $this->end_controls_tab();

        // end tab
        $this->end_controls_tabs();

        // end section
        $this->end_controls_section();

        // menu icon style
        $this->start_controls_section(
            '_section_style_menu_icon',
            [
                'label' => __( 'MENU ICON STYLE', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // menu icon color
        $this->add_control(
            'menu_icon_color',
            [
                'label'     => __( 'Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-main-menu ul .menu-item-has-children > a::after' => 'color: {{VALUE}};',
                ],
            ]
        );

        // menu icon hover color
        $this->add_control(
            'menu_icon_hover_color',
            [
                'label'     => __( 'Hover Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-main-menu ul li.menu-item-has-children > a:hover:after' => 'color: {{VALUE}};',
                ],
            ]
        );

        // menu icon size
        $this->add_responsive_control(
            'menu_icon_size',
            [
                'label'      => __( 'Size', 'telnet-core' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em' ],
                'range'      => [
                    'px' => [
                        'min'  => 5,
                        'max'  => 50,
                        'step' => 1,
                    ],
                    'em' => [
                        'min'  => 0.5,
                        'max'  => 5,
                        'step' => 0.1,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .tx-main-menu ul .menu-item-has-children > a::after' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // dot icon size
        $this->add_responsive_control(
            'dot_icon_size',
            [
                'label'      => __( 'Dot Size', 'telnet-core' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em' ],
                'range'      => [
                    'px' => [
                        'min'  => 5,
                        'max'  => 50,
                        'step' => 1,
                    ],
                    'em' => [
                        'min'  => 0.5,
                        'max'  => 5,
                        'step' => 0.1,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .tx-main-menu ul li a::before' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // Dot icon color
        $this->add_control(
            'dot_icon_color',
            [
                'label'     => __( 'Dot Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-main-menu ul li a::before' => 'background: {{VALUE}};',
                ],
            ]
        );

        // submenu icon color
        $this->add_control(
            'submenu_icon_color',
            [
                'label'     => __( 'Submenu Icon Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-main-menu ul li .sub-menu li.menu-item-has-children > a::after' => 'color: {{VALUE}};',
                ],
            ]
        );

        // submenu icon hover color
        $this->add_control(
            'submenu_icon_hover_color',
            [
                'label'     => __( 'Submenu Icon Hover Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-main-menu ul li .sub-menu li.menu-item-has-children > a:hover:after' => 'color: {{VALUE}};',
                ],
            ]
        );

        // submenu icon size
        $this->add_responsive_control(
            'submenu_icon_size',
            [
                'label'      => __( 'Submenu Icon Size', 'telnet-core' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em' ],
                'range'      => [
                    'px' => [
                        'min'  => 5,
                        'max'  => 50,
                        'step' => 1,
                    ],
                    'em' => [
                        'min'  => 0.5,
                        'max'  => 5,
                        'step' => 0.1,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .tx-main-menu ul li .sub-menu li.menu-item-has-children > a::after' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // sub menu left icon size
        $this->add_responsive_control(
            'submenu_left_icon_size',
            [
                'label'      => __( 'Submenu Left Icon Size', 'telnet-core' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em' ],
                'range'      => [
                    'px' => [
                        'min'  => 5,
                        'max'  => 50,
                        'step' => 1,
                    ],
                    'em' => [
                        'min'  => 0.5,
                        'max'  => 5,
                        'step' => 0.1,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .tx-main-menu ul li .sub-menu li a::before' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // sub menu left icon color
        $this->add_control(
            'submenu_left_icon_color',
            [
                'label'     => __( 'Submenu Left Icon Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-main-menu ul li .sub-menu li a::before' => 'color: {{VALUE}};',
                ],
            ]
        );

        // sub menu left icon hover color
        $this->add_control(
            'submenu_left_icon_hover_color',
            [
                'label'     => __( 'Submenu Left Icon Hover Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-main-menu ul li .sub-menu li a:hover::before' => 'color: {{VALUE}};',
                ],
            ]
        );

        // end
        $this->end_controls_section();


    }

    protected function render() {

        $settings = $this->get_settings_for_display();
        $dir = dirname( __FILE__ );

        if ( !empty( $settings['design_style'] ) && $settings['design_style'] == 'style_3' ):
            include $dir . '/views/view-3.php';

        elseif ( !empty( $settings['design_style'] ) && $settings['design_style'] == 'style_2' ):
            include $dir . '/views/view-2.php';
        else:
            include $dir . '/views/view-1.php';
        endif;
    }
}
