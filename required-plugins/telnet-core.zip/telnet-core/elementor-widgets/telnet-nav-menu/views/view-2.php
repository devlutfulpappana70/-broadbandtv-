<?php if ( !empty( $settings['select_menu'] ) ) : ?>
<div class="footer-2-menu">
    <?php
        echo wp_nav_menu( [
            'menu'        => '' . $settings['select_menu'] . '',
            'menu_class'  => 'navigation clearfix',
            'container'   => '',
            'fallback_cb' => 'Navwalker_Class::fallback',
            'walker'      => class_exists( 'Telnet_Mega_Menu_Walker' ) ? new Telnet_Mega_Menu_Walker : '',
        ] );
    ?>
</div>
<?php endif;