<section id="tel-price" class="tel-price-section tna-price-3 position-relative bg-default flat_3">
	<div class="container tna-container-1">
		<!-- section-title -->
		<div class="tel_price__nav-wrap position-relative">
			<div class="tel_price__nav tna_price_3_main swiper mySwiper swiper-container">
				<div class="swiper-wrapper">
				<?php foreach($settings['tab_lists'] as $list )  :?>
					<div class="swiper-slide">
						<div class="tel_price__nav-item text-center">
							<div class="tel_price__nav-icon d-flex align-items-center justify-content-center">
								<?php
                                    if ($list['type'] === 'image' && ($list['tab_title_image']['url'] || $list['tab_title_image']['id'])) {
                                        $this->get_render_attribute_string('tab_title_image');
                                        $list['hover_animation'] = 'disable-animation';
                                        echo Group_Control_Image_Size::get_attachment_image_html($list, 'thumbnail', 'tab_title_image');
                                    } elseif (!empty($list['tab_title_icon'])) {
                                        elh_element_render_icon($list, '', 'tab_title_icon');
                                    }
                                ?>
							</div>
							<?php if(!empty( $list['tab_title'] )) : ?>
                            <h3 class="tel_price__nav-title"><?php echo elh_element_kses_intermediate($list['tab_title']); ?></h3>
                            <?php endif; ?>
						</div>
					</div>
				<?php endforeach; ?>
				</div>
			</div>
			<div class="price-button-prev d-flex justify-content-center align-items-center"><i class="fal fa-long-arrow-left"></i></div>
			<div class="price-button-next d-flex justify-content-center align-items-center"><i class="fal fa-long-arrow-right"></i></div>
		</div>
		<div class="tel_price_content swiper tna_price_3_preview">
            <div class="swiper-wrapper">
                <?php foreach($settings['tab_lists'] as $list )  :
                    $tab_button_text = $list['tab_button_text'];
                    $tab_button_link = $list['tab_button_link']['url'];
                    if ($list['currency'] === 'custom') {
                        $currency = $list['currency_custom'];
                    } else {
                        $currency = self::get_currency_symbol($list['currency']);
                    }
                ?>
                <div class="swiper-slide">
                    <div class="tel_price_item-area">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="tel_price_img-area position-relative">
                                    <?php if(!empty( $list['tab_content_image']['url'] )) : ?>
                                    <div class="price-img1">
                                        <img src="<?php echo esc_url($list['tab_content_image']['url']); ?>" alt="">
                                    </div>
                                    <?php endif; ?>

                                    <?php if(!empty( $list['tab_content_image_2']['url'] )) : ?>
                                    <div class="price-img2 position-absolute">
                                        <img src="<?php echo esc_url($list['tab_content_image_2']['url']); ?>" alt="">
                                    </div>
                                    <?php endif; ?>

                                    <?php if(!empty( $currency || $list['price'] || $list['period'] )) : ?>
                                    <div class="price-plan-value position-absolute text-center text-uppercase">
                                        <h3>
                                            <?php if(!empty( $currency )) : ?>
                                            <sup><?php echo esc_html($currency); ?></sup>
                                            <?php endif; ?>

                                            <?php echo $list['price'] ? esc_html($list['price']) : ''; ?>
                                        </h3>

                                        <?php if(!empty( $list['period'] )) : ?>
                                        <p><?php echo esc_html($list['period']); ?></p>
                                        <?php endif; ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="tel_price_item-list ul-li-block">

                            	<?php
								$package_lists = $list['package_lists'];

								if (!empty($package_lists) && is_string($package_lists)) {
									$package_array = explode("\n", $package_lists);
								?>
							<ul>
								<?php foreach ($package_array as $features) : ?>
									<li>
										<i class="flaticon_3-check-mark"></i>
										<?php echo wp_kses($features, true); ?>
									</li>
								<?php endforeach; ?>
							</ul>
							<?php }
							?>



                                    <?php if(!empty( $tab_button_link || $tab_button_text )) : ?>
									<div class="tna-p3-btn">
										<a class="tna-pr-btn-4 has-white" href="<?php echo esc_url($tab_button_link) ?>">
											<span class="text"><?php echo elh_element_kses_intermediate($tab_button_text); ?></span>
											<?php
                                                if ($list['btn_type'] === 'image' && ($list['btn_image']['url'] || $list['btn_image']['id'])) {
                                                    $this->get_render_attribute_string('btn_image');
                                                    $list['hover_animation'] = 'disable-animation';
                                                    echo Group_Control_Image_Size::get_attachment_image_html($list, 'thumbnail', 'btn_image');
                                                } elseif (!empty($list['btn_icon'])) {
                                                    elh_element_render_icon($list, '', 'btn_icon');
                                                }
                                            ?>
										</a>
									</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
    	</div>
	</div>
</section>