<div class="tx-tabSection tx-tabSection__styleTwo pt-150 pb-40 position-relative">
    <?php if(!empty( $settings['background_image']['url'] )) : ?>
    <div class="tx-bgImg" data-background="<?php echo esc_url($settings['background_image']['url']) ?>"></div>
    <?php endif; ?>
    <?php if(!empty( $settings['tab_lists'] )) : ?>
    <div class="container tx-z1 position-relative">
        <div class="row">
            <div class="col-xl-12">
                <div class="tab-content">
                    <?php
                        foreach( $settings['tab_lists'] as $id => $list ) :
                        $tab_content_sub_title = $list['tab_content_sub_title'];
                        $tab_content_title = $list['tab_content_title'];
                        $tab_content_description = $list['tab_content_description'];
                        $tab_content_video_button_link = $list['tab_content_video_button_link']['url'];
                        $tab_button_text = $list['tab_button_text'];
                        $tab_button_link = $list['tab_button_link']['url'];

                        if ($list['currency'] === 'custom') {
                            $currency = $list['currency_custom'];
                        } else {
                            $currency = self::get_currency_symbol($list['currency']);
                        }

                        $active = ($id == 0) ? 'show active' : '';
                    ?>
                    <div class="tab-pane fade <?php echo esc_attr($active); ?>" id="txTab_<?php echo esc_attr($id); ?>" role="tabpanel" aria-labelledby="<?php echo esc_attr($id); ?>-tab">
                        <div class="tx-tabContentWrapper">
                            <div class="row">
                                <div class="col-lg-8">
                                    <div class="tx-sectionHeading">
                                        <?php if(!empty( $tab_content_sub_title )) : ?>
                                        <span class="tx-sectionHeading__subTitle tx-sectionHeading__subTitle--white tx-uppercase">
                                            <?php echo elh_element_kses_intermediate($tab_content_sub_title); ?>
                                        </span>
                                        <?php endif; ?>

                                        <?php if(!empty( $tab_content_title )) : ?>
                                        <h2 class="tx-sectionHeading__title tx-sectionHeading__title--white"><?php echo elh_element_kses_intermediate($tab_content_title); ?></h2>
                                        <?php endif; ?>

                                        <?php if(!empty( $currency || $list['price'] || $list['period'] || $list['package_feature'] )) : ?>
                                        <div class="tx-price mt-20">
                                            <?php if(!empty( $currency )) : ?>
                                            <sub class="tx-price__currency tx-fwLight"><?php echo esc_html($currency); ?></sub>
                                            <?php endif; ?>

                                            <?php if(!empty( $list['price'] )) : ?>
                                            <span class="tx-price__price">
                                                <?php echo esc_html($list['price']); ?>
                                            </span>
                                            <?php endif; ?>

                                            <?php if(!empty( $list['period'] )) : ?>
                                            <sub class="tx-price__period tx-fwLight"><?php echo esc_html($list['period']); ?></sub>
                                            <?php endif; ?>

                                            <?php if(!empty( $list['package_feature'] )) : ?>
                                            <span class="tx-price__package d-block"><?php echo esc_html($list['package_feature']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <?php endif; ?>

                                        <?php if(!empty( $tab_content_description )) : ?>
                                        <p class="mt-25"><?php echo elh_element_kses_intermediate($tab_content_description); ?></p>
                                        <?php endif; ?>

                                        <?php if(!empty( $tab_button_link || $tab_button_text )) : ?>
                                        <a href="<?php echo esc_url($tab_button_link); ?>" class="tx-button tx-button__styleTheme mt-40">
                                            <?php echo elh_element_kses_intermediate($tab_button_text); ?>
                                        </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-lg-4 text-center align-self-center">
                                <?php if(!empty( $tab_content_video_button_link )) : ?>
                                    <div class="tx-cercleBadgeWrapper tx-z1">
                                        <a href="<?php echo esc_url($tab_content_video_button_link) ?>" class="tx-cercleBadge position-relative m-auto" data-rel="lightcase">
                                            <i class="fas fa-play"></i>
                                        </a>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>



                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="tx-tabNavs nav mt-45 d-flex aling-items-center justify-content-center" role="tablist">
                    <?php
                        foreach( $settings['tab_lists'] as $id => $list ) :
                        $tab_title = $list['tab_title'];

                        $active = ($id == 0) ? 'active' : '';
                        $aria_selected = ($id == 0) ? 'true' : 'false';
                    ?>
                    <button class="nav-link tx-tabNavItem <?php echo esc_attr($active); ?>" id="<?php echo esc_attr($id); ?>-tab" data-bs-toggle="tab" data-bs-target="#txTab_<?php echo esc_attr($id); ?>" type="button" role="tab" aria-controls="txTab_<?php echo esc_attr($id); ?>" aria-selected="<?php echo esc_attr($aria_selected); ?>">
                        <?php echo $tab_title ? elh_element_kses_basic($tab_title) : ''; ?>
                    </button>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>