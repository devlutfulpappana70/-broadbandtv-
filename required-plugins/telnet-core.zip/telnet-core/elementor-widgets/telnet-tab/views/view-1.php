<div class="tx-tabSection tx-tabSection__styleOne pt-150 position-relative fix">
    <?php if(!empty( $settings['background_image']['url'] )) : ?>
    <div class="tx-bgImg" data-background="<?php echo esc_url($settings['background_image']['url']) ?>"></div>
    <?php endif; ?>
    <?php if(!empty( $settings['tab_lists'] )) : ?>
    <div class="container-fluid tx-z1 position-relative">
        <div class="row tx-column-gap-50">
            <div class="col-xl-2">
                <div class="tx-tabNavs nav mt-60" role="tablist">
                    <?php
                        foreach( $settings['tab_lists'] as $id => $list ) :
                        $smallThumb = $list['tab_title_image']['url'];
                        $tab_title = $list['tab_title'];
                        $tab_title_tag = $list['tab_title_tag'];

                        $active = ($id == 0) ? 'active' : '';
                        $aria_selected = ($id == 0) ? 'true' : 'false';

                    ?>
                    <button class="nav-link tx-tabNavItem <?php echo esc_attr($active); ?>" id="<?php echo esc_attr($id); ?>-tab" data-bs-toggle="tab" data-bs-target="#txTab_<?php echo esc_attr($id); ?>" type="button" role="tab" aria-controls="txTab_<?php echo esc_attr($id); ?>" aria-selected="<?php echo esc_attr($aria_selected); ?>">
                        <?php if(!empty( $smallThumb )) : ?>
                        <span class="tx-smallThumb">
                            <img src="<?php echo esc_url($smallThumb); ?>" alt="">
                        </span>
                        <?php endif; ?>

                        <?php if(!empty( $tab_title || $tab_title_tag )) : ?>
                        <span class="tx-smallContent">
                            <?php if(!empty( $tab_title )) : ?>
                            <span class="tx-smallTitle"><?php echo elh_element_kses_intermediate($tab_title); ?></span>
                            <?php endif; ?>

                            <?php if(!empty( $tab_title_tag )) : ?>
                            <span class="tx-smallDesc"><?php echo elh_element_kses_intermediate($tab_title_tag); ?></span>
                            <?php endif; ?>

                            <?php if(!empty( $list['tab_title_icon'] )) : ?>
                            <span class="tx-smallIcon" >
                                <?php elh_element_render_icon($list, '', 'tab_title_icon'); ?>
                            </span>
                            <?php endif; ?>
                        </span>
                        <?php endif; ?>

                    </button>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="col-xl-10">
                <div class="tab-content">
                    <?php
                        foreach( $settings['tab_lists'] as $id => $list ) :
                        $tab_content_image = $list['tab_content_image']['url'];
                        $tab_content_cercle_box_text = $list['tab_content_cercle_box_text'];
                        $tab_content_sub_title = $list['tab_content_sub_title'];
                        $tab_content_title = $list['tab_content_title'];
                        $tab_content_title_shape_img = $list['tab_content_title_shape_img']['url'];
                        $tab_content_video_button_img = $list['tab_content_video_button_img']['url'];
                        $tab_content_video_button_link = $list['tab_content_video_button_link']['url'];
                        $tab_content_video_text = $list['tab_content_video_text'];
                        $tab_button_text = $list['tab_button_text'];
                        $tab_button_link = $list['tab_button_link']['url'];

                        $active = ($id == 0) ? 'show active' : '';
                    ?>
                    <div class="tab-pane fade <?php echo esc_attr($active); ?>" id="txTab_<?php echo esc_attr($id); ?>" role="tabpanel" aria-labelledby="<?php echo esc_attr($id); ?>-tab">
                        <div class="tx-tabContentWrapper">
                            <?php if(!empty( $tab_content_image && $tab_content_cercle_box_text )) : ?>
                            <div class="tx-thumb position-relative">
                                <?php if(!empty( $tab_content_image )) : ?>
                                <img src="<?php echo esc_url($tab_content_image); ?>" alt="">
                                <?php endif; ?>

                                <?php if(!empty( $tab_content_cercle_box_text )) : ?>
                                <div class="tx-cercleBadgeWrapper position-absolute tx-uppercase text-center tx-z1">
                                    <span class="tx-cercleBadge position-relative">
                                        <?php echo elh_element_kses_intermediate($tab_content_cercle_box_text); ?>
                                    </span>
                                </div>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                            <div class="tx-content pl-65">
                                <div class="tx-sectionHeading tx-sectionHeading__styleTwo">
                                    <?php if(!empty( $tab_content_sub_title )) : ?>
                                    <span class="tx-sectionHeading__subTitle tx-sectionHeading__subTitle--white">
                                        <?php echo elh_element_kses_intermediate($tab_content_sub_title); ?>
                                    </span>
                                    <?php endif; ?>

                                    <?php if(!empty( $tab_content_title )) : ?>
                                    <h2 class="tx-sectionHeading__title tx-sectionHeading__title--white mt-20">
                                        <?php echo elh_element_kses_intermediate($tab_content_title); ?>
                                    </h2>
                                    <?php endif; ?>
                                </div>
                                <div class="tx-videoWrapper mt-35">
                                    <?php if(!empty( $tab_content_video_button_img || $tab_content_video_button_link )) : ?>
                                    <div class="tx-videoThumb position-relative">
                                        <img src="<?php echo esc_url($tab_content_video_button_img) ?>" alt="">

                                        <?php if(!empty( $tab_content_video_button_link )) : ?>
                                        <a href="<?php echo esc_url($tab_content_video_button_link) ?>" class="tx-round-btn position-absolute start-50 top-50 translate-middle" data-rel="lightcase">
                                            <i class="fas fa-play"></i>
                                        </a>
                                        <?php endif; ?>
                                    </div>
                                    <?php endif; ?>

                                    <?php if(!empty( $tab_content_video_text )) : ?>
                                    <div class="tx-videoContent">
                                        <p>
                                            <?php echo elh_element_kses_intermediate($tab_content_video_text); ?>
                                        </p>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <?php if(!empty( $tab_button_link || $tab_button_text )) : ?>
                                <a href="<?php echo esc_url($tab_button_link); ?>" class="tx-button tx-button__styleTheme mt-50">
                                    <?php echo elh_element_kses_intermediate($tab_button_text); ?>
                                </a>
                                <?php endif; ?>
                            </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>