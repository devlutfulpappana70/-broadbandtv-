<?php

namespace ElementHelper\Widget;

use \Elementor\Controls_Manager;
use \Elementor\Repeater;
use \Elementor\Core\Schemes\Typography;
use \Elementor\Utils;

defined( 'ABSPATH' ) || die();

class Telnet_Tab extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name() {
        return 'telnet_tab';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title() {
        return __( 'Telnet Tab', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/gradient-heading/';
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-t-letter';
    }

    public function get_keywords() {
        return ['brand', 'image', 'icon', 'telnet'];
    }

    protected function register_content_controls() {

        //Settings
        $this->start_controls_section(
            '_section_settings',
            [
                'label' => __( 'Settings', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'design_style',
            [
                'label'              => __( 'Design Style', 'telnet-core' ),
                'type'               => Controls_Manager::SELECT,
                'options'            => [
                    'style_1' => __( 'Style 1', 'telnet-core' ),
                    'style_2' => __( 'Style 2', 'telnet-core' ),
                ],
                'default'            => 'style_1',
                'frontend_available' => true,
                'style_transfer'     => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_image',
            [
                'label' => __( 'Images', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // background image
        $this->add_control(
            'background_image',
            [
                'label'       => __( 'Background Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'label_block' => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_title',
            [
                'label' => __( 'Tabs', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        // Tab Repeater
        $repeater = new Repeater();

        // tab style
        $repeater->add_control(
            'option_style',
            [
                'label'              => __( 'CHOOSE STYLE', 'telnet-core' ),
                'type'               => Controls_Manager::SELECT,
                'options'            => [
                    'style_1' => __( 'Style 1', 'telnet-core' ),
                    'style_2' => __( 'Style 2', 'telnet-core' ),
                ],
                'default'            => 'style_1',
                'frontend_available' => true,
                'style_transfer'     => true,
            ]
        );

        // tab title image
        $repeater->add_control(
            'tab_title_image',
            [
                'label'       => __( 'Tab Title Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'label_block' => true,
                'condition'   => [
                    'option_style' => ['style_1'],
                ],
            ]
        );

        // tab title
        $repeater->add_control(
            'tab_title',
            [
                'label'       => __( 'Tab Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Tab Title', 'telnet-core' ),
                'label_block' => true,
            ]
        );

        // tab title tags
        $repeater->add_control(
            'tab_title_tag',
            [
                'label'       => __( 'Tab Title Tag', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Branding', 'telnet-core' ),
                'label_block' => true,
                'condition'   => [
                    'option_style' => ['style_1'],
                ],
            ]
        );

        // tab title icon
        $repeater->add_control(
            'tab_title_icon',
            [
                'label'       => __( 'Tab Title Icon', 'telnet-core' ),
                'type'        => Controls_Manager::ICONS,
                'label_block' => true,
                'default'     => [
                    'value'   => 'fas fa-check',
                    'library' => 'solid',
                ],
                'condition'   => [
                    'option_style' => ['style_1'],
                ],
            ]
        );

        // tab content image
        $repeater->add_control(
            'tab_content_image',
            [
                'label'       => __( 'Tab Content Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'label_block' => true,
                'condition'   => [
                    'option_style' => ['style_1'],
                ],
            ]
        );

        // tab content cercle box text
        $repeater->add_control(
            'tab_content_cercle_box_text',
            [
                'label'       => __( 'Cercle Box Text', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __( 'Super 20 off', 'telnet-core' ),
                'placeholder' => __( 'Type Cercle Box Text', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
                'condition'   => [
                    'option_style' => ['style_1'],
                ],
            ]
        );

        // tab content sub title
        $repeater->add_control(
            'tab_content_sub_title',
            [
                'label'       => __( 'Tab Content Sub Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'default'     => __( 'Tab Content Sub Title', 'telnet-core' ),
                'placeholder' => __( 'Type Tab Content Sub Title', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );

        // tab content title
        $repeater->add_control(
            'tab_content_title',
            [
                'label'       => __( 'Tab Content Title', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'default'     => __( 'Tab Content Title', 'telnet-core' ),
                'placeholder' => __( 'Type Tab Content Title', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );

        // CURRENCY SYMBOL
        $repeater->add_control(
            'currency',
            [
                'label'       => __( 'Currency', 'telnet-core' ),
                'type'        => Controls_Manager::SELECT,
                'label_block' => false,
                'options'     => [
                    ''             => __( 'None', 'telnet-core' ),
                    'baht'         => '&#3647; ' . _x( 'Baht', 'Currency Symbol', 'telnet-core' ),
                    'bdt'          => '&#2547; ' . _x( 'BD Taka', 'Currency Symbol', 'telnet-core' ),
                    'dollar'       => '&#36; ' . _x( 'Dollar', 'Currency Symbol', 'telnet-core' ),
                    'euro'         => '&#128; ' . _x( 'Euro', 'Currency Symbol', 'telnet-core' ),
                    'franc'        => '&#8355; ' . _x( 'Franc', 'Currency Symbol', 'telnet-core' ),
                    'guilder'      => '&fnof; ' . _x( 'Guilder', 'Currency Symbol', 'telnet-core' ),
                    'krona'        => 'kr ' . _x( 'Krona', 'Currency Symbol', 'telnet-core' ),
                    'lira'         => '&#8356; ' . _x( 'Lira', 'Currency Symbol', 'telnet-core' ),
                    'peseta'       => '&#8359 ' . _x( 'Peseta', 'Currency Symbol', 'telnet-core' ),
                    'peso'         => '&#8369; ' . _x( 'Peso', 'Currency Symbol', 'telnet-core' ),
                    'pound'        => '&#163; ' . _x( 'Pound Sterling', 'Currency Symbol', 'telnet-core' ),
                    'real'         => 'R$ ' . _x( 'Real', 'Currency Symbol', 'telnet-core' ),
                    'ruble'        => '&#8381; ' . _x( 'Ruble', 'Currency Symbol', 'telnet-core' ),
                    'rupee'        => '&#8360; ' . _x( 'Rupee', 'Currency Symbol', 'telnet-core' ),
                    'indian_rupee' => '&#8377; ' . _x( 'Rupee (Indian)', 'Currency Symbol', 'telnet-core' ),
                    'shekel'       => '&#8362; ' . _x( 'Shekel', 'Currency Symbol', 'telnet-core' ),
                    'won'          => '&#8361; ' . _x( 'Won', 'Currency Symbol', 'telnet-core' ),
                    'yen'          => '&#165; ' . _x( 'Yen/Yuan', 'Currency Symbol', 'telnet-core' ),
                    'rand'         => 'R ' . _x( 'Rand', 'Currency Symbol', 'telnet-core' ),
                    'dinar'        => '&#8373; ' . _x( 'Dinar', 'Currency Symbol', 'telnet-core' ),
                    'dirham'       => '&#x62f;&#x2e;&#x625; ' . _x( 'Dirham', 'Currency Symbol', 'telnet-core' ),
                    'riyal'        => '&#65020; ' . _x( 'Riyal', 'Currency Symbol', 'telnet-core' ),
                    'ringgit'      => '&#82;&#77; ' . _x( 'Ringgit', 'Currency Symbol', 'telnet-core' ),
                    'baht'         => '&#3647; ' . _x( 'Baht', 'Currency Symbol', 'telnet-core' ),
                    'custom'       => __( 'Custom', 'telnet-core' ),
                ],
                'default'     => 'dollar',
                'condition'   => [
                    'option_style' => ['style_2'],
                ],
            ]
        );

        $repeater->add_control(
            'currency_custom',
            [
                'label'     => __( 'Custom Symbol', 'telnet-core' ),
                'type'      => Controls_Manager::TEXT,
                'condition' => [
                    'currency'     => 'custom',
                    'option_style' => ['style_2'],
                ],
                'dynamic'   => [
                    'active' => true,
                ],
            ]
        );

        // PRICE
        $repeater->add_control(
            'price',
            [
                'label'     => __( 'Price', 'telnet-core' ),
                'type'      => Controls_Manager::TEXT,
                'default'   => '9.99',
                'dynamic'   => [
                    'active' => true,
                ],
                'condition' => [
                    'option_style' => ['style_2'],
                ],
            ]
        );

        // PERIOD
        $repeater->add_control(
            'period',
            [
                'label'     => __( 'Period', 'telnet-core' ),
                'type'      => Controls_Manager::TEXT,
                'default'   => __( 'Per Month', 'telnet-core' ),
                'dynamic'   => [
                    'active' => true,
                ],
                'condition' => [
                    'option_style' => ['style_2'],
                ],
            ]
        );

        // tab content description
        $repeater->add_control(
            'tab_content_description',
            [
                'label'       => __( 'Tab Content Description', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'default'     => __( 'Tab Content Description', 'telnet-core' ),
                'placeholder' => __( 'Type Tab Content Description', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
                'condition'   => [
                    'option_style' => ['style_2'],
                ],
            ]
        );

        // tab content title shape img
        $repeater->add_control(
            'tab_content_title_shape_img',
            [
                'label'       => __( 'Tab Content Title Shape Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'label_block' => true,
                'condition'   => [
                    'option_style' => ['style_1'],
                ],
            ]
        );

        // tab content video button img
        $repeater->add_control(
            'tab_content_video_button_img',
            [
                'label'       => __( 'Tab Content Video Button Image', 'telnet-core' ),
                'type'        => Controls_Manager::MEDIA,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'label_block' => true,
                'condition'   => [
                    'option_style' => ['style_1'],
                ],
            ]
        );

        // tab content video button link
        $repeater->add_control(
            'tab_content_video_button_link',
            [
                'label'       => __( 'Tab Content Video Button Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'label_block' => true,
                'default'     => [
                    'url' => 'https://www.youtube.com/watch?v=9No-FiEInLA',
                ],
                'placeholder' => __( 'https://www.youtube.com/watch?v=9No-FiEInLA', 'telnet-core' ),
            ]
        );

        // tab content button text
        $repeater->add_control(
            'tab_content_video_text',
            [
                'label'       => __( 'Tab Content Video Text', 'telnet-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'default'     => __( 'Tab Content Video Text', 'telnet-core' ),
                'placeholder' => __( 'Type Tab Content Video Text', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
                'condition'   => [
                    'option_style' => ['style_1'],
                ],
            ]
        );

        // tab button text
        $repeater->add_control(
            'tab_button_text',
            [
                'label'       => __( 'Tab Button Text', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __( 'Tab Button Text', 'telnet-core' ),
                'placeholder' => __( 'Type Tab Button Text', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );

        // tab button link
        $repeater->add_control(
            'tab_button_link',
            [
                'label'       => __( 'Tab Button Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'label_block' => true,
                'default'     => [
                    'url' => '#',
                ],
                'placeholder' => __( 'https://your-link.com', 'telnet-core' ),
            ]
        );

        $this->add_control(
            'tab_lists',
            [
                'label'       => __( 'Tab List', 'telnet-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [
                    [
                        'tab_title_image'               => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                        'tab_title'                     => __( 'Tab Title', 'telnet-core' ),
                        'tab_title_tag'                 => __( 'Branding', 'telnet-core' ),
                        'tab_content_image'             => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                        'tab_content_cercle_box_text'   => __( 'Super 20 off', 'telnet-core' ),
                        'tab_content_sub_title'         => __( 'Tab Content Sub Title', 'telnet-core' ),
                        'tab_content_title'             => __( 'Tab Content Title', 'telnet-core' ),
                        'tab_content_title_shape_img'   => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                        'tab_content_video_button_img'  => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                        'tab_content_video_button_link' => [
                            'url' => 'https://www.youtube.com/watch?v=9No-FiEInLA',
                        ],
                        'tab_content_video_text'        => __( 'Tab Content Video Text', 'telnet-core' ),
                        'tab_button_text'               => __( 'Tab Button Text', 'telnet-core' ),
                        'tab_button_link'               => [
                            'url' => '#',
                        ],
                    ],
                ],
                'title_field' => '{{{ tab_title }}}',
            ]
        );

        $this->end_controls_section();

    }

    protected function register_style_controls() {
        // SECTION TAB STYLE
        $this->start_controls_section(
            '_section_tab_style',
            [
                'label' => __( 'Tab Style', 'telnet-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // BORDER RADIOUS
        $this->add_control(
            'tab_border_radius',
            [
                'label'      => __( 'Border Radius', 'telnet-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .tx-tabSection .tx-bgImg'        => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .tx-tabSection .tx-bgImg::after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // tab sub title color
        $this->add_control(
            'tab_sub_title_color',
            [
                'label'     => __( 'Tab Sub Title Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-sectionHeading__subTitle' => 'color: {{VALUE}};',
                ],
            ]
        );

        // sub title background color
        $this->add_control(
            'tab_sub_title_bg_color',
            [
                'label'     => __( 'Tab Sub Title Background Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-sectionHeading__subTitle' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        // typography tab sub title
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'tab_sub_title_typography',
                'label'    => __( 'Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-sectionHeading__subTitle',
            ]
        );

        // title color
        $this->add_control(
            'tab_title_color',
            [
                'label'     => __( 'Tab Title Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-sectionHeading__title' => 'color: {{VALUE}};',
                ],
            ]
        );

        // typography title
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'tab_title_typography',
                'label'    => __( 'Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-sectionHeading__title',
            ]
        );

        // currency color
        $this->add_control(
            'currency_color',
            [
                'label'     => __( 'Currency Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-tabSection__styleTwo .tx-price .tx-price__currency' => 'color: {{VALUE}};',
                ],
            ]
        );

        // currency typography
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'currency_typography',
                'label'    => __( 'Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-tabSection__styleTwo .tx-price .tx-price__currency',
            ]
        );

        // price color
        $this->add_control(
            'price_color',
            [
                'label'     => __( 'Price Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-tabSection__styleTwo .tx-price__price' => 'color: {{VALUE}};',
                ],
            ]
        );

        // price typography
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'price_typography',
                'label'    => __( 'Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-tabSection__styleTwo .tx-price__price',
            ]
        );

        // preiod color
        $this->add_control(
            'period_color',
            [
                'label'     => __( 'Period Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-tabSection__styleTwo .tx-price .tx-price__period' => 'color: {{VALUE}};',
                ],
            ]
        );

        // period typography
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'period_typography',
                'label'    => __( 'Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-tabSection__styleTwo .tx-price .tx-price__period',
            ]
        );

        // description color
        $this->add_control(
            'description_color',
            [
                'label'     => __( 'Description Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-tabSection__styleTwo .tx-sectionHeading p' => 'color: {{VALUE}};',
                ],
            ]
        );

        // description typography
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'description_typography',
                'label'    => __( 'Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-tabSection__styleTwo .tx-sectionHeading p',
            ]
        );

        // button text color
        $this->add_control(
            'button_text_color',
            [
                'label'     => __( 'Button Text Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-button__styleTheme' => 'color: {{VALUE}};',
                ],
            ]
        );

        // button bg color
        $this->add_control(
            'button_bg_color',
            [
                'label'     => __( 'Button Background Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-button__styleTheme' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        // button typography
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'button_typography',
                'label'    => __( 'Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-button__styleTheme',
            ]
        );

        // button hover text color
        $this->add_control(
            'button_hover_text_color',
            [
                'label'     => __( 'Button Hover Text Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-button__styleTheme:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        // button hover bg color
        $this->add_control(
            'button_hover_bg_color',
            [
                'label'     => __( 'Button Hover Background Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-button__styleTheme:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        // tab title color
        $this->add_control(
            'tab_title_btn_color',
            [
                'label'     => __( 'Tab Button Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-tabSection__styleTwo .tx-tabNavs .tx-tabNavItem' => 'color: {{VALUE}};',
                ],
            ]
        );

        // tab title background color
        $this->add_control(
            'tab_title_bg_color',
            [
                'label'     => __( 'Tab Title Background Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-tabSection__styleTwo .tx-tabNavs .tx-tabNavItem' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        // tab title typography
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'tab_btn_typography',
                'label'    => __( 'Typography', 'telnet-core' ),
                'selector' => '{{WRAPPER}} .tx-tabSection__styleTwo .tx-tabNavs .tx-tabNavItem',
            ]
        );

        // active tab title color
        $this->add_control(
            'active_tab_title_color',
            [
                'label'     => __( 'Active Tab Title Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-tabSection__styleTwo .tx-tabNavs .tx-tabNavItem.active' => 'color: {{VALUE}};',
                ],
            ]
        );

        // active tab title background color
        $this->add_control(
            'active_tab_title_bg_color',
            [
                'label'     => __( 'Active Tab Title Background Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-tabSection__styleTwo .tx-tabNavs .tx-tabNavItem.active' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        // tab border color
        $this->add_control(
            'tab_border_color',
            [
                'label'     => __( 'Tab Border Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-tabSection__styleTwo .tx-tabNavs .tx-tabNavItem.active::after' => 'border-bottom: 10px solid {{VALUE}};',
                ],
            ]
        );

        // video button icon color
        $this->add_control(
            'video_button_icon_color',
            [
                'label'     => __( 'Video Button Icon Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-tabSection__styleTwo .tx-cercleBadge' => 'color: {{VALUE}};',
                ],
            ]
        );

        // video button bg color
        $this->add_control(
            'video_button_bg_color',
            [
                'label'     => __( 'Video Button Background Color', 'telnet-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tx-cercleBadge::after' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        // END
        $this->end_controls_section();

    }

    private static function get_currency_symbol( $symbol_name ) {
        $symbols = [
            'baht'         => '&#3647;',
            'bdt'          => '&#2547;',
            'dollar'       => '&#36;',
            'euro'         => '&#128;',
            'franc'        => '&#8355;',
            'guilder'      => '&fnof;',
            'indian_rupee' => '&#8377;',
            'pound'        => '&#163;',
            'peso'         => '&#8369;',
            'peseta'       => '&#8359',
            'lira'         => '&#8356;',
            'ruble'        => '&#8381;',
            'shekel'       => '&#8362;',
            'rupee'        => '&#8360;',
            'real'         => 'R$',
            'krona'        => 'kr',
            'won'          => '&#8361;',
            'yen'          => '&#165;',
            'rand'         => 'R',
            'dinar'        => '&#8373;',
            'dirham'       => '&#x62f;&#x2e;&#x625;',
            'riyal'        => '&#65020;',
            'ringgit'      => '&#82;&#77;',
        ];

        return isset( $symbols[$symbol_name] ) ? $symbols[$symbol_name] : '';
    }

    protected function render() {

        $settings = $this->get_settings_for_display();
        $dir = dirname( __FILE__ );

        if ( !empty( $settings['design_style'] ) && $settings['design_style'] == 'style_3' ):
            include $dir . '/views/view-3.php';

        elseif ( !empty( $settings['design_style'] ) && $settings['design_style'] == 'style_2' ):
            include $dir . '/views/view-2.php';
        else:
            include $dir . '/views/view-1.php';
        endif;
    }
}
