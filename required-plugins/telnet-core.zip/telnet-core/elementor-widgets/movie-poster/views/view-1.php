<?php
    $this->add_inline_editing_attributes( 'title', 'basic' );
    $this->add_render_attribute( 'title', 'class', 'sec-title-five_heading' );
    $title = elh_element_kses_basic( $settings['title'] );
?>
<section class="movie-one">
    <?php if(!empty( $settings['bg_image']['url'] )) : ?>
    <div class="movie-one_image" style="background-image: url(<?php echo esc_url($settings['bg_image']['url']); ?>)"></div>
    <?php endif; ?>
    <div class="auto-container">
        <!-- Sec Title Five -->
        <div class="sec-title-five centered">
            <?php if(!empty( $settings['sub_title'] )) : ?>
            <div class="sec-title-five_title"><?php echo elh_element_kses_intermediate($settings['sub_title']); ?></div>
            <?php endif; ?>

            <?php
                printf('<%1$s %2$s>%3$s</%1$s>',
                    tag_escape($settings['title_tag']),
                    $this->get_render_attribute_string('title'),
                    $title
                );
            ?>
            <?php if(!empty($settings['description'])) : ?>
            <div class="sec-title-five_text"><?php echo wp_kses($settings['description'], true)?></div>
            <?php endif; ?>
        </div>
        <div class="movie-one_button text-center">
            <a href="<?php echo $settings['button_link']['url'] ? esc_url($settings['button_link']['url']) : ''; ?>" class="theme-btn btn-style-eighteen">
                <?php if(!empty( $settings['button_text'] )) : ?>
                <span class="txt"><?php echo elh_element_kses_intermediate($settings['button_text']); ?></span>
                <?php endif; ?>

                <?php \Elementor\Icons_Manager::render_icon( $settings['btn_icon'], [ 'aria-hidden' => 'true' ] ); ?>
            </a>
        </div>
        <?php if ( !empty( $settings['info_items'] ) ): ?>
        <div class="moview-one_gallery parallax-scene-1">
        <?php
        $id = 1;
        foreach ( $settings['info_items'] as $list ) :
        ?>
        <div class="post-<?php echo esc_attr($id) ?>" data-depth="<?php echo esc_attr($list['info_depth']); ?>">
            <div class="movie__item-img">
                <img src="<?php echo esc_url($list['info_image']['url']); ?>" alt="moview">
            </div>
        </div>
        <?php
        $id++;
        endforeach;
        ?>

        </div>
        <?php endif; ?>
    </div>
</section>