<?php
namespace ElementHelper\Widget;

use \Elementor\Group_Control_Background;
use \Elementor\Repeater;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Typography;
use \ElementHelper\Element_El_Select2;
use \Elementor\Core\Schemes\Typography;
use \Elementor\Utils;
use \Elementor\Control_Media;

defined( 'ABSPATH' ) || die();

class Hero_Slider_Four extends Element_El_Widget {

    /**
     * Get widget name.
     *
     * Retrieve Element Helper widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'hero_slider_four';
    }


    /**
     * Get widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Hero Slider Four', 'telnet-core' );
    }

    public function get_custom_help_url() {
        return 'http://elementor.themexriver.com/widgets/slider/';
    }

    /**
     * Get widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'elh-widget-icon eicon-slider-full-screen';
    }

    public function get_keywords() {
        return [ 'slider', 'image', 'gallery', 'carousel' ];
    }


    public function get_script_depends() {
		return ['ta_Hero_Slider_Four'];
	}

    public function get_style_depends() {
        return [ 'tf-hero-slider-style' ];
    }

    public function get_post_types() {
        $post_types = elh_element_get_post_types([], ['elementor_library', 'attachment']);
        return $post_types;
    }

    protected function register_content_controls() {

        $this->start_controls_section(
            '_section_slides',
            [
                'label' => __( 'SLIDE ITEMS', 'telnet-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'button_hover_bg_color',
				'types' => [ 'classic' ],
				'exclude' => [ 'color' ],
				'selector' => '{{WRAPPER}} .tel-slider-section-3:after',
                'fields_options' => [
                    'background' => [
                        'label' => esc_html__( 'Slider Background Image', 'invite-plugin' ),
                        'description' => esc_html__( 'Choose background type and style.', 'invite-plugin' ),
                        'separator' => 'before',
                    ]
                ]
			]
		);

        $repeater = new Repeater();

        // BIG IMAGE
        $repeater->add_control(
            'shape',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Shape', 'telnet-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ]
            ]
        );

        // SHAPE IMAGE
        $repeater->add_control(
            'image',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Image', 'telnet-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );
        $repeater->add_control(
            'image2',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Image 2', 'telnet-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        // TITLE
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'sub-icon',
				'types' => [ 'classic' ],
				'exclude' => [ 'color' ],
				'selector' => '{{WRAPPER}} .tel-main-slider-item-3 .tel-main-slider-text-3 .slider-slug:before',
                'fields_options' => [
                    'background' => [
                        'label' => esc_html__( 'Sub Title Icon', 'invite-plugin' ),
                        'description' => esc_html__( 'Choose background type and style.', 'invite-plugin' ),
                        'separator' => 'before',
                    ]
                ]
			]
		);
        $repeater->add_control(
            'subtitle',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'label' => __( 'Sub Title', 'telnet-core' ),
                'default' => __( 'Sub Title Here', 'telnet-core' ),
                'placeholder' => __( 'Type title here', 'telnet-core' ),
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'title',
            [
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'label' => __( 'Title', 'telnet-core' ),
                'default' => __( 'Title Here', 'telnet-core' ),
                'placeholder' => __( 'Type title here', 'telnet-core' ),
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );
        $repeater->add_control(
            'desc',
            [
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'label' => __( 'Desc', 'telnet-core' ),
                'default' => __( 'Title Here', 'telnet-core' ),
                'placeholder' => __( 'Type title here', 'telnet-core' ),
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );
        $repeater->add_control(
            'video_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'label' => __( 'Video Title', 'telnet-core' ),
            ]
        );
        $repeater->add_control(
            'video_link',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'label' => __( 'Video Image', 'telnet-core' ),
            ]
        );

        // BUTTON TEXT

        $repeater->add_control(
            'button_text',
            [
                'label'       => __( 'Text', 'telnet-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Button Text', 'telnet-core' ),
                'placeholder' => __( 'Type button text here', 'telnet-core' ),
                'label_block' => true,
                'dynamic'     => [
                    'active' => true,
                ],
            ]
        );

        // BUTTON LINK
        $repeater->add_control(
            'button_link',
            [
                'label'       => __( 'Link', 'telnet-core' ),
                'type'        => Controls_Manager::URL,
                'placeholder' => __( 'http://elementor.themexriver.com', 'telnet-core' ),
                'dynamic'     => [
                    'active' => true,
                ],
                'default' => [
					'url' => 'http://elementor.themexriver.com',
					'is_external' => true,
					'nofollow' => true,
				],
            ]
        );


        // ALL SLIDES
        $this->add_control(
            'slides',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '<# print(title || "Carousel Item"); #>',
                'default' => [
                    [
                        'image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_brands',
            [
                'label' => __( 'Brand ITEMS', 'telnet-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        // SHAPE IMAGE
        $repeater->add_control(
            'b_logo',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Brand Logo Image', 'telnet-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );


        // ALL SLIDES
        $this->add_control(
            'brands',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                ]
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
            '_section_counter',
            [
                'label' => __( 'Counter ITEMS', 'telnet-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $repeater = new Repeater();
        $repeater->add_control(
            'type',
            [
                'label'          => __( 'Icon', 'telnet-core' ),
                'type'           => Controls_Manager::CHOOSE,
                'label_block'    => false,
                'options'        => [
                    'icon'  => [
                        'title' => __( 'Icon', 'telnet-core' ),
                        'icon'  => 'far fa-smile',
                    ],
                    'image' => [
                        'title' => __( 'Image', 'telnet-core' ),
                        'icon'  => 'fa fa-image',
                    ],
                ],
                'default'        => 'image',
                'toggle'         => false,
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'image',
            [
                'label'     => __( 'Icon image', 'telnet-core' ),
                'type'      => Controls_Manager::MEDIA,
                'default'   => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'type' => 'image',
                ],
                'dynamic'   => [
                    'active' => true,
                ],
            ]
        );

        if ( elh_element_is_elementor_version( '<', '2.6.0' ) ) {
            $repeater->add_control(
                'icon',
                [
                    'label'       => __( 'Icon', 'telnet-core' ),
                    'label_block' => true,
                    'type'        => Controls_Manager::ICON,
                    'options'     => elh_element_get_elh_element_icons(),
                    'default'     => 'fa fa-smile-o',
                    'condition'   => [
                        'type' => 'icon'
                    ],
                ]
            );
        } else {
            $repeater->add_control(
                'selected_icon',
                [
                    'type'             => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block'      => true,
                    'default'          => [
                        'value'   => 'fal fa-long-arrow-right',
                        'library' => 'fa-solid',
                    ],
                    'condition'        => [
                        'type' => 'icon'
                    ],
                ]
            );
        }
        $repeater->add_control(
            'title',
            [
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'label' => __( 'Title', 'telnet-core' ),
                'default' => __( 'Title Here', 'telnet-core' ),
                'placeholder' => __( 'Type title here', 'telnet-core' ),
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );
        $repeater->add_control(
            'count',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'label' => __( 'Count', 'telnet-core' ),
                'default' => __( '457', 'telnet-core' ),
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );
        $this->add_control(
            'counters',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '<# print(title || "Carousel Item"); #>',
                'default' => [
                    [
                        'image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                ]
            ]
        );
        $this->end_controls_section();


    }

    protected function register_style_controls() {
        $dir = dirname( __FILE__ );

        include $dir . '/styles/slide-style.php';
        include $dir . '/styles/sub-title-style.php';
        include $dir . '/styles/title-style.php';
        include $dir . '/styles/description-style.php';
        include $dir . '/styles/cercle-box-style.php';
        include $dir . '/styles/price-style.php';
        include $dir . '/styles/button-style.php';

    }

    private static function get_currency_symbol($symbol_name)
    {
        $symbols = [
            'baht' => '&#3647;',
            'bdt' => '&#2547;',
            'dollar' => '&#36;',
            'euro' => '&#128;',
            'franc' => '&#8355;',
            'guilder' => '&fnof;',
            'indian_rupee' => '&#8377;',
            'pound' => '&#163;',
            'peso' => '&#8369;',
            'peseta' => '&#8359',
            'lira' => '&#8356;',
            'ruble' => '&#8381;',
            'shekel' => '&#8362;',
            'rupee' => '&#8360;',
            'real' => 'R$',
            'krona' => 'kr',
            'won' => '&#8361;',
            'yen' => '&#165;',
        ];

        return isset($symbols[$symbol_name]) ? $symbols[$symbol_name] : '';
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <section id="tel-slider-3" class="tel-slider-section-3 position-relative">
            <div class="tel-main-slider-area">
                <div class="tel-main-slider-3 swiper-container position-relative">
                    <div class="swiper-wrapper">
                        <?php foreach($settings['slides'] as $item):?>
                        <div class="swiper-slide">
                            <div class="tel-main-slider-item-3 position-relative">
                                <?php if(!empty($item['shape']['url'])):?>
                                    <div class="slider_shape_3_1 position-absolute"><img src="<?php echo esc_url($item['shape']['url']);?>" alt=""></div>
                                <?php endif;?>
                                <?php if(!empty($item['image']['url'])):?>
                                    <div class="slider_shape_3_2 position-absolute"><img src="<?php echo esc_url($item['image']['url']);?>" alt=""></div>
                                <?php endif;?>

                                <?php if(!empty($item['image2']['url'])):?>
                                    <div class="slider_shape_3_3 position-absolute"><img src="<?php echo esc_url($item['image2']['url']);?>" alt=""></div>
                                <?php endif;?>

                                <div class="container">
                                    <div class="tel-main-slider-text-3">
                                        <div class="slider-slug text-uppercase position-relative">
                                            <?php echo wp_kses($item['subtitle'], true);?>
                                        </div>
                                        <h1> <?php echo wp_kses($item['title'], true);?></h1>
                                        <p><?php echo wp_kses($item['desc'], true);?></p>
                                        <div class="tel-slider-btn-group d-flex align-items-center">
                                            <?php if(!empty($item['button_text'])):?>
                                            <div class="tel-btn-3 text-uppercase">
                                                <a href="<?php echo esc_url($item['button_link']['url']);?>"
                                                target="<?php echo esc_attr($item['button_link']['is_external'] ? '_blank' : '_self');?>"
                                                rel="<?php echo esc_attr($item['button_link']['nofollow'] ? 'nofollow' : '');?>"
                                                >
                                                    <?php echo esc_html($item['button_text']);?><i class="fas fa-arrow-right"></i>
                                                </a>
                                            </div>
                                            <?php endif;?>
                                            <?php if(!empty($item['video_title']) || !empty($item['video_link'])):?>
                                            <div class="tel-slider-video-btn">
                                                <a class="video_box d-flex align-items-center" href="<?php echo esc_url($item['video_link']);?>">
                                                    <div class="inner-icon">
                                                        <i class="far fa-play-circle"></i>
                                                    </div>
                                                    <div class="inner-text">
                                                        <?php echo esc_html($item['video_title']);?>
                                                    </div>
                                                </a>
                                            </div>
                                            <?php endif;?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach;?>
                    </div>
                    <div class="swiper-main-paginations-3 position-absolute"></div>
                </div>
            </div>
            <div class="tel-main-slider-sponsor-counter d-flex align-items-center justify-content-between">
                <?php if(!empty($settings['brands'])):?>
                <div class="tel-main-slider-sponsor-area">
                    <div class="tel-main-slider-sponsor swiper-container">
                        <div class="swiper-wrapper">
                            <?php foreach($settings['brands'] as $item):?>
                            <div class="swiper-slide">
                                <div class="main-sponsor-img">
                                    <img src="<?php echo esc_url($item['b_logo']['url']);?>" alt="">
                                </div>
                            </div>
                            <?php endforeach;?>
                        </div>
                    </div>
                </div>
                <?php endif;?>
                <?php if(!empty($settings['counters'])):?>
                <div class="tel-main-slider-counter">
                    <div class="row">
                        <?php foreach($settings['counters'] as $item):?>
                        <div class="col-sm-4">
                            <div class="tel-slider-counter-item d-flex align-items-center">
                                <div class="inner-icon d-flex justify-content-center align-items-center">
                                    <?php if($item['type'] == 'image'):?>
                                    <img src="<?php echo esc_url($item['image']['url']);?>" alt="">
                                    <?php else:?>
                                        <?php \Elementor\Icons_Manager::render_icon( $item['selected_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                    <?php endif;?>
                                </div>
                                <div class="inner-text text-uppercase">
                                    <h3><span class="counter odometer" data-count="<?php echo esc_html($item['count']);?>">00</span></h3>
                                    <p><?php echo esc_html($item['title']);?></p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach;?>
                    </div>
                </div>
                <?php endif;?>
            </div>
        </section>
        <?php
    }
}