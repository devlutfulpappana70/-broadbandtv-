<?php

// Control core classes for avoid errors
if ( class_exists( 'CSF' ) ) {

    // Set a unique slug-like ID
    $telnet_user = 'telnet_user_option';

    // Create profile options
    CSF::createProfileOptions( $telnet_user, [
        'data_type' => 'serialize',
        'title'     => __( 'User Profile', 'telnetplugin' ),
    ] );

    // Create a section
    CSF::createSection( $telnet_user, [
        'fields' => [

            // telnet_enable_author_box
            [
                'id'      => 'telnet_enable_author_box',
                'type'    => 'switcher',
                'title'   => __( 'Enable Author Box', 'telnetplugin' ),
                'default' => true,
            ],

            [
                'id'         => 'telnet_user_social',
                'type'       => 'repeater',
                'title'      => __( 'Social Links', 'telnetplugin' ),
                'dependency' => ['telnet_enable_author_box', '==', 'true'],
                'fields'     => [
                    [
                        'id'    => 'telnet_user_social_icon',
                        'type'  => 'icon',
                        'title' => __( 'Social Icon', 'telnetplugin' ),
                    ],
                    [
                        'id'    => 'telnet_user_social_link',
                        'type'  => 'text',
                        'title' => __( 'Social Link', 'telnetplugin' ),
                    ],
                ],
                'title_field' => 'telnet_user_social_icon',
            ],
        ],
    ] );

}
