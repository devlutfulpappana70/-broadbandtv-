<?php

CSF::createSection( $prefix . '_theme_options', [
    'title'  => esc_html__( 'Language Settings', 'telnet-core' ),
    'parent' => 'header_settings',
    'priority' => 2,
    'fields' => [
        [
            'type'    => 'subheading',
            'content' => '<h3>' . esc_html__( 'Language Settings', 'telnet-core' ) . '</h3>',
        ],

        // enable language
        [
            'id'         => 'header_language_enable',
            'title'      => esc_html__( 'Enable Language', 'telnet-core' ),
            'type'       => 'switcher',
            'default'    => false,
        ],
    ],
] );
