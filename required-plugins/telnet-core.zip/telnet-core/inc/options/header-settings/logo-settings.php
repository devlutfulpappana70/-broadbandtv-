<?php

CSF::createSection( $prefix . '_theme_options', [
    'title'    => esc_html__( 'Logo & Favicon Settings', 'telnet-core' ),
    'parent'   => 'header_settings',
    'priority' => 1,
    'fields'   => [
        [
            'type'    => 'subheading',
            'content' => '<h3>' . esc_html__( 'Logo Settings', 'telnet-core' ) . '</h3>',
        ],
        [
            'id'            => 'telnet_logo',
            'title'         => esc_html__( 'Default Logo', 'telnet-core' ),
            'type'          => 'media',
            'desc'          => esc_html__( 'Upload Logo', 'telnet-core' ),
            'default'       => [
                'url'    => get_template_directory_uri() . '/assets/img/logo/logo.png',
                'width'  => '150px',
                'height' => '50px',
            ],
            'preview'       => true,
            'preview_width' => '150px',
        ],

        // logo width
        [
            'id'          => 'telnet_logo_width',
            'type'        => 'slider',
            'title'       => 'Logo Width',
            'min'         => 50,
            'max'         => 300,
            'step'        => 1,
            'unit'        => 'px',
            'default'     => 150,
            'output'      => '.tx-header__styleDefault .tx-logo img',
            'output_mode' => 'max-width',
        ],

        // telnet_favicon_url
        [
            'id'            => 'telnet_favicon',
            'type'          => 'media',
            'title'         => esc_html__( 'Favicon', 'telnet-core' ),
            'desc'          => esc_html__( 'Upload Favicon', 'telnet-core' ),
            'default'       => [
                'url' => get_template_directory_uri() . '/assets/img/favicon.png',
            ],
            'preview'       => true,
            'preview_width' => '150px',
        ],

    ],
] );