<?php

CSF::createSection( $prefix . '_theme_options', [
    'title'    => esc_html__( 'Side Info Settings', 'telnet-core' ),
    'parent'   => 'header_settings',
    'priority' => 1,
    'fields'   => [
        [
            'type'    => 'subheading',
            'content' => '<h3>' . esc_html__( 'Side Info Settings', 'telnet-core' ) . '</h3>',
        ],
        [
            'id'            => 'telnet_side_info_logo',
            'title'         => esc_html__( 'Default Logo', 'telnet-core' ),
            'type'          => 'media',
            'desc'          => esc_html__( 'Upload Logo', 'telnet-core' ),
            'default'       => [
                'url'    => get_template_directory_uri() . '/assets/img/logo/logo-white.png',
                'width'  => '150px',
                'height' => '50px',
            ],
            'preview'       => true,
            'preview_width' => '150px',
        ],

        // logo width
        [
            'id'          => 'telnet_side_info_logo_width',
            'type'        => 'slider',
            'title'       => 'Logo Width',
            'min'         => 50,
            'max'         => 300,
            'step'        => 1,
            'unit'        => 'px',
            'default'     => 150,
            'output'      => '.tx-sideInfoWrapper .tx-logo img',
            'output_mode' => 'max-width',
        ],

         // enable button
         [
            'id'         => 'enable_button',
            'title'      => esc_html__( 'Enable Button', 'telnet-core' ),
            'type'       => 'switcher',
            'default'    => false,
        ],

        // button url
        [
            'id'         => 'button_url',
            'title'      => esc_html__( 'Button URL', 'telnet-core' ),
            'type'       => 'link',
            'dependency' => ['enable_button', '==', 'true'],
            'default'    => [
                'url'         => '#',
                'is_external' => false,
                'nofollow'    => false,
            ],
        ],

        // side info background color
        [
            'id'      => 'side_info_bg_color',
            'type'    => 'color',
            'title'   => 'Side Info Background Color',
            'default' => '#f1f1f1',
            'output'  => [
                '.tx-sideInfoWrapper',
            ],
            'output_mode' => 'background-color'
        ],

    ],
] );