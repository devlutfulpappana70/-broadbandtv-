<?php

CSF::createSection( $prefix . '_theme_options', [
    'title'  => esc_html__( 'Header Right Settings', 'telnet-core' ),
    'parent' => 'header_settings',
    'priority' => 2,
    'fields' => [
        [
            'type'    => 'subheading',
            'content' => '<h3>' . esc_html__( 'Header Right Settings', 'telnet-core' ) . '</h3>',
        ],

        // enable header right
        [
            'id'      => 'header_right_enable',
            'title'   => esc_html__( 'Enable Header Right', 'telnet-core' ),
            'type'    => 'switcher',
            'default' => false,
        ],

        // enable mini cart
        [
            'id'         => 'header_mini_cart_enable',
            'title'      => esc_html__( 'Enable Mini Cart', 'telnet-core' ),
            'type'       => 'switcher',
            'dependency' => ['header_right_enable', '==', 'true'],
            'default'    => false,
        ],

        // enable search
        [
            'id'         => 'header_search_enable',
            'title'      => esc_html__( 'Enable Search', 'telnet-core' ),
            'type'       => 'switcher',
            'dependency' => ['header_right_enable', '==', 'true'],
            'default'    => false,
        ],

    ],
] );
