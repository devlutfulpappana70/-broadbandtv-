<?php

CSF::createSection( $prefix . '_theme_options', [
    'title'  => esc_html__( 'Contact Info Settings', 'telnet-core' ),
    'parent' => 'header_settings',
    'priority' => 3,
    'fields' => [
        [
            'type'    => 'subheading',
            'content' => '<h3>' . esc_html__( 'Contact Info Settings', 'telnet-core' ) . '</h3>',
        ],

        // enable contact info
        [
            'id'         => 'header_contact_info_enable',
            'title'      => esc_html__( 'Enable Contact Info', 'telnet-core' ),
            'type'       => 'switcher',
            'default'    => false,
        ],

        // contact info icon
        [
            'id'         => 'header_contact_info_icon',
            'title'      => esc_html__( 'Contact Info Icon', 'telnet-core' ),
            'type'       => 'icon',
            'dependency' => ['header_contact_info_enable', '==', 'true'],
            'default'    => 'fa-solid fa-phone-volume',
        ],

        // contact info label
        [
            'id'         => 'header_contact_info_label',
            'title'      => esc_html__( 'Contact Info Label', 'telnet-core' ),
            'type'       => 'text',
            'dependency' => ['header_contact_info_enable', '==', 'true'],
            'default'    => 'Give us a call',
        ],

        // contact info number
        [
            'id'         => 'header_contact_info_number',
            'title'      => esc_html__( 'Contact Info Number', 'telnet-core' ),
            'type'       => 'text',
            'dependency' => ['header_contact_info_enable', '==', 'true'],
            'default'    => '+123 (4567) 890',
        ],

    ],
] );
