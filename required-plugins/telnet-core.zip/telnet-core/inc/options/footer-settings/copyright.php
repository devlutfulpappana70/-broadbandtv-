<?php

CSF::createSection( $prefix . '_theme_options', [
    'title'  => esc_html__( 'Copyright Text', 'telnet-core' ),
    'parent' => 'footer_settings',
    'fields' => [
        [
            'type'    => 'subheading',
            'content' => '<h3>' . esc_html__( 'Copyright Text', 'telnet-core' ) . '</h3>',
        ],
        // copyright text
        [
            'id'      => 'telnet_copyright',
            'title'   => esc_html__( 'Copyright Text', 'telnet-core' ),
            'type'    => 'textarea',
            'desc'    => esc_html__( 'Copyright Text', 'telnet-core' ),
            'default' => '© 2023 <a href="https://telnet.com.bd/" target="_blank">TelNet</a>— internet service provider WordPress Theme.',
        ],
    ],
] );
