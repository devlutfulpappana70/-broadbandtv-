<?php

CSF::createSection( $prefix . '_theme_options', [
    'title'  => esc_html__( 'Blog Details Settings', 'telnet-core' ),
    'parent' => 'blog_settings',
    'fields' => [
        [
            'type'    => 'subheading',
            'content' => '<h3>' . esc_html__( 'Blog Details Settings', 'telnet-core' ) . '</h3>',
        ],
        // enable social share
        [
            'id'      => 'telnet_enable_social_share',
            'type'    => 'switcher',
            'title'   => esc_html__( 'Enable Social Share', 'telnet-core' ),
            'default' => false,
        ],

        // enable blog navigation
        [
            'id'      => 'telnet_enable_blog_navigation',
            'type'    => 'switcher',
            'title'   => esc_html__( 'Enable Blog Navigation', 'telnet-core' ),
            'default' => false,
        ],
    ],
] );
