<?php

CSF::createSection( $prefix . '_theme_options', [
    'title'  => esc_html__( 'Color Settings', 'telnet-core' ),
    'parent' => 'theme_settings',
    'priority' => 2,
    'fields' => [
        [
            'type'    => 'subheading',
            'content' => '<h3>' . esc_html__( 'Color Settings', 'telnet-core' ) . '</h3>',
        ],
        [
            'id'      => 'theme_primary_color',
            'type'    => 'color',
            'title'   => 'Theme Primary Color',
            'default' => '#e10419',
        ],
        // theme_color 2
        [
            'id'      => 'theme_color_2',
            'type'    => 'color',
            'title'   => 'Theme Color 2',
            'default' => '#FF3838',
        ],

        // theme_color 3
        [
            'id'      => 'theme_color_3',
            'type'    => 'color',
            'title'   => 'Theme Color 3',
            'default' => '#f1b1af',
        ],

        // theme_color 4
        [
            'id'      => 'theme_color_4',
            'type'    => 'color',
            'title'   => 'Theme Color 4',
            'default' => '#ffa200',
        ],

        // theme_color 5
        [
            'id'      => 'theme_color_5',
            'type'    => 'color',
            'title'   => 'Theme Color 5',
            'default' => '#E10419',
        ],

        // theme_color 6
        [
            'id'      => 'theme_color_6',
            'type'    => 'color',
            'title'   => 'Theme Color 6',
            'default' => '#E504EE',
        ],

        // theme_color 7
        [
            'id'      => 'theme_color_7',
            'type'    => 'color',
            'title'   => 'Theme Color 7',
            'default' => '#173FCF',
        ],

         // theme gd 1
         [
            'id'      => 'theme_gd_color_1',
            'type'    => 'color_group',
            'title'   => 'Gradient Color One',
            'options' => [
                'color_1' => 'Color 1',
                'color_2' => 'Color 2',
            ],
            'default' => [
                'color_1' => '#E10419',
                'color_2' => '#8F0815',
            ],
        ],

        // theme gd 2
        [
            'id'      => 'theme_gd_color_2',
            'type'    => 'color_group',
            'title'   => 'Gradient Color Two',
            'options' => [
                'color_1' => 'Color 1',
                'color_2' => 'Color 2',
            ],
            'default' => [
                'color_1' => '#FFA200',
                'color_2' => '#E10419',
            ],
        ],

        // theme gd 3
        [
            'id'      => 'theme_gd_color_3',
            'type'    => 'color_group',
            'title'   => 'Gradient Color Three',
            'options' => [
                'color_1' => 'Color 1',
                'color_2' => 'Color 2',
            ],
            'default' => [
                'color_1' => '#173FCF',
                'color_2' => '#E504EE',
            ],
        ],

        // theme gd 4
        [
            'id'      => 'theme_gd_color_4',
            'type'    => 'color_group',
            'title'   => 'Gradient Color Four',
            'options' => [
                'color_1' => 'Color 1',
                'color_2' => 'Color 2',
                'color_3' => 'Color 3',
            ],
            'default' => [
                'color_1' => '#FFA200',
                'color_2' => '#E10419',
                'color_3' => '#FFA200',
            ],
        ],
    ],
] );