<?php

CSF::createSection( $prefix . '_theme_options', [
    'title'  => 'Preloader ON/OFF',
    'parent' => 'theme_settings',
    'priority' => 1,
    'fields' => [
        [
            'id'      => 'preloader_enable',
            'title'   => esc_html__( 'Enable Preloader', 'telnet-core' ),
            'type'    => 'switcher',
            'desc'    => esc_html__( 'Enable or Disable Preloader', 'telnet-core' ),
            'default' => true,
        ],

        // preloader background color
        [
            'id'       => 'preloader_bg_color',
            'type'     => 'color',
            'title'    => esc_html__( 'Preloader Background Color', 'telnet-core' ),
            'default'  => '#010317',
            'dependency' => ['preloader_enable', '==', 'true'],
            'output'   => '#tx-preloader',
            'output_mode' => 'background-color'
        ],

        // preloader image
        [
            'id'       => 'preloader_image',
            'type'     => 'media',
            'title'    => esc_html__( 'Preloader Image', 'telnet-core' ),
            'desc'     => esc_html__( 'Upload Preloader Image', 'telnet-core' ),
            'default'  => [
                'url' => get_template_directory_uri() . '/assets/img/preloader.svg',
            ],
            'dependency' => ['preloader_enable', '==', 'true'],
        ],

        // size
        [
            'id'          => 'preloader_image_width',
            'type'        => 'slider',
            'title'       => 'Width',
            'min'         => 50,
            'max'         => 300,
            'step'        => 1,
            'unit'        => 'px',
            'default'     => 150,
            'output'      => '#tx-preloader img',
            'output_mode' => 'max-width',
        ],
    ],
] );