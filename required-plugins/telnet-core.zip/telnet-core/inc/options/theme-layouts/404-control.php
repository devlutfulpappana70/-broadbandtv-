<?php

CSF::createSection( $prefix . '_theme_options', [
    'title'  => esc_html__( '404 Page Layout', 'telnet-core' ),
    'parent' => 'theme_layout',
    'priority' => 4,
    'fields' => [
        [
            'type'    => 'subheading',
            'content' => '<h3>' . esc_html__( '404 Page Layout', 'telnet-core' ) . '</h3>',
        ],
        [
            'id'    => 'telnet_error_image',
            'type'  => 'media',
            'title' => esc_html__( 'Error Code Image', 'telnet-core' ),
        ],
        [
            'id'      => 'telnet_error_title',
            'type'    => 'text',
            'title'   => esc_html__( '404 Title', 'telnet-core' ),
            'default' => esc_html__( 'Oops! Page Not found.', 'telnet-core' ),
        ],

        [
            'id'      => 'telnet_error_link_text',
            'type'    => 'text',
            'title'   => esc_html__( '404 Button', 'telnet-core' ),
            'default' => esc_html__( 'back to Home page ', 'telnet-core' ),
        ],
    ],
] );