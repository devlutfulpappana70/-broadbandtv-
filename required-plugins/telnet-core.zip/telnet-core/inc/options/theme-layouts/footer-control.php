<?php

CSF::createSection( $prefix . '_theme_options', [
    'title'  => esc_html__( 'Footer Layout', 'telnet-core' ),
    'parent' => 'theme_layout',
    'priority' => 2,
    'fields' => [
        [
            'type'    => 'subheading',
            'content' => '<h3>' . esc_html__( 'Footer Layout', 'telnet-core' ) . '</h3>',
        ],
        // Footer Style
        [
            'id'      => 'footer_style',
            'type'    => 'select',
            'title'   => __( 'Select Footer Style', 'telnet-core' ),
            'options' => Telnet_Core_Helper::get_footer_types(),
        ],
    ],
] );