<?php

CSF::createSection( $prefix . '_theme_options', [
    'title'  => esc_html__( 'Header Layout', 'telnet-core' ),
    'parent' => 'theme_layout',
    'priority' => 1,
    'fields' => [
        [
            'type'    => 'subheading',
            'content' => '<h3>' . esc_html__( 'Header Layout', 'telnet-core' ) . '</h3>',
        ],
        [
            'id'      => 'header_style',
            'type'    => 'select',
            'title'   => __( 'Select Header Style', 'telnet-core' ),
            'options' => Telnet_Core_Helper::get_header_types(),
        ],
    ],
] );