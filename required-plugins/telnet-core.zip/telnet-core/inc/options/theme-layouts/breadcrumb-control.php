<?php

CSF::createSection( $prefix . '_theme_options', [
    'title'  => esc_html__( 'Breadcrumb Layout', 'telnet-core' ),
    'parent' => 'theme_layout',
    'priority' => 3,
    'fields' => [
        [
            'type'    => 'subheading',
            'content' => '<h3>' . esc_html__( 'Breadcrumb Layout', 'telnet-core' ) . '</h3>',
        ],
        [
            'id'      => 'breadcrumb_bg_img',
            'title'   => esc_html__( 'Breadcrumb Image', 'telnet-core' ),
            'type'    => 'media',
            'desc'    => esc_html__( 'Upload Image', 'telnet-core' ),
            'preview' => true,
            'preview_width'  => '500px',
        ],
        // breadcrumb padding
        [
            'id'      => 'breadcrumb_padding',
            'type'    => 'spacing',
            'title'   => esc_html__( 'Breadcrumb Padding', 'telnet-core' ),
            'output'  => [
                '.tx-breadcrumb-section .tx-wrapper',
            ],
            'units'   => [ 'px', 'em' ],
            'mode'    => 'padding',
            'top'     => true,
            'right'   => true,
            'bottom'  => true,
            'left'    => true,
        ],
    ],
] );