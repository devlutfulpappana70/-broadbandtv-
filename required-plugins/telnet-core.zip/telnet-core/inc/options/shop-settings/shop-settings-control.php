<?php

CSF::createSection( $prefix . '_theme_options', [
    'title'    => esc_html__( 'Shop Settings ON/OFF', 'telnet-core' ),
    'parent'   => 'shop_settings',
    'priority' => 4,
    'fields'   => [
        [
            'id'      => 'shop_filter',
            'type'    => 'switcher',
            'title'   => esc_html__( 'Shop Filter', 'telnet-core' ),
            'default' => false,
            'desc'    => esc_html__( 'Enable/Disable Shop Filter', 'telnet-core' ),
        ],
        [
            'id'      => 'show_discount_percentage',
            'type'    => 'switcher',
            'title'   => esc_html__( 'Enable discount percentage', 'telnet-core' ),
            'default' => true,
            'desc'    => esc_html__( 'Enable/Disable discount percentage', 'telnet-core' ),
        ],
        [
            'id'      => 'enable_custom_add_to_cart_text',
            'type'    => 'switcher',
            'title'   => esc_html__( 'Enable custom add to cart text', 'telnet-core' ),
            'default' => false,
            'desc'    => esc_html__( 'Enable/Disable custom add to cart text', 'telnet-core' ),
        ],
        [
            'id'      => 'custom_add_to_cart_text',
            'type'    => 'text',
            'title'   => esc_html__( 'Custom add to cart text', 'telnet-core' ),
            'default' => esc_html__( 'Purchase Now', 'telnet-core' ),
            'desc'    => esc_html__( 'Custom add to cart text', 'telnet-core' ),
            'dependency' => [
                'enable_custom_add_to_cart_text',
                '==',
                'true'
            ]
        ],
    ],
] );