<?php
namespace ElementHelper;

class Helper {

    /**
     * Get widgets list
     */
    public static function get_widgets() {

        return [
            'telnet_headers' => [
                'title' => __( 'TelNet Headers', 'telnet-core' ),
            ],
            'hero_slider_four' => [
                'title' => __( 'Hero Slider Four', 'telnet-core' ),
            ],
            'telnet_logo' => [
                'title' => __( 'TelNet Logo', 'telnet-core' ),
            ],
            'pricing_plan' => [
                'title' => __( 'Pricing Plan', 'telnet-core' ),
            ],
            'telnet_nav_menu' => [
                'title' => __( 'TelNet Nav Menu', 'telnet-core' ),
            ],
            'section_heading' => [
                'title' => __( 'Section Heading', 'telnet-core' ),
            ],
            'hero_slider' => [
                'title' => __( 'Hero Slider', 'telnet-core' ),
            ],
            'hero_slider_two' => [
                'title' => __( 'Hero Slider Three', 'telnet-core' ),
            ],
            'hero_slider_three' => [
                'title' => __( 'Hero Slider Two', 'telnet-core' ),
            ],
            'service_grid' => [
                'title' => __( 'Service Grid', 'telnet-core' ),
            ],
            'service_slider' => [
                'title' => __( 'Service Slider', 'telnet-core' ),
            ],
            'list_link' => [
                'title' => __( 'List Link', 'telnet-core' ),
            ],
            'info_text' => [
                'title' => __( 'Info Text', 'telnet-core' ),
            ],
            'image_box' => [
                'title' => __( 'Image Box', 'telnet-core' ),
            ],
            'promo_slider' => [
                'title' => __( 'Promo Slider', 'telnet-core' ),
            ],
            'video_button' => [
                'title' => __( 'Video Button', 'telnet-core' ),
            ],
            'contact_form' => [
                'title' => __( 'Contact Form', 'telnet-core' ),
            ],
            'post_grid' => [
                'title' => __( 'Post Grid', 'telnet-core' ),
            ],
            'telnet_button' => [
                'title' => __( 'TelNet Button', 'telnet-core' ),
            ],
            'telnet_portfolio' => [
                'title' => __( 'TelNet Portfolio', 'telnet-core' ),
            ],
            'telnet_lists' => [
                'title' => __( 'TelNet Lists', 'telnet-core' ),
            ],
            'pricing_tab' => [
                'title' => __( 'Pricing Tab', 'telnet-core' ),
            ],
            'pricing_bar' => [
                'title' => __( 'Pricing Bar', 'telnet-core' ),
            ],
            'telnet_pricing' => [
                'title' => __( 'Telnet Pricing', 'telnet-core' ),
            ],
            'telnet_brand' => [
                'title' => __( 'Telnet Brand', 'telnet-core' ),
            ],
            'telnet_tab' => [
                'title' => __( 'Telnet Tab', 'telnet-core' ),
            ],
            'telnet_counter' => [
                'title' => __( 'Telnet Counter', 'telnet-core' ),
            ],
            'telnet_cta' => [
                'title' => __( 'TelNet Cta', 'telnet-core' ),
            ],
            'telnet_team' => [
                'title' => __( 'TelNet Team', 'telnet-core' ),
            ],
            'telnet_testimonial' => [
                'title' => __( 'TelNet Testimonial', 'telnet-core' ),
            ],
            'telnet_infobox' => [
                'title' => __( 'TelNet InfoBox', 'telnet-core' ),
            ],
            'telnet_gallery' => [
                'title' => __( 'TelNet Gallery', 'telnet-core' ),
            ],
            'telnet_progress' => [
                'title' => __( 'TelNet Progress', 'telnet-core' ),
            ],
            'telnet_faq' => [
                'title' => __( 'TelNet Faq', 'telnet-core' ),
            ],
            'upcomming_show_slider' => [
                'title' => __( 'Upcomming Show Slider', 'telnet-core' ),
            ],
            'movie_filter' => [
                'title' => __( 'Movie Filter', 'telnet-core' ),
            ],
            'info_lists' => [
                'title' => __( 'Info Lists ', 'telnet-core' ),
            ],
            'video_popup' => [
                'title' => __( 'Video Popup ', 'telnet-core' ),
            ],
            'parralax_image' => [
                'title' => __( 'Parralax Image', 'telnet-core' ),
            ],
            'telnet_streaming' => [
                'title' => __( 'TelNet Streaming', 'telnet-core' ),
            ],
            'about_content' => [
                'title' => __( 'About_Content', 'telnet-core' ),
            ],
            'hero_slider_five' => [
                'title' => __( 'Hero Slider Five', 'telnet-core' ),
            ],
            'counter_two' => [
                'title' => __( 'Counter Two', 'telnet-core' ),
            ],
            'pricing_table_two' => [
                'title' => __( 'Pricing Table Two', 'telnet-core' ),
            ],
            'testimonial_two' => [
                'title' => __( 'Testimonial Two', 'telnet-core' ),
            ],
            'cta_content' => [
                'title' => __( 'Cta Content', 'telnet-core' ),
            ],
            'telnet_icon_box' => [
                'title' => __( 'Telnet Icon Box', 'telnet-core' ),
            ],
            'hero_section' => [
                'title' => __( 'Hero Section', 'telnet-core' ),
            ],
            'moving_text' => [
                'title' => __( 'Moving Text', 'telnet-core' ),
            ],
            'service_slider_two' => [
                'title' => __( 'Service Slider Two', 'telnet-core' ),
            ],
            'movie_poster' => [
                'title' => __( 'Movie Poster', 'telnet-core' ),
            ],
            'telnet_tab_two' => [
                'title' => __( 'Telnet Tab Two', 'telnet-core' ),
            ],
            'telnet_about' => [
                'title' => __( 'Telnet About', 'telnet-core' ),
            ],
            'testimonial_three' => [
                'title' => __( 'Testimonial Three', 'telnet-core' ),
            ],
            'telnet_newsletter' => [
                'title' => __( 'Telnet Newsletter', 'telnet-core' ),
            ],
            'service_slider_three' => [
                'title' => __( 'Service Slider Three', 'telnet-core' ),
            ],
            'telnet_tab_three' => [
                'title' => __( 'Telnet Tab Three', 'telnet-core' ),
            ],
            'testimonial_four' => [
                'title' => __( 'Testimonial Four', 'telnet-core' ),
            ],
            'movie_poster_two' => [
                'title' => __( 'Movie Poster Two', 'telnet-core' ),
            ],
            'contact_info' => [
                'title' => __( 'Contact Info', 'telnet-core' ),
            ],
            'service_slider_four' => [
                'title' => __( 'Service Slider Four', 'telnet-core' ),
            ],
            'telnet_social_icons' => [
                'title' => __( 'Telnet Social Icons', 'telnet-core' ),
            ],
            'hero_slider_six' => [
                'title' => __( 'Hero Slider Six', 'telnet-core' ),
            ],
            'service_slider_five' => [
                'title' => __( 'Service Slider Five', 'telnet-core' ),
            ],
            'moving_text_two' => [
                'title' => __( 'Moving Text Two', 'telnet-core' ),
            ],
            'testimonial_five' => [
                'title' => __( 'Testimonial Five', 'telnet-core' ),
            ],
            'movie_poster_tab' => [
                'title' => __( 'Movie Poster Tab', 'telnet-core' ),
            ],
        ];
    }

    /**
     *  Get WooCommerce widgets list
     **/
    public static function get_woo_widgets() {
        return [
            'woo_product_slider' => [
                'title' => __( 'Product Slider', 'telnet-core' ),
            ],
        ];

    }

}
