{
    "icons" : [
        "fal fa-long-arrow-right",
        "fal fa-long-arrow-left",
        "fal fa-long-arrow-up",
        "fal fa-long-arrow-down",
        "fal fa-arrow-right",
        "fal fa-arrow-left",
        "fal fa-arrow-up",
        "fal fa-arrow-down",
        "fal fa-bullhorn",
        "fal fa-ribbon",
        "fal fa-times",
        "fal fa-calendar-alt",
        "fal fa-check"
    ]
}
