(function ($) {
    "use strict";
    

})(jQuery);